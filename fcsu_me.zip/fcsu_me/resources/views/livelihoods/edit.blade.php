<!DOCTYPE html>
<html>
<head lang="en">
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" />
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.0/jquery.validate.min.js"></script>
    <script
        src="https://code.jquery.com/jquery-3.4.1.js"
        integrity="sha256-WpOohJOqMqqyKL9FccASB9O0KwACQJpFTUBLTYOVvVU="
        crossorigin="anonymous"></script>

    <title>Livelihood (DLI 1.3)</title>
</head>
<body>
<div class="container p-5 my-5 border">
    <div class="col-md-6 text-right">
        <a href="{{ url()->previous() }}" class="btn btn-lg" style="background-color: #12d3e0;">Back to Result Area</a>
    </div>
    <br />
    <div class="card-header" style="background-color: #506dee;">
        <h2 style="margin-top: 10px; margin-left: 10px; color: white; text-align: center;">
            M&E-- LIVELIHOOD (DLI 1.3)
        </h2>
    </div>
    <h4 style="text-align: center;">Fill in the information carefully in the appropriate spaces</h4>
    <form method="post" action="{{ route('livelihoods.update', $data->id) }}" >
        @csrf
        @method('patch')
        <div class="container border border-primary p-4">
            <div class="row">
                <div class="card-header col-md-4 col-xs-12" style="background-color: #506dee;">
                    <label for="states" style="color: white;"
                    >Select Your State<span style="color: rgb(253, 237, 10);"
                        >(*)</span
                        ></label>
                    <select class="form-control" disabled
                            name="state_id" required>
                        <option value="">Select State</option>
                        @foreach($states as $state)
                            <option @if($data->state_id==$state->id) selected @endif
                            value="{{ $state->id }}">{{ $state->state }}</option>
                        @endforeach
                    </select>
                    @if ($errors->has('state_id'))
                        <span class="text-danger text-left">{{ $errors->first('state_id') }}</span>
                    @endif
                </div>
                <div class="card-header col-md-4 col-xs-12" style="background-color: #2198b1;">


                    <label for="DPs" style="color: white;"
                    >Select Your DP<span style="color: rgb(253, 237, 10);"
                        >(*)</span
                        ></label>
                    <select class="form-control" disabled
                            name="dp_id" required>
                        <option value="">Select DP</option>
                        @foreach($dps as $dp)
                            <option @if($data->dp_id==$dp->id) selected @endif
                            value="{{ $dp->id }}">{{ $dp->name }}</option>
                        @endforeach
                    </select>
                    @if ($errors->has('dp_id'))
                        <span class="text-danger text-left">{{ $errors->first('dp_id') }}</span>
                    @endif
                </div>
                <div class="card-header col-md-4 col-xs-12" style="background-color: #2198b1;">
                    <label for="monthyear" style="color: white;"
                    >Select Month<span style="color: rgb(253, 237, 10);"
                        >(*)</span
                        ></label>
                    <select class="form-control" disabled
                            name="monthyear" required>
                        <option value="">Select Month</option>
                        @foreach($months as $month)
                            <option @if($data->monthyear==$month->id) selected @endif
                            value="{{ $month->id }}">{{ $month->date }}</option>
                        @endforeach
                    </select>
                    @if ($errors->has('monthyear'))
                        <span class="text-danger text-left">{{ $errors->first('monthyear') }}</span>
                    @endif
                </div>

            </div>

            <br />

            <!------------------------------------------>
            <div class="row">
                  <span class="card-footer" style="color: white; background-color: #506dee;">
                      Total Number of Beneficiaries mined from Agreed Register</span>
                <div class="col-md-4">
                    <label>Female</label>
                    <input type="text" class="form-control" value="{{ $data->f_mined }}" name="f_mined" id="a" onkeyup="sum()" />
                </div>
                <div class="col-md-4">
                    <label>Male</label>
                    <input type="text" class="form-control" value="{{ $data->m_mined }}" name="m_mined" id="b" onkeyup="sum()" />
                </div>
                <div class="col-md-4">
                    <label>Total</label>
                    <input type="text" class="form-control to" value="{{ $data->tot_mined }}" name="tot_mined" id="c=a+b" readonly />
                </div>
            </div>
            <br />

            <div class="row">
                  <span class="card-footer" style="color: white; background-color: #506dee;">
                     Total Number of mined Beneficiaries validated</span>
                <div class="col-md-4">
                    <label>Female</label>
                    <input type="text" class="form-control" value="{{ $data->f_validated }}" name="f_validated" id="d" onkeyup="sum()" />
                </div>
                <div class="col-md-4">
                    <label>Male</label>
                    <input type="text" class="form-control" value="{{ $data->f_validated }}" name="m_validated" id="e" onkeyup="sum()" />
                </div>
                <div class="col-md-4">
                    <label>Total</label>
                    <input type="text" class="form-control to" value="{{ $data->tot_validated }}" name="tot_validated" id="f=d+e" readonly />
                </div>
            </div>
            <br />

            <div class="row">
                  <span class="card-footer" style="color: white; background-color: #506dee;">
                      Attrition (Mined minus Validated)</span>
                <div class="col-md-3">
                    <label>Female</label>
                    <input type="text" class="form-control to" value="{{ $data->att_fminedval }}" name="att_fminedval" id="g=a-d" readonly />
                </div>
                <div class="col-md-3">
                    <label>Male</label>
                    <input type="text" class="form-control to" value="{{ $data->att_mminedval }}" name="att_mminedval" id="h=b-e" readonly />
                </div>
                <div class="col-md-3">
                    <label>Total</label>
                    <input type="text" class="form-control to" value="{{ $data->att_totminedval }}" name="att_totminedval" id="i=c-f" readonly />
                </div>
                <div class="col-md-3">
                    <label>% Attrition</label>
                    <input type="text" class="form-control toa" value="{{ $data->att_minedvalpercent }}" name="att_minedvalpercent" id="j=i%" readonly />
                </div>
            </div>
            <br />
            <div class="row">
                <div class="col-md-12">
                    <input style="display:block" class="form-control" type="" value="{{ $data->comment1 }}"
                           name="comment1" id="comment4" placeholder="attrition remarks">
                </div>
            </div>
            <br />

            <div class="row">
                  <span class="card-footer" style="color: white; background-color: #506dee;">
                     Total Number of Individual trained on livelihood</span>
                <div class="col-md-4">
                    <label>Female</label>
                    <input type="text" class="form-control" value="{{ $data->f_train }}" name="f_train" id="k" onkeyup="sum()" />
                </div>
                <div class="col-md-4">
                    <label>Male</label>
                    <input type="text" class="form-control" value="{{ $data->m_train }}" name="m_train" id="l" onkeyup="sum()" />
                </div>
                <div class="col-md-4">
                    <label>Total</label>
                    <input type="text" class="form-control to" value="{{ $data->tot_train }}" name="tot_train" id="m=k+l" readonly />
                </div>
            </div>
            <br />

            <div class="row">
                  <span class="card-footer" style="color: white; background-color: #506dee;">
                     Total Number of Individuals that graduated from livelihood training</span>
                <div class="col-md-4">
                    <label>Female</label>
                    <input type="text" class="form-control" value="{{ $data->f_grad }}" name="f_grad" id="n" onkeyup="sum()" />
                </div>
                <div class="col-md-4">
                    <label>Male</label>
                    <input type="text" class="form-control" value="{{ $data->m_grad }}" name="m_grad" id="o" onkeyup="sum()" />
                </div>
                <div class="col-md-4">
                    <label>Total</label>
                    <input type="text" class="form-control to" value="{{ $data->tot_grad }}" name="tot_grad" id="p=n+o" readonly />
                </div>
            </div>
            <br />

            <div class="row">
                  <span class="card-footer" style="color: white; background-color: #506dee;">
                     Attrition (Trained minus Graduated)</span>
                <div class="col-md-3">
                    <label>Female</label>
                    <input type="text" class="form-control to" value="{{ $data->att_ftraingrad }}" name="att_ftraingrad" id="q = k-n" readonly />
                </div>
                <div class="col-md-3">
                    <label>Male</label>
                    <input type="text" class="form-control to" value="{{ $data->att_mtraingrad }}"  name="att_mtraingrad" id="r=L-o" readonly />
                </div>
                <div class="col-md-3">
                    <label>Total</label>
                    <input type="text" class="form-control to" value="{{ $data->att_tottraingrad }}" name="att_tottraingrad" id="s=m-p" readonly />
                </div>
                <div class="col-md-3">
                    <label>% Attrition</label>
                    <input type="text" class="form-control toa" value="{{ $data->att_traingradpercent }}" name="att_traingradpercent" id="t=s%" readonly />
                </div>
            </div>
            <br />
            <div class="row">
                <div class="col-md-12">
                    <input style="display:block" class="form-control" type=""
                           value="{{ $data->comment2}}"    name="comment2" id="comment4" placeholder="Attrition Remarks">
                </div>
            </div>
            <br />

            <div class="row">
                  <span class="card-header col-md-8" style="color: white; background-color: #506dee;">
                     Total Amount transferred to PSP (NGN)
                  </span>
                <div class="col-md-4">
                    <input type="text" class="form-control" value="{{ $data->amt_transpsp }}" name="amt_transpsp" id="u" onkeyup="sum()" />
                </div>
            </div>
            <br />

            <div class="row">
                  <span class="card-footer" style="color: white; background-color: #506dee;">
                     Total Number of Beneficiaries transferred to PSP for payment</span>
                <div class="col-md-4">
                    <label>Female</label>
                    <input type="text" class="form-control" value="{{ $data->tot_fbeneforpsppay }}" name="tot_fbeneforpsppay" id="v" onkeyup="sum()" />
                </div>
                <div class="col-md-4">
                    <label>Male</label>
                    <input type="text" class="form-control" value="{{ $data->tot_mbeneforpsppay }}" name="tot_mbeneforpsppay" id="w" onkeyup="sum()" />
                </div>
                <div class="col-md-4">
                    <label>Total</label>
                    <input type="text" class="form-control to" value="{{ $data->tot_beneforpsppay }}" name="tot_beneforpsppay" id="x=v+w" readonly />
                </div>
            </div>
            <br />

            <div class="row">
                  <span class="card-footer" style="color: white; background-color: #506dee;">
                      Total Number of beneficiaries supported with Livelihood Grants</span>
                <div class="col-md-4">
                    <label>Female</label>
                    <input type="text" class="form-control" value="{{ $data->tot_fbenerecv }}" name="tot_fbenerecv" id="yf" onkeyup="sum()" />
                </div>
                <div class="col-md-4">
                    <label>Male</label>
                    <input type="text" class="form-control" value="{{ $data->tot_mbenerecv }}" name="tot_mbenerecv" id="z" onkeyup="sum()" />
                </div>
                <div class="col-md-4">
                    <label>Total</label>
                    <input type="text" class="form-control to" value="{{ $data->tot_benerecv }}" name="tot_benerecv" id="a1=y+z" readonly />
                </div>
            </div>
            <br />
            <div class="row">
                  <span class="card-header col-md-8" style="color: white; background-color: #506dee;">
                     Total Amount paid to Beneficiaries (NGN)
                  </span>
                <div class="col-md-4">
                    <input type="text" class="form-control" value="{{ $data->tot_paidbene }}" name="tot_paidbene" id="ba" onkeyup="sum()" />
                </div>
            </div>
            <br />

            <div class="row">
                  <span class="card-header col-md-4" style="color: white; background-color: #506dee;">
                     Attrition
                  </span>
                <div class="col-md-2">
                    <input type="text" class="form-control to" value="{{ $data->attr }}" name="attr" id="attr" readonly />
                </div>
                <span class="card-header col-md-4" style="color: white; background-color: #506dee;">
                     Percent Attrition (%)
                  </span>
                <div class="col-md-2">
                    <input type="text" class="form-control toa" value="{{ $data->attr_pcent }}" name="attr_pcent" id="attrp" readonly />
                </div>
            </div>
            <br />

            <div class="row">
                <div class="col-md-12">
                    <input
                        style="display: block;"
                        class="form-control"
                        type=""
                        value="{{$data->comment3}}"
                        name="comment3"
                        id="comment4"
                        placeholder="Attrition Remarks"
                    />
                </div>
            </div>
            <br />
        </div>
        <input type="hidden" name="timestamp" id="timestamp" />
        <br />
        <div class="col-md-6 col-xs-12">
            <input type="submit" class="btn btn-primary btn-sm" />
        </div>
    </form>
    <br />

</div>

<script type="text/javascript">


    (function ($, undefined) {
        "use strict";

        // When ready.
        $(function () {
            var $form = $("#formid");
            var $input = $form.find('input[type="text"]');

            $input.on("keyup", function (event) {
                // When user select text in the document, also abort.
                var selection = window.getSelection().toString();
                if (selection !== "") {
                    return;
                }

                // When the arrow keys are pressed, abort.
                if ($.inArray(event.keyCode, [38, 40, 37, 39]) !== -1) {
                    return;
                }

                var $this = $(this);

                // Get the value.
                var input = $this.val();

                var input = input.replace(/[\D\s\._\-]+/g, "");
                input = input ? parseFloat(input, 10) : 0;

                $this.val(function () {
                    return input === 0 ? "0" : input.toLocaleString("en-US");
                });
            });
        });
    })(jQuery);

    function sum() {
        let a = parseFloat(document.getElementById("a").value.replace(/[^\d\.\-]/g, ""));
        let b = parseFloat(document.getElementById("b").value.replace(/[^\d\.\-]/g, ""));
        let d = parseFloat(document.getElementById("d").value.replace(/[^\d\.\-]/g, ""));
        let e = parseFloat(document.getElementById("e").value.replace(/[^\d\.\-]/g, ""));
        let k = parseFloat(document.getElementById("k").value.replace(/[^\d\.\-]/g, ""));
        let l = parseFloat(document.getElementById("l").value.replace(/[^\d\.\-]/g, ""));
        let n = parseFloat(document.getElementById("n").value.replace(/[^\d\.\-]/g, ""));
        let o = parseFloat(document.getElementById("o").value.replace(/[^\d\.\-]/g, ""));
        let u = parseFloat(document.getElementById("u").value.replace(/[^\d\.\-]/g, ""));
        let v = parseFloat(document.getElementById("v").value.replace(/[^\d\.\-]/g, ""));
        let w = parseFloat(document.getElementById("w").value.replace(/[^\d\.\-]/g, ""));
        let ba = parseFloat(document.getElementById("ba").value.replace(/[^\d\.\-]/g, ""));

        let yf = parseFloat(document.getElementById("yf").value.replace(/[^\d\.\-]/g, ""));
        let z = parseFloat(document.getElementById("z").value.replace(/[^\d\.\-]/g, ""));
        // let a1 = parseFloat(document.getElementById("a1=y+z").value.replace(/[^\d\.\-]/g, ""));

        document.getElementById("c=a+b").value = a + b;
        document.getElementById("f=d+e").value = d + e;
        document.getElementById("g=a-d").value = a - d;
        document.getElementById("h=b-e").value = b - e;
        document.getElementById("i=c-f").value = a + b - (d + e);
        document.getElementById("j=i%").value = (100 - ((((d + e) / (a + b))) * 100)).toFixed(2);
        document.getElementById("m=k+l").value = k + l;
        document.getElementById("p=n+o").value = n + o;
        document.getElementById("q = k-n").value = k - n;
        document.getElementById("r=L-o").value = l - o;
        document.getElementById("s=m-p").value = k + l - (n + o);
        document.getElementById("t=s%").value = (100 - (((n + o) / (k + l)) * 100)).toFixed(2);
        document.getElementById("x=v+w").value = w + v;
        document.getElementById("a1=y+z").value = z + yf;
        document.getElementById("attr").value = u - ba;
        document.getElementById("attrp").value = (((u-ba)/u)*100).toFixed(2);

        let state = document.getElementById("states").value;
        let none = "none";
        if (state === "none") {
            document.getElementById("states").style.backgroundColor = "red";
            alert("Error: Select your State");
        } else document.getElementById("states").style.backgroundColor = "white";
    }

    $(function() {
        var $form = $("#formid");
        var $input = $form.find('input[type="text"]');
        $input.on("keyup", function(e) {
            $(".toa").each(function(i) {
                if ($(this).val() == "NaN") {
                    ($(this).val(0))
                }
            });

            // 							check NaN
            $(".to").each(function(i) {
                if ($(this).val() == "NaN") {
                    ($(this).val(0))
                } else{
                    var $this = $(this);
                    var input = $this.val();
                    var input = input.replace(/[\D\s\._\-]+/g, "");
                    input = input ? parseFloat(input, 10) : 0;
                    $this.val(function() {
                        return input === 0 ? "0" : input.toLocaleString("en-US");
                    });
                }
            });

        });
    });

    document.getElementById("timestamp").value = new Date().toLocaleString();
</script>
</body>
</html>
