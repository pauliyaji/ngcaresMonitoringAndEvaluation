<!DOCTYPE html>
<html>
<head lang="en">
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" />
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.0/jquery.validate.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.4.1.js" integrity="sha256-WpOohJOqMqqyKL9FccASB9O0KwACQJpFTUBLTYOVvVU=" crossorigin="anonymous"></script>

    <title>Basic Services (DLI 1.4)</title>
</head>
<body>
<div class="container p-5 my-5 border">
    <div class="col-md-6 text-right">
        <a href="{{ url()->previous() }}" class="btn btn-lg" style="background-color: #12d3e0;">Back to Result Area</a>
    </div>

    <br />
    <div class="card-header" style="background-color: #506dee;">
        <h2 style="
            margin-top: 10px;
            margin-left: 10px;
            color: white;
            text-align: center;
          "> M&E-- BASIC SERVICES (DLI 1.4) </h2>
    </div>
    <h4 style="text-align: center;"> Fill in the information carefully in the appropriate spaces </h4>
    <form method="post" action="{{ route('basicservices.store') }}">
        @csrf
        <div class="container border border-primary p-4">
            <div class="card-header col-md-4 col-xs-12" style="background-color: #506dee;">
                <label for="states" style="color: white;"
                >Select Month<span style="color: rgb(253, 237, 10);"
                    >(*)</span
                    ></label>
                <select class="form-control"
                        name="monthyear" required>
                    <option value="">Select Month</option>
                    @foreach($months as $month)
                        <option value="{{ $month->id }}"
                            {{$month->date}}>{{ $month->date }}</option>
                    @endforeach
                </select>
                @if ($errors->has('monthyear'))
                    <span class="text-danger text-left">{{ $errors->first('monthyear') }}</span>
                @endif
            </div>
            <br />
            <div class="row">
            <span class="card-header col-md-4" style="color: white; background-color: #506dee;">
              Total No of communities sensitized in Focal LGAs </span>
                <div class="col-md-2">
                    <input type="text" class="form-control" name="tot_commssensi" id="a" onkeyup="check()" />
                </div>
                <span class="card-header col-md-4" style="color: white; background-color: #506dee;">
              Total No of groups sensitized in Focal LGAs </span>
                <div class="col-md-2">
                    <input type="text" class="form-control" name="tot_grpssensi" id="aa" onkeyup="check()" />
                </div>
            </div>
            <br />
            <div class="row">
            <span class="card-header col-md-4" style="color: white; background-color: #506dee;">
              Total No of EOI received from communities in Focal LGAs </span>
                <div class="col-md-2">
                    <input type="text" class="form-control" name="tot_eoirecvcomms" id="b" onkeyup="check()" />
                </div>
                <span class="card-header col-md-4" style="color: white; background-color: #506dee;">
              Total No of EOI received from groups in Focal LGAs </span>
                <div class="col-md-2">
                    <input type="text" class="form-control" name="tot_eoirecvgrps" id="bb" onkeyup="check()" />
                </div>
            </div>
            <br />
            <div class="row">
            <span class="card-header col-md-4" style="color: white; background-color: #506dee;">
              Total number of CDPs submitted by Communities </span>
                <div class="col-md-2">
                    <input type="text" class="form-control" name="tot_cdpssubmit" id="c" />
                </div>
                <span class="card-header col-md-4" style="color: white; background-color: #506dee;">
              Total number of GrDPs submitted by Groups </span>
                <div class="col-md-2">
                    <input type="text" class="form-control" name="tot_grdpssubmit" id="d" />
                </div>
            </div>
            <br />
            <div class="row">
            <span class="card-header col-md-4" style="color: white; background-color: #506dee;">
              Total Number of approved CDPs for funding </span>
                <div class="col-md-2">
                    <input type="text" class="form-control" name="tot_approvcdps" id="e" />
                </div>
                <span class="card-header col-md-4" style="color: white; background-color: #506dee;">
              Total Number of approved GrDP for funding </span>
                <div class="col-md-2">
                    <input type="text" class="form-control" name="tot_approvgrdp" id="f" />
                </div>
            </div>
            <br />
            <div class="row">
            <span class="card-footer" style="color: white; background-color: #506dee;">
              Total Number of MPs in the Approved CDPs by Sector</span>
                <div class="col-md-3">
                    <label>Education</label>
                    <input type="text" class="form-control" name="tot_mpscdpedu" id="g" />
                </div>
                <div class="col-md-3">
                    <label>Nutrition</label>
                    <input type="text" class="form-control" name="tot_mpscdpnut" id="h" />
                </div>
                <div class="col-md-3">
                    <label>Health</label>
                    <input type="text" class="form-control" name="tot_mpscdphlth" id="i" />
                </div>
                <div class="col-md-3">
                    <label>Water & Sanitation</label>
                    <input type="text" class="form-control" name="tot_mpscdpwatsani" id="j" />
                </div>
            </div>
            <br />
            <div class="row">
            <span class="card-footer" style="color: white; background-color: #506dee;">
              Total Number of MPs in the Approved GrDPs by Sector</span>
                <div class="col-md-3">
                    <label>Education</label>
                    <input type="text" class="form-control" name="tot_grdpsedu" id="ga" />
                </div>
                <div class="col-md-3">
                    <label>Nutrition</label>
                    <input type="text" class="form-control" name="tot_grdpswat" id="ha" />
                </div>
                <div class="col-md-3">
                    <label>Health</label>
                    <input type="text" class="form-control" name="tot_grdpshlth" id="ia" />
                </div>
                <div class="col-md-3">
                    <label>Water & Sanitation</label>
                    <input type="text" class="form-control" name="tot_grdpswatsani" id="ja" />
                </div>
            </div>
            <br />
            <div class="row">
            <span class="card-header col-md-4" style="color: white; background-color: #506dee;">
              Number of CPMC trained </span>
                <div class="col-md-2">
                    <input type="text" class="form-control" name="num_cpmctrained" id="k" />
                </div>
                <span class="card-header col-md-4" style="color: white; background-color: #506dee;">
              Number of GPMC trained </span>
                <div class="col-md-2">
                    <input type="text" class="form-control" name="num_gpmctrained" id="l" />
                </div>
            </div>
            <br />
            <div class="row">
            <span class="card-footer" style="color: white; background-color: #506dee;">
              Number of Community MPs completed in line with agreed Environmental and
              Social safeguard guidelines by Sectors</span>
                <div class="col-md-3">
                    <label>Education</label>
                    <input type="text" class="form-control" name="tot_mpsedu" id="m" />
                </div>
                <div class="col-md-3">
                    <label>Nutrition</label>
                    <input type="text" class="form-control" name="tot_mpsnut" id="n" />
                </div>
                <div class="col-md-3">
                    <label>Health</label>
                    <input type="text" class="form-control" name="tot_mpshlth" id="o" />
                </div>
                <div class="col-md-3">
                    <label>Water & Sanitation</label>
                    <input type="text" class="form-control" name="tot_mpssani" id="p" />
                </div>
            </div>
            <br />
            <div class="row">
            <span class="card-footer" style="color: white; background-color: #506dee;">
              Number of Group MPs completed in line with agreed Environmental and
              Social safeguard guidelines by Sectors</span>
                <div class="col-md-3">
                    <label>Education</label>
                    <input type="text" class="form-control" name="tot_grpmpsedu" id="m" />
                </div>
                <div class="col-md-3">
                    <label>Nutrition</label>
                    <input type="text" class="form-control" name="tot_grpmpswat" id="n" />
                </div>
                <div class="col-md-3">
                    <label>Health</label>
                    <input type="text" class="form-control" name="tot_grpmpshlth" id="o" />
                </div>
                <div class="col-md-3">
                    <label>Water & Sanitation</label>
                    <input type="text" class="form-control" name="tot_grpmpssani" id="p" />
                </div>
            </div>
            <br />
            <div class="row">
            <span class="card-header col-md-8" style="color: white; background-color: #506dee;">
               Number of direct Beneficiaries of completed and functional MPs </span>
                <div class="col-md-4">
                    <input type="text" class="form-control" name="tot_beneofmps" id="q" />
                </div>
            </div>
            <br />
            <div class="col-md-6 bg-light text-right">
                <input type="hidden" name="timestamp" id="timestamp" />
            </div>
        </div>
        <br />

        <div class="col-md-6 col-xs-12">
            <input type="submit" class="btn btn-primary btn-sm" />
        </div>
    </form>
    <br />

</div>


<script type="text/javascript">

    (function($, undefined) {
        "use strict";
        // When ready.
        $(function() {
            var $form = $("#formid");
            var $input = $form.find('input[type="text"]');
            $input.on("keyup", function(event) {
                // When user select text in the document, also abort.
                var selection = window.getSelection().toString();
                if (selection !== "") {
                    return;
                }
                // When the arrow keys are pressed, abort.
                if ($.inArray(event.keyCode, [38, 40, 37, 39]) !== -1) {
                    return;
                }
                var $this = $(this);
                // Get the value.
                var input = $this.val();
                var input = input.replace(/[\D\s\._\-]+/g, "");
                input = input ? parseFloat(input, 10) : 0;
                $this.val(function() {
                    return input === 0 ? "" : input.toLocaleString("en-US");
                });
            });
        });
    })(jQuery);

    function check() {
        let state = document.getElementById("states").value;
        let none = "none";
        if (state === "none") {
            document.getElementById("states").style.backgroundColor = "red";
            alert("Error: Select your State");
        } else document.getElementById("states").style.backgroundColor = "white";
    }
    document.getElementById("timestamp").value = new Date().toLocaleString();
</script>
</body>
</html>
