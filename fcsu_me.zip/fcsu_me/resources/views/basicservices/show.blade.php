<!DOCTYPE html>
<html>
<head lang="en">
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" />
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.0/jquery.validate.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.4.1.js" integrity="sha256-WpOohJOqMqqyKL9FccASB9O0KwACQJpFTUBLTYOVvVU=" crossorigin="anonymous"></script>

    <title>Basic Services (DLI 1.4)</title>
</head>
<body>
<div class="container p-5 my-5 border">
    <div class="col-md-6 text-right">
        <a href="{{ url()->previous() }}" class="btn btn-lg" style="background-color: #12d3e0;">Back to Result Area</a>
    </div>
    <br />
    <div class="card-header" style="background-color: #506dee;">
        <h2 style="
            margin-top: 10px;
            margin-left: 10px;
            color: white;
            text-align: center;
          "> M&E-- BASIC SERVICES (DLI 1.4) </h2>
    </div>
    <h4 style="text-align: center;"> Fill in the information carefully in the appropriate spaces </h4>
    <form method="post" action="{{ route('basicservices.strans', $data->id) }}">
        @csrf
        @method('patch')
        <div class="container border border-primary p-4">
            <div class="row">
                <div class="card-header col-md-4 col-xs-12" style="background-color: #506dee;">
                    <label for="states" style="color: white;"
                    >Select Your State<span style="color: rgb(253, 237, 10);"
                        >(*)</span
                        ></label>
                    <select class="form-control" disabled
                            name="state_id" required>
                        <option value="">Select State</option>
                        @foreach($states as $state)
                            <option @if($data->state_id==$state->id) selected @endif
                            value="{{ $state->id }}">{{ $state->state }}</option>
                        @endforeach
                    </select>
                    @if ($errors->has('state_id'))
                        <span class="text-danger text-left">{{ $errors->first('state_id') }}</span>
                    @endif
                </div>
                <div class="card-header col-md-4 col-xs-12" style="background-color: #2198b1;">


                    <label for="DPs" style="color: white;"
                    >Select Your DP<span style="color: rgb(253, 237, 10);"
                        >(*)</span
                        ></label>
                    <select class="form-control" disabled
                            name="dp_id" required>
                        <option value="">Select DP</option>
                        @foreach($dps as $dp)
                            <option @if($data->dp_id==$dp->id) selected @endif
                            value="{{ $dp->id }}">{{ $dp->name }}</option>
                        @endforeach
                    </select>
                    @if ($errors->has('dp_id'))
                        <span class="text-danger text-left">{{ $errors->first('dp_id') }}</span>
                    @endif
                </div>
                <div class="card-header col-md-4 col-xs-12" style="background-color: #2198b1;">
                    <label for="monthyear" style="color: white;"
                    >Select Month<span style="color: rgb(253, 237, 10);"
                        >(*)</span
                        ></label>
                    <select class="form-control" disabled
                            name="monthyear" required>
                        <option value="">Select Month</option>
                        @foreach($months as $month)
                            <option @if($data->monthyear==$month->id) selected @endif
                            value="{{ $month->id }}">{{ $month->date }}</option>
                        @endforeach
                    </select>
                    @if ($errors->has('monthyear'))
                        <span class="text-danger text-left">{{ $errors->first('monthyear') }}</span>
                    @endif
                </div>

            </div>
            <br />
            <div class="row">
            <span class="card-header col-md-4" style="color: white; background-color: #506dee;">
              Total No of communities sensitized in Focal LGAs </span>
                <div class="col-md-2">
                    <input type="text" class="form-control" value="{{ $data->tot_commssensi }}" name="tot_commssensi" id="a" onkeyup="check()" readonly/>
                </div>
                <span class="card-header col-md-4" style="color: white; background-color: #506dee;">
              Total No of groups sensitized in Focal LGAs </span>
                <div class="col-md-2">
                    <input type="text" class="form-control" value="{{ $data->tot_grpssensi }}" name="tot_grpssensi" id="aa" onkeyup="check()" readonly />
                </div>
            </div>
            <br />
            <div class="row">
            <span class="card-header col-md-4" style="color: white; background-color: #506dee;">
              Total No of EOI received from communities in Focal LGAs </span>
                <div class="col-md-2">
                    <input type="text" class="form-control" value="{{ $data->tot_eoirecvcomms }}" name="tot_eoirecvcomms" id="b" onkeyup="check()" readonly />
                </div>
                <span class="card-header col-md-4" style="color: white; background-color: #506dee;">
              Total No of EOI received from groups in Focal LGAs </span>
                <div class="col-md-2">
                    <input type="text" class="form-control" value="{{ $data->tot_eoirecvgrps }}" name="tot_eoirecvgrps" id="bb" onkeyup="check()" readonly />
                </div>
            </div>
            <br />
            <div class="row">
            <span class="card-header col-md-4" style="color: white; background-color: #506dee;">
              Total number of CDPs submitted by Communities </span>
                <div class="col-md-2">
                    <input type="text" class="form-control"
                    <input type="text" class="form-control" value="{{ $data->tot_cdpssubmit }}" name="tot_cdpssubmit" id="c" readonly />
                </div>
                <span class="card-header col-md-4" style="color: white; background-color: #506dee;">
              Total number of GrDPs submitted by Groups </span>
                <div class="col-md-2">
                    <input type="text" class="form-control" value="{{ $data->tot_grdpssubmit }}" name="tot_grdpssubmit" id="d" readonly/>
                </div>
            </div>
            <br />
            <div class="row">
            <span class="card-header col-md-4" style="color: white; background-color: #506dee;">
              Total Number of approved CDPs for funding </span>
                <div class="col-md-2">
                    <input type="text" class="form-control" value="{{ $data->tot_approvcdps }}" name="tot_approvcdps" id="e" readonly />
                </div>
                <span class="card-header col-md-4" style="color: white; background-color: #506dee;">
              Total Number of approved GrDP for funding </span>
                <div class="col-md-2">
                    <input type="text" class="form-control" value="{{ $data->tot_approvgrdp }}" name="tot_approvgrdp" id="f" readonly />
                </div>
            </div>
            <br />
            <div class="row">
            <span class="card-footer" style="color: white; background-color: #506dee;">
              Total Number of MPs in the Approved CDPs by Sector</span>
                <div class="col-md-3">
                    <label>Education</label>
                    <input type="text" class="form-control" value="{{ $data->tot_mpscdpedu }}" name="tot_mpscdpedu" id="g" readonly/>
                </div>
                <div class="col-md-3">
                    <label>Nutrition</label>
                    <input type="text" class="form-control" value="{{ $data->tot_mpscdpnut }}" name="tot_mpscdpnut" id="h" readonly/>
                </div>
                <div class="col-md-3">
                    <label>Health</label>
                    <input type="text" class="form-control" value="{{ $data->tot_mpscdphlth }}" name="tot_mpscdphlth" id="i" readonly/>
                </div>
                <div class="col-md-3">
                    <label>Water & Sanitation</label>
                    <input type="text" class="form-control" value="{{ $data->tot_mpscdpwatsani }}" name="tot_mpscdpwatsani" id="j" readonly/>
                </div>
            </div>
            <br />
            <div class="row">
            <span class="card-footer" style="color: white; background-color: #506dee;">
              Total Number of MPs in the Approved GrDPs by Sector</span>
                <div class="col-md-3">
                    <label>Education</label>
                    <input type="text" class="form-control" value="{{ $data->tot_grdpsedu }}" name="tot_grdpsedu" id="ga" readonly/>
                </div>
                <div class="col-md-3">
                    <label>Nutrition</label>
                    <input type="text" class="form-control" value="{{ $data->tot_grdpswat }}" name="tot_grdpswat" id="ha" readonly />
                </div>
                <div class="col-md-3">
                    <label>Health</label>
                    <input type="text" class="form-control" value="{{ $data->tot_grdpshlth }}" name="tot_grdpshlth" id="ia" readonly/>
                </div>
                <div class="col-md-3">
                    <label>Water & Sanitation</label>
                    <input type="text" class="form-control" value="{{ $data->tot_grdpswatsani }}" name="tot_grdpswatsani" id="ja"readonly />
                </div>
            </div>
            <br />
            <div class="row">
            <span class="card-header col-md-4" style="color: white; background-color: #506dee;">
              Number of CPMC trained </span>
                <div class="col-md-2">
                    <input type="text" class="form-control" value="{{ $data->num_cpmctrained }}" name="num_cpmctrained" id="k" readonly/>
                </div>
                <span class="card-header col-md-4" style="color: white; background-color: #506dee;">
              Number of GPMC trained </span>
                <div class="col-md-2">
                    <input type="text" class="form-control" value="{{ $data->num_gpmctrained }}" name="num_gpmctrained" id="l" readonly/>
                </div>
            </div>
            <br />
            <div class="row">
            <span class="card-footer" style="color: white; background-color: #506dee;">
              Number of Community MPs completed in line with agreed Environmental and
              Social safeguard guidelines by Sectors</span>
                <div class="col-md-3">
                    <label>Education</label>
                    <input type="text" class="form-control" value="{{ $data->tot_mpsedu }}" name="tot_mpsedu" id="m" readonly/>
                </div>
                <div class="col-md-3">
                    <label>Nutrition</label>
                    <input type="text" class="form-control" value="{{ $data->tot_mpsnut }}" name="tot_mpsnut" id="n" readonly/>
                </div>
                <div class="col-md-3">
                    <label>Health</label>
                    <input type="text" class="form-control" value="{{ $data->tot_mpshlth }}" name="tot_mpshlth" id="o" readonly/>
                </div>
                <div class="col-md-3">
                    <label>Water & Sanitation</label>
                    <input type="text" class="form-control" value="{{ $data->tot_mpssani }}" name="tot_mpssani" id="p" readonly />
                </div>
            </div>
            <br />
            <div class="row">
            <span class="card-footer" style="color: white; background-color: #506dee;">
              Number of Group MPs completed in line with agreed Environmental and
              Social safeguard guidelines by Sectors</span>
                <div class="col-md-3">
                    <label>Education</label>
                    <input type="text" class="form-control" value="{{ $data->tot_grpmpsedu }}" name="tot_grpmpsedu" id="m" readonly/>
                </div>
                <div class="col-md-3">
                    <label>Nutrition</label>
                    <input type="text" class="form-control" value="{{ $data->tot_grpmpswat }}" name="tot_grpmpswat" id="n" readonly/>
                </div>
                <div class="col-md-3">
                    <label>Health</label>
                    <input type="text" class="form-control" value="{{ $data->tot_grpmpshlth }}" name="tot_grpmpshlth" id="o" readonly/>
                </div>
                <div class="col-md-3">
                    <label>Water & Sanitation</label>
                    <input type="text" class="form-control" value="{{ $data->tot_grpmpssani }}" name="tot_grpmpssani" id="p" readonly/>
                </div>
            </div>
            <br />
            <div class="row">
            <span class="card-header col-md-8" style="color: white; background-color: #506dee;">
               Number of direct Beneficiaries of completed and functional MPs </span>
                <div class="col-md-4">
                    <input type="text" class="form-control" value="{{ $data->tot_beneofmps }}" name="tot_beneofmps" id="q" readonly/>
                </div>
            </div>
            <br/>
            @if($data->status_id == 3)
                <div class="card-header col-md-4 col-xs-12" style="background-color: #506dee;">
                    <label for="states" style="color: white;"
                    >Submission Status<span style="color: rgb(253, 237, 10);"
                        >(*)</span
                        ></label>
                    <select class="form-control" disabled
                            name="approval_id" required>
                        <option value="">Sent to FCSU</option>

                    </select>
                </div>
            @elseif($data->status_id != 2 && $data->dp_id == Auth::user()->dp_id)
                <div class="card-header col-md-4 col-xs-12" style="background-color: #506dee;">
                    <label for="states" style="color: white;"
                    >Approve this submission<span style="color: rgb(253, 237, 10);"
                        >(*)</span
                        ></label>
                    <select class="form-control"
                            name="approval_id" required>
                        <option value="">Select Status</option>
                        @foreach($approvals as $status)
                            <option @if($data->status_id==$status->id) selected @endif
                            value="{{ $status->id }}">{{ $status->name }}</option>
                        @endforeach
                    </select>
                    @if ($errors->has('approval_id'))
                        <span class="text-danger text-left">{{ $errors->first('approval_id') }}</span>
                    @endif
                </div>

            @endif
            <br />
            <div class="col-md-6 bg-light text-right">
                <input type="hidden" name="timestamp" id="timestamp" />
            </div>
        </div>
        <br />
        @if($data->dp_id == Auth::user()->dp_id)
        <div class="col-md-6 col-xs-12">
            <input type="submit" class="btn btn-primary btn-sm" />
        </div>
        @endif
    </form>
    <br />

</div>


<script type="text/javascript">

    (function($, undefined) {
        "use strict";
        // When ready.
        $(function() {
            var $form = $("#formid");
            var $input = $form.find('input[type="text"]');
            $input.on("keyup", function(event) {
                // When user select text in the document, also abort.
                var selection = window.getSelection().toString();
                if (selection !== "") {
                    return;
                }
                // When the arrow keys are pressed, abort.
                if ($.inArray(event.keyCode, [38, 40, 37, 39]) !== -1) {
                    return;
                }
                var $this = $(this);
                // Get the value.
                var input = $this.val();
                var input = input.replace(/[\D\s\._\-]+/g, "");
                input = input ? parseFloat(input, 10) : 0;
                $this.val(function() {
                    return input === 0 ? "" : input.toLocaleString("en-US");
                });
            });
        });
    })(jQuery);

    function check() {
        let state = document.getElementById("states").value;
        let none = "none";
        if (state === "none") {
            document.getElementById("states").style.backgroundColor = "red";
            alert("Error: Select your State");
        } else document.getElementById("states").style.backgroundColor = "white";
    }
    document.getElementById("timestamp").value = new Date().toLocaleString();
</script>
</body>
</html>

