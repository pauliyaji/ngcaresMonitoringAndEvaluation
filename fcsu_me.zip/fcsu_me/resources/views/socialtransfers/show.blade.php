<!DOCTYPE html>
<html>

<head lang="en">
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" />
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.0/jquery.validate.min.js"></script>
    <script
        src="https://code.jquery.com/jquery-3.4.1.js"
        integrity="sha256-WpOohJOqMqqyKL9FccASB9O0KwACQJpFTUBLTYOVvVU="
        crossorigin="anonymous"></script>

    <title>Social Transfer (DLI 1.1)</title>
</head>

<body>
<div class="container p-5 my-5 border">
    <div class="col-md-6 text-right"> <a href="{{ url()->previous() }}" class="btn btn-lg" style="background-color: #12d3e0;">Back to Result Area</a> </div>
    <br />
    <div class="card-header" style="background-color: #506dee;">
        <h2 style="
            margin-top: 10px;
            margin-left: 10px;
            color: white;
            text-align: center;
          ">
            M&E-- Social Transfer (DLI 1.1)
        </h2> </div>
    <h4 style="text-align: center;">Fill in the information carefully in the appropriate spaces</h4>
    <form method="post" action="{{ route('socialtransfers.strans', $data->id) }}" >
        @csrf
        @method('patch')
        <div class="container border border-primary p-4">
            <div class="row">
                <div class="card-header col-md-4 col-xs-12" style="background-color: #506dee;">
                    <label for="states" style="color: white;"
                    >Select Your State<span style="color: rgb(253, 237, 10);"
                        >(*)</span
                        ></label>
                    <select class="form-control" disabled
                            name="state_id" required>
                        <option value="">Select State</option>
                        @foreach($states as $state)
                            <option @if($data->state_id==$state->id) selected @endif
                            value="{{ $state->id }}">{{ $state->state }}</option>
                        @endforeach
                    </select>
                    @if ($errors->has('state_id'))
                        <span class="text-danger text-left">{{ $errors->first('state_id') }}</span>
                    @endif
                </div>
                <div class="card-header col-md-4 col-xs-12" style="background-color: #2198b1;">


                    <label for="DPs" style="color: white;"
                    >Select Your DP<span style="color: rgb(253, 237, 10);"
                        >(*)</span
                        ></label>
                    <select class="form-control" disabled
                            name="dp_id" required>
                        <option value="">Select DP</option>
                        @foreach($dps as $dp)
                            <option @if($data->dp_id==$dp->id) selected @endif
                            value="{{ $dp->id }}">{{ $dp->name }}</option>
                        @endforeach
                    </select>
                    @if ($errors->has('dp_id'))
                        <span class="text-danger text-left">{{ $errors->first('dp_id') }}</span>
                    @endif
                </div>
                <div class="card-header col-md-4 col-xs-12" style="background-color: #2198b1;">
                    <label for="monthyear" style="color: white;"
                    >Select Month<span style="color: rgb(253, 237, 10);"
                        >(*)</span
                        ></label>
                    <select class="form-control" disabled
                            name="monthyear" required>
                        <option value="">Select Month</option>
                        @foreach($months as $month)
                            <option @if($data->monthyear==$month->id) selected @endif
                            value="{{ $month->id }}">{{ $month->date }}</option>
                        @endforeach
                    </select>
                    @if ($errors->has('monthyear'))
                        <span class="text-danger text-left">{{ $errors->first('monthyear') }}</span>
                    @endif
                </div>

            </div>
            <br />
            <div class="row">
            <span class="card-footer" style="color: white; background-color: #506dee;">
              Total Number of Beneficiaries mined from Agreed Register</span>
                <div class="col-md-4">
                    <label>Female</label>
                    <input type="text" class="form-control" value={{ $data->f_mined }} name="f_mined" id="f1.1.1" onkeyup="reSum2();"  readonly/> </div>
                <div class="col-md-4">
                    <label>Male</label>
                    <input type="text" class="form-control" value={{ $data->m_mined }} name="m_mined" id="m1.1.1" onkeyup="reSum2();"  readonly/> </div>
                <div class="col-md-4">
                    <label>Total</label>
                    <input type="text" value={{ $data->tot_mined }} name="tot_mined" id="t1.1.1" readonly class="form-control" /> </div>
            </div>
            <br />
            <div class="row"> <span class="card-header" style="color: white; background-color: #506dee;">
              Total Number of Beneficiaries mined (disaggregated by vulnerability
              profile (Aged, Chronically ill, Urban Poor and people with special
              needs)
            </span>
                <div class="col-md-3">
                    <label>Aged</label>
                    <input type="text" value={{ $data->aged_mined }} name="aged_mined" id="a1.1.1" class="form-control" onkeyup="test1a()" readonly/> </div>
                <div class="col-md-3">
                    <label>Chronically ill</label>
                    <input type="text" value={{ $data->chro_mined }} name="chro_mined" id="ci1.1.1" class="form-control" onkeyup="test1a()" readonly/> </div>
                <div class="col-md-3">
                    <label>Urban Poor</label>
                    <input type="text" value={{ $data->urban_mined }} name="urban_mined" id="up1.1.1" class="form-control" onkeyup="test1a()" readonly/> </div>
                <div class="col-md-3">
                    <label>People with special needs</label>
                    <input type="text" value={{ $data->needs_mined }} name="needs_mined" id="psn1.1.1" class="form-control" onblur="test1()" readonly/> </div>
            </div>
            <br />
            <div class="row">
                <div class="col-md-12">
                    <input style="display: none; color: white;" class="form-control" type="" value={{ $data->comment1 }} name="comment1" id="comment1" placeholder="Input your reason here" readonly /> </div>
            </div>
            <br />
            <div class="row"> <span class="card-header" style="color: white; background-color: #506dee;">
              Total Number of mined Beneficiaries validated
            </span>
                <div class="col-md-4">
                    <label>Female</label>
                    <input type="text" value={{ $data->f_validated }} name="f_validated" id="f1.1.2" class="form-control" onkeyup="reSum2();" readonly/> </div>
                <div class="col-md-4">
                    <label>Male</label>
                    <input type="text" value={{ $data->m_validated }} name="m_validated" id="m1.1.2" class="form-control" onkeyup="reSum2();" readonly /> </div>
                <div class="col-md-4">
                    <label>Total</label>
                    <input type="number" value={{ $data->tot_validated }} name="tot_validated" id="t1.1.2" readonly class="form-control" onkeyup="reSum2();" /> </div>
            </div>
            <br />
            <div class="row"> <span class="card-header" style="color: white; background-color: #506dee;">
              Attrition (Mined
              <span style="color: yellow;">minus </span> Validated) </span>
                <div class="col-md-3">
                    <label>Female</label>
                    <input type="number" value={{ $data->att_fmined }} name="att_fmined" id="f1.1.3" class="form-control" readonly /> </div>
                <div class="col-md-3">
                    <label>Male</label>
                    <input type="number" value={{ $data->att_mmined }} name="att_mmined" id="m1.1.3" class="form-control" readonly /> </div>
                <div class="col-md-3">
                    <label>Total</label>
                    <input type="number" value={{ $data->att_totmined }} name="att_totmined" id="t1.1.3" readonly class="form-control" onkeyup="reSum2();" /> </div>
                <div class="col-md-3">
                    <label>Percent (%) Attrition</label>
                    <input type="number" value={{ $data->att_minedpercent }} name="att_minedpercent" id="p1.1.4" readonly class="form-control" /> </div>
            </div>
            <br />
            <div class="row">
					<span class="card-footer" style="color: white; background-color: #506dee;">
						Total Number of Beneficiaries enrolled</span>
                <div class="col-md-3">
                    <label>Female</label>
                    <input type="text" class="form-control" value={{ $data->fenrolled }} name="fenrolled" id="enF" onkeyup="reSum2();" readonly />
                </div>
                <div class="col-md-3">
                    <label>Male</label>
                    <input type="text" class="form-control" value={{ $data->menrolled }} name="menrolled" id="enM" onkeyup="reSum2();" readonly />
                </div>
                <div class="col-md-3">
                    <label>Total</label>
                    <input type="number" value={{ $data->tot_enrolled }} name="tot_enrolled" id="enT" readonly class="form-control" />
                </div>
                <div class="col-md-3">
                    <label>Percent (%) Enrolled</label>
                    <input type="number" value={{ $data->att_perenrolled }} name="att_perenrolled" id="enAT" readonly class="form-control" />
                </div>
            </div>
            <br />

            <div class="row">
            <span class="card-header" style="color: white; background-color: #506dee;">
              Total Number of Beneficiaries enrolled (disaggregated by
              vulnerability profile (Aged, Chronically ill, Urban Poor and people
              with special needs)
            </span>
                <div class="col-md-3">
                    <label>Aged Female</label>
                    <input type="text" value={{ $data->aged_fenrolled }} name="aged_fenrolled" id="af1.1.5" class="form-control" onkeyup="test2a()" readonly/> </div>
                <div class="col-md-3">
                    <label>Aged Male</label>
                    <input type="text" value={{ $data->aged_menrolled }} name="aged_menrolled" id="am1.1.5" class="form-control" onkeyup="test2a()" readonly /> </div>
                <div class="col-md-3">
                    <label>Chronically ill Female</label>
                    <input type="text" value={{ $data->chro_fenrolled }} name="chro_fenrolled" id="cif1.1.5" class="form-control" onkeyup="test2a()" readonly/> </div>
                <div class="col-md-3">
                    <label>Chronically ill Male</label>
                    <input type="text" value={{ $data->chro_menrolled }} name="chro_menrolled" id="cim1.1.5" class="form-control" onkeyup="test2a()" readonly /> </div>
                <div class="col-md-3">
                    <label>Urban Poor Female</label>
                    <input type="text"value={{ $data->urban_fenrolled }} name="urban_fenrolled" id="upf1.1.5" class="form-control" onkeyup="test2a()" /> </div>
                <div class="col-md-3">
                    <label>Urban Poor Male</label>
                    <input type="text" value={{ $data->urban_menrolled }} name="urban_menrolled" id="upm1.1.5" class="form-control" onkeyup="test2a()"  readonly/> </div>
                <div class="col-md-3">
                    <label>Special needs Female</label>
                    <input type="text" value={{ $data->needs_fenrolled }} name="needs_fenrolled" id="pnf1.1.5" class="form-control" onkeyup="test2()" readonly /> </div>
                <div class="col-md-3">
                    <label>Special needs Male</label>
                    <input type="text" value={{ $data->needs_menrolled }} name="needs_menrolled" id="pnm1.1.5" class="form-control" onblur="test2()" readonly /> </div>
            </div>
            <br />
            <div class="row">
                <div class="col-md-12">
                    <input style="display: none;" class="form-control" type="" value={{ $data->comment2 }} name="comment2" id="comment2" placeholder="Input your reason here" readonly /> </div>
            </div>
            <br />
            <div class="row"> <span class="card-header" style="color: white; background-color: #506dee;">
              Attrition (Validated
              <span style="color: yellow;">minus </span> Enrolled) </span>
                <div class="col-md-4">
                    <label>Female</label>
                    <input type="number" value={{ $data->att_fval_enr }} name="att_fval_enr" id="f1.1.6" class="form-control" readonly /> </div>
                <div class="col-md-4">
                    <label>Male</label>
                    <input type="number" value={{ $data->att_mval_enr }} name="att_mval_enr" id="m1.1.6" class="form-control" readonly /> </div>
                <div class="col-md-4">
                    <label>Total</label>
                    <input type="number" value={{ $data->att_totval_enr }} name="att_totval_enr" id="t1.1.6" readonly class="form-control" /> </div>
            </div>
            <br />
            <div class="row"> <span class="card-header col-md-6" style="color: white; background-color: #506dee;">
              Total Amount transferred to PSP (NGN)
            </span>
                <div class="col-md-6 col-xs-12">
                    <input type="text" value={{ $data->amt_transpsp }} name="amt_transpsp" id="form-input" class="form-control" readonly /> </div>
            </div>
            <br />
            <div class="row"> <span class="card-header" style="color: white; background-color: #506dee;">
              Total Number of Beneficiaries transferred to PSP for payment
            </span>
                <div class="row">
                    <div class="row">
                        <div class="col-md-4">
                            <label>Female</label>
                            <input type="text" value={{ $data->tot_fbeneforpsppay }} name="tot_fbeneforpsppay" id="f1.1.8" class="form-control" onkeyup="reSum5()" readonly/> </div>
                        <div class="col-md-4">
                            <label>Male</label>
                            <input type="text" value={{ $data->tot_mbeneforpsppay }} name="tot_mbeneforpsppay" id="m1.1.8" onkeyup="reSum5()" class="form-control" readonly/> </div>
                        <div class="col-md-4">
                            <label>Total</label>
                            <input type="number" value={{ $data->tot_beneforpsppay }} name="tot_beneforpsppay" id="t1.1.8" class="form-control" readonly /> </div>
                    </div>
                    <div class="col-md-3">
                        <label>Aged Female</label>
                        <input type="text" value={{ $data->tot_agedfbeneforpsppay }} name="tot_agedfbeneforpsppay" id="af1.1.8" class="form-control" onkeyup="test3a()" readonly /> </div>
                    <div class="col-md-3">
                        <label>Aged Male</label>
                        <input type="text" value={{ $data->tot_agedmbeneforpsppay }} name="tot_agedmbeneforpsppay" id="am1.1.8" class="form-control" onkeyup="test3a()" readonly/> </div>
                    <div class="col-md-3">
                        <label>Chronically ill Female</label>
                        <input type="text" value={{ $data->tot_chrofbeneforpsppay }} name="tot_chrofbeneforpsppay" id="cif1.1.8" class="form-control" onkeyup="test3a()" readonly/> </div>
                    <div class="col-md-3">
                        <label>Chronically ill Male</label>
                        <input type="text" value={{ $data->tot_chrombeneforpsppay }} name="tot_chrombeneforpsppay" id="cim1.1.8" class="form-control" onkeyup="test3a()" readonly/> </div>
                </div>
                <br />
                <div class="row">
                    <div class="col-md-3">
                        <label>Urban Poor Female</label>
                        <input type="text" value={{ $data->tot_urbanfbeneforpsppay }} name="tot_urbanfbeneforpsppay" id="upf1.1.8" class="form-control" onkeyup="test3a()" readonly/> </div>
                    <div class="col-md-3">
                        <label>Urban Poor Male</label>
                        <input type="text" value={{ $data->tot_urbanmbeneforpsppay }} name="tot_urbanmbeneforpsppay" id="upm1.1.8" class="form-control" onkeyup="test3a()" readonly/> </div>
                    <div class="col-md-3">
                        <label>People w Special needs Female</label>
                        <input type="text" value={{ $data->tot_needsfbeneforpsppay }} name="tot_needsfbeneforpsppay" id="pnf1.1.8" class="form-control" onkeyup="test3a()" readonly/> </div>
                    <div class="col-md-3">
                        <label>People with Special needs Male</label>
                        <input type="text" value={{ $data->tot_needsmbeneforpsppay }} name="tot_needsmbeneforpsppay" id="pnm1.1.8" class="form-control" onblur="test3()" readonly/> </div>
                </div>
            </div>
            <br />
            <div class="row">
                <div class="col-md-12">
                    <input style="display: none;" class="form-control" type="text" value={{ $data->comment3 }} name="comment3" id="comment3" placeholder="Input your reason here" readonly/> </div>
            </div>
            <br />
            <div class="row"> <span class="card-header col-md-4" style="color: white; background-color: #506dee;">
              Total Number of Beneficiaries paid
            </span>
                <div class="col-md-2">
                    <input class="form-control" type="text" value={{ $data->tot_numbenepaid }}  name="tot_numbenepaid" id="1.1.9" onkeyup="reSum5()" readonly/> </div> <span class="card-header col-md-4" style="color: white; background-color: #506dee;">
              Attrition (Not Paid)
            </span>
                <div class="col-md-2">
                    <input type="text" class="form-control" value={{ $data->attrition_ntpaid }}  name="attrition_ntpaid" id="p" readonly /> </div>
            </div>
            <br />
            <div class="row"> <span class="card-header col-md-4" style="color: white; background-color: #506dee;">
              Attrition (%)
            </span>
                <div class="col-md-2">
                    <input type="text" class="form-control" value="{{ $data->attrition_ntpaid_percent }}"  name="attrition_ntpaid_percent" id="q" readonly /> </div>
            </div>
            <br />
            <div class="row">
                <div class="col-md-12">
                    <input class="form-control" type="text" value="{{ $data->comment4 }}"  name="comment4" id="comment4" placeholder="Attrition Remarks" readonly/>
                </div>
            </div>
            <br />
            @if($data->status_id == 2)
                <div class="card-header col-md-4 col-xs-12" style="background-color: #506dee;">
                    <label for="states" style="color: white;"
                    >Approve status<span style="color: rgb(253, 237, 10);"
                        >(*)</span
                        ></label>
                    <select class="form-control" disabled
                            name="approval_id" required>
                        <option value="">DP Approved</option>

                    </select>
                </div>
            @elseif($data->status_id == 3)
                <div class="card-header col-md-4 col-xs-12" style="background-color: #506dee;">
                    <label for="states" style="color: white;"
                    >Submission Status<span style="color: rgb(253, 237, 10);"
                        >(*)</span
                        ></label>
                    <select class="form-control" disabled
                            name="approval_id" required>
                        <option value="">Sent to FCSU</option>

                    </select>
                </div>
            @elseif($data->status_id == 4 && $data->dp_id == Auth::user()->dp_id)
                <div class="card-header col-md-4 col-xs-12" style="background-color: #506dee;">
                    <label for="states" style="color: white;"
                    >Approve this submission<span style="color: rgb(253, 237, 10);"
                        >(*)</span
                        ></label>
                    <select class="form-control"
                            name="approval_id" required>
                        <option value="">Select Status</option>
                        @foreach($approvals as $status)
                            <option @if($data->status_id==$status->id) selected @endif
                            value="{{ $status->id }}">{{ $status->name }}</option>
                        @endforeach
                    </select>
                    @if ($errors->has('approval_id'))
                        <span class="text-danger text-left">{{ $errors->first('approval_id') }}</span>
                    @endif
                </div>

            @endif

        </div>
        <br />
        <input type="hidden" name="timestamp" id="timestamp" />

        <br/>
        @if($data->dp_id == Auth::user()->dp_id)
            <div class="col-md-6 col-xs-12">
                <input type="submit" class="btn btn-primary btn-sm" />
            </div>
        @endif

    </form>
    <br />
</div>

<script type="text/javascript">
    // function sb() {
    // 	location.reload(true);
    // 	alert("Data successfully submitted.");
    // 	window.location.href = "../";
    // }
    (function($, undefined) {
        "use strict";
        // When ready.
        $(function() {
            var $form = $("#formid");
            var $input = $form.find('input[type="text"]');
            $input.on("keyup", function(event) {
                // When user select text in the document, also abort.
                var selection = window.getSelection().toString();
                if(selection !== "") {
                    return;
                }
                // When the arrow keys are pressed, abort.
                if($.inArray(event.keyCode, [38, 40, 37, 39]) !== -1) {
                    return;
                }
                var $this = $(this);
                // Get the value.
                var input = $this.val();
                var input = input.replace(/[\D\s\._\-]+/g, "");
                input = input ? parseFloat(input, 10) : 0;
                $this.val(function() {
                    return input === 0 ? "0" : input.toLocaleString("en-US");
                });
            });

        });
    })(jQuery);


    function test1() {
        var c = parseFloat(document.getElementById("t1.1.1").value.replace(/[^\d\.\-]/g, ""));
        var d = parseFloat(document.getElementById("a1.1.1").value.replace(/[^\d\.\-]/g, ""));
        var e = parseFloat(document.getElementById("ci1.1.1").value.replace(/[^\d\.\-]/g, ""));
        var f = parseFloat(document.getElementById("up1.1.1").value.replace(/[^\d\.\-]/g, ""));
        var g = parseFloat(document.getElementById("psn1.1.1").value.replace(/[^\d\.\-]/g, ""));
        var cmt1 = document.getElementById("comment1").value.length;
        var set1 = d + e + f + g;
        if(c !== set1 && cmt1 < 1) {
            document.getElementById("t1.1.1").style.backgroundColor = "yellow";
            document.getElementById("comment1").style.backgroundColor = "red";
            document.getElementById("comment1").style.display = "block";
            alert("Error: \nTotal Number of Beneficiaries mined from Agreed Register not equal input reason");
        } else {
            document.getElementById("comment1").value = "";
            document.getElementById("comment1").style.display = "none";
        }
    }

    function test1a() {
        var c = parseFloat(document.getElementById("t1.1.1").value.replace(/[^\d\.\-]/g, ""));
        var d = parseFloat(document.getElementById("a1.1.1").value.replace(/[^\d\.\-]/g, ""));
        var e = parseFloat(document.getElementById("ci1.1.1").value.replace(/[^\d\.\-]/g, ""));
        var f = parseFloat(document.getElementById("up1.1.1").value.replace(/[^\d\.\-]/g, ""));
        var g = parseFloat(document.getElementById("psn1.1.1").value.replace(/[^\d\.\-]/g, ""));
        var cmt1 = document.getElementById("comment1").value.length;
        var x = (document.getElementById("comment1").style.display = "none");
        var set1 = d + e + f + g;
        if(c !== set1 && cmt1 < 1) {
            if(c == set1 && x === "block") {
                document.getElementById("comment1").style.display = "none";
            }
        }
    }

    function test2() {
        var ent = parseFloat(document.getElementById("enF").value.replace(/[^\d\.\-]/g, ""));
        var ent2 = parseFloat(document.getElementById("enM").value.replace(/[^\d\.\-]/g, ""));
        var o = parseFloat(document.getElementById("af1.1.5").value.replace(/[^\d\.\-]/g, ""));
        var p = parseFloat(document.getElementById("am1.1.5").value.replace(/[^\d\.\-]/g, ""));
        var q = parseFloat(document.getElementById("cif1.1.5").value.replace(/[^\d\.\-]/g, ""));
        var r = parseFloat(document.getElementById("cim1.1.5").value.replace(/[^\d\.\-]/g, ""));
        var s = parseFloat(document.getElementById("upf1.1.5").value.replace(/[^\d\.\-]/g, ""));
        var t = parseFloat(document.getElementById("upm1.1.5").value.replace(/[^\d\.\-]/g, ""));
        var u = parseFloat(document.getElementById("pnf1.1.5").value.replace(/[^\d\.\-]/g, ""));
        var v = parseFloat(document.getElementById("pnm1.1.5").value.replace(/[^\d\.\-]/g, ""));
        var cmt2 = document.getElementById("comment2").value.length;
        var set2 = o + q + s + u;
        var set3 = p + r + t + v;
        if(ent !== set2 && cmt2 < 1) {
            document.getElementById("enF").style.backgroundColor = "red";
            document.getElementById("comment2").style.backgroundColor = "red";
            document.getElementById("comment2").style.display = "block";
            // alert("Error: \nCheck Total Number of Female Beneficiaries enrolled");
        } else if(ent2 !== set3 && cmt2 < 1) {
            document.getElementById("enM").style.backgroundColor = "red";
            document.getElementById("enF").style.backgroundColor = "white";
            document.getElementById("comment2").style.backgroundColor = "red";
            document.getElementById("comment2").style.display = "block";
            // alert("Error: \nCheck Total Number of Male Beneficiaries enrolled");
        } else {
            document.getElementById("comment2").value = "";
            document.getElementById("comment2").style.display = "none";
            document.getElementById("enM").style.backgroundColor = "white";
        }
    }

    function test2a() {
        var ent = parseFloat(document.getElementById("enT").value.replace(/[^\d\.\-]/g, ""));
        var o = parseFloat(document.getElementById("af1.1.5").value.replace(/[^\d\.\-]/g, ""));
        var p = parseFloat(document.getElementById("am1.1.5").value.replace(/[^\d\.\-]/g, ""));
        var q = parseFloat(document.getElementById("cif1.1.5").value.replace(/[^\d\.\-]/g, ""));
        var r = parseFloat(document.getElementById("cim1.1.5").value.replace(/[^\d\.\-]/g, ""));
        var s = parseFloat(document.getElementById("upf1.1.5").value.replace(/[^\d\.\-]/g, ""));
        var t = parseFloat(document.getElementById("upm1.1.5").value.replace(/[^\d\.\-]/g, ""));
        var u = parseFloat(document.getElementById("pnf1.1.5").value.replace(/[^\d\.\-]/g, ""));
        var v = parseFloat(document.getElementById("pnm1.1.5").value.replace(/[^\d\.\-]/g, ""));
        var cmt2 = document.getElementById("comment2").value.length;
        var set2 = o + p + q + r + s + t + u + v;
        var x = (document.getElementById("comment2").style.display = "none");
        if(ent !== set2 && cmt2 < 1) {
            if(ent == set2 && x === "block") {
                document.getElementById("comment2").style.display = "none";
            }
        }
    }

    function test3() {
        var a3 = parseFloat(document.getElementById("t1.1.8").value.replace(/[^\d\.\-]/g, ""));
        var a4 = parseFloat(document.getElementById("af1.1.8").value.replace(/[^\d\.\-]/g, ""));
        var a5 = parseFloat(document.getElementById("am1.1.8").value.replace(/[^\d\.\-]/g, ""));
        var a6 = parseFloat(document.getElementById("cif1.1.8").value.replace(/[^\d\.\-]/g, ""));
        var a7 = parseFloat(document.getElementById("cim1.1.8").value.replace(/[^\d\.\-]/g, ""));
        var a8 = parseFloat(document.getElementById("upf1.1.8").value.replace(/[^\d\.\-]/g, ""));
        var a9 = parseFloat(document.getElementById("upm1.1.8").value.replace(/[^\d\.\-]/g, ""));
        var a10 = parseFloat(document.getElementById("pnf1.1.8").value.replace(/[^\d\.\-]/g, ""));
        var a11 = parseFloat(document.getElementById("pnm1.1.8").value.replace(/[^\d\.\-]/g, ""));
        var a12 = parseFloat(document.getElementById("1.1.9").value.replace(/[^\d\.\-]/g, ""));
        var cmt3 = document.getElementById("comment3").value.length;
        var set3 = a4 + a5 + a6 + a7 + a8 + a9 + a10 + a11;
        alert(set3);
        if(set3 > a3 && cmt3 < 1) {
            alert("Disaggregated Total is greater than Beneficiaries ");
            document.getElementById("sbt").disabled = true;
        } else {
            document.getElementById("sbt").disabled = false;
        }
        if(a3 !== set3 && cmt3 < 1) {
            document.getElementById("t1.1.8").style.backgroundColor = "red";
            document.getElementById("comment3").style.backgroundColor = "red";
            document.getElementById("comment3").style.display = "block";
            alert("Error: \nCheck Total Number of Beneficiaries transferred to PSP for payment");
        } else {
            document.getElementById("comment3").value = "";
            document.getElementById("comment3").style.display = "none";
        }
    }

    function test3a() {
        var a3 = parseFloat(document.getElementById("t1.1.8").value.replace(/[^\d\.\-]/g, ""));
        var a4 = parseFloat(document.getElementById("af1.1.8").value.replace(/[^\d\.\-]/g, ""));
        var a5 = parseFloat(document.getElementById("am1.1.8").value.replace(/[^\d\.\-]/g, ""));
        var a6 = parseFloat(document.getElementById("cif1.1.8").value.replace(/[^\d\.\-]/g, ""));
        var a7 = parseFloat(document.getElementById("cim1.1.8").value.replace(/[^\d\.\-]/g, ""));
        var a8 = parseFloat(document.getElementById("upf1.1.8").value.replace(/[^\d\.\-]/g, ""));
        var a9 = parseFloat(document.getElementById("upm1.1.8").value.replace(/[^\d\.\-]/g, ""));
        var a10 = parseFloat(document.getElementById("pnf1.1.8").value.replace(/[^\d\.\-]/g, ""));
        var a11 = parseFloat(document.getElementById("pnm1.1.8").value.replace(/[^\d\.\-]/g, ""));
        var a12 = parseFloat(document.getElementById("1.1.9").value.replace(/[^\d\.\-]/g, ""));
        var cmt3 = document.getElementById("comment3").value.length;
        var set3 = a4 + a5 + a6 + a7 + a8 + a9 + a10 + a11;
        var x = (document.getElementById("comment3").style.display = "none");
        if(set3 > a3 && cmt3 < 1) {
            alert("Disaggregated Total is greater than Beneficiaries ");
            document.getElementById("sbt").disabled = true;
        } else {
            document.getElementById("sbt").disabled = false;
        }
        if(a3 !== set3 && cmt3 < 1) {
            if(a3 == set3 && x === "block") {
                document.getElementById("comment3").style.display = "none";
            }
        }
    }

    function test4() {
        var a15 = parseFloat(document.getElementById("t1.1.10").value.replace(/[^\d\.\-]/g, ""));
        var a16 = parseFloat(document.getElementById("af1.1.10").value.replace(/[^\d\.\-]/g, ""));
        var a17 = parseFloat(document.getElementById("am1.1.10").value.replace(/[^\d\.\-]/g, ""));
        var a18 = parseFloat(document.getElementById("cif1.1.10").value.replace(/[^\d\.\-]/g, ""));
        var a19 = parseFloat(document.getElementById("cim1.1.10").value.replace(/[^\d\.\-]/g, ""));
        var a20 = parseFloat(document.getElementById("upf1.1.10").value.replace(/[^\d\.\-]/g, ""));
        var a21 = parseFloat(document.getElementById("upm1.1.10").value.replace(/[^\d\.\-]/g, ""));
        var a22 = parseFloat(document.getElementById("pnf1.1.10").value.replace(/[^\d\.\-]/g, ""));
        var a23 = parseFloat(document.getElementById("pnm1.1.10").value.replace(/[^\d\.\-]/g, ""));
        var cmt4 = document.getElementById("comment4").value.length;
        var set4 = a16 + a17 + a18 + a19 + a20 + a21 + a22 + a23;
        if(a15 !== set4 && cmt4 < 1) {
            document.getElementById("t1.1.10").style.backgroundColor = "red";
            document.getElementById("comment4").style.backgroundColor = "red";
            document.getElementById("comment4").style.display = "block";
            alert("Error: \nCheck Total Number of Beneficiaries that confirm receipt of periodic social transfer");
        } else {
            document.getElementById("comment4").value = "";
            document.getElementById("comment4").style.display = "none";
        }
    }

    function test4a() {
        var a15 = parseFloat(document.getElementById("t1.1.10").value.replace(/[^\d\.\-]/g, ""));
        var a16 = parseFloat(document.getElementById("af1.1.10").value.replace(/[^\d\.\-]/g, ""));
        var a17 = parseFloat(document.getElementById("am1.1.10").value.replace(/[^\d\.\-]/g, ""));
        var a18 = parseFloat(document.getElementById("cif1.1.10").value.replace(/[^\d\.\-]/g, ""));
        var a19 = parseFloat(document.getElementById("cim1.1.10").value.replace(/[^\d\.\-]/g, ""));
        var a20 = parseFloat(document.getElementById("upf1.1.10").value.replace(/[^\d\.\-]/g, ""));
        var a21 = parseFloat(document.getElementById("upm1.1.10").value.replace(/[^\d\.\-]/g, ""));
        var a22 = parseFloat(document.getElementById("pnf1.1.10").value.replace(/[^\d\.\-]/g, ""));
        var a23 = parseFloat(document.getElementById("pnm1.1.10").value.replace(/[^\d\.\-]/g, ""));
        var cmt4 = document.getElementById("comment4").value.length;
        var set4 = a16 + a17 + a18 + a19 + a20 + a21 + a22 + a23;
        var x = (document.getElementById("comment4").style.display = "none");
        if(a15 !== set4 && cmt4 < 1) {
            if(a15 == set4 && x === "block") {
                document.getElementById("comment4").style.display = "none";
            }
        }
    }

    function reSum2() {
        var num1 = parseFloat(document.getElementById("f1.1.2").value.replace(/[^\d\.\-]/g, ""));
        var num2 = parseFloat(document.getElementById("m1.1.2").value.replace(/[^\d\.\-]/g, ""));
        var num3 = parseFloat(document.getElementById("f1.1.1").value.replace(/[^\d\.\-]/g, ""));
        var num4 = parseFloat(document.getElementById("m1.1.1").value.replace(/[^\d\.\-]/g, ""));
        var enf = parseFloat(document.getElementById("enF").value.replace(/[^\d\.\-]/g, ""));
        var enm = parseFloat(document.getElementById("enM").value.replace(/[^\d\.\-]/g, ""));
        var numTotalAgreedRegister = num4 + num3;
        var numTotalBeneEnrolled = enm + enf;
        var AttritionEnrolled = ((numTotalBeneEnrolled / numTotalAgreedRegister)) * 100;
        var numt = num4 + num3 - (num2 + num1);
        var numat = 100 - (((num2 + num1) / (num4 + num3)) * 100);
        var menrol = num1 - enf + (num2 - enm);
        document.getElementById("t1.1.1").value = num3 + num4;
        document.getElementById("t1.1.2").value = num1 + num2;
        document.getElementById("f1.1.3").value = num3 - num1;
        document.getElementById("m1.1.3").value = num4 - num2;
        document.getElementById("t1.1.3").value = numt;
        document.getElementById("p1.1.4").value = numat.toFixed(2);
        document.getElementById("t1.1.6").value = num1 + num2;
        document.getElementById("f1.1.6").value = num1 - enf;
        document.getElementById("m1.1.6").value = num2 - enm;
        document.getElementById("t1.1.6").value = menrol;
        document.getElementById("enT").value = enf + enm;
        document.getElementById("enAT").value = AttritionEnrolled.toFixed(2);
        let px = document.getElementById("t1.1.1").value;
        let cc = "NaN";
        if(px == cc) {
            document.getElementById("t1.1.1").value = "0";
        }
    }

    function reSum5() {
        var num3 = parseFloat(document.getElementById("f1.1.8").value.replace(/[^\d\.\-]/g, ""));
        var num4 = parseFloat(document.getElementById("m1.1.8").value.replace(/[^\d\.\-]/g, ""));
        var numTotalTransferred = parseFloat(document.getElementById("t1.1.8").value.replace(/[^\d\.\-]/g, ""));
        var numTotalPaid = parseFloat(document.getElementById("1.1.9").value.replace(/[^\d\.\-]/g, ""));
        var att = numTotalTransferred - numTotalPaid;
        var att2 = (att / (numTotalTransferred)) * 100;
        document.getElementById("t1.1.8").value = num3 + num4;
        document.getElementById("q").value = att2.toFixed(2);
        document.getElementById("p").value = att;
        let px = document.getElementById("p").value;
        let qx = document.getElementById("q").value;
        let cc = "NaN";
        if(px == cc) {
            document.getElementById("p").value = "0";
        }
        if(qx == cc) {
            document.getElementById("q").value = "0";
        }
    }

    function test() {
        var c = parseFloat(document.getElementById("t1.1.1").value.replace(/[^\d\.\-]/g, ""));
        var d = parseFloat(document.getElementById("a1.1.1").value.replace(/[^\d\.\-]/g, ""));
        var e = parseFloat(document.getElementById("ci1.1.1").value.replace(/[^\d\.\-]/g, ""));
        var f = parseFloat(document.getElementById("up1.1.1").value.replace(/[^\d\.\-]/g, ""));
        var g = parseFloat(document.getElementById("psn1.1.1").value.replace(/[^\d\.\-]/g, ""));
        var cmt1 = document.getElementById("comment1").value.length;
        var set1 = d + e + f + g;
        var ent = parseFloat(document.getElementById("enT").value.replace(/[^\d\.\-]/g, ""));
        var o = parseFloat(document.getElementById("af1.1.5").value.replace(/[^\d\.\-]/g, ""));
        var p = parseFloat(document.getElementById("am1.1.5").value.replace(/[^\d\.\-]/g, ""));
        var q = parseFloat(document.getElementById("cif1.1.5").value.replace(/[^\d\.\-]/g, ""));
        var r = parseFloat(document.getElementById("cim1.1.5").value.replace(/[^\d\.\-]/g, ""));
        var s = parseFloat(document.getElementById("upf1.1.5").value.replace(/[^\d\.\-]/g, ""));
        var t = parseFloat(document.getElementById("upm1.1.5").value.replace(/[^\d\.\-]/g, ""));
        var u = parseFloat(document.getElementById("pnf1.1.5").value.replace(/[^\d\.\-]/g, ""));
        var v = parseFloat(document.getElementById("pnm1.1.5").value.replace(/[^\d\.\-]/g, ""));
        var cmt2 = document.getElementById("comment2").value.length;
        var set2 = o + p + q + r + s + t + u + v;
        var a3 = parseFloat(document.getElementById("t1.1.8").value.replace(/[^\d\.\-]/g, ""));
        var a4 = parseFloat(document.getElementById("af1.1.8").value.replace(/[^\d\.\-]/g, ""));
        var a5 = parseFloat(document.getElementById("am1.1.8").value.replace(/[^\d\.\-]/g, ""));
        var a6 = parseFloat(document.getElementById("cif1.1.8").value.replace(/[^\d\.\-]/g, ""));
        var a7 = parseFloat(document.getElementById("cim1.1.8").value.replace(/[^\d\.\-]/g, ""));
        var a8 = parseFloat(document.getElementById("upf1.1.8").value.replace(/[^\d\.\-]/g, ""));
        var a9 = parseFloat(document.getElementById("upm1.1.8").value.replace(/[^\d\.\-]/g, ""));
        var a10 = parseFloat(document.getElementById("pnf1.1.8").value.replace(/[^\d\.\-]/g, ""));
        var a11 = parseFloat(document.getElementById("pnm1.1.8").value.replace(/[^\d\.\-]/g, ""));
        var a12 = parseFloat(document.getElementById("1.1.9").value.replace(/[^\d\.\-]/g, ""));
        var cmt3 = document.getElementById("comment3").value.length;
        var set3 = a4 + a5 + a6 + a7 + a8 + a9 + a10 + a11;
        var a15 = parseFloat(document.getElementById("t1.1.10").value.replace(/[^\d\.\-]/g, ""));
        var a16 = parseFloat(document.getElementById("af1.1.10").value.replace(/[^\d\.\-]/g, ""));
        var a17 = parseFloat(document.getElementById("am1.1.10").value.replace(/[^\d\.\-]/g, ""));
        var a18 = parseFloat(document.getElementById("cif1.1.10").value.replace(/[^\d\.\-]/g, ""));
        var a19 = parseFloat(document.getElementById("cim1.1.10").value.replace(/[^\d\.\-]/g, ""));
        var a20 = parseFloat(document.getElementById("upf1.1.10").value.replace(/[^\d\.\-]/g, ""));
        var a21 = parseFloat(document.getElementById("upm1.1.10").value.replace(/[^\d\.\-]/g, ""));
        var a22 = parseFloat(document.getElementById("pnf1.1.10").value.replace(/[^\d\.\-]/g, ""));
        var a23 = parseFloat(document.getElementById("pnm1.1.10").value.replace(/[^\d\.\-]/g, ""));
        var cmt4 = document.getElementById("comment4").value.length;
        var set4 = a16 + a17 + a18 + a19 + a20 + a21 + a22 + a23;
        var state = document.getElementById("states").value;
        var none = "none";
        if(state === "none") {
            document.getElementById("states").style.backgroundColor = "red";
            alert("Error: Select your State");
        } else if(c !== set1 && cmt1 < 1) {
            document.getElementById("t1.1.1").style.backgroundColor = "red";
            document.getElementById("comment1").style.backgroundColor = "red";
            document.getElementById("comment1").style.display = "block";
            alert("Error: \nTotal Number of Beneficiaries mined from Agreed Register not equal input reason");
        } else if(ent !== set2 && cmt2 < 1) {
            document.getElementById("enT").style.backgroundColor = "red";
            document.getElementById("comment2").style.backgroundColor = "red";
            document.getElementById("comment2").style.display = "block";
            alert("Error: \nCheck Total Number of Beneficiaries enrolled");
        } else if(a3 !== set3 && cmt3 < 1) {
            document.getElementById("t1.1.8").style.backgroundColor = "red";
            document.getElementById("comment3").style.backgroundColor = "red";
            document.getElementById("comment3").style.display = "block";
            alert("Error: \nCheck Total Number of Beneficiaries transferred to PSP for payment");
        } else if(a15 !== set4 && cmt4 < 1) {
            document.getElementById("t1.1.10").style.backgroundColor = "red";
            document.getElementById("comment4").style.backgroundColor = "red";
            document.getElementById("comment4").style.display = "block";
            alert("Error: \nCheck Total Number of Beneficiaries that confirm receipt of periodic social transfer");
        } else {
            document.getElementById("sbt").disabled = false;
            alert("No Error found \nYou can proceed to submit");
        }
    }

    document.getElementById("timestamp").value = new Date().toLocaleString();

</script>
</body>

</html>
