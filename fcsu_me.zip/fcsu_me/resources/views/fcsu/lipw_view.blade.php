<!DOCTYPE html>
<html>
<head lang="en">
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <link
        href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css"
        rel="stylesheet"
    />
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.0/jquery.validate.min.js"></script>
    <script
        src="https://code.jquery.com/jquery-3.4.1.js"
        integrity="sha256-WpOohJOqMqqyKL9FccASB9O0KwACQJpFTUBLTYOVvVU="
        crossorigin="anonymous"></script>
    {{--  <script>
          function SubForm (){
              $.ajax({
                  url:"https://api.apispreadsheets.com/data/cNu8fKvruGoN7cjc/",
                  type:"post",
                  data:$("#formid").serializeArray(),
                  headers:{
                      accessKey: "19218b237dc8618c20e44f7dcc177f24",
                      secretKey: "af095d33c9f17975aaee1a4ae95a33a9"},
                  success: function() {
                      location.reload(true);
                      alert("LIPW (DLI 1.2) Form Data Submitted Successfully");
                  },
                  error: function() {
                      alert("Network Error: 404");
                  }
              });
          }
      </script>--}}

    <title>LIPW (DLI 1.2)</title>
</head>
<body>
<div class="container p-5 my-5 border">
    <div class="col-md-6 text-right">
        <a href="{{ url()->previous() }}" class="btn btn-lg" style="background-color: #12d3e0;">Back to Result Area</a>
    </div>
    <br />
    <div class="card-header" style="background-color: #506dee;">
        <h2
            style="
            margin-top: 10px;
            margin-left: 10px;
            color: white;
            text-align: center;
          ">
            M&E-- LABOUR INTENSIVE PUBLIC WORKS (DLI 1.2)
        </h2>
    </div>
    <h4 style="text-align: center;">Fill in the information carefully in the appropriate spaces</h4>
    <form method="post" action="{{ route('lipws.strans', $data->id) }}" >
        @csrf
        @method('patch')
        <div class="container border border-primary p-4">
            <div class="row">
                <div class="card-header col-md-4 col-xs-12" style="background-color: #506dee;">
                    <label for="states" style="color: white;"
                    >Select Your State<span style="color: rgb(253, 237, 10);"
                        >(*)</span
                        ></label>
                    <select class="form-control" disabled
                            name="state_id" required>
                        <option value="">Select State</option>
                        @foreach($states as $state)
                            <option @if($data->state_id==$state->id) selected @endif
                            value="{{ $state->id }}">{{ $state->state }}</option>
                        @endforeach
                    </select>
                    @if ($errors->has('state_id'))
                        <span class="text-danger text-left">{{ $errors->first('state_id') }}</span>
                    @endif
                </div>
                <div class="card-header col-md-4 col-xs-12" style="background-color: #2198b1;">


                    <label for="DPs" style="color: white;"
                    >Select Your DP<span style="color: rgb(253, 237, 10);"
                        >(*)</span
                        ></label>
                    <select class="form-control" disabled
                            name="dp_id" required>
                        <option value="">Select DP</option>
                        @foreach($dps as $dp)
                            <option @if($data->dp_id==$dp->id) selected @endif
                            value="{{ $dp->id }}">{{ $dp->name }}</option>
                        @endforeach
                    </select>
                    @if ($errors->has('dp_id'))
                        <span class="text-danger text-left">{{ $errors->first('dp_id') }}</span>
                    @endif
                </div>
                <div class="card-header col-md-4 col-xs-12" style="background-color: #2198b1;">
                    <label for="monthyear" style="color: white;"
                    >Select Month<span style="color: rgb(253, 237, 10);"
                        >(*)</span
                        ></label>
                    <select class="form-control" disabled
                            name="monthyear" required>
                        <option value="">Select Month</option>
                        @foreach($months as $month)
                            <option @if($data->monthyear==$month->id) selected @endif
                            value="{{ $month->id }}">{{ $month->date }}</option>
                        @endforeach
                    </select>
                    @if ($errors->has('monthyear'))
                        <span class="text-danger text-left">{{ $errors->first('monthyear') }}</span>
                    @endif
                </div>


                <label for="DPs" style="color: white;"
                    >Select Your DP<span style="color: rgb(253, 237, 10);"
                        >(*)</span
                        ></label>
                    <select class="form-control" disabled
                            name="dp_id" required>
                        <option value="">Select DP</option>
                        @foreach($dps as $dp)
                            <option @if($data->dp_id==$dp->id) selected @endif
                            value="{{ $dp->id }}">{{ $dp->name }}</option>
                        @endforeach
                    </select>
                    @if ($errors->has('dp_id'))
                        <span class="text-danger text-left">{{ $errors->first('dp_id') }}</span>
                    @endif
                </div>
                <div class="card-header col-md-4 col-xs-12" style="background-color: #2198b1;">
                    <label for="monthyear" style="color: white;"
                    >Select Month<span style="color: rgb(253, 237, 10);"
                        >(*)</span
                        ></label>
                    <select class="form-control" disabled
                            name="monthyear" required>
                        <option value="">Select Month</option>
                        @foreach($months as $month)
                            <option @if($data->monthyear==$month->id) selected @endif
                            value="{{ $month->id }}">{{ $month->date }}</option>
                        @endforeach
                    </select>
                    @if ($errors->has('monthyear'))
                        <span class="text-danger text-left">{{ $errors->first('monthyear') }}</span>
                    @endif
                </div>

            </div>
            <br />

            <!-- ////////////////////////////////////////////////////// -->
            <div class="row">
              <span class="card-footer" style="color: white; background-color: #506dee;">
                Total Number of Beneficiaries mined from Agreed Register</span>
                <div class="col-md-4">
                    <label>Female</label>
                    <input type="text" class="form-control" value="{{ $data->f_mined }}" name="f_mined" id="a" onkeyup="sum()" readonly />
                </div>
                <div class="col-md-4">
                    <label>Male</label>
                    <input type="text" class="form-control" value="{{ $data->m_mined }}" name="m_mined" id="b" onkeyup="sum()" readonly/>
                </div>
                <div class="col-md-4">
                    <label>Total</label>
                    <input type="text" class="form-control" value="{{ $data->tot_mined }}" name="tot_mined" id="c=a+b" readonly />
                </div>
            </div>
            <br />
            <div class="row">
              <span class="card-footer" style="color: white; background-color: #506dee;">
                Total Number of mined Beneficiaries validated</span>
                <div class="col-md-4">
                    <label>Female</label>
                    <input type="text" class="form-control" value="{{ $data->f_validated }}" name="f_validated" id="d" onkeyup="sum()" readonly/>
                </div>
                <div class="col-md-4">
                    <label>Male</label>
                    <input type="text" class="form-control" value="{{ $data->m_validated }}" name="m_validated" id="e" onkeyup="sum()" readonly/>
                </div>
                <div class="col-md-4">
                    <label>Total</label>
                    <input type="text" class="form-control" value="{{ $data->tot_validated }}" name="tot_validated" id="f=d+e" readonly />
                </div>
            </div>
            <br />
            <div class="row">
              <span class="card-footer" style="color: white; background-color: #506dee;">
                 Attrition (Mined minus Validated)</span>
                <div class="col-md-3">
                    <label>Female</label>
                    <input type="text" class="form-control" value="{{ $data->att_fminedval }}" name="att_fminedval" id="g=a-d" readonly />
                </div>
                <div class="col-md-3">
                    <label>Male</label>
                    <input type="text" class="form-control" value="{{ $data->att_mminedval }}" name="att_mminedval" id="h=b-e" readonly />
                </div>
                <div class="col-md-3">
                    <label>Total</label>
                    <input type="text" class="form-control" value="{{ $data->att_totminedval }}" name="att_totminedval" id="i=c-f" readonly />
                </div>
                <div class="col-md-3">
                    <label>Percent Attrition</label>
                    <input type="text" class="form-control" value="{{ $data->att_minedvalpercent }}" name="att_minedvalpercent" id="j=i%" readonly />
                </div>
            </div>
            <br />
            <div class="row">
                <div class="col-md-12">
                    <input style="display: block;" class="form-control" type="" value="{{ $data->p_att }}" name="p_att" placeholder="Attrition Remarks" />
                </div>
            </div>
            <br />
            <div class="row">
              <span class="card-footer" style="color: white; background-color: #506dee;">
                Number Enrolled/Engaged into LIPW activities on Social services and works</span>
                <div class="col-md-4">
                    <label>Female</label>
                    <input type="text" class="form-control" value="{{ $data->f_enrolled }}" name="f_enrolled" id="k" onkeyup="sum()" readonly/>
                </div>
                <div class="col-md-4">
                    <label>Male</label>
                    <input type="text" class="form-control" value="{{ $data->m_enrolled }}" name="m_enrolled" id="l" onkeyup="sum()" readonly/>
                </div>
                <div class="col-md-4">
                    <label>Total</label>
                    <input type="text" class="form-control" value="{{ $data->tot_enrolled }}" name="tot_enrolled" id="m=k+l" readonly />
                </div>
            </div>
            <br />
            <div class="row">
              <span class="card-footer" style="color: white; background-color: #506dee;">
                Number Deployed into LIPW activities on Social services and works</span>
                <div class="col-md-4">
                    <label>Female</label>
                    <input type="text" class="form-control" value="{{ $data->f_deploy }}" name="f_deploy" id="n" onkeyup="sum()" readonly/>
                </div>
                <div class="col-md-4">
                    <label>Male</label>
                    <input type="text" class="form-control" value="{{ $data->m_deploy }}" name="m_deploy" id="o" onkeyup="sum()" readonly/>
                </div>
                <div class="col-md-4">
                    <label>Total</label>
                    <input type="text" class="form-control" value="{{ $data->tot_deploy }}" name="tot_deploy" id="p=n+o" readonly />
                </div>
            </div>
            <br />
            <div class="row">
              <span class="card-footer" style="color: white; background-color: #506dee;">
                Attrition (Enrolled minus Deployed)</span>
                <div class="col-md-3">
                    <label>Female</label>
                    <input type="text" class="form-control" value="{{ $data->att_fenr_deploy }}" name="att_fenr_deploy" id="q = k-n" readonly />
                </div>
                <div class="col-md-3">
                    <label>Male</label>
                    <input type="text" class="form-control" value="{{ $data->att_menr_deploy }}" name="att_menr_deploy" id="r=L-o" readonly />
                </div>
                <div class="col-md-3">
                    <label>Total</label>
                    <input type="text" class="form-control" value="{{ $data->att_totenr_deploy }}" name="att_totenr_deploy" id="s=m-p" readonly />
                </div>
                <div class="col-md-3">
                    <label>Percent Attrition</label>
                    <input type="text" class="form-control" value="{{ $data->att_enr_deployed }}" name="att_enr_deployed" id="t=s%" readonly />
                </div>
            </div>
            <br />
            <div class="row">
                <div class="col-md-12">
                    <input style="display: block;" class="form-control" type="" value="{{ $data->comment }}" name="comment" placeholder="Attrition Remarks" readonly/>
                </div>
            </div>
            <br />
            <div class="row">
              <span class="card-header col-md-4" style="color: white; background-color: #506dee;">
                Number of working days/beneficiary (Days) </span>
                <div class="col-md-2">
                    <input type="text" class="form-control" value="{{ $data->num_workdays }}" name="num_workdays" id="u" onkeyup="sum()" readonly/>
                </div>
                <span class="card-header col-md-4" style="color: white; background-color: #506dee;">
                Total Amount transferred to PSP (NGN) </span>
                <div class="col-md-2">
                    <input type="text" class="form-control" value="{{ $data->amt_transpsp }}" name="amt_transpsp" id="v" onkeyup="sum()" readonly />
                </div>
            </div>
            <br />
            <div class="row">
              <span class="card-footer" style="color: white; background-color: #506dee;">
                Total Number of Beneficiaries transferred to PSP for payment</span>
                <div class="col-md-4">
                    <label>Female</label>
                    <input type="text" class="form-control" value="{{ $data->tot_fbeneforpsppay }}" name="tot_fbeneforpsppay" id="w" onkeyup="sum()" readonly/>
                </div>
                <div class="col-md-4">
                    <label>Male</label>
                    <input type="text" class="form-control" value="{{ $data->tot_mbeneforpsppay }}" name="tot_mbeneforpsppay" id="x" onkeyup="sum()" readonly/>
                </div>
                <div class="col-md-4">
                    <label>Total</label>
                    <input type="text" class="form-control" value="{{ $data->tot_beneforpsppay }}" name="tot_beneforpsppay" id="TotalBT" readonly />
                </div>
            </div>
            <br />
            <div class="row">
              <span class="card-footer" style="color: white; background-color: #506dee;">
                Total Number of Beneficiaries paid </span>
                <div class="col-md-4">
                    <label>Female</label>
                    <input type="text" class="form-control" value="{{ $data->tot_fbenepaid }}" name="tot_fbenepaid" id="z" onkeyup="sum()" readonly />
                </div>
                <div class="col-md-4">
                    <label>Male</label>
                    <input type="text" class="form-control" value="{{ $data->tot_mbenepaid }}" name="tot_mbenepaid" id="a1" onkeyup="sum()" readonly />
                </div>
                <div class="col-md-4">
                    <label>Total</label>
                    <input type="text" class="form-control" value="{{ $data->tot_benepaid }}" name="tot_benepaid" id="TotalBpaid" readonly />
                </div>
            </div>
            <br />
            <div class="row">
              <span class="card-footer" style="color: white; background-color: #506dee;">
                Attrition (Total Number of Beneficiaries Transfered Minus Paid) </span>
                <div class="col-md-3">
                    <label>Female</label>
                    <input type="text" class="form-control" value="{{ $data->att_fbenepaid }}" name="att_fbenepaid" id="z1" readonly onkeyup="sum()" />
                </div>
                <div class="col-md-3">
                    <label>Male</label>
                    <input type="text" class="form-control" value="{{ $data->att_mbenepaid }}" name="att_mbenepaid" id="a11" onkeyup="sum()" readonly />
                </div>
                <div class="col-md-3">
                    <label>Attrition</label>
                    <input type="text" class="form-control" value="{{ $data->att_benepaid }}" name="att_benepaid" id="p" readonly />
                </div>
                <div class="col-md-3">
                    <label>Percent Attrition</label>
                    <input type="text" class="form-control" value="{{ $data->att_pcent_benepaid }}" name="att_pcent_benepaid" id="q" readonly />
                </div>
            </div>
            <br />
            <div class="row">
                <div class="col-md-12">
                    <input style="display: block;" class="form-control" type="" value="{{ $data->commenta }}" name="commenta" id="commenta" placeholder="Attrition Remarks" readonly />
                </div>
            </div>
            <br />
            <div class="row">
                <span class="card-header col-md-4" style="color: white; background-color: #506dee;"> Total Amount paid to Beneficiaries (N) </span>
                <div class="col-md-2">
                    <input type="text" class="form-control" value="{{ $data->amountbpaid }}" name="amountbpaid" id="AmountBpaid" onkeyup="sum()" readonly />
                </div>
            </div>
            <br />
            <div class="row">
                <span class="card-header col-md-4" style="color: white; background-color: #506dee;"> Total Attrition </span>
                <div class="col-md-2">
                    <input type="text" class="form-control" value="{{ $data->attbpaid }}" name="attbpaid" id="AttBpaid" readonly />
                </div>
                <span class="card-header col-md-4" style="color: white; background-color: #506dee;"> Percent Attrition (%) </span>
                <div class="col-md-2">
                    <input type="" class="form-control" value="{{ $data->attpaidp }}" name="attbpaidp" id="AttBpaidp" readonly />
                </div>
            </div>
            <br />
            <div class="row">
                <div class="col-md-12">
                    <input style="display: block;" class="form-control" type="" value="{{ $data->comment4 }}" name="comment4" id="comment4" placeholder="Attittion Remarks" readonly/>
                </div>
            </div>
            <br />
            @if($data->status_id == 2 && $data->dp_id == Auth::user()->dp_id)
                <div class="card-header col-md-4 col-xs-12" style="background-color: #506dee;">
                    <label for="states" style="color: white;"
                    >Approve status<span style="color: rgb(253, 237, 10);"
                        >(*)</span
                        ></label>
                    <select class="form-control" disabled
                            name="approval_id" required>
                        <option value="">DP Approved</option>

                    </select>
                </div>
            @elseif($data->status_id == 3)
                <div class="card-header col-md-4 col-xs-12" style="background-color: #506dee;">
                    <label for="states" style="color: white;"
                    >Submission Status<span style="color: rgb(253, 237, 10);"
                        >(*)</span
                        ></label>
                    <select class="form-control" disabled
                            name="approval_id" required>
                        <option value="">Sent to FCSU</option>

                    </select>
                </div>
            @elseif($data->status_id != 2 && $data->dp_id == Auth::user()->dp_id)
                <div class="card-header col-md-4 col-xs-12" style="background-color: #506dee;">
                    <label for="states" style="color: white;"
                    >Approve this submission<span style="color: rgb(253, 237, 10);"
                        >(*)</span
                        ></label>
                    <select class="form-control"
                            name="approval_id" required>
                        <option value="">Select Status</option>
                        @foreach($approvals as $status)
                            <option @if($data->status_id==$status->id) selected @endif
                            value="{{ $status->id }}">{{ $status->name }}</option>
                        @endforeach
                    </select>
                    @if ($errors->has('approval_id'))
                        <span class="text-danger text-left">{{ $errors->first('approval_id') }}</span>
                    @endif
                </div>

            @endif

            <br/>
        </div>

        <br />
        <input type="hidden" name="timestamp" id="timestamp" />
        <br />
        @if($data->dp_id == Auth::user()->dp_id)
            <div class="col-md-6 col-xs-12">
                <input type="submit" class="btn btn-primary btn-sm" />
            </div>
        @endif
    </form>

</div>

<script type="text/javascript">

    (function ($, undefined) {
        "use strict";

        // When ready.
        $(function () {
            var $form = $("#formid");
            var $input = $form.find('input[type="text"]');

            $input.on("keyup", function (event) {
                // When user select text in the document, also abort.
                var selection = window.getSelection().toString();
                if (selection !== "") {
                    return;
                }

                // When the arrow keys are pressed, abort.
                if ($.inArray(event.keyCode, [38, 40, 37, 39]) !== -1) {
                    return;
                }

                var $this = $(this);

                // Get the value.
                var input = $this.val();

                var input = input.replace(/[\D\s\._\-]+/g, "");
                input = input ? parseFloat(input, 10) : 0;

                $this.val(function () {
                    return input === 0 ? "" : input.toLocaleString("en-US");
                });
            });
        });
    })(jQuery);

    function sum() {
        let a = parseFloat(
            document.getElementById("a").value.replace(/[^\d\.\-]/g, "")
        );
        let b = parseFloat(
            document.getElementById("b").value.replace(/[^\d\.\-]/g, "")
        );
        let d = parseFloat(
            document.getElementById("d").value.replace(/[^\d\.\-]/g, "")
        );
        let e = parseFloat(
            document.getElementById("e").value.replace(/[^\d\.\-]/g, "")
        );
        let k = parseFloat(
            document.getElementById("k").value.replace(/[^\d\.\-]/g, "")
        );
        let l = parseFloat(
            document.getElementById("l").value.replace(/[^\d\.\-]/g, "")
        );
        let n = parseFloat(
            document.getElementById("n").value.replace(/[^\d\.\-]/g, "")
        );
        let o = parseFloat(
            document.getElementById("o").value.replace(/[^\d\.\-]/g, "")
        );
        let v = parseFloat(
            document.getElementById("v").value.replace(/[^\d\.\-]/g, "")
        );
        let w = parseFloat(
            document.getElementById("w").value.replace(/[^\d\.\-]/g, "")
        );
        let x = parseFloat(
            document.getElementById("x").value.replace(/[^\d\.\-]/g, "")
        );
        let z = parseFloat(
            document.getElementById("z").value.replace(/[^\d\.\-]/g, "")
        );
        let a1 = parseFloat(
            document.getElementById("a1").value.replace(/[^\d\.\-]/g, "")
        );
        let AmountBpaid = parseFloat(
            document.getElementById("AmountBpaid").value.replace(/[^\d\.\-]/g, "")
        );
        let AttBpaid = v - AmountBpaid;
        let AttBpaidp = ((AttBpaid/v)*100).toFixed(2);
        let a11 = x - a1;
        let z1 = w - z;

        document.getElementById("c=a+b").value = a + b;
        document.getElementById("f=d+e").value = d + e;
        document.getElementById("g=a-d").value = a - d;
        document.getElementById("h=b-e").value = b - e;
        document.getElementById("i=c-f").value = ((a + b) - (d + e));
        document.getElementById("j=i%").value = ((((a + b) - (d + e)) / (a + b)) * 100).toFixed(2);
        document.getElementById("m=k+l").value = k + l;
        document.getElementById("p=n+o").value = n + o;
        document.getElementById("q = k-n").value = k - n;
        document.getElementById("r=L-o").value = l - o;
        document.getElementById("s=m-p").value = ((k + l) - (n + o));
        document.getElementById("t=s%").value = ((((k + l) - (n + o)) / (k + l)) * 100).toFixed(2);
        document.getElementById("TotalBT").value = w + x;
        document.getElementById("TotalBpaid").value = z + a1;
        document.getElementById("AttBpaid").value = AttBpaid;
        document.getElementById("AttBpaidp").value = AttBpaidp;
        document.getElementById("a11").value = a11;
        document.getElementById("z1").value = z1;
        document.getElementById("p").value = (w + x) - (z + a1);
        document.getElementById("q").value = ((((w + x) - (z + a1))/(z + a1))*100).toFixed(2);


        let c = document.getElementById("c=a+b").value;
        let f = document.getElementById("f=d+e").value;
        let g = document.getElementById("g=a-d").value;
        let h = document.getElementById("h=b-e").value;
        let i = document.getElementById("i=c-f").value;
        let j = document.getElementById("j=i%").value;
        let m = document.getElementById("m=k+l").value;
        let p = document.getElementById("p=n+o").value;
        let q = document.getElementById("q = k-n").value;
        let r = document.getElementById("r=L-o").value;
        let s = document.getElementById("s=m-p").value;
        let t = document.getElementById("t=s%").value;
        let y = document.getElementById("TotalBT").value;
        let b1 = document.getElementById("TotalBpaid").value;
        let b2 = document.getElementById("p").value;
        let b3 = document.getElementById("q").value;
        let z1x = document.getElementById("z1").value;
        let a11x = document.getElementById("a11").value;
        let AmountBpaidx = document.getElementById("AmountBpaid").value;
        let AttBpaidx = document.getElementById("AttBpaid").value;
        let AttBpaidpx = document.getElementById("AttBpaidp").value;
        let cc = "NaN";


        if (c == cc) {
            document.getElementById("c=a+b").value = "0";
        }
        if (f == cc) {
            document.getElementById("f=d+e").value = "0";
        }
        if (g == cc) {
            document.getElementById("g=a-d").value = "0";
        }
        if (h == cc) {
            document.getElementById("h=b-e").value = "0";
        }
        if (i == cc) {
            document.getElementById("i=c-f").value = "0";
        }
        if (j == cc) {
            document.getElementById("j=i%").value = "0";
        }
        if (m == cc) {
            document.getElementById("m=k+l").value = "0";
        }
        if (p == cc) {
            document.getElementById("p=n+o").value = "0";
        }
        if (q == cc) {
            document.getElementById("q = k-n").value = "0";
        }
        if (r == cc) {
            document.getElementById("r=L-o").value = "0";
        }
        if (s == cc) {
            document.getElementById("s=m-p").value = "0";
        }
        if (t == cc) {
            document.getElementById("t=s%").value = "0";
        }
        if (y == cc) {
            document.getElementById("TotalBT").value = "0";
        }
        if (b1 == cc) {
            document.getElementById("TotalBpaid").value = "0";
        }
        if (b2 == cc) {
            document.getElementById("p").value = "0";
        }
        if (b3 == cc) {
            document.getElementById("q").value = "0";
        }
        if (z1x == cc) {
            document.getElementById("z1").value = "0";
        }
        if (a11x == cc) {
            document.getElementById("a11").value = "0";
        }
        if (AmountBpaidx == cc) {
            document.getElementById("AmountBpaid").value = "0";
        }
        if (AttBpaidx == cc) {
            document.getElementById("AttBpaid").value = "0";
        }
        if (AttBpaidpx == cc) {
            document.getElementById("AttBpaidp").value = "0";
        }

        let state = document.getElementById("states").value;
        let none = "none";
        if (state === "none") {
            document.getElementById("states").style.backgroundColor = "red";
            alert("Error: Select your State");
        } else
            document.getElementById("states").style.backgroundColor = "white";
    }

    document.getElementById("timestamp").value = new Date().toLocaleString();

</script>
</body>
</html>
<?php
