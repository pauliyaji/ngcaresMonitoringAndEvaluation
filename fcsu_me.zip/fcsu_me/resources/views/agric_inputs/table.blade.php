<table class="table table-bordered" id="dataTable">
    <thead>
    <tr>
        <th>#</th>
        <th>State</th>
        <th>DLi</th>
        <th>Status</th>
        <th>Period</th>
        <th>Date</th>
        <th>Action</th>

    </tr>
    </thead>

    <tbody>
    @if($data)
        @foreach($data as $d)
            <tr>
                <td>{{ $d->id }}</td>
                <td>{{ $d->states->state }}</td>
                <td>{{ $d->dli->title  }}</td>
                <td style="color: green; font-weight: bold">{{ $d->status->status }}</td>
                <td> {{ $d->months->date }}</td>
                <td>{{ date('d-M-Y', strtotime($d->created_at)) }}</td>
                <td>
                    @if(Auth::user()->id == 1)
                        <a href="{{ route('agric_inputs.show', $d->id) }}" class="btn btn-info btn-sm"><i class="fa fa-eye"></i></a>
                        <a href="{{ route('agric_inputs.edit', $d->id) }}" class="btn btn-primary btn-sm"><i class="fa fa-edit"></i></a>
                    @elseif($d->user_id == Auth::user()->id && $d->status_id != 3)
                        <a href="{{ route('agric_inputs.edit', $d->id) }}" class="btn btn-primary btn-sm"><i class="fa fa-edit"></i></a>
                    @elseif($d->user_id == Auth::user()->id)
                        <a href="{{ route('agric_inputs.show', $d->id) }}" class="btn btn-info btn-sm"><i class="fa fa-eye"></i></a>
                    @endif
                </td>
            </tr>
        @endforeach
    @endif
    </tbody>
</table>
