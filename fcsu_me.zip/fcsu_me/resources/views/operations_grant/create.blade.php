<!DOCTYPE html>
<html>
<head lang="en">
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" />
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css" />
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.0/jquery.validate.min.js"></script>
    <title>Operational Support Grants</title>
</head>
<body>
<div class="container p-5 my-5 border">
    <div class="col-md-6 text-right">
        <a href="{{ url()->previous() }}" class="btn btn-info">Back to Result Area</a>
    </div>
    <br />
    <div class="card-header" style="background-color: #0987b9;">
        <h2 style="margin-top: 10px; margin-left: 10px; color: white; text-align: center;"> M&E-- OPERATIONAL SUPPORT GRANT (DLI 3.2) </h2>
    </div>
    <h4 style="text-align:center;">Fill in the information carefully in the appropriate spaces</h4>
    <form method="post" action="{{ route('operations_grant.store') }}" id="formid">
        @csrf
        <div class="container border border-info p-4">
            <div class="card-header col-md-4 col-xs-12" style="background-color: #506dee;">
                <label for="states" style="color: white;"
                >Select Month<span style="color: rgb(253, 237, 10);"
                    >(*)</span
                    ></label>
                <select class="form-control"
                        name="monthyear" required>
                    <option value="">Select Month</option>
                    @foreach($months as $month)
                        <option value="{{ $month->id }}"
                            {{$month->date}}>{{ $month->date }}</option>
                    @endforeach
                </select>
                @if ($errors->has('monthyear'))
                    <span class="text-danger text-left">{{ $errors->first('monthyear') }}</span>
                @endif
            </div>

            <br />
            <div class="row">
            <span class="card-header  col-md-8" style="color: white; background-color: #0987b9;">
              Total Number of registered firms for operational grants </span>
                <div class="col-md-4">
                    <input type="text" class="form-control to" name="tot_reg_ops" id="registered" readonly />
                </div>
            </div>
            <br />
            <div class="row">
                <span class="card-footer " style="color: white; background-color: #0987b9;"> Micro scale Firms</span>
                <div class="col-md-4">
                    <label>Male Owners</label>
                    <input type="text" class="form-control" name="tot_reg_opsmmicro" id="c" onkeyup="sum()" />
                </div>
                <div class="col-md-4">
                    <label>Female Owners</label>
                    <input type="text" class="form-control" name="tot_reg_opsfmicro" id="d" onkeyup="sum()" />
                </div>
                <div class="col-md-4">
                    <label>Total</label>
                    <input type="text" readonly class="form-control to" name="tot_reg_opsmicro" id="e" />
                </div>
            </div>
            <br />
            <div class="row">
                <span class="card-footer " style="color: white; background-color: #0987b9;"> Small Scale Firms </span>
                <div class="col-md-4">
                    <label>Male Owners</label>
                    <input type="text" class="form-control" name="tot_reg_opsmsmall" id="f" onkeyup="sum()" />
                </div>
                <div class="col-md-4">
                    <label>Female Owners</label>
                    <input type="text" class="form-control" name="tot_reg_opsfsmall" id="g" onkeyup="sum()" />
                </div>
                <div class="col-md-4">
                    <label>Total</label>
                    <input type="text" readonly class="form-control to" name="tot_reg_opssmall" id="h" />
                </div>
            </div>
            <br />
            <div class="row">
            <span class="card-header  col-md-8" style="color: white; background-color: #0987b9;">
              The Total Number of firms that are eligible and has been verified for operational grants </span>
                <div class="col-md-4">
                    <input type="text" class="form-control to" name="tot_eli_ver" id="verified" readonly />
                </div>
            </div>
            <br />
            <div class="row">
                <span class="card-footer " style="color: white; background-color: #0987b9;"> Micro scale Firms</span>
                <div class="col-md-4">
                    <label>Male Owners</label>
                    <input type="text" class="form-control" name="tot_eli_vermmicro" id="j" onkeyup="sum()" />
                </div>
                <div class="col-md-4">
                    <label>Female Owners</label>
                    <input type="text" class="form-control" name="tot_eli_verfmicro" id="k" onkeyup="sum()" />
                </div>
                <div class="col-md-4">
                    <label>Total</label>
                    <input type="text" readonly class="form-control to" name="tot_eli_vermicro" id="l" />
                </div>
            </div>
            <br />
            <div class="row">
                <span class="card-footer " style="color: white; background-color: #0987b9;"> Small Scale Firms </span>
                <div class="col-md-4">
                    <label>Male Owners</label>
                    <input type="text" class="form-control" name="tot_eli_vermsmall" id="m" onkeyup="sum()" />
                </div>
                <div class="col-md-4">
                    <label>Female Owners</label>
                    <input type="text" class="form-control" name="tot_eli_verfsmall" id="n" onkeyup="sum()" />
                </div>
                <div class="col-md-4">
                    <label>Total</label>
                    <input type="text" readonly class="form-control to" name="tot_eli_versmall" id="o" />
                </div>
            </div>
            <br />
            <div class="row">
            <span class="card-header  col-md-8" style="color: white; background-color: #0987b9;">
              Attrition (Registered Firms minus Verified Firms) </span>
                <div class="col-md-4">
                    <input type="text" class="form-control to" name="att_reg_minus_ver" id="AttritionRV" readonly />
                </div>
            </div>
            <br />
            <div class="row">
            <span class="card-header  col-md-8" style="color: white; background-color: #0987b9;">
              Total Number of selected firms for operational grants </span>
                <div class="col-md-4">
                    <input type="text" class="form-control to" name="tot_sel_ops" id="selected" readonly/>
                </div>
            </div>
            <br />
            <div class="row">
                <span class="card-footer " style="color: white; background-color: #0987b9;"> Micro scale Firms</span>
                <div class="col-md-4">
                    <label>Male Owners</label>
                    <input type="text" class="form-control" name="tot_sel_opsmmicro" id="r" onkeyup="sum()" />
                </div>
                <div class="col-md-4">
                    <label>Female Owners</label>
                    <input type="text" class="form-control" name="tot_sel_opsfmicro" id="s" onkeyup="sum()" />
                </div>
                <div class="col-md-4">
                    <label>Total</label>
                    <input type="text" readonly class="form-control to" name="tot_sel_opsmicro" id="t" />
                </div>
            </div>
            <br />
            <div class="row">
                <span class="card-footer " style="color: white; background-color: #0987b9;"> Small Scale Firms </span>
                <div class="col-md-4">
                    <label>Male Owners</label>
                    <input type="text" class="form-control" name="tot_sel_opsmsmall" id="u" onkeyup="sum()" />
                </div>
                <div class="col-md-4">
                    <label>Female Owners</label>
                    <input type="text" class="form-control" name="tot_sel_opsfsmall" id="v" onkeyup="sum()" />
                </div>
                <div class="col-md-4">
                    <label>Total</label>
                    <input type="text" class="form-control to" name="tot_sel_opssmall" id="w" readonly />
                </div>
            </div>
            <br />
            <div class="row">
            <span class="card-header  col-md-8" style="color: white; background-color: #0987b9;">
              Attrition (Verified Firms minus Selected Firms) </span>
                <div class="col-md-4">
                    <input type="text" class="form-control to" name="att_ver_minus_sel" id="AttritionVS" readonly />
                </div>
            </div>
            <br />
            <div class="row">
            <span class="card-header  col-md-8" style="color: white; background-color: #0987b9;">
              Total Number of firms receiving conditional – operational support grants </span>
                <div class="col-md-4">
                    <input type="text" class="form-control to" name="tot_rec_ops" id="receiving" readonly/>
                </div>
            </div>
            <br />
            <div class="row">
                <span class="card-footer " style="color: white; background-color: #0987b9;"> Micro scale Firms</span>
                <div class="col-md-4">
                    <label>Male Owners</label>
                    <input type="text" class="form-control" name="tot_rec_opsmmicro" id="y" onkeyup="sum()" />
                </div>
                <div class="col-md-4">
                    <label>Female Owners</label>
                    <input type="text" class="form-control" name="tot_rec_opsfmicro" id="z" onkeyup="sum()" />
                </div>
                <div class="col-md-4">
                    <label>Total</label>
                    <input type="text" readonly class="form-control to" name="tot_rec_opsmicro" id="a1" />
                </div>
            </div>
            <br />
            <div class="row">
                <span class="card-footer " style="color: white; background-color: #0987b9;"> Small Scale Firms </span>
                <div class="col-md-4">
                    <label>Male Owners</label>
                    <input type="text" class="form-control" name="tot_rec_opsmsmall" id="a2" onkeyup="sum()" />
                </div>
                <div class="col-md-4">
                    <label>Female Owners</label>
                    <input type="text" class="form-control" name="tot_rec_opsfsmall" id="a3" onkeyup="sum()" />
                </div>
                <div class="col-md-4">
                    <label>Total</label>
                    <input type="text" readonly class="form-control to" name="tot_rec_opssmall" id="a4" />
                </div>
            </div>
            <br />
            <div class="row">
            <span class="card-header  col-md-8" style="color: white; background-color: #0987b9;">
              Attrition (Selected Firms minus Receiving Firms) </span>
                <div class="col-md-4">
                    <input type="text" class="form-control" name="att_sel_minus_rec" id="AttritionSR" readonly />
                </div>
            </div>
            <br />

            <div class="row">
            <span class="card-header  col-md-10" style="color: white; background-color: #0987b9;">
              Firms working on mini solar panels receiving grants for operational support <br />  </span>
                <div class="col-md-2">
                    <input type="text" class="form-control to" name="tot_sol_rec" id="Disagregated" readonly />
                </div>
            </div>
            <br />
            <div class="row">
                <span class="card-footer " style="color: white; background-color: #0987b9;"> Micro scale Firms</span>
                <div class="col-md-4">
                    <label>Male Owners</label>
                    <input type="text" class="form-control" name="tot_sol_recmmicro" id="c1" onkeyup="sum()" />
                </div>
                <div class="col-md-4">
                    <label>Female Owners</label>
                    <input type="text" class="form-control" name="tot_sol_recfmicro" id="d1" onkeyup="sum()" />
                </div>
                <div class="col-md-4">
                    <label>Total</label>
                    <input type="text" readonly class="form-control to" name="tot_sol_recmicro" id="e1" />
                </div>
            </div>
            <br />
            <div class="row">
                <span class="card-footer " style="color: white; background-color: #0987b9;"> Small Scale Firms </span>
                <div class="col-md-4">
                    <label>Male Owners</label>
                    <input type="text" class="form-control" name="tot_sol_recmsmall" id="f1" onkeyup="sum()" />
                </div>
                <div class="col-md-4">
                    <label>Female Owners</label>
                    <input type="text" class="form-control" name="tot_sol_recfsmall" id="g1" onkeyup="sum()" />
                </div>
                <div class="col-md-4">
                    <label>Total</label>
                    <input type="text" readonly class="form-control" name="tot_sol_recsmall" id="h1" />
                </div>
            </div>
            <br />
            <div class="row">
            <span class="card-header  col-md-8" style="color: white; background-color: #0987b9;">
              Attrition (Selected Firms minus Receiving Firms) </span>
                <div class="col-md-4">
                    <input type="text" class="form-control" name="att_rec_minus_solrec" id="Attrg_rc" readonly />
                </div>
            </div>
            <br />
            <div class="row">
            <span class="card-header  col-md-8" style="color: white; background-color: #0987b9;">
              Amount disbursed to beneficiary firms for operational grants </span>
                <div class="col-md-4">
                    <input type="text" class="form-control to" name="tot_amt_dis" id="disbursed" readonly/>
                </div>
            </div>
            <br />
            <div class="row">
                <span class="card-footer " style="color: white; background-color: #0987b9;"> Micro scale Firms</span>
                <div class="col-md-4">
                    <label>Male Owners</label>
                    <input type="text" class="form-control" name="tot_amt_dismmicro" id="a7" onkeyup="sum()" />
                </div>
                <div class="col-md-4">
                    <label>Female Owners</label>
                    <input type="text" class="form-control" name="tot_amt_disfmicro" id="a8" onkeyup="sum()" />
                </div>
                <div class="col-md-4">
                    <label>Total</label>
                    <input type="text" readonly class="form-control to" name="tot_amt_dismicro" id="a9" />
                </div>
            </div>
            <br />
            <div class="row">
                <span class="card-footer " style="color: white; background-color: #0987b9;"> Small Scale Firms </span>
                <div class="col-md-4">
                    <label>Male Owners</label>
                    <input type="text" class="form-control" name="tot_amt_dismsmall" id="a10" onkeyup="sum()" />
                </div>
                <div class="col-md-4">
                    <label>Female Owners</label>
                    <input type="text" class="form-control" name="tot_amt_disfsmall" id="a11" onkeyup="sum()" />
                </div>
                <div class="col-md-4">
                    <label>Total</label>
                    <input type="text" readonly class="form-control to" name="tot_amt_dissmall" id="a12" />
                </div>
            </div>
            <br />
        </div>
        <br />
        <input type="hidden" name="timestamp" id="timestamp" />
        <br />
        <div class="col-md-6 col-xs-12">
            <input type="submit" class="btn btn-primary btn-sm" />
        </div>
    </form>
</div>

<script type="text/javascript">
    src = "https://code.jquery.com/jquery-3.4.1.js"
    integrity = "sha256-WpOohJOqMqqyKL9FccASB9O0KwACQJpFTUBLTYOVvVU="
    crossorigin = "anonymous"

    function SubForm (){
        $.ajax({
            url:"https://api.apispreadsheets.com/data/sxN6M4945Ey2hXa3/",
            type:"post",
            data:$("#formid").serializeArray(),
            headers:{
                accessKey: "e19835f6acbebc6a89d298e8a1fd6dc8",
                secretKey: "1a8f62a12e64fbd91b8b9838f87a8eae"},
            success: function() {
                location.reload(true);
                alert("Operation Grants (DLI 3.2) Form Data Submitted Successfully");
            },
            error: function() {
                alert("Network Error: 404");
            }
        });
    }
    // document.getElementById("timestamp").value = new Date().toLocaleString();
    //   function sb(){location.reload(true);alert("Data successfully submitted.");window.location.href = '../';}

    (function($, undefined) {
        "use strict";
        // When ready.
        $(function() {
            var $form = $("#formid");
            var $input = $form.find('input[type="text"]');
            $input.on("keyup", function(event) {
                // When user select text in the document, also abort.
                var selection = window.getSelection().toString();
                if (selection !== "") {
                    return;
                }
                // When the arrow keys are pressed, abort.
                if ($.inArray(event.keyCode, [38, 40, 37, 39]) !== -1) {
                    return;
                }
                var $this = $(this);
                // Get the value.
                var input = $this.val();
                var input = input.replace(/[\D\s\._\-]+/g, "");
                input = input ? parseFloat(input, 10) : 0;
                $this.val(function() {
                    return input === 0 ? "0" : input.toLocaleString("en-US");
                });
            });
        });
    })(jQuery);

    $(function() {
        var $form = $("#formid");
        var $input = $form.find('input[type="text"]');
        $input.on("keyup", function(e) {
            //////////////////////// registered firm //////////////////////////////////
            var a = parseFloat($("#c").val().replace(/[^\d\.\-]/g, ""));
            var b = parseFloat($("#d").val().replace(/[^\d\.\-]/g, ""));
            var c = parseFloat($("#f").val().replace(/[^\d\.\-]/g, ""));
            var d = parseFloat($("#g").val().replace(/[^\d\.\-]/g, ""));
            $("#e").val(a + b);
            $("#h").val(c + d);
            $('#registered').val(c + d + a + b);

            ///////////////////////// verified firm //////////////////////////////////
            var a = parseFloat($("#j").val().replace(/[^\d\.\-]/g, ""));
            var b = parseFloat($("#k").val().replace(/[^\d\.\-]/g, ""));
            var c = parseFloat($("#m").val().replace(/[^\d\.\-]/g, ""));
            var d = parseFloat($("#n").val().replace(/[^\d\.\-]/g, ""));
            $("#l").val(a + b);
            $("#o").val(c + d);
            $('#verified').val(c + d + a + b);
            /////// Attrition
            var e = parseFloat($("#registered").val().replace(/[^\d\.\-]/g, ""));
            var f = parseFloat($("#verified").val().replace(/[^\d\.\-]/g, ""));
            $('#AttritionRV').val(e - f);

            ///////////////////////// selected firm //////////////////////////////////
            var a = parseFloat($("#r").val().replace(/[^\d\.\-]/g, ""));
            var b = parseFloat($("#s").val().replace(/[^\d\.\-]/g, ""));
            var c = parseFloat($("#u").val().replace(/[^\d\.\-]/g, ""));
            var d = parseFloat($("#v").val().replace(/[^\d\.\-]/g, ""));
            $("#t").val(a + b);
            $("#w").val(c + d);
            $('#selected').val(c + d + a + b);
            /////// Attrition
            var e = parseFloat($("#verified").val().replace(/[^\d\.\-]/g, ""));
            var f = parseFloat($("#selected").val().replace(/[^\d\.\-]/g, ""));
            $('#AttritionVS').val(e - f);

            ///////////////////////// receiving firm //////////////////////////////////
            var a = parseFloat($("#y").val().replace(/[^\d\.\-]/g, ""));
            var b = parseFloat($("#z").val().replace(/[^\d\.\-]/g, ""));
            var c = parseFloat($("#a2").val().replace(/[^\d\.\-]/g, ""));
            var d = parseFloat($("#a3").val().replace(/[^\d\.\-]/g, ""));
            $("#a1").val(a + b);
            $("#a4").val(c + d);
            $('#receiving').val(c + d + a + b);
            /////// Attrition
            var e = parseFloat($("#selected").val().replace(/[^\d\.\-]/g, ""));
            var f = parseFloat($("#receiving").val().replace(/[^\d\.\-]/g, ""));
            $('#AttritionSR').val(e - f);

            ///////////////////////// receiving Disagregated //////////////////////////////////
            var a = parseFloat($("#c1").val().replace(/[^\d\.\-]/g, ""));
            var b = parseFloat($("#d1").val().replace(/[^\d\.\-]/g, ""));
            var c = parseFloat($("#f1").val().replace(/[^\d\.\-]/g, ""));
            var d = parseFloat($("#g1").val().replace(/[^\d\.\-]/g, ""));
            $("#e1").val(a + b);
            $("#h1").val(c + d);
            $('#Disagregated').val(c + d + a + b);

///////////////// Attrition (Registered Firms minus Receiving Firms)
            var a = parseFloat($("#registered").val().replace(/[^\d\.\-]/g, ""));
            var b = parseFloat($("#receiving").val().replace(/[^\d\.\-]/g, ""));
            $("#Attrg_rc").val(a - b);

///////////////////////// disbursed Disagregated //////////////////////////////////
            var a = parseFloat($("#a7").val().replace(/[^\d\.\-]/g, ""));
            var b = parseFloat($("#a8").val().replace(/[^\d\.\-]/g, ""));
            var c = parseFloat($("#a10").val().replace(/[^\d\.\-]/g, ""));
            var d = parseFloat($("#a11").val().replace(/[^\d\.\-]/g, ""));
            $("#a9").val(a + b);
            $("#a12").val(c + d);
            $('#disbursed').val(c + d + a + b);


            // 							check NaN
            $(".to").each(function(i) {
                if ($(this).val() == "NaN") {
                    ($(this).val(0))
                } else{
                    var $this = $(this);
                    var input = $this.val();
                    var input = input.replace(/[\D\s\._\-]+/g, "");
                    input = input ? parseFloat(input, 10) : 0;
                    $this.val(function() {
                        return input === 0 ? "0" : input.toLocaleString("en-US");
                    });
                }
            });
        });
    });



    function sum() {

        let state = document.getElementById("states").value;
        let none = "none";
        if (state === "none") {
            document.getElementById("states").style.backgroundColor = "red";
            alert("Error: Select your State");
        }
        else document.getElementById("states").style.backgroundColor = "white";
    }
    document.getElementById("timestamp").value = new Date().toLocaleString();

</script>
</body>
</html>
