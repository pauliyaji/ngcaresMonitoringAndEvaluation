<!DOCTYPE html>
<html>
<head lang="en">
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" />
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.0/jquery.validate.min.js"></script>
    <title>Receiving Grant (DLI 3.3)</title>
</head>
<body>
<div class="container p-5 my-5 border">
    <div class="col-md-6 text-right">
        <a href="{{ url()->previous() }}" class="btn btn-lg" style="background-color: #12d3e0;">Back to Result Area</a>
    </div>
    <br />
    <div class="card-header" style="background-color: #0987b9;">
        <h2 style="margin-top: 10px; margin-left: 10px; color: white; text-align: center;"> M&E-- RECEIVING GRANT (DLI 3.3) </h2>
    </div>
    <h4 style="text-align: center;">Fill in the information carefully in the appropriate spaces</h4>
    <form method="post" action="{{ route('enhancement_grants.store') }}" id="formid">
        @csrf

        <div class="container border border-info p-4">
            <div class="card-header col-md-4 col-xs-12" style="background-color: #506dee;">
                <label for="states" style="color: white;"
                >Select Month<span style="color: rgb(253, 237, 10);"
                    >(*)</span
                    ></label>
                <select class="form-control"
                        name="monthyear" required>
                    <option value="">Select Month</option>
                    @foreach($months as $month)
                        <option value="{{ $month->id }}"
                            {{$month->date}}>{{ $month->date }}</option>
                    @endforeach
                </select>
                @if ($errors->has('monthyear'))
                    <span class="text-danger text-left">{{ $errors->first('monthyear') }}</span>
                @endif
            </div>

            <br />
            <div class="row">
            <span class="card-header  col-md-8" style="color: white; background-color: #0987b9;">
                Total Number of registered firms for IT-enhancement </span>
                <div class="col-md-4">
                    <input type="text" class="form-control" name="tot_regit" id="registered" readonly />
                </div>
            </div>
            <br />
            <div class="row">
            <span class="card-footer " style="color: white; background-color: #0987b9;">
                Micro scale Firms</span>
                <div class="col-md-4">
                    <label>Male Owners</label>
                    <input type="text" class="form-control" name="tot_regitmmicro" id="c" onkeyup="sum()" />
                </div>
                <div class="col-md-4">
                    <label>Female Owners</label>
                    <input type="text" class="form-control" name="tot_regitfmicro" id="d" onkeyup="sum()" />
                </div>
                <div class="col-md-4">
                    <label>Total</label>
                    <input type="text" readonly class="form-control to" name="tot_regitmicro" id="e" />
                </div>
            </div>
            <br />
            <div class="row">
            <span class="card-footer " style="color: white; background-color: #0987b9;">
                Small Scale Firms </span>
                <div class="col-md-4">
                    <label>Male Owners</label>
                    <input type="text" class="form-control" name="tot_regitmsmall" id="f" onkeyup="sum()" />
                </div>
                <div class="col-md-4">
                    <label>Female Owners</label>
                    <input type="text" class="form-control" name="tot_regitfsmall" id="g" onkeyup="sum()" />
                </div>
                <div class="col-md-4">
                    <label>Total</label>
                    <input type="text" readonly class="form-control" name="tot_regitsmall" id="h" />
                </div>
            </div>
            <br />
            <div class="row">
            <span class="card-header  col-md-8" style="color: white; background-color: #0987b9;">
                Total Number of eligible and verified firms for IT-enhancement </span>
                <div class="col-md-4">
                    <input type="text" class="form-control to" name="tot_eligverit" id="verified" readonly/>
                </div>
            </div>
            <br />
            <div class="row">
                <span class="card-footer " style="color: white; background-color: #0987b9;"> Micro scale Firms</span>
                <div class="col-md-4">
                    <label>Male Owners</label>
                    <input type="text" class="form-control" name="tot_eligmmicro" id="j" onkeyup="sum()" />
                </div>
                <div class="col-md-4">
                    <label>Female Owners</label>
                    <input type="text" class="form-control" name="tot_eligfmicro" id="k" onkeyup="sum()" />
                </div>
                <div class="col-md-4">
                    <label>Total</label>
                    <input type="text" readonly class="form-control to" name="tot_eligmicro" id="l" />
                </div>
            </div>
            <br />
            <div class="row">
                <span class="card-footer " style="color: white; background-color: #0987b9;"> Small Scale Firms </span>
                <div class="col-md-4">
                    <label>Male Owners</label>
                    <input type="text" class="form-control" name="tot_eligmsmall" id="m" onkeyup="sum()" />
                </div>
                <div class="col-md-4">
                    <label>Female Owners</label>
                    <input type="text" class="form-control" name="tot_eligfsmall" id="n" onkeyup="sum()" />
                </div>
                <div class="col-md-4">
                    <label>Total</label>
                    <input type="text" readonly class="form-control to" name="tot_eligsmall" id="o" />
                </div>
            </div>
            <br />
            <div class="row">
            <span class="card-header  col-md-8" style="color: white; background-color: #0987b9;">
                Attrition (Registered Firms minus Verified Firms) </span>
                <div class="col-md-4">
                    <input type="text" class="form-control to" name="att_reg_minus_ver" id="AttritionRV" readonly />
                </div>
            </div>
            <br />
            <div class="row">
            <span class="card-header  col-md-8" style="color: white; background-color: #0987b9;">
                Total Number of selected firms on IT-enhancement </span>
                <div class="col-md-4">
                    <input type="text" class="form-control to" name="tot_sel" id="selected" readonly/>
                </div>
            </div>
            <br />
            <div class="row">
                <span class="card-footer " style="color: white; background-color: #0987b9;">Micro scale Firms</span>
                <div class="col-md-4">
                    <label>Male Owners</label>
                    <input type="text" class="form-control" name="tot_selmmicro" id="r" onkeyup="sum()" />
                </div>
                <div class="col-md-4">
                    <label>Female Owners</label>
                    <input type="text" class="form-control" name="tot_selfmicro" id="s" onkeyup="sum()" />
                </div>
                <div class="col-md-4">
                    <label>Total</label>
                    <input type="text" readonly class="form-control to" name="tot_selmicro" id="t" />
                </div>
            </div>
            <br />
            <div class="row">
                <span class="card-footer " style="color: white; background-color: #0987b9;"> Small Scale Firms </span>
                <div class="col-md-4">
                    <label>Male Owners</label>
                    <input type="text" class="form-control" name="tot_selmsmall" id="u" onkeyup="sum()" />
                </div>
                <div class="col-md-4">
                    <label>Female Owners</label>
                    <input type="text" class="form-control" name="tot_selfsmall" id="v" onkeyup="sum()" />
                </div>
                <div class="col-md-4">
                    <label>Total</label>
                    <input type="text" readonly class="form-control to" name="tot_selsmall" id="w" />
                </div>
            </div>
            <br />
            <div class="row">
            <span class="card-header  col-md-8" style="color: white; background-color: #0987b9;">
                Attrition (Verified Firms minus Selected Firms) </span>
                <div class="col-md-4">
                    <input type="text" class="form-control to" name="att_ver_minus_sel" id="AttritionVS" readonly />
                </div>
            </div>
            <br />

            <!-------------------------------------------------------->
            <!-------------------------------------------------------->
            <!-- ----------------------------------------------------->

            <div class="row">
            <span class="card-header  col-md-10" style="color: white; background-color: #0987b9;">
              Total Number of contracted service providers/ vendors of IT solutions </span>
                <div class="col-md-2">
                    <input type="text" class="form-control" name="tot_ser_pro" id="id_tot_ser_pro" />
                </div>
            </div>
            <br />


            <div class="row">
            <span class="card-header  col-md-10" style="color: white; background-color: #0987b9;">
                Total Number of firms that confirm receipt of IT </span>
                <div class="col-md-2">
                    <input type="text" class="form-control to" name="tot_conf" id="confirm" readonly/>
                </div>
            </div>
            <br />
            <div class="row">
                <span class="card-footer " style="color: white; background-color: #0987b9;">Micro scale Firms</span>
                <div class="col-md-4">
                    <label>Male Owners</label>
                    <input type="text" class="form-control" name="tot_confmmicro" id="confmmicro" onkeyup="sum()" />
                </div>
                <div class="col-md-4">
                    <label>Female Owners</label>
                    <input type="text" class="form-control" name="tot_conffmicro" id="conffmicro" onkeyup="sum()" />
                </div>
                <div class="col-md-4">
                    <label>Total</label>
                    <input type="text" readonly class="form-control to" name="tot_confmicro" id="tot_confmicro" />
                </div>
            </div>
            <br />
            <div class="row">
                <span class="card-footer " style="color: white; background-color: #0987b9;"> Small Scale Firms </span>
                <div class="col-md-4">
                    <label>Male Owners</label>
                    <input type="text" class="form-control" name="tot_confmsmall" id="confmsmall" onkeyup="sum()" />
                </div>
                <div class="col-md-4">
                    <label>Female Owners</label>
                    <input type="text" class="form-control" name="tot_conffsmall" id="conffsmall" onkeyup="sum()" />
                </div>
                <div class="col-md-4">
                    <label>Total</label>
                    <input type="text" readonly class="form-control to" name="tot_confsmall" id="tot_confsmall" />
                </div>
            </div>
            <br />
            <div class="row">
            <span class="card-header  col-md-8" style="color: white; background-color: #0987b9;">
                Attrition (Selected minus Confirmed Firms) </span>
                <div class="col-md-4">
                    <input type="text" class="form-control to" name="att_sel_minus_conf" id="AttritionSC" readonly />
                </div>
            </div>
            <br />
            <br />
            <!------------------------------------------------->

            <br />
            <div class="row">
            <span class="card-header  col-md-8" style="color: white; background-color: #0987b9;">
              Total Number of instances of tech deployment to support beneficiaries </span>
                <div class="col-md-4">
                    <input type="text" class="form-control to" name="tot_tech" id="tech" readonly/>
                </div>
            </div>
            <br />
            <div class="row">
                <span class="card-footer " style="color: white; background-color: #0987b9;">Micro scale Firms</span>
                <div class="col-md-4">
                    <label>Male Owners</label>
                    <input type="text" class="form-control" name="tot_techmmicro" id="techmmicro" onkeyup="sum()" />
                </div>
                <div class="col-md-4">
                    <label>Female Owners</label>
                    <input type="text" class="form-control" name="tot_techfmicro" id="techfmicro" onkeyup="sum()" />
                </div>
                <div class="col-md-4">
                    <label>Total</label>
                    <input type="text" readonly class="form-control to" name="tot_techmicro" id="tot_techmicro" />
                </div>
            </div>
            <br />
            <div class="row">
                <span class="card-footer " style="color: white; background-color: #0987b9;"> Small Scale Firms </span>
                <div class="col-md-4">
                    <label>Male Owners</label>
                    <input type="text" class="form-control" name="tot_techmsmall" id="techmsmall" onkeyup="sum()" />
                </div>
                <div class="col-md-4">
                    <label>Female Owners</label>
                    <input type="text" class="form-control" name="tot_techfsmall" id="techfsmall" onkeyup="sum()" />
                </div>
                <div class="col-md-4">
                    <label>Total</label>
                    <input type="text" readonly class="form-control to" name="tot_techsmall" id="tot_techsmall" />
                </div>
            </div>
            <br />
            <div class="row">
            <span class="card-header  col-md-8" style="color: white; background-color: #0987b9;">
                Attrition (Confirmed Receipt minus Tech deployed Firms) </span>
                <div class="col-md-4">
                    <input type="text" class="form-control to" name="att_conf_minus_tech" id="AttritionCT" readonly />
                </div>
            </div>
            <br />



            <!------------------------------------------------->

            <div class="row">
            <span class="card-header  col-md-10" style="color: white; background-color: #0987b9;">
                Total Number of firms Receiving Conditional Grants </span>
                <div class="col-md-2">
                    <input type="text" class="form-control to" name="tot_rec" id="received" readonly/>
                </div>
            </div>
            <br />
            <div class="row">
                <span class="card-footer " style="color: white; background-color: #0987b9;">Micro scale Firms</span>
                <div class="col-md-4">
                    <label>Male Owners</label>
                    <input type="text" class="form-control" name="tot_recmmicro" id="y" onkeyup="sum()" />
                </div>
                <div class="col-md-4">
                    <label>Female Owners</label>
                    <input type="text" class="form-control" name="tot_recfmicro" id="z" onkeyup="sum()" />
                </div>
                <div class="col-md-4">
                    <label>Total</label>
                    <input type="text" readonly class="form-control to" name="tot_recmicro" id="a1" />
                </div>
            </div>
            <br />
            <div class="row">
                <span class="card-footer " style="color: white; background-color: #0987b9;"> Small Scale Firms </span>
                <div class="col-md-4">
                    <label>Male Owners</label>
                    <input type="text" class="form-control" name="tot_recmsmall" id="a2" onkeyup="sum()" />
                </div>
                <div class="col-md-4">
                    <label>Female Owners</label>
                    <input type="text" class="form-control" name="tot_recfsmall" id="a3" onkeyup="sum()" />
                </div>
                <div class="col-md-4">
                    <label>Total</label>
                    <input type="text" readonly class="form-control to" name="tot_recsmall" id="a4" />
                </div>
            </div>
            <br />
            <br />
            <div class="row">
            <span class="card-header  col-md-8" style="color: white; background-color: #0987b9;">
                Attrition (Tech Deployment minus Received) </span>
                <div class="col-md-4">
                    <input type="text" class="form-control to" name="att_tech_minus_rec" id="AttritionTR" readonly />
                </div>
            </div>
            <br />

            <!------------------------------------------------->

            <!------------------------------------------------->

            <div class="row">
            <span class="card-header  col-md-10" style="color: white; background-color: #0987b9;">
                Amount disbursed to lending financial institutions (on behalf of beneficiary firms) </span>
                <div class="col-md-2">
                    <input type="text" class="form-control to" name="tot_dis" id="disbursed" readonly/>
                </div>
            </div>
            <br />
            <div class="row">
                <span class="card-footer " style="color: white; background-color: #0987b9;"> Micro scale Firms</span>
                <div class="col-md-4">
                    <label>Male Owners</label>
                    <input type="text" class="form-control" name="tot_dismmicro" id="a22" onkeyup="sum()" />
                </div>
                <div class="col-md-4">
                    <label>Female Owners</label>
                    <input type="text" class="form-control" name="tot_disfmicro" id="a23" onkeyup="sum()" />
                </div>
                <div class="col-md-4">
                    <label>Total</label>
                    <input type="text" readonly class="form-control to" name="tot_dismicro" id="a24" />
                </div>
            </div>
            <br />
            <div class="row">
                <span class="card-footer " style="color: white; background-color: #0987b9;"> Small Scale Firms </span>
                <div class="col-md-4">
                    <label>Male Owners</label>
                    <input type="text" class="form-control" name="tot_dismsmall" id="a25" onkeyup="sum()" />
                </div>
                <div class="col-md-4">
                    <label>Female Owners</label>
                    <input type="text" class="form-control" name="tot_disfsmall" id="a26" onkeyup="sum()" />
                </div>
                <div class="col-md-4">
                    <label>Total</label>
                    <input type="text" readonly class="form-control to" name="tot_dissmall" id="a27" />
                </div>
            </div>
            <br />
            <div class="col-md-6 bg-light text-right">
                <input type="hidden" name="timestamp" id="timestamp" />
            </div>
        </div>
        <br />

        <div class="col-md-6 col-xs-12">
            <input type="submit" class="btn btn-primary btn-sm" />
        </div>
    </form>
    <br />


<script type="text/javascript">
    src = "https://code.jquery.com/jquery-3.4.1.js"
    integrity = "sha256-WpOohJOqMqqyKL9FccASB9O0KwACQJpFTUBLTYOVvVU="
    crossorigin = "anonymous"

    function SubForm (){
        $.ajax({
            url:"https://api.apispreadsheets.com/data/wUAF99I75SMe90Zk/",
            type:"post",
            data:$("#formid").serializeArray(),
            headers:{
                accessKey: "224a5c0858d0b2a88769e4a72cbf108d",
                secretKey: "85cd0eeb89587d67121ac8c2d012f760"},
            success: function() {
                location.reload(true);
                // window.location.href = '/front.html';
                alert("Enhancement Grants (DLI 3.3) Form Data Submitted Successfully");
            },
            error: function() {
                alert("Network Error: 404");
            }
        });
    }

    //   document.getElementById("timestamp").value = new Date().toLocaleString();
    //    function sb(){location.reload(true);alert("Data successfully submitted.");window.location.href = '../';}
    (function($, undefined) {
        "use strict";
        // When ready.
        $(function() {
            var $form = $("#formid");
            var $input = $form.find('input[type="text"]');
            $input.on("keyup", function(event) {
                // When user select text in the document, also abort.
                var selection = window.getSelection().toString();
                if (selection !== "") {
                    return;
                }
                // When the arrow keys are pressed, abort.
                if ($.inArray(event.keyCode, [38, 40, 37, 39]) !== -1) {
                    return;
                }
                var $this = $(this);
                // Get the value.
                var input = $this.val();
                var input = input.replace(/[\D\s\._\-]+/g, "");
                input = input ? parseFloat(input, 10) : 0;
                $this.val(function() {
                    return input === 0 ? "0" : input.toLocaleString("en-US");
                });
            });
        });
    })(jQuery);

    $(function() {
        var $form = $("#formid");
        var $input = $form.find('input[type="text"]');
        $input.on("keyup", function(e) {
            document.getElementById("timestamp").value = new Date().toLocaleString();

            //////////////////////// registered firm //////////////////////////////////
            var a = parseFloat($("#c").val().replace(/[^\d\.\-]/g, ""));
            var b = parseFloat($("#d").val().replace(/[^\d\.\-]/g, ""));
            var c = parseFloat($("#f").val().replace(/[^\d\.\-]/g, ""));
            var d = parseFloat($("#g").val().replace(/[^\d\.\-]/g, ""));
            $("#e").val(a + b);
            $("#h").val(c + d);
            $('#registered').val(c + d + a + b);

            ///////////////////////// verified firm //////////////////////////////////
            var a = parseFloat($("#j").val().replace(/[^\d\.\-]/g, ""));
            var b = parseFloat($("#k").val().replace(/[^\d\.\-]/g, ""));
            var c = parseFloat($("#m").val().replace(/[^\d\.\-]/g, ""));
            var d = parseFloat($("#n").val().replace(/[^\d\.\-]/g, ""));
            $("#l").val(a + b);
            $("#o").val(c + d);
            $('#verified').val(c + d + a + b);
            /////// Attrition
            var e = parseFloat($("#registered").val().replace(/[^\d\.\-]/g, ""));
            var f = parseFloat($("#verified").val().replace(/[^\d\.\-]/g, ""));
            $('#AttritionRV').val(e - f);

            ///////////////////////// selected firm //////////////////////////////////
            var a = parseFloat($("#r").val().replace(/[^\d\.\-]/g, ""));
            var b = parseFloat($("#s").val().replace(/[^\d\.\-]/g, ""));
            var c = parseFloat($("#u").val().replace(/[^\d\.\-]/g, ""));
            var d = parseFloat($("#v").val().replace(/[^\d\.\-]/g, ""));
            $("#t").val(a + b);
            $("#w").val(c + d);
            $('#selected').val(c + d + a + b);
            /////// Attrition
            var e = parseFloat($("#verified").val().replace(/[^\d\.\-]/g, ""));
            var f = parseFloat($("#selected").val().replace(/[^\d\.\-]/g, ""));
            $('#AttritionVS').val(e - f);

            ///////////////////////// confirm firm //////////////////////////////////
            var a = parseFloat($("#confmmicro").val().replace(/[^\d\.\-]/g, ""));
            var b = parseFloat($("#conffmicro").val().replace(/[^\d\.\-]/g, ""));
            var c = parseFloat($("#confmsmall").val().replace(/[^\d\.\-]/g, ""));
            var d = parseFloat($("#conffsmall").val().replace(/[^\d\.\-]/g, ""));
            $("#tot_confmicro").val(a + b);
            $("#tot_confsmall").val(c + d);
            $('#confirm').val(c + d + a + b);
            /////// Attrition
            var e = parseFloat($("#selected").val().replace(/[^\d\.\-]/g, ""));
            var f = parseFloat($("#confirm").val().replace(/[^\d\.\-]/g, ""));
            $('#AttritionSC').val(e - f);

            ///////////////////////// TECH DEPLOY //////////////////////////////////
            var a = parseFloat($("#techmmicro").val().replace(/[^\d\.\-]/g, ""));
            var b = parseFloat($("#techfmicro").val().replace(/[^\d\.\-]/g, ""));
            var c = parseFloat($("#techmsmall").val().replace(/[^\d\.\-]/g, ""));
            var d = parseFloat($("#techfsmall").val().replace(/[^\d\.\-]/g, ""));
            $("#tot_techmicro").val(a + b);
            $("#tot_techsmall").val(c + d);
            $('#tech').val(c + d + a + b);
            /////// Attrition
            var e = parseFloat($("#confirm").val().replace(/[^\d\.\-]/g, ""));
            var f = parseFloat($("#tech").val().replace(/[^\d\.\-]/g, ""));
            $('#AttritionCT').val(e - f);

            ///////////////////////// RECEIVING //////////////////////////////////
            var a = parseFloat($("#y").val().replace(/[^\d\.\-]/g, ""));
            var b = parseFloat($("#z").val().replace(/[^\d\.\-]/g, ""));
            var c = parseFloat($("#a2").val().replace(/[^\d\.\-]/g, ""));
            var d = parseFloat($("#a3").val().replace(/[^\d\.\-]/g, ""));
            $("#a1").val(a + b);
            $("#a4").val(c + d);
            $('#received').val(c + d + a + b);
            /////// Attrition
            var e = parseFloat($("#tech").val().replace(/[^\d\.\-]/g, ""));
            var f = parseFloat($("#received").val().replace(/[^\d\.\-]/g, ""));
            $('#AttritionTR').val(e - f);





            ///////////////////////// disbursed to lending financial institutions //////////////////////////////////
            var a = parseFloat($("#a22").val().replace(/[^\d\.\-]/g, ""));
            var b = parseFloat($("#a23").val().replace(/[^\d\.\-]/g, ""));
            var c = parseFloat($("#a25").val().replace(/[^\d\.\-]/g, ""));
            var d = parseFloat($("#a26").val().replace(/[^\d\.\-]/g, ""));
            $("#a24").val(a + b);
            $("#a27").val(c + d);
            $('#disbursed').val(c + d + a + b);
            /////// Attrition
            // var e = parseFloat($("#received").val().replace(/[^\d\.\-]/g, ""));
            // var f = parseFloat($("#disbursed").val().replace(/[^\d\.\-]/g, ""));
            // $('#AttritionRD').val(e - f);




            // 							check NaN
            $(".to").each(function(i) {
                if ($(this).val() == "NaN") {
                    ($(this).val(0))
                } else{
                    var $this = $(this);
                    var input = $this.val();
                    var input = input.replace(/[\D\s\._\-]+/g, "");
                    input = input ? parseFloat(input, 10) : 0;
                    $this.val(function() {
                        return input === 0 ? "0" : input.toLocaleString("en-US");
                    });
                }
            });
        });
    });


    function sum() {
        let state = document.getElementById("states").value;
        let none = "none";
        if (state === "none") {
            document.getElementById("states").style.backgroundColor = "red";
            alert("Error: Select your State");
        } else document.getElementById("states").style.backgroundColor = "white";
    }

</script>
</body>
</html>
