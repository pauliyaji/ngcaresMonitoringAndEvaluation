<table class="table table-bordered" id="dataTable">
    <thead style="background-color: cornflowerblue; color: white">
    <tr>
        <th colspan="8">{{ Auth::user()->states->state }} {{ $data->dli->title }} Submission for {{ $data->months->date }}</th>
    </tr>
    <tr>
        <th>Dli</th>
        <th colspan="2">Disbursement Indicator</th>
        <th></th>
        <th>Unit of Measurement</th>
        <th>Previous (as at {{ $old_rec->months->date }} )</th>
        <th>Current (as at {{ $data->months->date }} )</th>
        <th>Total</th>
    </tr>
    </thead>

    <tbody>
    <tr>
        <th>3.2</th>
        <th>Total Number of Registered Firms that Applied for Operational Grants</th>
        <th></th>
        <th></th>
        <th>No.</th>
        @if($prev_vals == null)
            <th>0</th>
        @else
            <th>{{ $prev_vals->sum('tot_reg_ops') }}</th>
        @endif
        <th>{{ $data->tot_reg_ops }}</th>
        <th>{{ $data->tot_reg_ops + $prev_vals->sum('tot_reg_ops')}}</th>
    </tr>
    <tr>
        <th>3.2.1.1</th>
        <th rowspan="2">Micro Scale Firms</th>
        <th>Male Owners</th>
        <td></td>
        <td>No.</td>
        @if($prev_vals == null)
            <th>0</th>
        @else
            <td>{{ $prev_vals->sum('tot_reg_opsmmicro') }}</td>
        @endif
        <td>{{ $data->tot_reg_opsmmicro }}</td>
        <td>{{ $data->tot_reg_opsmmicro + $prev_vals->sum('tot_reg_opsmmicro')}}</td>
    </tr>
    <tr>
        <th></th>
        <th>Female Owners</th>
        <td></td>
        <td>No.</td>
        @if($prev_vals == null)
            <th>0</th>
        @else
            <td>{{ $prev_vals->sum('tot_reg_opsfmicro') }}</td>
        @endif
        <td>{{ $data->tot_reg_opsfmicro }}</td>
        <td>{{ $data->tot_reg_opsfmicro + $prev_vals->sum('tot_reg_opsfmicro')}}</td>
    </tr>
    <tr style="background-color: cornflowerblue; color: black;">
        <th></th>
        <td></td>
        <th>Total</th>
        <td></td>

        <td>No.</td>
        @if($prev_vals == null)
            <th>0</th>
        @else
            <td>{{ $prev_vals->sum('tot_reg_opsmicro') }}</td>
        @endif
        <th>{{ $data->tot_reg_opsmicro }}</th>
        <th>{{ $data->tot_reg_opsmicro + $prev_vals->sum('tot_reg_opsmicro')}}</th>
    </tr>
    <tr>
        <th>3.2.1.2</th>
        <th rowspan="2">Small Scale Firms</th>
        <th>Male Owners</th>
        <td></td>
        <td>No.</td>
        @if($prev_vals == null)
            <th>0</th>
        @else
            <td>{{ $prev_vals->sum('tot_reg_opsmsmall') }}</td>
        @endif
        <td>{{ $data->tot_reg_opsmsmall }}</td>
        <td>{{ $data->tot_reg_opsmsmall + $prev_vals->sum('tot_reg_opsmsmall')}}</td>
    </tr>
    <tr>
        <th></th>
        <th>Female Owners</th>
        <td></td>
        <td>No.</td>
        @if($prev_vals == null)
            <th>0</th>
        @else
            <td>{{ $prev_vals->sum('tot_reg_opsfsmall') }}</td>
        @endif
        <td>{{ $data->tot_reg_opsfsmall }}</td>
        <td>{{ $data->tot_reg_opsfsmall + $prev_vals->sum('tot_reg_opsfsmall')}}</td>
    </tr>
    <tr style="background-color: cornflowerblue; color: black;">
        <th></th>
        <td></td>
        <th>Total</th>
        <td></td>

        <td>No.</td>
        @if($prev_vals == null)
            <th>0</th>
        @else
            <td>{{ $prev_vals->sum('tot_reg_opssmall') }}</td>
        @endif
        <th>{{ $data->tot_reg_opssmall }}</th>
        <th>{{ $data->tot_reg_opssmall + $prev_vals->sum('tot_reg_opssmall')}}</th>
    </tr>
    <tr>
        <th>3.2.2</th>
        <th>The Total Number of Firms that are Eligible and have been Verified for Operational Support Grants</th>
        <th></th>
        <th></th>
        <th>No.</th>
        @if($prev_vals == null)
            <th>0</th>
        @else
            <th>{{ $prev_vals->sum('tot_eli_ver') }}</th>
        @endif
        <th>{{ $data->tot_eli_ver }}</th>
        <th>{{ $data->tot_eli_ver + $prev_vals->sum('tot_eli_ver')}}</th>
    </tr>

    <tr>
        <th>3.2.2.1</th>
        <th rowspan="2">Micro Scale Firms</th>
        <th>Male Owners</th>
        <td></td>
        <td>No.</td>
        @if($prev_vals == null)
            <th>0</th>
        @else
            <td>{{ $prev_vals->sum('tot_eli_vermmicro') }}</td>
        @endif
        <td>{{ $data->tot_eli_vermmicro }}</td>
        <td>{{ $data->tot_eli_vermmicro + $prev_vals->sum('tot_eli_vermmicro')}}</td>
    </tr>
    <tr>
        <th></th>
        <th>Female Owners</th>
        <td></td>
        <td>No.</td>
        @if($prev_vals == null)
            <th>0</th>
        @else
            <td>{{ $prev_vals->sum('tot_eli_verfmicro') }}</td>
        @endif
        <td>{{ $data->tot_eli_verfmicro }}</td>
        <td>{{ $data->tot_eli_verfmicro + $prev_vals->sum('tot_eli_verfmicro')}}</td>
    </tr>
    <tr style="background-color: cornflowerblue; color: black;">
        <th></th>
        <td></td>
        <th>Total</th>
        <td></td>

        <td>No.</td>
        @if($prev_vals == null)
            <th>0</th>
        @else
            <td>{{ $prev_vals->sum('tot_eli_vermicro') }}</td>
        @endif
        <th>{{ $data->tot_eli_vermicro }}</th>
        <th>{{ $data->tot_eli_vermicro + $prev_vals->sum('tot_eli_vermicro')}}</th>
    </tr>

    <tr>
        <th>3.2.2.2</th>
        <th rowspan="2">Small Scale Firms </th>
        <th>Male Owners</th>
        <td></td>
        <td>No.</td>
        @if($prev_vals == null)
            <th>0</th>
        @else
            <td>{{ $prev_vals->sum('tot_eli_vermsmall') }}</td>
        @endif
        <td>{{ $data->tot_eli_vermsmall }}</td>
        <td>{{ $data->tot_eli_vermsmall + $prev_vals->sum('tot_eli_vermsmall')}}</td>
    </tr>
    <tr>
        <th></th>
        <th>Female Owners</th>
        <td></td>
        <td>No.</td>
        @if($prev_vals == null)
            <th>0</th>
        @else
            <td>{{ $prev_vals->sum('tot_eli_verfsmall') }}</td>
        @endif
        <td>{{ $data->tot_eli_verfsmall }}</td>
        <td>{{ $data->tot_eli_verfsmall + $prev_vals->sum('tot_eli_verfsmall')}}</td>
    </tr>
    <tr style="background-color: cornflowerblue; color: black;">
        <th></th>
        <td></td>
        <th>Total</th>
        <td></td>

        <td>No.</td>
        @if($prev_vals == null)
            <th>0</th>
        @else
            <td>{{ $prev_vals->sum('tot_eli_versmall') }}</td>
        @endif
        <th>{{ $data->tot_eli_versmall }}</th>
        <th>{{ $data->tot_eli_versmall + $prev_vals->sum('tot_eli_versmall')}}</th>
    </tr>
    <tr>
        <th>3.2.3</th>
        <th>Total Number of Selected Firms for Operational Grants</th>
        <th></th>
        <th></th>
        <th>No.</th>
        @if($prev_vals == null)
            <th>0</th>
        @else
            <th>{{ $prev_vals->sum('tot_sel_ops') }}</th>
        @endif
        <th>{{ $data->tot_sel_ops }}</th>
        <th>{{ $data->tot_sel_ops + $prev_vals->sum('tot_sel_ops')}}</th>
    </tr>

    <tr>
        <th>3.2.3.1</th>
        <th rowspan="2">Micro Scale Firms</th>
        <th>Male Owners</th>
        <td></td>
        <td>No.</td>
        @if($prev_vals == null)
            <th>0</th>
        @else
            <td>{{ $prev_vals->sum('tot_sel_opsmmicro') }}</td>
        @endif
        <td>{{ $data->tot_sel_opsmmicro }}</td>
        <td>{{ $data->tot_sel_opsmmicro + $prev_vals->sum('tot_sel_opsmmicro')}}</td>
    </tr>
    <tr>
        <th></th>
        <th>Female Owners</th>
        <td></td>
        <td>No.</td>
        @if($prev_vals == null)
            <th>0</th>
        @else
            <td>{{ $prev_vals->sum('tot_sel_opsfmicro') }}</td>
        @endif
        <td>{{ $data->tot_sel_opsfmicro }}</td>
        <td>{{ $data->tot_sel_opsfmicro + $prev_vals->sum('tot_sel_opsfmicro')}}</td>
    </tr>
    <tr style="background-color: cornflowerblue; color: black;">
        <th></th>
        <td></td>
        <th>Total</th>
        <td></td>

        <td>No.</td>
        @if($prev_vals == null)
            <th>0</th>
        @else
            <td>{{ $prev_vals->sum('tot_sel_opsmicro') }}</td>
        @endif
        <th>{{ $data->tot_sel_opsmicro }}</th>
        <th>{{ $data->tot_sel_opsmicro + $prev_vals->sum('tot_sel_opsmicro')}}</th>
    </tr>

    <tr>
        <th>3.2.3.2</th>
        <th rowspan="2">Small Scale Firms</th>
        <th>Male Owners</th>
        <td></td>
        <td>No.</td>
        @if($prev_vals == null)
            <th>0</th>
        @else
            <td>{{ $prev_vals->sum('tot_sel_opsmsmall') }}</td>
        @endif
        <td>{{ $data->tot_sel_opsmsmall }}</td>
        <td>{{ $data->tot_sel_opsmsmall + $prev_vals->sum('tot_sel_opsmsmall')}}</td>
    </tr>
    <tr>
        <th></th>
        <th>Female Owners</th>
        <td></td>
        <td>No.</td>
        @if($prev_vals == null)
            <th>0</th>
        @else
            <td>{{ $prev_vals->sum('tot_sel_opsfsmall') }}</td>
        @endif
        <td>{{ $data->tot_sel_opsfsmall }}</td>
        <td>{{ $data->tot_sel_opsfsmall + $prev_vals->sum('tot_sel_opsfsmall')}}</td>
    </tr>
    <tr style="background-color: cornflowerblue; color: black;">
        <th></th>
        <td></td>
        <th>Total</th>
        <td></td>

        <td>No.</td>
        @if($prev_vals == null)
            <th>0</th>
        @else
            <td>{{ $prev_vals->sum('tot_sel_opssmall') }}</td>
        @endif
        <th>{{ $data->tot_sel_opssmall }}</th>
        <th>{{ $data->tot_sel_opssmall + $prev_vals->sum('tot_sel_opssmall')}}</th>
    </tr>

    <tr>
        <th>3.2.4</th>
        <th>Total Number of Firms Receiving Operational Support Grants</th>
        <th></th>
        <th></th>
        <th>No.</th>
        @if($prev_vals == null)
            <th>0</th>
        @else
            <th>{{ $prev_vals->sum('tot_rec_ops') }}</th>
        @endif
        <th>{{ $data->tot_rec_ops }}</th>
        <th>{{ $data->tot_rec_ops + $prev_vals->sum('tot_rec_ops')}}</th>
    </tr>

    <tr>
        <th>3.2.4.1</th>
        <th rowspan="2">Micro Scale Firms</th>
        <th>Male Owners</th>
        <td></td>
        <td>No.</td>
        @if($prev_vals == null)
            <th>0</th>
        @else
            <td>{{ $prev_vals->sum('tot_rec_opsmmicro') }}</td>
        @endif
        <td>{{ $data->tot_rec_opsmmicro }}</td>
        <td>{{ $data->tot_rec_opsmmicro + $prev_vals->sum('tot_rec_opsmmicro')}}</td>
    </tr>
    <tr>
        <th></th>
        <th>Female Owners</th>
        <td></td>
        <td>No.</td>
        @if($prev_vals == null)
            <th>0</th>
        @else
            <td>{{ $prev_vals->sum('tot_rec_opsfmicro') }}</td>
        @endif
        <td>{{ $data->tot_rec_opsfmicro }}</td>
        <td>{{ $data->tot_rec_opsfmicro + $prev_vals->sum('tot_rec_opsfmicro')}}</td>
    </tr>
    <tr style="background-color: cornflowerblue; color: black;">
        <th></th>
        <td></td>
        <th>Total</th>
        <td></td>

        <td>No.</td>
        @if($prev_vals == null)
            <th>0</th>
        @else
            <td>{{ $prev_vals->sum('tot_rec_opsmicro') }}</td>
        @endif
        <th>{{ $data->tot_rec_opsmicro }}</th>
        <th>{{ $data->tot_rec_opsmicro + $prev_vals->sum('tot_rec_opsmicro')}}</th>
    </tr>
    <tr>
        <th>3.2.4.2</th>
        <th rowspan="2">Small Scale Firms</th>
        <th>Male Owners</th>
        <td></td>
        <td>No.</td>
        @if($prev_vals == null)
            <th>0</th>
        @else
            <td>{{ $prev_vals->sum('tot_rec_opsmsmall') }}</td>
        @endif
        <td>{{ $data->tot_rec_opsmsmall }}</td>
        <td>{{ $data->tot_rec_opsmsmall + $prev_vals->sum('tot_rec_opsmsmall')}}</td>
    </tr>
    <tr>
        <th></th>
        <th>Female Owners</th>
        <td></td>
        <td>No.</td>
        @if($prev_vals == null)
            <th>0</th>
        @else
            <td>{{ $prev_vals->sum('tot_rec_opsfsmall') }}</td>
        @endif
        <td>{{ $data->tot_rec_opsfsmall }}</td>
        <td>{{ $data->tot_rec_opsfsmall + $prev_vals->sum('tot_rec_opsfsmall')}}</td>
    </tr>
    <tr style="background-color: cornflowerblue; color: black;">
        <th></th>
        <td></td>
        <th>Total</th>
        <td></td>

        <td>No.</td>
        @if($prev_vals == null)
            <th>0</th>
        @else
            <td>{{ $prev_vals->sum('tot_rec_opssmall') }}</td>
        @endif
        <th>{{ $data->tot_rec_opssmall }}</th>
        <th>{{ $data->tot_rec_opssmall + $prev_vals->sum('tot_rec_opssmall')}}</th>
    </tr>


    <tr>
        <th>3.2.5</th>
        <th>Firms Working on Mini Solar Panels Receiving Grants for Operational Support</th>
        <th></th>
        <th></th>
        <th>No.</th>
        @if($prev_vals == null)
            <th>0</th>
        @else
            <th>{{ $prev_vals->sum('tot_sol_rec') }}</th>
        @endif
        <th>{{ $data->tot_sol_rec }}</th>
        <th>{{ $data->tot_sol_rec + $prev_vals->sum('tot_sol_rec')}}</th>
    </tr>

    <tr>
        <th>3.2.5.1</th>
        <th rowspan="2">Micro Scale Firms</th>
        <th>Male Owners</th>
        <td></td>
        <td>No.</td>
        @if($prev_vals == null)
            <th>0</th>
        @else
            <td>{{ $prev_vals->sum('tot_sol_recmmicro') }}</td>
        @endif
        <td>{{ $data->tot_sol_recmmicro }}</td>
        <td>{{ $data->tot_sol_recmmicro + $prev_vals->sum('tot_sol_recmmicro')}}</td>
    </tr>
    <tr>
        <th></th>
        <th>Female Owners</th>
        <td></td>
        <td>No.</td>
        @if($prev_vals == null)
            <th>0</th>
        @else
            <td>{{ $prev_vals->sum('tot_sol_recfmicro') }}</td>
        @endif
        <td>{{ $data->tot_sol_recfmicro }}</td>
        <td>{{ $data->tot_sol_recfmicro + $prev_vals->sum('tot_sol_recfmicro')}}</td>
    </tr>
    <tr style="background-color: cornflowerblue; color: black;">
        <th></th>
        <td></td>
        <th>Total</th>
        <td></td>

        <td>No.</td>
        @if($prev_vals == null)
            <th>0</th>
        @else
            <td>{{ $prev_vals->sum('tot_sol_recmicro') }}</td>
        @endif
        <th>{{ $data->tot_sol_recmicro }}</th>
        <th>{{ $data->tot_sol_recmicro + $prev_vals->sum('tot_sol_recmicro')}}</th>
    </tr>
    <tr>
        <th>3.2.5.2</th>
        <th rowspan="2">Small Scale Firms</th>
        <th>Male Owners</th>
        <td></td>
        <td>No.</td>
        @if($prev_vals == null)
            <th>0</th>
        @else
            <td>{{ $prev_vals->sum('tot_sol_recmsmall') }}</td>
        @endif
        <td>{{ $data->tot_sol_recmsmall }}</td>
        <td>{{ $data->tot_sol_recmsmall + $prev_vals->sum('tot_sol_recmsmall')}}</td>
    </tr>
    <tr>
        <th></th>
        <th>Female Owners</th>
        <td></td>
        <td>No.</td>
        @if($prev_vals == null)
            <th>0</th>
        @else
            <td>{{ $prev_vals->sum('tot_sol_recfsmall') }}</td>
        @endif
        <td>{{ $data->tot_sol_recfsmall }}</td>
        <td>{{ $data->tot_sol_recfsmall + $prev_vals->sum('tot_sol_recfsmall')}}</td>
    </tr>
    <tr style="background-color: cornflowerblue; color: black;">
        <th></th>
        <td></td>
        <th>Total</th>
        <td></td>

        <td>No.</td>
        @if($prev_vals == null)
            <th>0</th>
        @else
            <td>{{ $prev_vals->sum('tot_sol_recsmall') }}</td>
        @endif
        <th>{{ $data->tot_sol_recsmall }}</th>
        <th>{{ $data->tot_sol_recsmall + $prev_vals->sum('tot_sol_recsmall')}}</th>
    </tr>

    <tr>
        <th>3.2.6</th>
        <th>Amount Disbursed to Beneficiary Firms for Operational Grants</th>
        <th></th>
        <th></th>
        <th>NGN</th>
        @if($prev_vals == null)
            <th>0</th>
        @else
            <th>{{ $prev_vals->sum('tot_amt_dis') }}</th>
        @endif
        <th>{{ $data->tot_amt_dis }}</th>
        <th>{{ $data->tot_amt_dis + $prev_vals->sum('tot_amt_dis')}}</th>
    </tr>
    <tr>
        <th>3.2.6.1</th>
        <th rowspan="2">Micro Scale Firms</th>
        <th>Male Owners</th>
        <td></td>
        <td>No.</td>
        @if($prev_vals == null)
            <th>0</th>
        @else
            <td>{{ $prev_vals->sum('tot_amt_dismmicro') }}</td>
        @endif
        <td>{{ $data->tot_amt_dismmicro }}</td>
        <td>{{ $data->tot_amt_dismmicro + $prev_vals->sum('tot_amt_dismmicro') }}</td>
    </tr>
    <tr>
        <th></th>
        <th>Female Owners</th>
        <td></td>
        <td>No.</td>
        @if($prev_vals == null)
            <th>0</th>
        @else
            <td>{{ $prev_vals->sum('tot_amt_disfmicro') }}</td>
        @endif
        <td>{{ $data->tot_amt_disfmicro }}</td>
        <td>{{ $data->tot_amt_disfmicro + $prev_vals->sum('tot_amt_disfmicro')}}</td>
    </tr>
    <tr style="background-color: cornflowerblue; color: black;">
        <th></th>
        <td></td>
        <th>Total</th>
        <td></td>

        <td>No.</td>
        @if($prev_vals == null)
            <th>0</th>
        @else
            <td>{{ $prev_vals->sum('tot_amt_dismicro') }}</td>
        @endif
        <th>{{ $data->tot_amt_dismicro }}</th>
        <th>{{ $data->tot_amt_dismicro + $prev_vals->sum('tot_amt_dismicro')}}</th>
    </tr>
    <tr>
        <th>3.2.6.2</th>
        <th rowspan="2">Small Scale Firms</th>
        <th>Male Owners</th>
        <td></td>
        <td>No.</td>
        @if($prev_vals == null)
            <th>0</th>
        @else
            <td>{{ $prev_vals->sum('tot_amt_dismsmall') }}</td>
        @endif
        <td>{{ $data->tot_amt_dismsmall }}</td>
        <td>{{ $data->tot_amt_dismsmall + $prev_vals->sum('tot_amt_dismsmall')}}</td>
    </tr>
    <tr>
        <th></th>
        <th>Female Owners</th>
        <td></td>
        <td>No.</td>
        @if($prev_vals == null)
            <th>0</th>
        @else
            <td>{{ $prev_vals->sum('tot_amt_disfsmall') }}</td>
        @endif
        <td>{{ $data->tot_amt_disfsmall }}</td>
        <td>{{ $data->tot_amt_disfsmall + $prev_vals->sum('tot_amt_disfsmall') }}</td>
    </tr>
    <tr style="background-color: cornflowerblue; color: black;">
        <th></th>
        <td></td>
        <th>Total</th>
        <td></td>

        <td>No.</td>
        @if($prev_vals == null)
            <th>0</th>
        @else
            <td>{{ $prev_vals->sum('tot_amt_dissmall') }}</td>
        @endif
        <th>{{ $data->tot_amt_dissmall }}</th>
        <th>{{ $data->tot_amt_dissmall + $prev_vals->sum('tot_amt_dissmall')}}</th>
    </tr>
    </tbody>
</table>
