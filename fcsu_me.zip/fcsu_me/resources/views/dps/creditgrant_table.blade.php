<table class="table table-bordered" id="dataTable">
    <thead style="background-color: cornflowerblue; color: white">
    <tr>
        <th colspan="8">{{ Auth::user()->states->state }} {{ $data->dli->title }} Submission for {{ $data->months->date }}</th>
    </tr>
    <tr>
        <th>Dli</th>
        <th colspan="2">Disbursement Indicator</th>
        <th></th>
        <th>Unit of Measurement</th>
        <th>Previous (as at {{ $old_rec->months->date }} )</th>
        <th>Current (as at {{ $data->months->date }} )</th>
        <th>Total</th>
    </tr>
    </thead>
    <tbody>
    <tr>
        <th>3.1</th>
        <th>Number of Firms Receiving Conditional Matching Credit Grant to Support New Post-COVID 19 Loans</th>
        <th></th>
        <th></th>
        <th>No.</th>
        @if($prev_vals == null)
            <th>0</th>
        @else
            <th>{{ $prev_vals->sum('tot_reg') }}</th>
        @endif
        <th>{{ $data->tot_reg }}</th>
        <th>{{ $data->tot_reg + $prev_vals->sum('tot_reg')}}</th>
    </tr>
    <tr>
        <th>3.1.1.1</th>
        <th rowspan="2">Micro Scale Firms</th>
        <th>Male Owners</th>
        <td></td>
        <td>No.</td>
        @if($prev_vals == null)
            <th>0</th>
        @else
            <td>{{ $prev_vals->sum('tot_regmmicro') }}</td>
        @endif
        <td>{{ $data->tot_regmmicro }}</td>
        <td>{{ $data->tot_regmmicro + $prev_vals->sum('tot_regmmicro')}}</td>
    </tr>
    <tr>
        <th></th>
        <th>Female Owners</th>
        <td></td>
        <td>No.</td>
        @if($prev_vals == null)
            <th>0</th>
        @else
            <td>{{ $prev_vals->sum('tot_regfmicro') }}</td>
        @endif
        <td>{{ $data->tot_regfmicro }}</td>
        <td>{{ $data->tot_regfmicro + $prev_vals->sum('tot_regfmicro')}}</td>
    </tr>
    <tr style="background-color: cornflowerblue; color: black;">
        <th></th>
        <td></td>
        <th>Total</th>
        <td></td>

        <td>No.</td>
        @if($prev_vals == null)
            <th>0</th>
        @else
            <td>{{ $prev_vals->sum('tot_regmicro') }}</td>
        @endif
        <th>{{ $data->tot_regmicro }}</th>
        <th>{{ $data->tot_regmicro + $prev_vals->sum('tot_regmicro')}}</th>
    </tr>
    <tr>
        <th>3.1.1.2</th>
        <th rowspan="2">Small Scale Firms</th>
        <th>Male Owners</th>
        <td></td>
        <td>No.</td>
        @if($prev_vals == null)
            <th>0</th>
        @else
            <td>{{ $prev_vals->sum('tot_regmsmall') }}</td>
        @endif
        <td>{{ $data->tot_regmsmall }}</td>
        <td>{{ $data->tot_regmsmall + $prev_vals->sum('tot_regmsmall')}}</td>
    </tr>
    <tr>
        <th></th>
        <th>Female Owners</th>
        <td></td>
        <td>No.</td>
        @if($prev_vals == null)
            <th>0</th>
        @else
            <td>{{ $prev_vals->sum('tot_regfsmall') }}</td>
        @endif
        <td>{{ $data->tot_regfsmall }}</td>
        <td>{{ $data->tot_regfsmall + $prev_vals->sum('tot_regfsmall')}}</td>
    </tr>
    <tr style="background-color: cornflowerblue; color: black;">
        <th></th>
        <td></td>
        <th>Total</th>
        <td></td>

        <td>No.</td>
        @if($prev_vals == null)
            <th>0</th>
        @else
            <td>{{ $prev_vals->sum('tot_regsmall') }}</td>
        @endif
        <th>{{ $data->tot_regsmall }}</th>
        <th>{{ $data->tot_regsmall + $prev_vals->sum('tot_regsmall')}}</th>
    </tr>
    <tr>
        <th>3.1.2</th>
        <th>Total Number of Eligible and Verified Firms for Conditional Matching Credit Grants to Support Post-COVID-19 Loans</th>
        <th></th>
        <th></th>
        <th>No.</th>
        @if($prev_vals == null)
            <th>0</th>
        @else
            <th>{{ $prev_vals->sum('tot_eli_ver') }}</th>
        @endif
        <th>{{ $data->tot_eli_ver }}</th>
        <th>{{ $data->tot_eli_ver + $prev_vals->sum('tot_eli_ver')}}</th>
    </tr>

    <tr>
        <th>3.1.2.1</th>
        <th rowspan="2">Micro Scale Firms</th>
        <th>Male Owners</th>
        <td></td>
        <td>No.</td>
        @if($prev_vals == null)
            <th>0</th>
        @else
            <td>{{ $prev_vals->sum('tot_eli_vermmicro') }}</td>
        @endif
        <td>{{ $data->tot_eli_vermmicro }}</td>
        <td>{{ $data->tot_eli_vermmicro + $prev_vals->sum('tot_eli_vermmicro')}}</td>
    </tr>
    <tr>
        <th></th>
        <th>Female Owners</th>
        <td></td>
        <td>No.</td>
        @if($prev_vals == null)
            <th>0</th>
        @else
            <td>{{ $prev_vals->sum('tot_eli_verfmicro') }}</td>
        @endif
        <td>{{ $data->tot_eli_verfmicro }}</td>
        <td>{{ $data->tot_eli_verfmicro + $prev_vals->sum('tot_eli_verfmicro')}}</td>
    </tr>
    <tr style="background-color: cornflowerblue; color: black;">
        <th></th>
        <td></td>
        <th>Total</th>
        <td></td>

        <td>No.</td>
        @if($prev_vals == null)
            <th>0</th>
        @else
            <td>{{ $prev_vals->sum('tot_eli_vermicro') }}</td>
        @endif
        <th>{{ $data->tot_eli_vermicro }}</th>
        <th>{{ $data->tot_eli_vermicro + $prev_vals->sum('tot_eli_vermicro')}}</th>
    </tr>

    <tr>
        <th>3.1.2.2</th>
        <th rowspan="2">Small Scale Firms </th>
        <th>Male Owners</th>
        <td></td>
        <td>No.</td>
        @if($prev_vals == null)
            <th>0</th>
        @else
            <td>{{ $prev_vals->sum('tot_eli_vermsmall') }}</td>
        @endif
        <td>{{ $data->tot_eli_vermsmall }}</td>
        <td>{{ $data->tot_eli_vermsmall + $prev_vals->sum('tot_eli_vermsmall')}}</td>
    </tr>
    <tr>
        <th></th>
        <th>Female Owners</th>
        <td></td>
        <td>No.</td>
        @if($prev_vals == null)
            <th>0</th>
        @else
            <td>{{ $prev_vals->sum('tot_eli_verfsmall') }}</td>
        @endif
        <td>{{ $data->tot_eli_verfsmall }}</td>
        <td>{{ $data->tot_eli_verfsmall + $prev_vals->sum('tot_eli_verfsmall')}}</td>
    </tr>
    <tr style="background-color: cornflowerblue; color: black;">
        <th></th>
        <td></td>
        <th>Total</th>
        <td></td>

        <td>No.</td>
        @if($prev_vals == null)
            <th>0</th>
        @else
            <td>{{ $prev_vals->sum('tot_eli_versmall') }}</td>
        @endif
        <th>{{ $data->tot_eli_versmall }}</th>
        <th>{{ $data->tot_eli_versmall + $prev_vals->sum('tot_eli_versmall')}}</th>
    </tr>
    <tr>
        <th>3.1.3</th>
        <th>Total Number of Selected Firms for Conditional Matching Credit Grants to Support Post-COVID-19 Loans</th>
        <th></th>
        <th></th>
        <th>No.</th>
        @if($prev_vals == null)
            <th>0</th>
        @else
            <th>{{ $prev_vals->sum('tot_sel') }}</th>
        @endif
        <th>{{ $data->tot_sel }}</th>
        <th>{{ $data->tot_sel + $prev_vals->sum('tot_sel')}}</th>
    </tr>

    <tr>
        <th>3.1.3.1</th>
        <th rowspan="2">Micro Scale Firms</th>
        <th>Male Owners</th>
        <td></td>
        <td>No.</td>
        @if($prev_vals == null)
            <th>0</th>
        @else
            <td>{{ $prev_vals->sum('tot_selmmicro') }}</td>
        @endif
        <td>{{ $data->tot_selmmicro }}</td>
        <td>{{ $data->tot_selmmicro + $prev_vals->sum('tot_selmmicro')}}</td>
    </tr>
    <tr>
        <th></th>
        <th>Female Owners</th>
        <td></td>
        <td>No.</td>
        @if($prev_vals == null)
            <th>0</th>
        @else
            <td>{{ $prev_vals->sum('tot_selfmicro') }}</td>
        @endif
        <td>{{ $data->tot_selfmicro }}</td>
        <td>{{ $data->tot_selfmicro + $prev_vals->sum('tot_selfmicro')}}</td>
    </tr>
    <tr style="background-color: cornflowerblue; color: black;">
        <th></th>
        <td></td>
        <th>Total</th>
        <td></td>

        <td>No.</td>
        @if($prev_vals == null)
            <th>0</th>
        @else
            <td>{{ $prev_vals->sum('tot_selmicro') }}</td>
        @endif
        <th>{{ $data->tot_selmicro }}</th>
        <th>{{ $data->tot_selmicro + $prev_vals->sum('tot_selmicro')}}</th>
    </tr>

    <tr>
        <th>3.1.3.2</th>
        <th rowspan="2">Small Scale Firms</th>
        <th>Male Owners</th>
        <td></td>
        <td>No.</td>
        @if($prev_vals == null)
            <th>0</th>
        @else
            <td>{{ $prev_vals->sum('tot_selmsmall') }}</td>
        @endif
        <td>{{ $data->tot_selmsmall }}</td>
        <td>{{ $data->tot_selmsmall + $prev_vals->sum('tot_selmsmall')}}</td>
    </tr>
    <tr>
        <th></th>
        <th>Female Owners</th>
        <td></td>
        <td>No.</td>
        @if($prev_vals == null)
            <th>0</th>
        @else
            <td>{{ $prev_vals->sum('tot_selfsmall') }}</td>
        @endif
        <td>{{ $data->tot_selfsmall }}</td>
        <td>{{ $data->tot_selfsmall + $prev_vals->sum('tot_selfsmall')}}</td>
    </tr>
    <tr style="background-color: cornflowerblue; color: black;">
        <th></th>
        <td></td>
        <th>Total</th>
        <td></td>

        <td>No.</td>
        @if($prev_vals == null)
            <th>0</th>
        @else
            <td>{{ $prev_vals->sum('tot_selsmall') }}</td>
        @endif
        <th>{{ $data->tot_selsmall }}</th>
        <th>{{ $data->tot_selsmall + $prev_vals->sum('tot_selsmall')}}</th>
    </tr>

    <tr>
        <th>3.1.4</th>
        <th>Total Number of Verified Lending Financial Institutions for Matching Credit Grants to Support Post-COVID-19 Loans</th>
        <th></th>
        <th></th>
        <th>No.</th>
        @if($prev_vals == null)
            <th>0</th>
        @else
            <th>{{ $prev_vals->sum('tot_ver_len') }}</th>
        @endif
        <th>{{ $data->tot_ver_len }}</th>
        <th>{{ $data->tot_ver_len + $prev_vals->sum('tot_ver_len')}}</th>
    </tr>

    <tr>
        <th>3.1.5</th>
        <th>Total Number of Firms with Verified New Loan Records</th>
        <th></th>
        <th></th>
        <th>No.</th>
        @if($prev_vals == null)
            <th>0</th>
        @else
            <th>{{ $prev_vals->sum('tot_ver_newl') }}</th>
        @endif
        <th>{{ $data->tot_ver_newl }}</th>
        <th>{{ $data->tot_ver_newl + $prev_vals->sum('tot_ver_newl')}}</th>
    </tr>

    <tr>
        <th>3.1.5.1</th>
        <th rowspan="2">Micro Scale Firms</th>
        <th>Male Owners</th>
        <td></td>
        <td>No.</td>
        @if($prev_vals == null)
            <th>0</th>
        @else
            <td>{{ $prev_vals->sum('tot_ver_newlmmicro') }}</td>
        @endif
        <td>{{ $data->tot_ver_newlmmicro }}</td>
        <td>{{ $data->tot_ver_newlmmicro + $prev_vals->sum('tot_ver_newlmmicro')}}</td>
    </tr>
    <tr>
        <th></th>
        <th>Female Owners</th>
        <td></td>
        <td>No.</td>
        @if($prev_vals == null)
            <th>0</th>
        @else
            <td>{{ $prev_vals->sum('tot_ver_newlfmicro') }}</td>
        @endif
        <td>{{ $data->tot_ver_newlfmicro }}</td>
        <td>{{ $data->tot_ver_newlfmicro + $prev_vals->sum('tot_ver_newlfmicro')}}</td>
    </tr>
    <tr style="background-color: cornflowerblue; color: black;">
        <th></th>
        <td></td>
        <th>Total</th>
        <td></td>

        <td>No.</td>
        @if($prev_vals == null)
            <th>0</th>
        @else
            <td>{{ $prev_vals->sum('tot_ver_newlmicro') }}</td>
        @endif
        <th>{{ $data->tot_ver_newlmicro }}</th>
        <th>{{ $data->tot_ver_newlmicro + $prev_vals->sum('tot_ver_newlmicro')}}</th>
    </tr>
    <tr>
        <th>3.1.5.2</th>
        <th rowspan="2">Small Scale Firms</th>
        <th>Male Owners</th>
        <td></td>
        <td>No.</td>
        @if($prev_vals == null)
            <th>0</th>
        @else
            <td>{{ $prev_vals->sum('tot_ver_newlmsmall') }}</td>
        @endif
        <td>{{ $data->tot_ver_newlmsmall }}</td>
        <td>{{ $data->tot_ver_newlmsmall + $prev_vals->sum('tot_ver_newlmsmall')}}</td>
    </tr>
    <tr>
        <th></th>
        <th>Female Owners</th>
        <td></td>
        <td>No.</td>
        @if($prev_vals == null)
            <th>0</th>
        @else
            <td>{{ $prev_vals->sum('tot_ver_newlfsmall') }}</td>
        @endif
        <td>{{ $data->tot_ver_newlfsmall }}</td>
        <td>{{ $data->tot_ver_newlfsmall + $prev_vals->sum('tot_ver_newlfsmall')}}</td>
    </tr>
    <tr style="background-color: cornflowerblue; color: black;">
        <th></th>
        <td></td>
        <th>Total</th>
        <td></td>

        <td>No.</td>
        @if($prev_vals == null)
            <th>0</th>
        @else
            <td>{{ $prev_vals->sum('tot_ver_newlsmall') }}</td>
        @endif
        <th>{{ $data->tot_ver_newlsmall }}</th>
        <th>{{ $data->tot_ver_newlsmall + $prev_vals->sum('tot_ver_newlsmall')}}</th>
    </tr>


    <tr>
        <th>3.1.6</th>
        <th>Total Number of Firms Receiving Conditional Matching Credit Grant to Support New - Post-COVID19 Loans</th>
        <th></th>
        <th></th>
        <th>No.</th>
        @if($prev_vals == null)
            <th>0</th>
        @else
            <th>{{ $prev_vals->sum('tot_reccap') }}</th>
        @endif
        <th>{{ $data->tot_reccap }}</th>
        <th>{{ $data->tot_reccap + $prev_vals->sum('tot_reccap')}}</th>
    </tr>

    <tr>
        <th>3.1.6.1</th>
        <th rowspan="2">Micro Scale Firms</th>
        <th>Male Owners</th>
        <td></td>
        <td>No.</td>
        @if($prev_vals == null)
            <th>0</th>
        @else
            <td>{{ $prev_vals->sum('tot_reccap_mmicro') }}</td>
        @endif
        <td>{{ $data->tot_reccap_mmicro }}</td>
        <td>{{ $data->tot_reccap_mmicro + $prev_vals->sum('tot_reccap_mmicro')}}</td>
    </tr>
    <tr>
        <th></th>
        <th>Female Owners</th>
        <td></td>
        <td>No.</td>
        @if($prev_vals == null)
            <th>0</th>
        @else
            <td>{{ $prev_vals->sum('tot_reccap_fmicro') }}</td>
        @endif
        <td>{{ $data->tot_reccap_fmicro }}</td>
        <td>{{ $data->tot_reccap_fmicro + $prev_vals->sum('tot_reccap_fmicro')}}</td>
    </tr>
    <tr style="background-color: cornflowerblue; color: black;">
        <th></th>
        <td></td>
        <th>Total</th>
        <td></td>

        <td>No.</td>
        @if($prev_vals == null)
            <th>0</th>
        @else
            <td>{{ $prev_vals->sum('tot_reccap_micro') }}</td>
        @endif
        <th>{{ $data->tot_reccap_micro }}</th>
        <th>{{ $data->tot_reccap_micro + $prev_vals->sum('tot_reccap_micro')}}</th>
    </tr>
    <tr>
        <th>3.1.6.2</th>
        <th rowspan="2">Small Scale Firms</th>
        <th>Male Owners</th>
        <td></td>
        <td>No.</td>
        @if($prev_vals == null)
            <th>0</th>
        @else
            <td>{{ $prev_vals->sum('tot_reccapmsmall') }}</td>
        @endif
        <td>{{ $data->tot_reccapmsmall }}</td>
        <td>{{ $data->tot_reccapmsmall + $prev_vals->sum('tot_reccapmsmall')}}</td>
    </tr>
    <tr>
        <th></th>
        <th>Female Owners</th>
        <td></td>
        <td>No.</td>
        @if($prev_vals == null)
            <th>0</th>
        @else
            <td>{{ $prev_vals->sum('tot_reccapfsmall') }}</td>
        @endif
        <td>{{ $data->tot_reccapfsmall }}</td>
        <td>{{ $data->tot_reccapfsmall + $prev_vals->sum('tot_reccapfsmall')}}</td>
    </tr>
    <tr style="background-color: cornflowerblue; color: black;">
        <th></th>
        <td></td>
        <th>Total</th>
        <td></td>
        <td>No.</td>
        @if($prev_vals == null)
            <th>0</th>
        @else
            <td>{{ number_format($prev_vals->sum('tot_reccap_small'), 2) }}</td>
        @endif
        <th>{{ number_format($data->tot_reccap_small, 2) }}</th>
        <th>{{ number_format($data->tot_reccap_small + $prev_vals->sum('tot_reccap_small'), 2)}}</th>
    </tr>

    <tr>
        <th>3.1.7</th>
        <th>Amount Disbursed to Lending Financial Institutions (on behalf of Beneficiary Firms)</th>
        <th></th>
        <th></th>
        <th>NGN</th>
        @if($prev_vals == null)
            <th>0</th>
        @else
            <th>{{ number_format($prev_vals->sum('amt_dis'),2) }}</th>
        @endif
        <th>{{ number_format($data->amt_dis, 2)}}</th>
        <th>{{ number_format($data->amt_dis + $prev_vals->sum('amt_dis')), 2}}</th>
    </tr>
    <tr>
        <th>3.1.7.1</th>
        <th>Micro Scale Firms</th>
        <th></th>
        <th></th>
        <th>NGN</th>
        @if($prev_vals == null)
            <th>0</th>
        @else
            <th>{{ number_format($prev_vals->sum('amt_dismicro'), 2) }}</th>
        @endif
        <th>{{ number_format($data->amt_dismicro, 2) }}</th>
        <th>{{ number_format($data->amt_dismicro + $prev_vals->sum('amt_dismicro'), 2)}}</th>
    </tr>

    <tr>
        <th>3.1.7.2</th>
        <th>Micro Scale Firms</th>
        <th></th>
        <th></th>
        <th>NGN</th>
        @if($prev_vals == null)
            <th>0</th>
        @else
            <th>{{ number_format($prev_vals->sum('amt_dissmall'),2) }}</th>
        @endif
        <th>{{ number_format($data->amt_dissmall, 2) }}</th>
        <th>{{ number_format($data->amt_dissmall + $prev_vals->sum('amt_dissmall'), 2)}}</th>
    </tr>

    </tbody>
</table>
