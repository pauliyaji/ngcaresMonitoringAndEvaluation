<table class="table table-bordered" id="dataTable">
    <thead style="background-color: cornflowerblue; color: white">
    <tr>
        <th colspan="8">{{ Auth::user()->states->state }} {{ $data->dli->title }} Submission for {{ $data->months->date }}</th>
    </tr>
    <tr>
        <th>Dli</th>
        <th colspan="2">Disbursement Indicator</th>
        <th></th>
        <th>Unit of Measurement</th>
        <th>Previous (as at {{ $old_rec->months->date }} )</th>
        <th>Current (as at {{ $data->months->date }})</th>
        <th>Total</th>
    </tr>
    </thead>
    <tbody>
    <tr>
        <th>1.3.1</th>
        <th rowspan="2">Total Number of Beneficiaries Mined from Agreed Register</th>
        <th>Female</th>
        <td></td>
        <td>No.</td>
        @if($prev_vals == null)
            <th>0</th>
        @else
            <td>{{ $prev_vals->sum('f_mined') }}</td>
        @endif
        <td>{{ $data->f_mined }}</td>
        <td>{{ $data->f_mined + $prev_vals->sum('f_mined')  }}</td>
    </tr>
    <tr>
        <th></th>
        <th>Male</th>
        <td></td>
        <td>No.</td>
        @if($prev_vals == null)
            <th>0</th>
        @else
            <td>{{ $prev_vals->sum('m_mined') }}</td>
        @endif
        <td>{{ $data->m_mined }}</td>
        <td>{{ $data->m_mined + $prev_vals->sum('m_mined') }}</td>
    </tr>
    <tr style="background-color: cornflowerblue; color: black;">
        <th></th>
        <td></td>
        <th>Total</th>
        <td></td>

        <td>No.</td>
        @if($prev_vals == null)
            <th>0</th>
        @else
            <td>{{ $prev_vals->sum('tot_mined') }}</td>
        @endif
        <th>{{ $data->tot_mined }}</th>
        <th>{{ $data->tot_mined + $prev_vals->sum('tot_mined') }}</th>
    </tr>
    <tr>
        <th>1.3.2</th>
        <th rowspan="2">Total Number of Mined Beneficiaries Validated</th>
        <th>Female</th>
        <td></td>
        <td>No.</td>
        @if($prev_vals == null)
            <th>0</th>
        @else
            <td>{{ $prev_vals->sum('f_validated') }}</td>
        @endif
        <td>{{ $data->f_validated }}</td>
        <td>{{ $data->f_validated + $prev_vals->sum('f_validated') }}</td>
    </tr>
    <tr>
        <th></th>
        <th>Male</th>
        <td></td>
        <td>No.</td>
        @if($prev_vals == null)
            <th>0</th>
        @else
            <td>{{ $prev_vals->sum('m_validated') }}</td>
        @endif
        <td>{{ $data->m_validated }}</td>
        <td>{{ $data->m_validated + $prev_vals->sum('m_validated')}}</td>
    </tr>
    <tr style="background-color: cornflowerblue; color: black;">
        <th></th>
        <td></td>
        <th>Total</th>
        <td></td>

        <td>No.</td>
        @if($prev_vals == null)
            <th>0</th>
        @else
            <td>{{ $prev_vals->sum('tot_validated') }}</td>
        @endif
        <th>{{ $data->tot_validated }}</th>
        <th>{{ $data->tot_validated + $prev_vals->sum('tot_validated') }}</th>
    </tr>
    <tr>
        <th>1.3.3</th>
        <th rowspan="2">Total Number of Beneficiaries Trained on Livelihood</th>
        <th>Female</th>
        <td></td>
        <td>No.</td>
        @if($prev_vals == null)
            <th>0</th>
        @else
            <td>{{ $prev_vals->sum('f_train') }}</td>
        @endif
        <td>{{ $data->f_train }}</td>
        <td>{{ $data->f_train + $prev_vals->sum('f_train') }}</td>
    </tr>
    <tr>
        <th></th>
        <th>Male</th>
        <td></td>
        <td>No.</td>
        @if($prev_vals == null)
            <th>0</th>
        @else
            <td>{{ $prev_vals->sum('m_train') }}</td>
        @endif
        <td>{{ $data->m_train }}</td>
        <td>{{ $data->m_train + $prev_vals->sum('m_train')}}</td>
    </tr>
    <tr style="background-color: cornflowerblue; color: black;">
        <th></th>
        <td></td>
        <th>Total</th>
        <td></td>

        <td>No.</td>
        @if($prev_vals == null)
            <th>0</th>
        @else
            <td>{{ $prev_vals->sum('tot_train') }}</td>
        @endif
        <th>{{ $data->tot_train }}</th>
        <th>{{ $data->tot_train + $prev_vals->sum('tot_train')}}</th>
    </tr>
    <tr>
        <th>1.3.4</th>
        <th rowspan="2">Total Number of Beneficiaries that have Graduated from Livelihood Training</th>
        <th>Female</th>
        <td></td>
        <td>No.</td>
        @if($prev_vals == null)
            <th>0</th>
        @else
            <td>{{ $prev_vals->sum('f_grad') }}</td>
        @endif
        <td>{{ $data->f_grad }}</td>
        <td>{{ $data->f_grad + $prev_vals->sum('f_grad')}}</td>
    </tr>
    <tr>
        <th></th>
        <th>Male</th>
        <td></td>
        <td>No.</td>
        @if($prev_vals == null)
            <th>0</th>
        @else
            <td>{{ $prev_vals->sum('m_grad') }}</td>
        @endif
        <td>{{ $data->m_grad }}</td>
        <td>{{ $data->m_grad + $prev_vals->sum('m_grad')}}</td>
    </tr>
    <tr style="background-color: cornflowerblue; color: black;">
        <th></th>
        <td></td>
        <th>Total</th>
        <td></td>

        <td>No.</td>
        @if($prev_vals == null)
            <th>0</th>
        @else
            <td>{{ $prev_vals->sum('tot_grad') }}</td>
        @endif
        <th>{{ $data->tot_grad }}</th>
        <th>{{ $data->tot_grad + $prev_vals->sum('tot_grad')}}</th>
    </tr>

    <tr>
        <th>1.3.5</th>
        <th>Total Amount Transferred to PSP</th>
        <th></th>
        <th></th>
        <th>NGN</th>
        @if($prev_vals == null)
            <th>0</th>
        @else
            <th>{{ number_format($prev_vals->sum('amt_transpsp'), 2) }}</th>
        @endif
        <th>{{ number_format($data->amt_transpsp, 2)}}</th>
        <th>{{ number_format($data->amt_transpsp + $prev_vals->sum('amt_transpsp'), 2)}}</th>
    </tr>

    <tr>
        <th>1.3.6</th>
        <th rowspan="2">Total Number of Beneficiaries Transferred to PSP for Payment</th>
        <th>Female</th>
        <td></td>
        <td>No.</td>
        @if($prev_vals == null)
            <th>0</th>
        @else
            <td>{{ $prev_vals->sum('tot_fbeneforpsppay') }}</td>
        @endif
        <td>{{ $data->tot_fbeneforpsppay }}</td>
        <td>{{ $data->tot_fbeneforpsppay + $prev_vals->sum('tot_fbeneforpsppay')}}</td>
    </tr>
    <tr>
        <th></th>
        <th>Male</th>
        <td></td>
        <td>No.</td>
        @if($prev_vals == null)
            <th>0</th>
        @else
            <td>{{ $prev_vals->sum('tot_mbeneforpsppay') }}</td>
        @endif
        <td>{{ $data->tot_mbeneforpsppay }}</td>
        <td>{{ $data->tot_mbeneforpsppay + $prev_vals->sum('tot_mbeneforpsppay')}}</td>
    </tr>
    <tr style="background-color: cornflowerblue; color: black;">
        <th></th>
        <td></td>
        <th>Total</th>
        <td></td>

        <td>No.</td>
        @if($prev_vals == null)
            <th>0</th>
        @else
            <td>{{ $prev_vals->sum('tot_beneforpsppay') }}</td>
        @endif
        <th>{{ $data->tot_beneforpsppay }}</th>
        <th>{{ $data->tot_beneforpsppay + $prev_vals->sum('tot_beneforpsppay')}}</th>
    </tr>
    <tr>
        <th>1.3.7</th>
        <th rowspan="2">Total Number of Beneficiaries Supported with Livelihood Grants</th>
        <th>Female</th>
        <td></td>
        <td>No.</td>
        @if($prev_vals == null)
            <th>0</th>
        @else
            <td>{{ $prev_vals->sum('tot_fbenerecv') }}</td>
        @endif
        <td>{{ $data->tot_fbenerecv }}</td>
        <td>{{ $data->tot_fbenerecv + $prev_vals->sum('tot_fbenerecv')}}</td>
    </tr>
    <tr>
        <th></th>
        <th>Male</th>
        <td></td>
        <td>No.</td>
        @if($prev_vals == null)
            <th>0</th>
        @else
            <td>{{ $prev_vals->sum('tot_mbenerecv') }}</td>
        @endif
        <td>{{ $data->tot_mbenerecv }}</td>
        <td>{{ $data->tot_mbenerecv + $prev_vals->sum('tot_mbenerecv')}}</td>
    </tr>
    <tr style="background-color: cornflowerblue; color: black;">
        <th></th>
        <td></td>
        <th>Total</th>
        <td></td>

        <td>No.</td>
        @if($prev_vals == null)
            <th>0</th>
        @else
            <td>{{ $prev_vals->sum('tot_benerecv') }}</td>
        @endif
        <th>{{ $data->tot_benerecv }}</th>
        <th>{{ $data->tot_benerecv + $prev_vals->sum('tot_benerecv')}}</th>
    </tr>

    <tr>
        <th>1.3.8</th>
        <th>Total Amount Paid to Beneficiaries</th>
        <th></th>
        <th></th>
        <th>NGN</th>
        @if($prev_vals == null)
            <th>0</th>
        @else
            <th>{{ number_format($prev_vals->sum('tot_paidbene'), 2) }}</th>
        @endif
        <th>{{ number_format($data->tot_paidbene, 2)}}</th>
        <th>{{ number_format($data->tot_paidbene + $prev_vals->sum('tot_paidbene'), 2)}}</th>
    </tr>

    </tbody>
</table>
