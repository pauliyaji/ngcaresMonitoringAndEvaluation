
@extends('layouts/layout')

@section('content')

    <!-- Begin Page Content -->
    <div class="container-fluid">

        <!-- Page Heading -->

        <!-- DataTales Example -->
        <div class="card shadow mb-4">
            <div class="card-header py-3">
                <h4 class="m-0 font-weight-bold text-primary">All {{ Auth::user()->dps->name }} Submissions {{--from {{ Auth::user()->states->state }}--}}
                    <a href="#" class="float-right btn btn-success btn-sm">Back</a>
                </h4>
            </div>
            <div class="card-body">
                @if(Session::has('success'))
                    <p class="text-success">{{ Session('success') }}</p>
                @endif
                    <div class="table-responsive">

                        <table class="table table-bordered" id="dataTable">
                            <thead>
                            <tr>
                                <th>State</th>
                                <th>DP</th>
                                <th>Status</th>
                                <th>Period</th>
                                <th>Date</th>
                                <th>Action</th>

                            </tr>
                            </thead>
                            <tfoot>
                            <tr>
                                <th>State</th>
                                <th>Head M&E</th>
                                <th>Status</th>
                                <th>Period</th>
                                <th>Date</th>
                                <th>Action</th>
                            </tr>
                            </tfoot>
                            <tbody>
                            @if($sts)
                                @foreach($sts as $d)
                                    <tr>
                                        <td>{{ $d->states->state }}</td>
                                        <td>{{ $d->dli->title  }}</td>
                                        <td style="color: green; font-weight: bold">{{ $d->status->status }}</td>
                                        <td> {{ $d->months->date }}</td>
                                        <td>{{ date('d-M-Y', strtotime($d->created_at)) }}</td>

                                        <td>

                                                <a href="{{route('socialtransfers.show', $d->id) }}" class="btn btn-info btn-sm"><i class="fa fa-eye"></i></a>
                                                <a href="{{ route('dps.sts_report', $d->id) }}" class="btn btn-primary btn-sm">View report</a>

                                        </td>
                                    </tr>
                                @endforeach
                            @endif
                            @if($lipws)
                                @foreach($lipws as $d)
                                    <tr>
                                        <td>{{ $d->states->state }}</td>
                                        <td>{{ $d->dli->title  }}</td>
                                        <td style="color: green; font-weight: bold">{{ $d->status->status }}</td>
                                        <td> {{ $d->months->date }}</td>
                                        <td>{{ date('d-M-Y', strtotime($d->created_at)) }}</td>

                                        <td>
                                                    <a href="{{ route('lipws.show', $d->id) }}" class="btn btn-info btn-sm"><i class="fa fa-eye"></i></a>
                                                    <a href="{{ route('dps.lipws_report', $d->id) }}" class="btn btn-primary btn-sm">View report</a>
                                        </td>
                                    </tr>
                                @endforeach
                            @endif
                            @if($lihds)
                                @foreach($lihds as $d)
                                    <tr>
                                        <td>{{ $d->states->state }}</td>
                                        <td>{{ $d->dli->title  }}</td>
                                        <td style="color: green; font-weight: bold">{{ $d->status->status }}</td>
                                        <td> {{ $d->months->date }}</td>
                                        <td>{{ date('d-M-Y', strtotime($d->created_at)) }}</td>

                                        <td>
                                                    <a href="{{ route('livelihoods.show', $d->id) }}" class="btn btn-info btn-sm"><i class="fa fa-eye"></i></a>
                                                    <a href="{{ route('dps.livelihood_report', $d->id) }}" class="btn btn-primary btn-sm">View report</a>

                                        </td>
                                    </tr>
                                @endforeach
                            @endif
                            @if($bss)
                                @foreach($bss as $d)
                                    <tr>
                                        <td>{{ $d->states->state }}</td>
                                        <td>{{ $d->dli->title  }}</td>
                                        <td style="color: green; font-weight: bold">{{ $d->status->status }}</td>
                                        <td> {{ $d->months->date }}</td>
                                        <td>{{ date('d-M-Y', strtotime($d->created_at)) }}</td>

                                        <td>
                                                    <a href="{{ route('basicservices.show', $d->id) }}" class="btn btn-info btn-sm"><i class="fa fa-eye"></i></a>
                                                    <a href="{{ route('dps.basicservices_report', $d->id) }}" class="btn btn-primary btn-sm">View report</a>

                                        </td>
                                    </tr>
                                @endforeach
                            @endif
                          {{--  @if($aginps)
                                @foreach($aginps as $d)
                                    <tr>
                                        <td>{{ $d->states->state }}</td>
                                        <td>{{ $d->dli->title  }}</td>
                                        <td style="color: green; font-weight: bold">{{ $d->status->status }}</td>
                                        <td>{{ date('d-M-Y', strtotime($d->created_at)) }}</td>

                                        <td>
                                            @if(Auth::user()->id == 1)
                                                <a href="#" class="btn btn-info btn-sm"><i class="fa fa-eye"></i></a>
                                                <a href="#" class="btn btn-primary btn-sm"><i class="fa fa-edit"></i></a>
                                            @elseif($d->user_id == Auth::user()->id)
                                                <a href="#" class="btn btn-info btn-sm"><i class="fa fa-eye"></i></a>
                                                <a href="#" class="btn btn-primary btn-sm"><i class="fa fa-edit"></i></a>

                                            @elseif($d->dp_id == Auth::user()->dp_id)
                                                <a href="{{ route('agric_inputs.show', $d->id) }}" class="btn btn-info btn-sm"><i class="fa fa-eye"></i></a>
                                            @endif
                                        </td>
                                    </tr>
                                @endforeach
                            @endif--}}
                            @if($aginfs)
                                @foreach($aginfs as $d)
                                    <tr>
                                        <td>{{ $d->states->state }}</td>
                                        <td>{{ $d->dli->title  }}</td>
                                        <td style="color: green; font-weight: bold">{{ $d->status->status }}</td>
                                        <td> {{ $d->months->date }}</td>
                                        <td>{{ date('d-M-Y', strtotime($d->created_at)) }}</td>

                                        <td>
                                                <a href="{{ route('agric_infrastructures.show', $d->id) }}" class="btn btn-info btn-sm"><i class="fa fa-eye"></i></a>
                                                <a href="{{ route('dps.agric_infrastructure_report', $d->id) }}" class="btn btn-primary btn-sm">View report</a>

                                        </td>
                                    </tr>
                                @endforeach
                            @endif
                            @if($agass)
                                @foreach($agass as $d)
                                    <tr>
                                        <td>{{ $d->states->state }}</td>
                                        <td>{{ $d->dli->title  }}</td>
                                        <td style="color: green; font-weight: bold">{{ $d->status->status }}</td>
                                        <td> {{ $d->months->date }}</td>
                                        <td>{{ date('d-M-Y', strtotime($d->created_at)) }}</td>

                                        <td>
                                                <a href="{{ route('agric_assets.show', $d->id) }}" class="btn btn-info btn-sm"><i class="fa fa-eye"></i></a>
                                                <a href="{{ route('dps.agric_assets_report', $d->id) }}" class="btn btn-primary btn-sm">View report</a>

                                        </td>
                                    </tr>
                                @endforeach
                            @endif
                            @if($wms)
                                @foreach($wms as $d)
                                    <tr>
                                        <td>{{ $d->states->state }}</td>
                                        <td>{{ $d->dli->title  }}</td>
                                        <td style="color: green; font-weight: bold">{{ $d->status->status }}</td>
                                        <td> {{ $d->months->date }}</td>
                                        <td>{{ date('d-M-Y', strtotime($d->created_at)) }}</td>

                                        <td>
                                                <a href="{{ route('wetmarkets.show', $d->id) }}" class="btn btn-info btn-sm"><i class="fa fa-eye"></i></a>
                                            <a href="{{ route('dps.wetmarket_report', $d->id) }}" class="btn btn-primary btn-sm">View report</a>

                                        </td>
                                    </tr>
                                @endforeach
                            @endif
                         @if($cgs)
                                @foreach($cgs as $d)
                                    <tr>
                                        <td>{{ $d->states->state }}</td>
                                        <td>{{ $d->dli->title  }}</td>
                                        <td style="color: green; font-weight: bold">{{ $d->status->status }}</td>
                                        <td> {{ $d->months->date }}</td>
                                        <td>{{ date('d-M-Y', strtotime($d->created_at)) }}</td>

                                        <td>
                                                <a href="{{ route('credit_grants.show', $d->id) }}" class="btn btn-info btn-sm"><i class="fa fa-eye"></i></a>
                                            <a href="{{ route('dps.creditgrant_report', $d->id) }}" class="btn btn-primary btn-sm">View report</a>

                                        </td>
                                    </tr>
                                @endforeach
                            @endif
                              @if($ops)
                                  @foreach($ops as $d)
                                      <tr>
                                          <td>{{ $d->states->state }}</td>
                                          <td>{{ $d->dli->title  }}</td>
                                          <td style="color: green; font-weight: bold">{{ $d->status->status }}</td>
                                          <td> {{ $d->months->date }}</td>
                                          <td>{{ date('d-M-Y', strtotime($d->created_at)) }}</td>

                                          <td>

                                                  <a href="{{ route('operations_grant.show', $d->id) }}" class="btn btn-info btn-sm"><i class="fa fa-eye"></i></a>
                                              <a href="{{ route('dps.operationsgrant_report', $d->id) }}" class="btn btn-primary btn-sm">View report</a>

                                          </td>
                                      </tr>
                                  @endforeach
                              @endif
                               @if($ens)
                                  @foreach($ens as $d)
                                      <tr>
                                          <td>{{ $d->states->state }}</td>
                                          <td>{{ $d->dli->title  }}</td>
                                          <td style="color: green; font-weight: bold">{{ $d->status->status }}</td>
                                          <td> {{ $d->months->date }}</td>
                                          <td>{{ date('d-M-Y', strtotime($d->created_at)) }}</td>

                                          <td>

                                                  <a href="{{ route('enhancement_grants.show', $d->id) }}" class="btn btn-info btn-sm"><i class="fa fa-eye"></i></a>
                                                  <a href="{{ route('dps.enhancementgrant_report', $d->id) }}" class="btn btn-primary btn-sm">View report</a>

                                          </td>
                                      </tr>
                                  @endforeach
                              @endif

                            </tbody>
                        </table>
                    </div>


            </div>
        </div>

  </div>
    <!-- /.container-fluid -->

@endsection

@include('layouts/footer')


<!-- Bootstrap core JavaScript-->

