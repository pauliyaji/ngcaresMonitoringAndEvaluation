
@extends('layouts/layout')

@section('content')

    <!-- Begin Page Content -->
    <div class="container-fluid">

        <!-- Page Heading -->

        <!-- DataTales Example -->
        <div class="card shadow mb-4">
            <div class="card-header py-3">
                <h4 class="m-0 font-weight-bold text-primary">{{ Auth::user()->states->state }} {{ $data->dli->title }} Submission for {{ $data->months->date }} {{--from {{ Auth::user()->states->state }}--}}
                    <a href="{{ url()->previous() }}" class="float-right btn btn-success btn-sm">Back</a>
                </h4>
            </div>
            <div class="card-body">
                @if(Session::has('success'))
                    <p class="text-success">{{ Session('success') }}</p>
                @endif
                <div class="table-responsive">

                    <table class="table table-bordered" id="dataTable">
                        <thead style="background-color: cornflowerblue; color: white">
                        <tr>
                            <th>Dli</th>
                            <th colspan="2">Disbursement Indicator</th>
                            <th></th>
                            <th>Unit of Measurement</th>
                            <th>Previous (as at {{ $old_date->date }} )</th>
                            <th>Current (as at {{ $data->months->date }})</th>
                            <th>Total</th>
                        </tr>
                        </thead>
                        <tfoot style="background-color: cornflowerblue; color: white">
                        <tr>
                            <th>Dli</th>
                            <th colspan="2">Disbursement Indicator</th>
                            <th></th>
                            <th>Unit of Measurement</th>
                            <th>Previous (as at {{ $old_date->date }} )</th>
                            <th>Current (as at {{ $data->months->date }})</th>
                            <th>Total</th>
                        </tr>
                        </tfoot>
                       <tbody>
                       <tr>
                       <th>1.1.1</th>
                       <th rowspan="2">Total Number of Beneficiaries Mined from Agreed Register</th>
                           <th>Female</th>
                           <td></td>
                           <td>No.</td>
                           @if($previous == null)
                               <th>0</th>
                           @else
                               <td>{{ $previous->f_mined }}</td>
                           @endif
                           <td>{{ $data->f_mined }}</td>
                           @if($previous != null)
                           <td>{{ $data->f_mined + $previous->f_mined }}</td>
                               @endif
                       </tr>
                       <tr>
                           <th></th>
                           <th>Male</th>
                           <td></td>
                           <td>No.</td>
                           @if($previous == null)
                               <th>0</th>
                           @else
                               <td>{{ $previous->m_mined }}</td>
                           @endif
                           <td>{{ $data->m_mined }}</td>
                           @if($previous != null)
                           <td>{{ $data->m_mined + $previous->m_mined }}</td>
                           @endif
                       </tr>
                       <tr style="background-color: cornflowerblue; color: black;">
                           <th></th>
                           <td></td>
                           <th>Total</th>
                           <td></td>

                           <td>No.</td>
                           @if($previous == null)
                               <th>0</th>
                           @else
                               <td>{{ $previous->tot_mined }}</td>
                           @endif
                           <th>{{ $data->tot_mined }}</th>
                           @if($previous != null)
                           <th>{{ $data->tot_mined + $previous->tot_mined}}</th>
                               @endif
                       </tr>

                       <tr>
                           <th>1.1.2</th>
                           <th rowspan="4">Total Number of Beneficiaries Mined disaggregated by vulnerability profile: Aged, Chronically Ill, Urban Poor and People with Special Needs. </th>
                           <th>Aged</th>
                           <td></td>
                           <td>No.</td>
                           @if($previous == null)
                               <th>0</th>
                           @else
                               <td>{{ $previous->aged_mined }}</td>
                           @endif
                           <td>{{ $data->aged_mined }}</td>
                           @if($previous != null)
                           <td>{{ $data->aged_mined + $previous->aged_mined}}</td>
                               @endif
                       </tr>
                       <tr>
                           <th></th>
                           <th>Chronically ill</th>
                           <td></td>
                           <td>No.</td>
                           @if($previous == null)
                               <th>0</th>
                           @else
                               <td>{{ $previous->chro_mined }}</td>
                           @endif
                           <td>{{ $data->chro_mined }}</td>
                           @if($previous != null)
                           <td>{{ $data->chro_mined + $previous->chro_mined }}</td>
                               @endif
                       </tr>
                       <tr>
                           <th></th>
                           <th>Urban Poor</th>
                           <td></td>
                           <td>No.</td>
                           @if($previous == null)
                               <th>0</th>
                           @else
                               <td>{{ $previous->urban_mined }}</td>
                           @endif
                           <td>{{ $data->urban_mined }}</td>
                           @if($previous != null)
                           <td>{{ $data->urban_mined + $previous->urban_mined }}</td>
                               @endif
                       </tr>
                       <tr>
                           <th></th>
                           <th>People with Special Needs</th>
                           <td></td>
                           <td>No.</td>
                           @if($previous == null)
                               <th>0</th>
                           @else
                               <td>{{ $previous->needs_mined }}</td>
                           @endif
                           <td>{{ $data->needs_mined }}</td>
                           @if($previous != null)
                           <td>{{ $data->needs_mined  + $previous->needs_mined }}</td>
                               @endif
                       </tr>
                       <tr style="background-color: cornflowerblue; color: black;">
                           <th></th>
                           <td></td>
                           <th>Total</th>
                           <td></td>
                           <td>No.</td>
                           @if($previous == null)
                               <th>0</th>
                           @else
                               <td>{{ $previous->aged_mined + $previous->chro_mined + $previous->urban_mined + $previous->needs_mined }}</td>
                           @endif
                           <th>{{ $data->aged_mined + $data->chro_mined + $data->urban_mined + $data->needs_mined }}</th>
                           @if($previous != null)
                           <th>{{ $data->aged_mined + $data->chro_mined + $data->urban_mined + $data->needs_mined + $previous->aged_mined + $previous->chro_mined + $previous->urban_mined + $previous->needs_mined}}</th>
                            @endif
                       </tr>

                       <tr>
                           <th>1.1.3</th>
                           <th rowspan="2">Total Number of Mined Beneficiaries Validated</th>
                           <th>Female</th>
                           <td></td>
                           <td>No.</td>
                           @if($previous == null)
                               <th>0</th>
                           @else
                               <td>{{ $previous->f_validated }}</td>
                           @endif
                           <td>{{ $data->f_validated }}</td>
                           @if($previous != null)
                           <td>{{ $data->f_validated + $previous->f_validated }}</td>
                               @endif
                       </tr>
                       <tr>
                           <th></th>
                           <th>Male</th>
                           <td></td>
                           <td>No.</td>
                           @if($previous == null)
                               <th>0</th>
                           @else
                               <td>{{ $previous->m_validated }}</td>
                           @endif
                           <td>{{ $data->m_validated }}</td>
                           @if($previous != null)
                           <td>{{ $data->m_validated + $previous->m_validated}}</td>
                               @endif
                       </tr>
                       <tr style="background-color: cornflowerblue; color: black;">
                           <th></th>
                           <td></td>
                           <th>Total</th>
                           <td></td>
                           <td>No.</td>
                           @if($previous == null)
                               <th>0</th>
                           @else
                               <td>{{ $previous->tot_validated }}</td>
                           @endif
                           <th>{{ $data->tot_validated }}</th>
                           @if($previous != null)
                           <th>{{ $data->tot_validated + $previous->tot_validated }}</th>
                               @endif
                       </tr>

                       <tr>
                           <th rowspan="8">1.1.4</th>
                           <th rowspan="7">Total Number of Beneficiaries Enrolled disaggregated by vulnerability profile: Aged, Chronically ill, Urban Poor and People with Special Needs </th>
                           <th rowspan="2">Aged</th>
                           <th>Female</th>
                           <td>No.</td>
                           @if($previous == null)
                               <th>0</th>
                           @else
                               <td>{{ $previous->aged_fenrolled }}</td>
                           @endif
                           <td>{{ $data->aged_fenrolled }}</td>
                           @if($previous != null)
                           <td>{{ $data->aged_fenrolled + $previous->aged_fenrolled }}</td>
                       @endif
                       <tr>

                           <th>Male</th>
                           <td>No.</td>
                           @if($previous == null)
                               <th>0</th>
                           @else
                               <td>{{ $previous->aged_menrolled }}</td>
                           @endif
                           <td>{{ $data->aged_menrolled }}</td>
                           @if($previous != null)
                           <td>{{ $data->aged_menrolled + $previous->aged_menrolled}}</td>
                               @endif
                       </tr>

                       </tr>
                       <tr>

                           <th rowspan="2">Chronically ill</th>
                           <th>Female</th>
                           <td>No.</td>
                           @if($previous == null)
                               <th>0</th>
                           @else
                               <td>{{ $previous->chro_fenrolled }}</td>
                           @endif
                           <td>{{ $data->chro_fenrolled }}</td>
                           @if($previous != null)
                           <td>{{ $data->chro_fenrolled + $previous->chro_fenrolled}}</td>
                       @endif
                       <tr>

                           <th>Male</th>
                           <td>No.</td>
                           @if($previous == null)
                               <th>0</th>
                           @else
                               <td>{{ $previous->chro_menrolled }}</td>
                           @endif
                           <td>{{ $data->chro_menrolled }}</td>
                           @if($previous != null)
                           <td>{{ $data->chro_menrolled + $previous->chro_menrolled}}</td>
                               @endif
                       </tr>
                       </tr>
                       <tr>

                           <th rowspan="2">Urban Poor</th>
                           <th>Female</th>
                           <td>No.</td>
                           @if($previous == null)
                               <th>0</th>
                           @else
                               <td>{{ $previous->urban_fenrolled }}</td>
                           @endif
                           <td>{{ $data->urban_fenrolled }}</td>
                           @if($previous != null)
                           <td>{{ $data->urban_fenrolled + $previous->urban_fenrolled }}</td>
                       @endif
                       <tr>

                           <th>Male</th>
                           <td>No.</td>
                           @if($previous == null)
                               <th>0</th>
                           @else
                               <td>{{ $previous->urban_menrolled }}</td>
                           @endif
                           <td>{{ $data->urban_menrolled }}</td>
                           @if($previous != null)
                           <td>{{ $data->urban_menrolled + $previous->urban_menrolled }}</td>
                               @endif
                       </tr>
                       </tr>
                       <tr>

                           <th rowspan="2">People with Special Needs</th>
                           <th>Female</th>
                           <td>No.</td>
                           @if($previous == null)
                               <th>0</th>
                           @else
                               <td>{{ $previous->needs_fenrolled }}</td>
                           @endif
                           <td>{{ $data->needs_fenrolled }}</td>
                           @if($previous != null)
                           <td>{{ $data->needs_fenrolled + $previous->needs_fenrolled }}</td>
                       @endif
                       <tr>
                           <th></th>
                           <th>Male</th>
                           <td>No.</td>
                           @if($previous == null)
                               <th>0</th>
                           @else
                               <td>{{ $previous->needs_menrolled }}</td>
                           @endif
                           <td>{{ $data->needs_menrolled }}</td>
                           @if($previous != null)
                           <td>{{ $data->needs_menrolled }}</td>
                               @endif
                       </tr>
                       </tr>
                       <tr style="background-color: cornflowerblue; color: black;">
                           <th></th>
                           <th></th>
                           <th>Total</th>
                           <th></th>
                           <td>No.</td>
                           @if($previous == null)
                               <th>0</th>
                           @else
                               <td>{{ $previous->tot_enrolled }}</td>
                           @endif
                           <th>{{ $data->tot_enrolled}}</th>
                           @if($previous != null)
                           <th>{{ $data->tot_enrolled + $previous->tot_enrolled}}</th>
                               @endif
                       </tr>
                       <tr>
                           <th>1.1.5</th>
                           <th>Total Number of Beneficiaries Paid </th>
                           <th></th>
                           <th></th>
                           <th>NGN</th>
                           @if($previous == null)
                               <th>0</th>
                           @else
                               <th>{{number_format($previous->amt_transpsp, 2) }}</th>
                           @endif
                           <th>{{ number_format($data->amt_transpsp, 2)}}</th>
                           @if($previous != null)
                           <th>{{ number_format(($data->amt_transpsp + $previous->amt_transpsp), 2)}}</th>
                               @endif
                       </tr>
                       <tr>
                           <th>1.1.6</th>
                           <th rowspan="2">Total Number of Beneficiaries Transferred to PSP for Payment</th>
                           <th>Female</th>
                           <td></td>
                           <td>No.</td>
                           @if($previous == null)
                               <th>0</th>
                           @else
                               <td>{{ $previous->tot_fbeneforpsppay }}</td>
                           @endif
                           <td>{{ $data->tot_fbeneforpsppay }}</td>
                           @if($previous != null)
                           <td>{{ $data->tot_fbeneforpsppay + $previous->tot_fbeneforpsppay }}</td>
                               @endif
                       </tr>
                       <tr>
                           <th></th>
                           <th>Male</th>
                           <td></td>
                           <td>No.</td>
                           @if($previous == null)
                               <th>0</th>
                           @else
                               <td>{{ $previous->tot_mbeneforpsppay }}</td>
                           @endif
                           <td>{{ $data->tot_mbeneforpsppay }}</td>
                           @if($previous != null)
                           <td>{{ $data->tot_mbeneforpsppay + $previous->tot_mbeneforpsppay }}</td>
                               @endif
                       </tr>
                       <tr style="background-color: cornflowerblue; color: black;">
                           <th></th>
                           <td></td>
                           <th>Total</th>
                           <td></td>

                           <td>No.</td>
                           @if($previous == null)
                               <th>0</th>
                           @else
                               <td>{{ $previous->tot_beneforpsppay }}</td>
                           @endif
                           <th>{{ $data->tot_beneforpsppay }}</th>
                           @if($previous != null)
                           <th>{{ $data->tot_beneforpsppay + $previous->tot_beneforpsppay}}</th>
                               @endif
                       </tr>
                       <tr>
                           <th rowspan="8">1.1.7</th>
                           <th rowspan="7">Total Number of Beneficiaries Transferred to PSP for Payment </th>
                           <th rowspan="2">Aged</th>
                           <th>Female</th>
                           <td>No.</td>
                           @if($previous == null)
                               <th>0</th>
                           @else
                               <td>{{ $previous->tot_agedfbeneforpsppay }}</td>
                           @endif
                           <td>{{ $data->tot_agedfbeneforpsppay }}</td>
                           @if($previous != null)
                           <td>{{ $data->tot_agedfbeneforpsppay + $previous->tot_agedfbeneforpsppay }}</td>
                       @endif
                       <tr>

                           <th>Male</th>
                           <td>No.</td>
                           @if($previous == null)
                               <th>0</th>
                           @else
                               <td>{{ $previous->tot_agedmbeneforpsppay }}</td>
                           @endif
                           <td>{{ $data->tot_agedmbeneforpsppay }}</td>
                           @if($previous != null)
                           <td>{{ $data->tot_agedmbeneforpsppay + $previous->tot_agedmbeneforpsppay }}</td>
                               @endif
                       </tr>

                       </tr>
                       <tr>

                           <th rowspan="2">Chronically ill</th>
                           <th>Female</th>
                           <td>No.</td>
                           @if($previous == null)
                               <th>0</th>
                           @else
                               <td>{{ $previous->tot_chrofbeneforpsppay }}</td>
                           @endif
                           <td>{{ $data->tot_chrofbeneforpsppay }}</td>
                           @if($previous != null)
                           <td>{{ $data->tot_chrofbeneforpsppay + $previous->tot_chrofbeneforpsppay }}</td>
                       @endif
                       <tr>

                           <th>Male</th>
                           <td>No.</td>
                           @if($previous == null)
                               <th>0</th>
                           @else
                               <td>{{ $previous->tot_chrombeneforpsppay }}</td>
                           @endif
                           <td>{{ $data->tot_chrombeneforpsppay }}</td>
                           @if($previous != null)
                           <td>{{ $data->tot_chrombeneforpsppay + $previous->tot_chrombeneforpsppay}}</td>
                               @endif
                       </tr>
                       </tr>
                       <tr>

                           <th rowspan="2">Urban Poor</th>
                           <th>Female</th>
                           <td>No.</td>
                           @if($previous == null)
                               <th>0</th>
                           @else
                               <td>{{ $previous->tot_urbanfbeneforpsppay }}</td>
                           @endif
                           <td>{{ $data->tot_urbanfbeneforpsppay }}</td>
                           @if($previous != null)
                           <td>{{ $data->tot_urbanfbeneforpsppay + $previous->tot_urbanfbeneforpsppay }}</td>
                       @endif
                       <tr>

                           <th>Male</th>
                           <td>No.</td>
                           @if($previous == null)
                               <th>0</th>
                           @else
                               <td>{{ $previous->tot_urbanmbeneforpsppay }}</td>
                           @endif
                           <td>{{ $data->tot_urbanmbeneforpsppay }}</td>
                           @if($previous != null)
                           <td>{{ $data->tot_urbanmbeneforpsppay + $previous->tot_urbanmbeneforpsppay}}</td>
                               @endif
                       </tr>
                       </tr>
                       <tr>

                           <th rowspan="2">People with Special Needs</th>
                           <th>Female</th>
                           <td>No.</td>
                           @if($previous == null)
                               <th>0</th>
                           @else
                               <td>{{ $previous->tot_needsfbeneforpsppay }}</td>
                           @endif
                           <td>{{ $data->tot_needsfbeneforpsppay }}</td>
                           @if($previous != null)
                           <td>{{ $data->tot_needsfbeneforpsppay + $previous->tot_needsfbeneforpsppay}}</td>
                       @endif
                       <tr>
                           <th></th>
                           <th>Male</th>
                           <td>No.</td>
                           @if($previous == null)
                               <th>0</th>
                           @else
                               <td>{{ $previous->tot_needsmbeneforpsppay }}</td>
                           @endif
                           <td>{{ $data->tot_needsmbeneforpsppay }}</td>
                           @if($previous != null)
                           <td>{{ $data->tot_needsmbeneforpsppay + $previous->tot_needsmbeneforpsppay }}</td>
                               @endif
                       </tr>
                       </tr>
                       <tr style="background-color: cornflowerblue; color: black;">
                           <th></th>
                           <th></th>
                           <th>Total</th>
                           <th></th>
                           <td>No.</td>
                           @if($previous == null)
                               <th>0</th>
                           @else
                               <td>{{ $previous->tot_beneforpsppay }}</td>
                           @endif
                           <th>{{ $data->tot_beneforpsppay}}</th>
                           @if($previous != null)
                           <th>{{ $data->tot_beneforpsppay + $previous->tot_beneforpsppay}}</th>
                               @endif
                       </tr>
                       <tr>
                       <tr>
                           <th>1.1.8</th>
                           <th rowspan="2">Total Number of Beneficiaries Paid</th>
                           <th>Female</th>
                           <td></td>
                           <td>No.</td>
                           @if($previous == null)
                               <th>0</th>
                           @else
                               <td>{{ $previous->tot_fbeneforpsppay }}</td>
                           @endif
                           <td>{{ $data->tot_fbeneforpsppay }}</td>
                           @if($previous != null)
                           <td>{{ $data->tot_fbeneforpsppay + $previous->tot_fbeneforpsppay }}</td>
                               @endif
                       </tr>
                       <tr>
                           <th></th>
                           <th>Male</th>
                           <td></td>
                           <td>No.</td>
                           @if($previous == null)
                               <th>0</th>
                           @else
                               <td>{{ $previous->tot_mbeneforpsppay }}</td>
                           @endif
                           <td>{{ $data->tot_mbeneforpsppay }}</td>
                           @if($previous != null)
                           <td>{{ $data->tot_mbeneforpsppay + $previous->tot_mbeneforpsppay}}</td>
                               @endif
                       </tr>


                       </tbody>
                    </table>
                </div>


            </div>
        </div>

    </div>
    <!-- /.container-fluid -->

@endsection

@include('layouts/footer')


<!-- Bootstrap core JavaScript-->

