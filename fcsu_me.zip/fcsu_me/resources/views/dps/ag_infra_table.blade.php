<table class="table table-bordered" id="dataTable">
    <thead style="background-color: cornflowerblue; color: white">
    <tr>
        <th colspan="8">{{ Auth::user()->states->state }} {{ $data->dli->title }} Submission for {{ $data->months->date }}</th>
    </tr>
    <tr>
        <th>Dli</th>
        <th colspan="2">Disbursement Indicator</th>
        <th></th>
        <th>Unit of Measurement</th>
        <th>Previous (as at {{ $old_rec->months->date }} )</th>
        <th>Current (as at {{ $data->months->date }})</th>
        <th>Total</th>
    </tr>
    </thead>

    <tbody>
    <tr>
        <th>2.2.1</th>
        <th>Total Number of FCAs Sensitized and Mobilized </th>
        <th></th>
        <th></th>
        <th>No.</th>
        @if($prev_vals == null)
            <th>0</th>
        @else
            <th>{{ $prev_vals->sum('tot_fcasense') }}</th>
        @endif
        <th>{{ $data->tot_fcasense }}</th>
        <th>{{ $data->tot_fcasense + $prev_vals->sum('tot_fcasense') }}</th>
    </tr>
    <tr>
        <th>2.2.2</th>
        <th>Total Number of CARP Prepared </th>
        <th></th>
        <th></th>
        <th>No.</th>
        @if($prev_vals == null)
            <th>0</th>
        @else
            <th>{{ $prev_vals->sum('tot_carpprep')}}</th>
        @endif
        <th>{{ $data->tot_carpprep }}</th>
        <th>{{ $data->tot_carpprep + $prev_vals->sum('tot_carpprep')}}</th>
    </tr>

    <tr>
        <th>2.2.3</th>
        <th>Total Number of CARP Approved </th>
        <th></th>
        <th></th>
        <th>No.</th>
        @if($prev_vals == null)
            <th>0</th>
        @else
            <th>{{ $prev_vals->sum('tot_carpapprov') }}</th>
        @endif
        <th>{{ $data->tot_carpapprov }}</th>
        <th>{{ $data->tot_carpapprov + $prev_vals->sum('tot_carpapprov') }}</th>
    </tr>

    <tr>
        <th>2.2.4</th>
        <th>Total Number of Agricultural Infrastructures with agreed LIPW Requirements</th>
        <th></th>
        <th></th>
        <th>No.</th>
        @if($prev_vals == null)
            <th>0</th>
        @else
            <th>{{ $prev_vals->sum('tot_agricinfrac') }}</th>
        @endif
        <th>{{ $data->tot_agricinfrac }}</th>
        <th>{{ $data->tot_agricinfrac + $prev_vals->sum('tot_agricinfrac')}}</th>
    </tr>

    <tr>
        <th>2.2.5</th>
        <th rowspan="2">Total Number of Farmers who Applied for Agricultural Infrastructures with agreed LIPW Requirements</th>
        <th>Female</th>
        <td></td>
        <td>No.</td>
        @if($prev_vals == null)
            <th>0</th>
        @else
            <td>{{ $prev_vals->sum('tot_ffarmersapp') }}</td>
        @endif
        <td>{{ $data->tot_ffarmersapp }}</td>
        <td>{{ $data->tot_ffarmersapp + $prev_vals->sum('tot_ffarmersapp') }}</td>
    </tr>
    <tr>
        <th></th>
        <th>Male</th>
        <td></td>
        <td>No.</td>
        <td>{{ $prev_vals->sum('tot_mfarmersapp') }}</td>
        <td>{{ $data->tot_mfarmersapp }}</td>
        <td>{{ $data->tot_mfarmersapp + $prev_vals->sum('tot_mfarmersapp')}}</td>
    </tr>
    <tr style="background-color: cornflowerblue; color: black;">
        <th></th>
        <td></td>
        <th>Total</th>
        <td></td>

        <td>No.</td>
        @if($prev_vals == null)
            <th>0</th>
        @else
            <td>{{ $prev_vals->sum('tot_farmersapp') }}</td>
        @endif
        <th>{{ $data->tot_farmersapp }}</th>
        <th>{{ $data->tot_farmersapp + $prev_vals->sum('tot_farmersapp')}}</th>
    </tr>
    <tr>
        <th>2.2.6</th>
        <th rowspan="2">Total Number of Farmers who Received Agricultural Infrastructures with agreed LIPW Requirements</th>
        <th>Female</th>
        <td></td>
        <td>No.</td>
        @if($prev_vals == null)
            <th>0</th>
        @else
            <td>{{ $prev_vals->sum('tot_ffarmersrec') }}</td>
        @endif
        <td>{{ $data->tot_ffarmersrec }}</td>
        <td>{{ $data->tot_ffarmersrec + $prev_vals->sum('tot_ffarmersrec') }}</td>
    </tr>
    <tr>
        <th></th>
        <th>Male</th>
        <td></td>
        <td>No.</td>
        @if($prev_vals == null)
            <th>0</th>
        @else
            <td>{{ $prev_vals->sum('tot_mfarmersrec') }}</td>
        @endif
        <td>{{ $data->tot_mfarmersrec }}</td>
        <td>{{ $data->tot_mfarmersrec + $prev_vals->sum('tot_mfarmersrec')}}</td>
    </tr>
    <tr style="background-color: cornflowerblue; color: black;">
        <th></th>
        <td></td>
        <th>Total</th>
        <td></td>

        <td>No.</td>
        @if($prev_vals == null)
            <th>0</th>
        @else
            <td>{{ $prev_vals->sum('tot_farmersrec') }}</td>
        @endif
        <th>{{ $data->tot_farmersrec }}</th>
        <th>{{ $data->tot_farmersrec + $prev_vals->sum('tot_farmersrec')}}</th>
    </tr>

    <tr>
        <th>2.2.7</th>
        <th rowspan="2">Total Number of Farmers who are Accessing/Utilizing Improved Agricultural Infrastructures with agreed LIPW Requirements</th>
        <th>Female</th>
        <td></td>
        <td>No.</td>
        @if($prev_vals == null)
            <th>0</th>
        @else
            <td>{{ $prev_vals->sum('tot_ffarmersutil') }}</td>
        @endif
        <td>{{ $data->tot_ffarmersutil }}</td>
        <td>{{ $data->tot_ffarmersutil + $prev_vals->sum('tot_ffarmersutil') }}</td>
    </tr>
    <tr>
        <th></th>
        <th>Male</th>
        <td></td>
        <td>No.</td>
        @if($prev_vals == null)
            <th>0</th>
        @else
            <td>{{ $prev_vals->sum('tot_mfarmersutil') }}</td>
        @endif
        <td>{{ $data->tot_mfarmersutil }}</td>
        <td>{{ $data->tot_mfarmersutil + $prev_vals->sum('tot_mfarmersutil')}}</td>
    </tr>
    <tr style="background-color: cornflowerblue; color: black;">
        <th></th>
        <td></td>
        <th>Total</th>
        <td></td>

        <td>No.</td>
        @if($prev_vals == null)
            <th>0</th>
        @else
            <td>{{ $prev_vals->sum('tot_farmersutil') }}</td>
        @endif
        <th>{{ $data->tot_farmersutil }}</th>
        <th>{{ $data->tot_farmersutil + $prev_vals->sum('tot_farmersutil')}}</th>
    </tr>

    <tr>
        <th>2.2.8</th>
        <th>Total Number of Agricultural Infrastructure Completed </th>
        <th></th>
        <th></th>
        <th>No.</th>
        @if($prev_vals == null)
            <th>0</th>
        @else
            <th>{{ $prev_vals->sum('tot_infracomp') }}</th>
        @endif
        <th>{{ $data->tot_infracomp }}</th>
        <th>{{ $data->tot_infracomp + $prev_vals->sum('tot_infracomp') }}</th>
    </tr>


    <tr>
        <th>2.2.9</th>
        <th>Total Number of Completed Agricultural Infrastructure Paid for</th>
        <th></th>
        <th></th>
        <th>No.</th>
        @if($prev_vals == null)
            <th>0</th>
        @else
            <th>{{ $prev_vals->sum('tot_infracomppaid') }}</th>
        @endif
        <th>{{ $data->tot_infracomppaid }}</th>
        <th>{{ $data->tot_infracomppaid + $prev_vals->sum('tot_infracomppaid')}}</th>
    </tr>

    </tbody>
</table>
