<table class="table table-bordered" id="dataTable">
    <thead style="background-color: cornflowerblue; color: white">
    <tr>
        <th colspan="8">{{ Auth::user()->states->state }} {{ $data->dli->title }} Submission for {{ $data->months->date }}</th>
    </tr>
    <tr>
        <th>Dli</th>
        <th colspan="2">Disbursement Indicator</th>
        <th></th>
        <th>Unit of Measurement</th>
        <th>Previous (as at {{ $old_rec->months->date }} )</th>
        <th>Current (as at {{ $data->months->date }})</th>
        <th>Total</th>
    </tr>
    </thead>

    <tbody>
    <tr>
        <th>1.4.1</th>
        <th>Total Number of Communities and Groups Sensitized in Poverty Focal LGAs  </th>
        <th></th>
        <th></th>
        <th>No.</th>
        @if($prev_vals == null)
            <th>0</th>
        @else
            <th>{{ $prev_vals->sum('tot_commssensi') }}</th>
        @endif
        <th>{{ $data->tot_commssensi }}</th>
        <th>{{ $data->tot_commssensi + $prev_vals->sum('tot_commssensi')}}</th>
    </tr>
    <tr>
        <th>1.4.2</th>
        <th>Total Number of  EOI Received from Communities and Groups in Poverty Focal LGAs </th>
        <th></th>
        <th></th>
        <th>No.</th>
        @if($prev_vals == null)
            <th>0</th>
        @else
            <th>{{ $prev_vals->sum('tot_eoirecvcomms') + $prev_vals->sum('tot_eoirecvgrps') }}</th>
        @endif
        <th>{{ $data->tot_eoirecvcomms + $data->tot_eoirecvgrps }}</th>
        <th>{{ $data->tot_eoirecvcomms + $data->tot_eoirecvgrps + $prev_vals->sum('tot_eoirecvcomms') + $prev_vals->sum('tot_eoirecvgrps') }}</th>
    </tr>

    <tr>
        <th>1.4.3</th>
        <th>Total Number of CDPs Submitted by Communities</th>
        <th></th>
        <th></th>
        <th>No.</th>
        @if($prev_vals == null)
            <th>0</th>
        @else
            <th>{{ $prev_vals->sum('tot_cdpssubmit') }}</th>
        @endif
        <th>{{ $data->tot_cdpssubmit }}</th>
        <th>{{ $data->tot_cdpssubmit + $prev_vals->sum('tot_cdpssubmit') }}</th>
    </tr>

    <tr>
        <th>1.4.4</th>
        <th>Number of CPMC Trained</th>
        <th></th>
        <th></th>
        <th>No.</th>
        @if($prev_vals == null)
            <th>0</th>
        @else
            <th>{{ $prev_vals->sum('num_cpmctrained') }}</th>
        @endif
        <th>{{ $data->num_cpmctrained }}</th>
        <th>{{ $data->num_cpmctrained + $prev_vals->sum('num_cpmctrained') }}</th>
    </tr>

    <tr>
        <th>1.4.4</th>
        <th>Number of Communities with Completed and Functional CDPs</th>
        <th></th>
        <th></th>
        <th>No.</th>
        @if($prev_vals == null)
            <th>0</th>
        @else
            <th>{{ $prev_vals->sum('num_cpmctrained') }}</th>
        @endif
        <th>{{ $data->num_cpmctrained }}</th>
        <th>{{ $data->num_cpmctrained + $prev_vals->sum('num_cpmctrained')}}</th>
    </tr>

    </tbody>
</table>
