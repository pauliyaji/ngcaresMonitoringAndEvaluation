<table class="table table-bordered" id="dataTable">
    <thead style="background-color: cornflowerblue; color: white">
    <tr>
        <th colspan="8">{{ Auth::user()->states->state }} {{ $data->dli->title }} Submission for {{ $data->months->date }}</th>
    </tr>
    <tr>
        <th>Dli</th>
        <th colspan="2">Disbursement Indicator</th>
        <th></th>
        <th>Unit of Measurement</th>
        <th>Previous (as at {{ $old_rec->months->date }} )</th>
        <th>Current (as at {{ $data->months->date }})</th>
        <th>Total</th>
    </tr>
    </thead>

    <tbody>
    <tr>
        <th>1.2.1</th>
        <th rowspan="2">Total Number of Beneficiaries Mined from Agreed Register</th>
        <th>Female</th>
        <td></td>
        <td>No.</td>
        @if($prev_vals == null)
            <th>0</th>
        @else
            <td>{{ $prev_vals->sum('f_mined') }}</td>
        @endif
        <td>{{ $data->f_mined }}</td>
        <td>{{ $data->f_mined + $prev_vals->sum('f_mined') }}</td>
    </tr>
    <tr>
        <th></th>
        <th>Male</th>
        <td></td>
        <td>No.</td>
        @if($prev_vals == null)
            <th>0</th>
        @else
            <td>{{ $prev_vals->sum('m_mined') }}</td>
        @endif
        <td>{{ $data->m_mined }}</td>
        <td>{{ $data->m_mined + $prev_vals->sum('m_mined') }}</td>
    </tr>
    <tr style="background-color: cornflowerblue; color: black;">
        <th></th>
        <td></td>
        <th>Total</th>
        <td></td>

        <td>No.</td>
        @if($prev_vals == null)
            <th>0</th>
        @else
            <td>{{ $prev_vals->sum('tot_mined') }}</td>
        @endif
        <th>{{ $data->tot_mined }}</th>
        <th>{{ $data->tot_mined + $prev_vals->sum('tot_mined') }}</th>
    </tr>
    <tr>
        <th>1.2.2</th>
        <th rowspan="2">Total Number of Mined Beneficiaries Validated</th>
        <th>Female</th>
        <td></td>
        <td>No.</td>
        @if($prev_vals == null)
            <th>0</th>
        @else
            <td>{{ $prev_vals->sum('f_validated') }}</td>
        @endif
        <td>{{ $data->f_validated }}</td>
        <td>{{ $data->f_validated + $prev_vals->sum('f_validated') }}</td>
    </tr>
    <tr>
        <th></th>
        <th>Male</th>
        <td></td>
        <td>No.</td>
        @if($prev_vals == null)
            <th>0</th>
        @else
            <td>{{ $prev_vals->sum('m_validated')  }}</td>
        @endif
        <td>{{ $data->m_validated }}</td>
        <td>{{ $data->m_validated + $prev_vals->sum('m_validated') }}</td>
    </tr>
    <tr style="background-color: cornflowerblue; color: black;">
        <th></th>
        <td></td>
        <th>Total</th>
        <td></td>

        <td>No.</td>
        @if($prev_vals == null)
            <th>0</th>
        @else
            <td>{{ $prev_vals->sum('tot_validated')  }}</td>
        @endif
        <th>{{ $data->tot_validated }}</th>
        <th>{{ $data->tot_validated + $prev_vals->sum('tot_validated') }}</th>
    </tr>
    <tr>
        <th>1.2.3</th>
        <th rowspan="2">Number Enrolled/Engaged into LIPW activities on Social Services and Works</th>
        <th>Female</th>
        <td></td>
        <td>No.</td>
        @if($prev_vals == null)
            <th>0</th>
        @else
            <td>{{ $prev_vals->sum('f_enrolled') }}</td>
        @endif
        <td>{{ $data->f_enrolled }}</td>
        <td>{{ $data->f_enrolled + $prev_vals->sum('f_enrolled') }}</td>
    </tr>
    <tr>
        <th></th>
        <th>Male</th>
        <td></td>
        <td>No.</td>
        @if($prev_vals == null)
            <th>0</th>
        @else
            <td>{{ $prev_vals->sum('m_enrolled') }}</td>
        @endif
        <td>{{ $data->m_enrolled }}</td>
        <td>{{ $data->m_enrolled + $prev_vals->sum('m_enrolled') }}</td>
    </tr>
    <tr style="background-color: cornflowerblue; color: black;">
        <th></th>
        <td></td>
        <th>Total</th>
        <td></td>

        <td>No.</td>
        @if($prev_vals == null)
            <th>0</th>
        @else
            <td>{{ $prev_vals->sum('tot_enrolled') }}</td>
        @endif
        <th>{{ $data->tot_enrolled }}</th>
        <th>{{ $data->tot_enrolled + $prev_vals->sum('tot_enrolled') }}</th>
    </tr>
    <tr>
        <th>1.2.4</th>
        <th rowspan="2">Number Deployed into LIPW activities on Social Services and Works</th>
        <th>Female</th>
        <td></td>
        <td>No.</td>
        @if($prev_vals == null)
            <th>0</th>
        @else
            <td>{{ $prev_vals->sum('f_deploy') }}</td>
        @endif
        <td>{{ $data->f_deploy }}</td>
        <td>{{ $data->f_deploy + $prev_vals->sum('f_deploy') }}</td>
    </tr>
    <tr>
        <th></th>
        <th>Male</th>
        <td></td>
        <td>No.</td>
        @if($prev_vals == null)
            <th>0</th>
        @else
            <td>{{ $prev_vals->sum('m_deploy') }}</td>
        @endif
        <td>{{ $data->m_deploy }}</td>
        <td>{{ $data->m_deploy + $prev_vals->sum('m_deploy') }}</td>
    </tr>
    <tr style="background-color: cornflowerblue; color: black;">
        <th></th>
        <td></td>
        <th>Total</th>
        <td></td>

        <td>No.</td>
        @if($prev_vals == null)
            <th>0</th>
        @else
            <td>{{ $prev_vals->sum('tot_deploy') }}</td>
        @endif
        <th>{{ $data->tot_deploy }}</th>
        <th>{{ $data->tot_deploy + $prev_vals->sum('tot_deploy') }}</th>
    </tr>

    <tr>
        <th>1.2.5</th>
        <th>Number of Working Days/Beneficiary </th>
        <th></th>
        <th></th>
        <th>No.</th>
        @if($prev_vals == null)
            <th>0</th>
        @else
            <th>{{ $prev_vals->sum('num_workdays') }}</th>
        @endif
        <th>{{ $data->num_workdays }}</th>
        <th>{{ $data->num_workdays + $prev_vals->sum('num_workdays')  }}</th>
    </tr>
    <tr>
        <th>1.2.6</th>
        <th>Total Amount Transferred to PSP</th>
        <th></th>
        <th></th>
        <th>NGN</th>
        @if($prev_vals == null)
            <th>0</th>
        @else
            <th>{{ number_format($prev_vals->sum('amt_transpsp'), 2) }}</th>
        @endif
        <th>{{ number_format($data->amt_transpsp, 2)}}</th>
        <th>{{ number_format($data->amt_transpsp + $prev_vals->sum('amt_transpsp'), 2)}}</th>
    </tr>

    <tr>
        <th>1.2.7</th>
        <th rowspan="2">Total Number of Beneficiaries Transferred to PSP for Payment</th>
        <th>Female</th>
        <td></td>
        <td>No.</td>
        @if($prev_vals == null)
            <th>0</th>
        @else
            <td>{{ $prev_vals->sum('tot_fbeneforpsppay') }}</td>
        @endif
        <td>{{ $data->tot_fbeneforpsppay }}</td>
        <td>{{ $data->tot_fbeneforpsppay + $prev_vals->sum('tot_fbeneforpsppay') }}</td>
    </tr>
    <tr>
        <th></th>
        <th>Male</th>
        <td></td>
        <td>No.</td>
        @if($prev_vals == null)
            <th>0</th>
        @else
            <td>{{ $prev_vals->sum('tot_mbeneforpsppay') }}</td>
        @endif
        <td>{{ $data->tot_mbeneforpsppay }}</td>
        <td>{{ $data->tot_mbeneforpsppay + $prev_vals->sum('tot_mbeneforpsppay')}}</td>
    </tr>
    <tr style="background-color: cornflowerblue; color: black;">
        <th></th>
        <td></td>
        <th>Total</th>
        <td></td>

        <td>No.</td>
        @if($prev_vals == null)
            <th>0</th>
        @else
            <td>{{ $prev_vals->sum('tot_beneforpsppay') }}</td>
        @endif
        <th>{{ $data->tot_beneforpsppay }}</th>
        <th>{{ $data->tot_beneforpsppay + $prev_vals->sum('tot_beneforpsppay')}}</th>
    </tr>
    <tr>
        <th>1.2.8</th>
        <th rowspan="2">Total Number of Beneficiaries Paid</th>
        <th>Female</th>
        <td></td>
        <td>No.</td>
        @if($prev_vals == null)
            <th>0</th>
        @else
            <td>{{ $prev_vals->sum('tot_fbenepaid') }}</td>
        @endif
        <td>{{ $data->tot_fbenepaid }}</td>
        <td>{{ $data->tot_fbenepaid + $prev_vals->sum('tot_fbenepaid') }}</td>
    </tr>
    <tr>
        <th></th>
        <th>Male</th>
        <td></td>
        <td>No.</td>
        @if($prev_vals == null)
            <th>0</th>
        @else
            <td>{{ $prev_vals->sum('tot_mbenepaid') }}</td>
        @endif
        <td>{{ $data->tot_mbenepaid }}</td>
        <td>{{ $data->tot_mbenepaid + $prev_vals->sum('tot_mbenepaid') }}</td>
    </tr>
    <tr style="background-color: cornflowerblue; color: black;">
        <th></th>
        <td></td>
        <th>Total</th>
        <td></td>

        <td>No.</td>
        @if($prev_vals == null)
            <th>0</th>
        @else
            <td>{{ $prev_vals->sum('tot_benepaid') }}</td>
        @endif
        <th>{{ $data->tot_benepaid }}</th>
        <th>{{ $data->tot_benepaid + $prev_vals->sum('tot_benepaid') }}</th>
    </tr>
    </tbody>

</table>

