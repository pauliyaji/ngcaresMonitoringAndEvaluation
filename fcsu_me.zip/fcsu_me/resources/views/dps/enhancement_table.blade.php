<table class="table table-bordered" id="dataTable">
    <thead style="background-color: cornflowerblue; color: white">
    <tr>
        <th colspan="8">{{ Auth::user()->states->state }} {{ $data->dli->title }} Submission for {{ $data->months->date }}</th>
    </tr>
    <tr>
        <th>Dli</th>
        <th colspan="2">Disbursement Indicator</th>
        <th></th>
        <th>Unit of Measurement</th>
        <th>Previous (as at {{ $old_rec->months->date }} )</th>
        <th>Current (as at {{ $data->months->date }})</th>
        <th>Total</th>
    </tr>
    </thead>

    <tbody>
    <tr>
        <th>3.3</th>
        <th>Total Number of Registered Firms that Applied for IT-Enhancement</th>
        <th></th>
        <th></th>
        <th>No.</th>

            <th>{{ $prev_vals->sum('tot_regit') }}</th>

        <th>{{ $data->tot_regit }}</th>
        <th>{{ $data->tot_regit + $prev_vals->sum('tot_regit')}}</th>
    </tr>
    <tr>
        <th>3.3.1.1</th>
        <th rowspan="2">Micro Scale Firms</th>
        <th>Male Owners</th>
        <td></td>
        <td>No.</td>
        @if($prev_vals == null)
            <th>0</th>
        @else
            <td>{{ $prev_vals->sum('tot_regitmmicro') }}</td>
        @endif
        <td>{{ $data->tot_regitmmicro }}</td>
        <td>{{ $data->tot_regitmmicro + $prev_vals->sum('tot_regitmmicro')}}</td>
    </tr>
    <tr>
        <th></th>
        <th>Female Owners</th>
        <td></td>
        <td>No.</td>
        @if($prev_vals == null)
            <th>0</th>
        @else
            <td>{{ $prev_vals->sum('tot_regitfmicro') }}</td>
        @endif
        <td>{{ $data->tot_regitfmicro }}</td>
        <td>{{ $data->tot_regitfmicro + $prev_vals->sum('tot_regitfmicro')}}</td>
    </tr>
    <tr style="background-color: cornflowerblue; color: black;">
        <th></th>
        <td></td>
        <th>Total</th>
        <td></td>

        <td>No.</td>
        @if($prev_vals == null)
            <th>0</th>
        @else
            <td>{{ $prev_vals->sum('tot_regitmicro') }}</td>
        @endif
        <th>{{ $data->tot_regitmicro }}</th>
        <th>{{ $data->tot_regitmicro + $prev_vals->sum('tot_regitmicro')}}</th>
    </tr>
    <tr>
        <th>3.3.1.2</th>
        <th rowspan="2">Small Scale Firms</th>
        <th>Male Owners</th>
        <td></td>
        <td>No.</td>
        @if($prev_vals == null)
            <th>0</th>
        @else
            <td>{{ $prev_vals->sum('tot_regitmsmall') }}</td>
        @endif
        <td>{{ $data->tot_regitmsmall }}</td>
        <td>{{ $data->tot_regitmsmall + $prev_vals->sum('tot_regitmsmall')}}</td>
    </tr>
    <tr>
        <th></th>
        <th>Female Owners</th>
        <td></td>
        <td>No.</td>
        @if($prev_vals == null)
            <th>0</th>
        @else
            <td>{{ $prev_vals->sum('tot_regitfsmall') }}</td>
        @endif
        <td>{{ $data->tot_regitfsmall }}</td>
        <td>{{ $data->tot_regitfsmall + $prev_vals->sum('tot_regitfsmall')}}</td>
    </tr>
    <tr style="background-color: cornflowerblue; color: black;">
        <th></th>
        <td></td>
        <th>Total</th>
        <td></td>

        <td>No.</td>
        @if($prev_vals == null)
            <th>0</th>
        @else
            <td>{{ $prev_vals->sum('tot_regitsmall') }}</td>
        @endif
        <th>{{ $data->tot_regitsmall }}</th>
        <th>{{ $data->tot_regitsmall + $prev_vals->sum('tot_regitsmall')}}</th>
    </tr>
    <tr>
        <th>3.3.2</th>
        <th>Total Number of Eligible and Verified Firms for IT-Enhancement</th>
        <th></th>
        <th></th>
        <th>No.</th>
        @if($prev_vals == null)
            <th>0</th>
        @else
            <th>{{ $prev_vals->sum('tot_eligverit') }}</th>
        @endif
        <th>{{ $data->tot_eligverit }}</th>
        <th>{{ $data->tot_eligverit + $prev_vals->sum('tot_eligverit')}}</th>
    </tr>

    <tr>
        <th>3.3.2.1</th>
        <th rowspan="2">Micro Scale Firms</th>
        <th>Male Owners</th>
        <td></td>
        <td>No.</td>
        @if($prev_vals == null)
            <th>0</th>
        @else
            <td>{{ $prev_vals->sum('tot_eligmmicro') }}</td>
        @endif
        <td>{{ $data->tot_eligmmicro }}</td>
        <td>{{ $data->tot_eligmmicro + $prev_vals->sum('tot_eligmmicro')}}</td>
    </tr>
    <tr>
        <th></th>
        <th>Female Owners</th>
        <td></td>
        <td>No.</td>
        @if($prev_vals == null)
            <th>0</th>
        @else
            <td>{{ $prev_vals->sum('tot_eligfmicro') }}</td>
        @endif
        <td>{{ $data->tot_eligfmicro }}</td>
        <td>{{ $data->tot_eligfmicro + $prev_vals->sum('tot_eligfmicro')}}</td>
    </tr>
    <tr style="background-color: cornflowerblue; color: black;">
        <th></th>
        <td></td>
        <th>Total</th>
        <td></td>

        <td>No.</td>
        @if($prev_vals == null)
            <th>0</th>
        @else
            <td>{{ $prev_vals->sum('tot_eligmicro') }}</td>
        @endif
        <th>{{ $data->tot_eligmicro }}</th>
        <th>{{ $data->tot_eligmicro + $prev_vals->sum('tot_eligmicro')}}</th>
    </tr>

    <tr>
        <th>3.3.2.2</th>
        <th rowspan="2">Small Scale Firms </th>
        <th>Male Owners</th>
        <td></td>
        <td>No.</td>
        @if($prev_vals == null)
            <th>0</th>
        @else
            <td>{{ $prev_vals->sum('tot_eligmsmall') }}</td>
        @endif
        <td>{{ $data->tot_eligmsmall }}</td>
        <td>{{ $data->tot_eligmsmall + $prev_vals->sum('tot_eligmsmall')}}</td>
    </tr>
    <tr>
        <th></th>
        <th>Female Owners</th>
        <td></td>
        <td>No.</td>
        @if($prev_vals == null)
            <th>0</th>
        @else
            <td>{{ $prev_vals->sum('tot_eligfsmall') }}</td>
        @endif
        <td>{{ $data->tot_eligfsmall }}</td>
        <td>{{ $data->tot_eligfsmall + $prev_vals->sum('tot_eligfsmall')}}</td>
    </tr>
    <tr style="background-color: cornflowerblue; color: black;">
        <th></th>
        <td></td>
        <th>Total</th>
        <td></td>

        <td>No.</td>
        @if($prev_vals == null)
            <th>0</th>
        @else
            <td>{{ $prev_vals->sum('tot_eligsmall') }}</td>
        @endif
        <th>{{ $data->tot_eligsmall }}</th>
        <th>{{ $data->tot_eligsmall + $prev_vals->sum('tot_eligsmall')}}</th>
    </tr>
    <tr>
        <th>3.3.3</th>
        <th>Total Number of Selected Firms for IT-Enhancement</th>
        <th></th>
        <th></th>
        <th>No.</th>
        @if($prev_vals == null)
            <th>0</th>
        @else
            <th>{{ $prev_vals->sum('tot_sel') }}</th>
        @endif
        <th>{{ $data->tot_sel }}</th>
        <th>{{ $data->tot_sel + $prev_vals->sum('tot_sel')}}</th>
    </tr>

    <tr>
        <th>3.3.3.1</th>
        <th rowspan="2">Micro Scale Firms</th>
        <th>Male Owners</th>
        <td></td>
        <td>No.</td>
        @if($prev_vals == null)
            <th>0</th>
        @else
            <td>{{ $prev_vals->sum('tot_selmmicro') }}</td>
        @endif
        <td>{{ $data->tot_selmmicro }}</td>
        <td>{{ $data->tot_selmmicro + $prev_vals->sum('tot_selmmicro')}}</td>
    </tr>
    <tr>
        <th></th>
        <th>Female Owners</th>
        <td></td>
        <td>No.</td>
        @if($prev_vals == null)
            <th>0</th>
        @else
            <td>{{ $prev_vals->sum('tot_selfmicro') }}</td>
        @endif
        <td>{{ $data->tot_selfmicro }}</td>
        <td>{{ $data->tot_selfmicro + $prev_vals->sum('tot_selfmicro')}}</td>
    </tr>
    <tr style="background-color: cornflowerblue; color: black;">
        <th></th>
        <td></td>
        <th>Total</th>
        <td></td>

        <td>No.</td>
        @if($prev_vals == null)
            <th>0</th>
        @else
            <td>{{ $prev_vals->sum('tot_selmicro') }}</td>
        @endif
        <th>{{ $data->tot_selmicro }}</th>
        <th>{{ $data->tot_selmicro + $prev_vals->sum('tot_selmicro')}}</th>
    </tr>

    <tr>
        <th>3.3.3.2</th>
        <th rowspan="2">Small Scale Firms</th>
        <th>Male Owners</th>
        <td></td>
        <td>No.</td>
        @if($prev_vals == null)
            <th>0</th>
        @else
            <td>{{ $prev_vals->sum('tot_selmsmall') }}</td>
        @endif
        <td>{{ $data->tot_selmsmall }}</td>
        <td>{{ $data->tot_selmsmall + $prev_vals->sum('tot_selmsmall')}}</td>
    </tr>
    <tr>
        <th></th>
        <th>Female Owners</th>
        <td></td>
        <td>No.</td>
        @if($prev_vals == null)
            <th>0</th>
        @else
            <td>{{ $prev_vals->sum('tot_selfsmall') }}</td>
        @endif
        <td>{{ $data->tot_selfsmall }}</td>
        <td>{{ $data->tot_selfsmall + $prev_vals->sum('tot_selfsmall')}}</td>
    </tr>
    <tr style="background-color: cornflowerblue; color: black;">
        <th></th>
        <td></td>
        <th>Total</th>
        <td></td>

        <td>No.</td>
        @if($prev_vals == null)
            <th>0</th>
        @else
            <td>{{ $prev_vals->sum('tot_selsmall') }}</td>
        @endif
        <th>{{ $data->tot_selsmall }}</th>
        <th>{{ $data->tot_selsmall + $prev_vals->sum('tot_selsmall')}}</th>
    </tr>

    <tr>
        <th>3.3.4</th>
        <th>Total Number of Contracted Service Providers of IT Solutions</th>
        <th></th>
        <th></th>
        <th>No.</th>
        @if($prev_vals == null)
            <th>0</th>
        @else
            <th>{{ $prev_vals->sum('tot_ser_pro') }}</th>
        @endif
        <th>{{ $data->tot_ser_pro }}</th>
        <th>{{ $data->tot_ser_pro + $prev_vals->sum('tot_ser_pro')}}</th>
    </tr>

    <tr>
        <th>3.3.5</th>
        <th>Total Number of Firms that Confirm Receipt of IT Solutions</th>
        <th></th>
        <th></th>
        <th>No.</th>
        @if($prev_vals == null)
            <th>0</th>
        @else
            <th>{{ $prev_vals->sum('tot_conf') }}</th>
        @endif
        <th>{{ $data->tot_conf }}</th>
        <th>{{ $data->tot_conf + $prev_vals->sum('tot_conf')}}</th>
    </tr>

    <tr>
        <th>3.3.5.1</th>
        <th rowspan="2">Micro Scale Firms</th>
        <th>Male Owners</th>
        <td></td>
        <td>No.</td>
        @if($prev_vals == null)
            <th>0</th>
        @else
            <td>{{ $prev_vals->sum('tot_confmmicro') }}</td>
        @endif
        <td>{{ $data->tot_confmmicro }}</td>
        <td>{{ $data->tot_confmmicro + $prev_vals->sum('tot_confmmicro')}}</td>
    </tr>
    <tr>
        <th></th>
        <th>Female Owners</th>
        <td></td>
        <td>No.</td>
        @if($prev_vals == null)
            <th>0</th>
        @else
            <td>{{ $prev_vals->sum('tot_conffmicro') }}</td>
        @endif
        <td>{{ $data->tot_conffmicro }}</td>
        <td>{{ $data->tot_conffmicro + $prev_vals->sum('tot_conffmicro')}}</td>
    </tr>
    <tr style="background-color: cornflowerblue; color: black;">
        <th></th>
        <td></td>
        <th>Total</th>
        <td></td>

        <td>No.</td>
        @if($prev_vals == null)
            <th>0</th>
        @else
            <td>{{ $prev_vals->sum('tot_confmicro') }}</td>
        @endif
        <th>{{ $data->tot_confmicro }}</th>
        <th>{{ $data->tot_confmicro + $prev_vals->sum('tot_confmicro')}}</th>
    </tr>
    <tr>
        <th>3.3.5.2</th>
        <th rowspan="2">Small Scale Firms</th>
        <th>Male Owners</th>
        <td></td>
        <td>No.</td>
        @if($prev_vals == null)
            <th>0</th>
        @else
            <td>{{ $prev_vals->sum('tot_confmsmall') }}</td>
        @endif
        <td>{{ $data->tot_confmsmall }}</td>
        <td>{{ $data->tot_confmsmall + $prev_vals->sum('tot_confmsmall')}}</td>
    </tr>
    <tr>
        <th></th>
        <th>Female Owners</th>
        <td></td>
        <td>No.</td>
        @if($prev_vals == null)
            <th>0</th>
        @else
            <td>{{ $prev_vals->sum('tot_conffsmall') }}</td>
        @endif
        <td>{{ $data->tot_conffsmall }}</td>
        <td>{{ $data->tot_conffsmall + $prev_vals->sum('tot_conffsmall')}}</td>
    </tr>
    <tr style="background-color: cornflowerblue; color: black;">
        <th></th>
        <td></td>
        <th>Total</th>
        <td></td>

        <td>No.</td>
        @if($prev_vals == null)
            <th>0</th>
        @else
            <td>{{ $prev_vals->sum('tot_confsmall') }}</td>
        @endif
        <th>{{ $data->tot_confsmall }}</th>
        <th>{{ $data->tot_confsmall + $prev_vals->sum('tot_confsmall')}}</th>
    </tr>


    <tr>
        <th>3.3.6</th>
        <th>Total Number of Instances of Technology Deployment to Support Beneficiaries</th>
        <th></th>
        <th></th>
        <th>No.</th>
        @if($prev_vals == null)
            <th>0</th>
        @else
            <th>{{ $prev_vals->sum('tot_tech') }}</th>
        @endif
        <th>{{ $data->tot_tech }}</th>
        <th>{{ $data->tot_tech + $prev_vals->sum('tot_tech')}}</th>
    </tr>

    <tr>
        <th>3.3.6.1</th>
        <th rowspan="2">Micro Scale Firms</th>
        <th>Male Owners</th>
        <td></td>
        <td>No.</td>
        @if($prev_vals == null)
            <th>0</th>
        @else
            <td>{{ $prev_vals->sum('tot_techmmicro') }}</td>
        @endif
        <td>{{ $data->tot_techmmicro }}</td>
        <td>{{ $data->tot_techmmicro + $prev_vals->sum('tot_techmmicro')}}</td>
    </tr>
    <tr>
        <th></th>
        <th>Female Owners</th>
        <td></td>
        <td>No.</td>
        @if($prev_vals == null)
            <th>0</th>
        @else
            <td>{{ $prev_vals->sum('tot_techfmicro') }}</td>
        @endif
        <td>{{ $data->tot_techfmicro }}</td>
        <td>{{ $data->tot_techfmicro + $prev_vals->sum('tot_techfmicro')}}</td>
    </tr>
    <tr style="background-color: cornflowerblue; color: black;">
        <th></th>
        <td></td>
        <th>Total</th>
        <td></td>

        <td>No.</td>
        @if($prev_vals == null)
            <th>0</th>
        @else
            <td>{{ $prev_vals->sum('tot_techmicro') }}</td>
        @endif
        <th>{{ $data->tot_techmicro }}</th>
        <th>{{ $data->tot_techmicro + $prev_vals->sum('tot_techmicro')}}</th>
    </tr>
    <tr>
        <th>3.3.6.2</th>
        <th rowspan="2">Small Scale Firms</th>
        <th>Male Owners</th>
        <td></td>
        <td>No.</td>
        @if($prev_vals == null)
            <th>0</th>
        @else
            <td>{{ $prev_vals->sum('tot_techmsmall') }}</td>
        @endif
        <td>{{ $data->tot_techmsmall }}</td>
        <td>{{ $data->tot_techmsmall + $prev_vals->sum('tot_techmsmall')}}</td>
    </tr>
    <tr>
        <th></th>
        <th>Female Owners</th>
        <td></td>
        <td>No.</td>
        @if($prev_vals == null)
            <th>0</th>
        @else
            <td>{{ $prev_vals->sum('tot_techfsmall') }}</td>
        @endif
        <td>{{ $data->tot_techfsmall }}</td>
        <td>{{ $data->tot_techfsmall + $prev_vals->sum('tot_techfsmall')}}</td>
    </tr>
    <tr style="background-color: cornflowerblue; color: black;">
        <th></th>
        <td></td>
        <th>Total</th>
        <td></td>

        <td>No.</td>
        @if($prev_vals == null)
            <th>0</th>
        @else
            <td>{{ $prev_vals->sum('tot_techsmall') }}</td>
        @endif
        <th>{{ $data->tot_techsmall }}</th>
        <th>{{ $data->tot_techsmall + $prev_vals->sum('tot_techsmall')}}</th>
    </tr>

    <tr>
        <th>3.3.7</th>
        <th>Total Number of Firms Receiving Conditional Grants to Support IT Enhancement</th>
        <th></th>
        <th></th>
        <th>No.</th>
        @if($prev_vals == null)
            <th>0</th>
        @else
            <th>{{ $prev_vals->sum('tot_rec') }}</th>
        @endif
        <th>{{ $data->tot_rec }}</th>
        <th>{{ $data->tot_rec + $prev_vals->sum('tot_rec')}}</th>
    </tr>
    <tr>
        <th>3.3.7.1</th>
        <th rowspan="2">Micro Scale Firms</th>
        <th>Male Owners</th>
        <td></td>
        <td>No.</td>
        @if($prev_vals == null)
            <th>0</th>
        @else
            <td>{{ $prev_vals->sum('tot_recmmicro') }}</td>
        @endif
        <td>{{ $data->tot_recmmicro }}</td>
        <td>{{ $data->tot_recmmicro + $prev_vals->sum('tot_recmmicro')}}</td>
    </tr>
    <tr>
        <th></th>
        <th>Female Owners</th>
        <td></td>
        <td>No.</td>
        @if($prev_vals == null)
            <th>0</th>
        @else
            <td>{{ $prev_vals->sum('tot_recfmicro') }}</td>
        @endif
        <td>{{ $data->tot_recfmicro }}</td>
        <td>{{ $data->tot_recfmicro + $prev_vals->sum('tot_recfmicro')}}</td>
    </tr>
    <tr style="background-color: cornflowerblue; color: black;">
        <th></th>
        <td></td>
        <th>Total</th>
        <td></td>

        <td>No.</td>
        @if($prev_vals == null)
            <th>0</th>
        @else
            <td>{{ $prev_vals->sum('tot_recmicro') }}</td>
        @endif
        <th>{{ $data->tot_recmicro }}</th>
        <th>{{ $data->tot_recmicro + $prev_vals->sum('tot_recmicro') }}</th>
    </tr>
    <tr>
        <th>3.3.7.2</th>
        <th rowspan="2">Small Scale Firms</th>
        <th>Male Owners</th>
        <td></td>
        <td>No.</td>
        @if($prev_vals == null)
            <th>0</th>
        @else
            <td>{{ $prev_vals->sum('tot_recmsmall') }}</td>
        @endif
        <td>{{ $data->tot_recmsmall }}</td>
        <td>{{ $data->tot_recmsmall + $prev_vals->sum('tot_recmsmall')}}</td>
    </tr>
    <tr>
        <th></th>
        <th>Female Owners</th>
        <td></td>
        <td>No.</td>
        @if($prev_vals == null)
            <th>0</th>
        @else
            <td>{{ $prev_vals->sum('tot_recfsmall') }}</td>
        @endif
        <td>{{ $data->tot_recfsmall }}</td>
        <td>{{ $data->tot_recfsmall + $prev_vals->sum('tot_recfsmall')}}</td>
    </tr>
    <tr style="background-color: cornflowerblue; color: black;">
        <th></th>
        <td></td>
        <th>Total</th>
        <td></td>

        <td>No.</td>
        @if($prev_vals == null)
            <th>0</th>
        @else
            <td>{{ $prev_vals->sum('tot_recsmall') }}</td>
        @endif
        <th>{{ $data->tot_recsmall }}</th>
        <th>{{ $data->tot_recsmall + $prev_vals->sum('tot_recsmall')}}</th>
    </tr>

    <tr>
        <th>3.3.8</th>
        <th>Amount Disbursed to Service Providers of IT Solutions (on behalf of Beneficiary Firms)</th>
        <th></th>
        <th></th>
        <th>No.</th>
        @if($prev_vals == null)
            <th>0</th>
        @else
            <th>{{ $prev_vals->sum('tot_dis') }}</th>
        @endif
        <th>{{ $data->tot_dis }}</th>
        <th>{{ $data->tot_dis + $prev_vals->sum('tot_dis')}}</th>
    </tr>
    <tr>
        <th>3.3.8.1</th>
        <th rowspan="2">Micro Scale Firms</th>
        <th>Male Owners</th>
        <td></td>
        <td>No.</td>
        @if($prev_vals == null)
            <th>0</th>
        @else
            <td>{{ $prev_vals->sum('tot_dismmicro') }}</td>
        @endif
        <td>{{ $data->tot_dismmicro }}</td>
        <td>{{ $data->tot_dismmicro + $prev_vals->sum('tot_dismmicro')}}</td>
    </tr>
    <tr>
        <th></th>
        <th>Female Owners</th>
        <td></td>
        <td>No.</td>
        @if($prev_vals == null)
            <th>0</th>
        @else
            <td>{{ $prev_vals->sum('tot_disfmicro') }}</td>
        @endif
        <td>{{ $data->tot_disfmicro }}</td>
        <td>{{ $data->tot_disfmicro + $prev_vals->sum('tot_disfmicro')}}</td>
    </tr>
    <tr style="background-color: cornflowerblue; color: black;">
        <th></th>
        <td></td>
        <th>Total</th>
        <td></td>

        <td>No.</td>
        @if($prev_vals == null)
            <th>0</th>
        @else
            <td>{{ $prev_vals->sum('tot_dismicro') }}</td>
        @endif
        <th>{{ $data->tot_dismicro }}</th>
        <th>{{ $data->tot_dismicro + $prev_vals->sum('tot_dismicro')}}</th>
    </tr>
    <tr>
        <th>3.3.8.2</th>
        <th rowspan="2">Small Scale Firms</th>
        <th>Male Owners</th>
        <td></td>
        <td>No.</td>
        @if($prev_vals == null)
            <th>0</th>
        @else
            <td>{{ $prev_vals->sum('tot_dismsmall') }}</td>
        @endif
        <td>{{ $data->tot_dismsmall }}</td>
        <td>{{ $data->tot_dismsmall + $prev_vals->sum('tot_dismsmall')}}</td>
    </tr>
    <tr>
        <th></th>
        <th>Female Owners</th>
        <td></td>
        <td>No.</td>
        @if($prev_vals == null)
            <th>0</th>
        @else
            <td>{{ $prev_vals->sum('tot_disfsmall') }}</td>
        @endif
        <td>{{ $data->tot_disfsmall }}</td>
        <td>{{ $data->tot_disfsmall + $prev_vals->sum('tot_disfsmall')}}</td>
    </tr>
    <tr style="background-color: cornflowerblue; color: black;">
        <th></th>
        <td></td>
        <th>Total</th>
        <td></td>

        <td>No.</td>
        @if($prev_vals == null)
            <th>0</th>
        @else
            <td>{{ $prev_vals->sum('tot_dissmall') }}</td>
        @endif
        <th>{{ $data->tot_dissmall }}</th>
        <th>{{ $data->tot_dissmall + $prev_vals->sum('tot_dissmall')}}</th>
    </tr>

    </tbody>
</table>
