

@extends('layouts/layout')

@section('content')

    <!-- Begin Page Content -->
    <div class="container-fluid">

        <!-- Page Heading -->

        <!-- DataTales Example -->
        <div class="card shadow mb-4">
            <div class="card-header py-3">
                <h4 class="m-0 font-weight-bold text-primary">{{ Auth::user()->states->state }} {{ $data->dli->title }} Submission for {{ $data->months->date }} {{--from {{ Auth::user()->states->state }}--}}
                    <a href="{{ url()->previous() }}" class="float-right btn btn-success btn-sm">Back</a>
                </h4>
            </div>
            <div class="card-body">
                @if(Session::has('success'))
                    <p class="text-success">{{ Session('success') }}</p>
                @endif
                    <a href="{{ route('enhancement_grantexport', $data->id) }}" class="btn btn-primary m-2 me-1">Export Data</a>

                    <div class="table-responsive">

                  @include('dps.enhancement_table')
                </div>


            </div>
        </div>

    </div>
    <!-- /.container-fluid -->

@endsection

@include('layouts/footer')


<!-- Bootstrap core JavaScript-->

