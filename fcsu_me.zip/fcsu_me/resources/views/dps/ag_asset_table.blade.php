<table class="table table-bordered" id="dataTable">

    <thead style="background-color: cornflowerblue; color: white">
    <tr>
        <th colspan="8">{{ Auth::user()->states->state }} {{ $data->dli->title }} Submission for {{ $data->months->date }}</th>
    </tr>
    <tr>
        <th>Dli</th>
        <th colspan="2">Disbursement Indicator</th>
        <th></th>
        <th>Unit of Measurement</th>
        <th>Previous (as at {{ $old_rec->months->date }} )</th>
        <th>Current (as at {{ $data->months->date }})</th>
        <th>Total</th>
    </tr>
    </thead>

    <tbody>
    <tr>
        <th>2.3.1</th>
        <th>Total Number of FCAs Sensitized and Mobilized </th>
        <th></th>
        <th></th>
        <th>No.</th>
        @if($prev_vals == null)
            <th>0</th>
        @else
            <th>{{ $prev_vals->sum('tot_fcasense') }}</th>
        @endif
        <th>{{ $data->tot_fcasense }}</th>
        <th>{{ $data->tot_fcasense + $prev_vals->sum('tot_fcasense')}}</th>
    </tr>
    <tr>
        <th>2.3.2</th>
        <th>Total Number of CARP Prepared  </th>
        <th></th>
        <th></th>
        <th>No.</th>
        @if($prev_vals == null)
            <th>0</th>
        @else
            <th>{{ $prev_vals->sum('tot_carp_prep') }}</th>
        @endif
        <th>{{ $data->tot_carp_prep }}</th>
        <th>{{ $data->tot_carp_prep + $prev_vals->sum('tot_carp_prep')}}</th>
    </tr>

    <tr>
        <th>2.3.3</th>
        <th>Total Number of CARP Approved</th>
        <th></th>
        <th></th>
        <th>No.</th>
        @if($prev_vals == null)
            <th>0</th>
        @else
            <th>{{ $prev_vals->sum('tot_carp_approv') }}</th>
        @endif
        <th>{{ $data->tot_carp_approv }}</th>
        <th>{{ $data->tot_carp_approv + $prev_vals->sum('tot_carp_approv')}}</th>
    </tr>
    <tr>
        <th>2.3.4</th>
        <th rowspan="2">Total Number of Farmers who Applied for Agricultural Assets</th>
        <th>Female</th>
        <td></td>
        <td>No.</td>
        @if($prev_vals == null)
            <th>0</th>
        @else
            <td>{{ $prev_vals->sum('tot_ffar_app_assets') }}</td>
        @endif
        <td>{{ $data->tot_ffar_app_assets }}</td>
        <td>{{ $data->tot_ffar_app_assets + $prev_vals->sum('tot_ffar_app_assets')}}</td>
    </tr>
    <tr>
        <th></th>
        <th>Male</th>
        <td></td>
        <td>No.</td>
        @if($prev_vals == null)
            <th>0</th>
        @else
            <td>{{ $prev_vals->sum('tot_mfar_app_assets') }}</td>
        @endif
        <td>{{ $data->tot_mfar_app_assets }}</td>
        <td>{{ $data->tot_mfar_app_assets + $prev_vals->sum('tot_mfar_app_assets')}}</td>
    </tr>
    <tr style="background-color: cornflowerblue; color: black;">
        <th></th>
        <td></td>
        <th>Total</th>
        <td></td>

        <td>No.</td>
        @if($prev_vals == null)
            <th>0</th>
        @else
            <td>{{ $prev_vals->sum('tot_far_app_assets') }}</td>
        @endif
        <th>{{ $data->tot_far_app_assets }}</th>
        <th>{{ $data->tot_far_app_assets + $prev_vals->sum('tot_far_app_assets')}}</th>
    </tr>
    <tr>
        <th>2.3.5</th>
        <th rowspan="2">Total Number of  Farmers who Received Agricultural Assets</th>
        <th>Female</th>
        <td></td>
        <td>No.</td>
        @if($prev_vals == null)
            <th>0</th>
        @else
            <td>{{ $prev_vals->sum('tot_ffar_rec_assets') }}</td>
        @endif
        <td>{{ $data->tot_ffar_rec_assets }}</td>
        <td>{{ $data->tot_ffar_rec_assets + $prev_vals->sum('tot_ffar_rec_assets') }}</td>
    </tr>
    <tr>
        <th></th>
        <th>Male</th>
        <td></td>
        <td>No.</td>
        @if($prev_vals == null)
            <th>0</th>
        @else
            <td>{{ $prev_vals->sum('tot_mfar_rec_assets') }}</td>
        @endif
        <td>{{ $data->tot_mfar_rec_assets }}</td>
        <td>{{ $data->tot_mfar_rec_assets + $prev_vals->sum('tot_mfar_rec_assets')}}</td>
    </tr>
    <tr style="background-color: cornflowerblue; color: black;">
        <th></th>
        <td></td>
        <th>Total</th>
        <td></td>

        <td>No.</td>
        @if($prev_vals == null)
            <th>0</th>
        @else
            <td>{{ $prev_vals->sum('tot_far_rec_assets') }}</td>
        @endif
        <th>{{ $data->tot_far_rec_assets }}</th>
        <th>{{ $data->tot_far_rec_assets + $prev_vals->sum('tot_far_rec_assets') }}</th>
    </tr>

    <tr>
        <th>2.3.6</th>
        <th rowspan="2">Total Number of  Farmers Utilizing Agricultural Assets</th>
        <th>Female</th>
        <td></td>
        <td>No.</td>
        @if($prev_vals == null)
            <th>0</th>
        @else
            <td>{{ $prev_vals->sum('tot_ffar_util_assets') }}</td>
        @endif
        <td>{{ $data->tot_ffar_util_assets }}</td>
        <td>{{ $data->tot_ffar_util_assets + $prev_vals->sum('tot_ffar_util_assets')}}</td>
    </tr>
    <tr>
        <th></th>
        <th>Male</th>
        <td></td>
        <td>No.</td>
        @if($prev_vals == null)
            <th>0</th>
        @else
            <td>{{ $prev_vals->sum('tot_mfar_util_assets') }}</td>
        @endif
        <td>{{ $data->tot_mfar_util_assets }}</td>
        <td>{{ $data->tot_mfar_util_assets + $prev_vals->sum('tot_mfar_util_assets')}}</td>
    </tr>
    <tr style="background-color: cornflowerblue; color: black;">
        <th></th>
        <td></td>
        <th>Total</th>
        <td></td>

        <td>No.</td>
        @if($prev_vals == null)
            <th>0</th>
        @else
            <td>{{ $prev_vals->sum('tot_far_util_assets') }}</td>
        @endif
        <th>{{ $data->tot_far_util_assets }}</th>
        <th>{{ $data->tot_far_util_assets + $prev_vals->sum('tot_far_util_assets')}}</th>
    </tr>

    </tbody>
</table>
