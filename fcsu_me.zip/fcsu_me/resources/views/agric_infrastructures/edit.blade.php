<!DOCTYPE html>
<html>

<head lang="en">
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" />
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.0/jquery.validate.min.js"></script>
    <script
        src="https://code.jquery.com/jquery-3.4.1.js"
        integrity="sha256-WpOohJOqMqqyKL9FccASB9O0KwACQJpFTUBLTYOVvVU="
        crossorigin="anonymous"></script>
    <script>
        function SubForm (){
            $.ajax({
                url:"https://api.apispreadsheets.com/data/kEZilJ3qEJ84GmS2/",
                type:"post",
                data:$("#formid").serializeArray(),
                headers:{
                    accessKey: "985215718e39af782e5fcc74f74e97fc",
                    secretKey: "947945054352888e12d3100729c7e8ff"},
                success: function() {
                    location.reload(true);
                    alert("Agricultural Infrastructure(DLI 2.2) Form Data Submitted Successfully");
                },
                error: function() {
                    alert("Network Error: 404");
                }
            });
        }
    </script>
    <title>Agricultural Infrastructure(DLI 2.2)</title>
</head>

<body>
<div class="container p-5 my-5 border">
    <div class="col-md-6 text-right">
        <a href="{{ url()->previous() }}" class="btn btn-lg" style="background-color: #12d3e0;">Back to Result Area</a>
    </div>
    <br />
    <div class="card-header" style="background-color: #1fa366;">
        <h2 style="
            margin-top: 10px;
            margin-left: 10px;
            color: white;
            text-align: center;
          ">
            M&E-- AGRICULTURAL INFRASTRUCTURE (DLI 2.2)
        </h2> </div>
    <h4 style="text-align: center;">Fill in the information carefully in the appropriate spaces</h4>
    <form method="post" action="{{route('agric_infrastructures.update', $data->id)}}" id="formid">
        @csrf
        @method('patch')
        <div class="container border border-success p-4">
            <div class="row">
                <div class="card-header col-md-4 col-xs-12" style="background-color: #506dee;">
                    <label for="states" style="color: white;"
                    >Select Your State<span style="color: rgb(253, 237, 10);"
                        >(*)</span
                        ></label>
                    <select class="form-control" disabled
                            name="state_id" required>
                        <option value="">Select State</option>
                        @foreach($states as $state)
                            <option @if($data->state_id==$state->id) selected @endif
                            value="{{ $state->id }}">{{ $state->state }}</option>
                        @endforeach
                    </select>
                    @if ($errors->has('state_id'))
                        <span class="text-danger text-left">{{ $errors->first('state_id') }}</span>
                    @endif
                </div>
                <div class="card-header col-md-4 col-xs-12" style="background-color: #2198b1;">
                    <label for="DPs" style="color: white;"
                    >Select Your DP<span style="color: rgb(253, 237, 10);"
                        >(*)</span
                        ></label>
                    <select class="form-control" disabled
                            name="dp_id" required>
                        <option value="">Select DP</option>
                        @foreach($dps as $dp)
                            <option @if($data->dp_id==$dp->id) selected @endif
                            value="{{ $dp->id }}">{{ $dp->name }}</option>
                        @endforeach
                    </select>
                    @if ($errors->has('dp_id'))
                        <span class="text-danger text-left">{{ $errors->first('dp_id') }}</span>
                    @endif
                </div>
                <div class="card-header col-md-4 col-xs-12" style="background-color: #2198b1;">
                    <label for="monthyear" style="color: white;"
                    >Select Month<span style="color: rgb(253, 237, 10);"
                        >(*)</span
                        ></label>
                    <select class="form-control" disabled
                            name="monthyear" required>
                        <option value="">Select Month</option>
                        @foreach($months as $month)
                            <option @if($data->monthyear==$month->id) selected @endif
                            value="{{ $month->id }}">{{ $month->date }}</option>
                        @endforeach
                    </select>
                    @if ($errors->has('monthyear'))
                        <span class="text-danger text-left">{{ $errors->first('monthyear') }}</span>
                    @endif
                </div>

            </div>
            <br />
            <div class="row">
            <span class="card-footer" style="color: white; background-color: #1fa366;">
              Total Number of FCAs sensitized and mobilized</span>
                <div class="col-md-4">
                    <label>Micro scale</label>
                    <input type="text" class="form-control fca" value="{{ $data->tot_microfcasense }}" name="tot_microfcasense" id="a" onkeyup="sum()" />
                </div>
                <div class="col-md-4">
                    <label>Small scale</label>
                    <input type="text" class="form-control fca" value="{{$data->tot_smallfcasense}}" name="tot_smallfcasense" id="b" onkeyup="sum()" />
                </div>
                <div class="col-md-4">
                    <label>Total</label>
                    <input type="text" class="form-control to" value="{{ $data->tot_fcasense }}" name="tot_fcasense" id="c" readonly />
                </div>
            </div>
            <br />
            <div class="row">
                <span class="card-header" style="color: white; background-color: #1fa366;"> CARP</span>
            </div>
            <div class="row">
                <div class="col-md-3">
                    <br />
                    <label>Total Number of CARP Prepared</label>
                    <input type="text" class="form-control carp1" value="{{ $data->tot_carpprep }}" name="tot_carpprep" id="d" onkeyup="sum()" />
                </div>
                <div class="col-md-3">
                    <label>Total Number of CARP Approved</label>
                    <input type="text" class="form-control carp2" value="{{$data->tot_carpapprov}}" name="tot_carpapprov" id="e" onkeyup="sum()" />
                </div>
                <div class="col-md-3">
                    <label>Attrition (Prepared minus Approved)</label>
                    <input type="text" class="form-control to" value="{{ $data->att_prep_approv }}" name="att_prep_approv" id="f" readonly />
                </div>
                <div class="col-md-3">
                    <br />
                    <label>Attrition %</label>
                    <input type="text" class="form-control tot" value="{{ $data->att_prep }}" name="att_prep" id="f1" readonly />
                </div>
            </div>
            <br />
            <div class="row">
            <span class="card-header col-md-8" style="color: white; background-color: #1fa366;">
              Total Number of agricultural infrastructures with agreed LIPW requirements </span>
                <div class="col-md-4">
                    <input type="text" class="form-control" value="{{ $data->tot_agricinfrac }}" name="tot_agricinfrac" id="g" />
                </div>
            </div>
            <br />
            <div class="row">
            <span class="card-header" style="color: white; background-color: #1fa366;">
              Total Number of farmers who Applied for agricultural
              infrastructures with agreed LIPW requirements</span>
            </div>
            <div class="row">
                <div class="col-md-4">
                    <label>Female</label>
                    <input type="text" class="form-control alip1" value="{{$data->tot_ffarmersapp}}" name="tot_ffarmersapp" id="h" onkeyup="sum()" />
                </div>
                <div class="col-md-4">
                    <label>Male</label>
                    <input type="text" class="form-control alip2" value="{{$data->tot_mfarmersapp}}" name="tot_mfarmersapp" id="i" onkeyup="sum()" />
                </div>
                <div class="col-md-4">
                    <label>Total</label>
                    <input type="text" class="form-control to" value="{{$data->tot_farmersapp}}" name="tot_farmersapp" id="j" readonly />
                </div>
            </div>
            <br />
            <div class="row">
            <span class="card-footer bg-success" style="color: white;">
              Total Number of farmers who received agricultural infrastructures
              with agreed LIPW requirements</span>
                <div class="col-md-2">
                    <br />
                    <label>Female</label>
                    <input type="text" class="form-control rlip1" value="{{$data->tot_farmersapp}}" name="tot_ffarmersrec" id="k" onkeyup="sum()" />
                </div>
                <div class="col-md-2">
                    <br />
                    <label>Male</label>
                    <input type="text" class="form-control rlip2" value="{{$data->tot_mfarmersrec }}" name="tot_mfarmersrec" id="l" onkeyup="sum()" />
                </div>
                <div class="col-md-2">
                    <br />
                    <label>Total</label>
                    <input type="text" class="form-control to" value="{{$data->tot_farmersrec}}" name="tot_farmersrec" id="m" readonly />
                </div>
                <div class="col-md-3">
                    <label>Attrition (Applied minus Receiving)</label>
                    <input type="text" class="form-control to" value="{{$data->att_app_rec}}" name="att_app_rec" id="n" readonly />
                </div>
                <div class="col-md-3">
                    <br />
                    <label>Attrition %</label>
                    <input type="text" class="form-control tot" value="{{$data->pcent_att_app_rec}}" name="pcent_att_app_rec" id="n1" readonly />
                </div>
            </div>
            <br />
            <div class="row">
            <span class="card-footer bg-success" style="color: white; background-color: #1fa366;">
              Total Number of farmers who are Utilizing Improved Agricultural
              infrastructures with agreed LIPW requirements</span>
                <div class="col-md-2">
                    <br />
                    <label>Female</label>
                    <input type="text" class="form-control uti1" value="{{$data->tot_ffarmersutil}}" name="tot_ffarmersutil" id="o" onkeyup="sum()" />
                </div>
                <div class="col-md-2">
                    <br />
                    <label>Male</label>
                    <input type="text" class="form-control uti2" value="{{ $data->tot_mfarmersutil }}" name="tot_mfarmersutil" id="p" onkeyup="sum()" />
                </div>
                <div class="col-md-2">
                    <br />
                    <label>Total</label>
                    <input type="text" class="form-control to" value="{{$data->tot_farmersutil}}" name="tot_farmersutil" id="q" readonly />
                </div>
                <div class="col-md-3">
                    <label>Attrition (Receiving minus Utilizing)</label>
                    <input type="text" class="form-control to" value="{{$data->att_farmersutil}}" name="att_farmersutil" id="r" readonly />
                </div>
                <div class="col-md-3">
                    <br />
                    <label>Attrition %</label>
                    <input type="text" class="form-control tot" value="{{$data->pcent_att_farmersutil}}" name="pcent_att_farmersutil" id="r1" readonly />
                </div>
            </div>
            <br />
            <div class="row">
            <span class="card-header col-md-8" style="color: white; background-color: #1fa366;">
              Total Number of Agricultural infrastructure completed </span>
                <div class="col-md-4">
                    <input type="text" class="form-control" value="{{$data->tot_infracomp}}" name="tot_infracomp" id="s" onkeyup="sum()" />
                </div>
            </div>
            <br />
            <div class="row">
            <span class="card-header col-md-8" style="color: white; background-color: #1fa366;">
              Total Number of Completed Agricultural infrastructure paid for </span>
                <div class="col-md-4">
                    <input type="text" class="form-control" value="{{$data->tot_infracomppaid}}" name="tot_infracomppaid" id="t" onkeyup="sum()" />
                </div>
            </div>
            <br />
            <div class="row">
            <span class="card-header col-md-10" style="color: white; background-color: #1fa366;">
              Attrition (Agricultural infrastructure completed minus Completed Agricultural infrastructure paid for) </span>
                <div class="col-md-2">
                    <input type="text" class="form-control to" value="{{$data->att_comp_paid}}" name="att_comp_paid" id="u" readonly />
                </div>
            </div>
            <br /> </div>
        <input type="hidden" name="timestamp" id="timestamp" />
        <br/>
        <div class="col-md-6 col-xs-12">
            <input type="submit" class="btn btn-primary btn-sm" />
        </div>
    </form>
    <br />

</div>



<script type="text/javascript">

    (function($, undefined) {
        "use strict";
        // When ready.
        $(function() {
            var $form = $("#formid");
            var $input = $form.find('input[type="text"]');
            $input.on("keyup", function(event) {
                // When user select text in the document, also abort.
                var selection = window.getSelection().toString();
                if(selection !== "") {
                    return;
                }
                // When the arrow keys are pressed, abort.
                if($.inArray(event.keyCode, [38, 40, 37, 39]) !== -1) {
                    return;
                }
                var $this = $(this);
                // Get the value.
                var input = $this.val();
                var input = input.replace(/[\D\s\._\-]+/g, "");
                input = input ? parseFloat(input, 10) : 0;
                $this.val(function() {
                    return input === 0 ? "0" : input.toLocaleString("en-US");
                });
            });
        });
    })(jQuery);


    $(function() {
        var $form = $("#formid");
        var $input = $form.find('input[type="text"]');

        $input.on("keyup", function (e) {

            var sum_value = 0;
            $('.fca').each(function(){
                sum_value += +$(this).val().replace(/[^\d\.\-]/g, "");
                $('#c').val(sum_value);
            });

            // 							CARP
            var a = parseFloat($(".carp1").val().replace(/[^\d\.\-]/g, ""));
            var b = parseFloat($(".carp2").val().replace(/[^\d\.\-]/g, ""));
            $("#f").val(a - b);
            var c =  $('#f').val();
            var patt = ((c/a)*100).toFixed(2);
            $('#f1').val(patt);

            // 							applied LIPW
            var a = parseFloat($(".alip1").val().replace(/[^\d\.\-]/g, ""));
            var b = parseFloat($(".alip2").val().replace(/[^\d\.\-]/g, ""));
            $("#j").val(a + b);

            // 							received LIPW
            var a = parseFloat($(".rlip1").val().replace(/[^\d\.\-]/g, ""));
            var b = parseFloat($(".rlip2").val().replace(/[^\d\.\-]/g, ""));
            $("#m").val(a + b);
            var c = $('#j').val();
            var d = $('#m').val();
            $("#n").val(c - d);
            var patt = ((d/c)*100).toFixed(2);
            $('#n1').val(patt);

            // 							utilizing LIPW
            var a = parseFloat($(".uti1").val().replace(/[^\d\.\-]/g, ""));
            var b = parseFloat($(".uti2").val().replace(/[^\d\.\-]/g, ""));
            $("#q").val(a + b);
            var c = $('#m').val();
            var d = $('#q').val();
            $("#r").val(c - d);
            var patt = ((d/c)*100).toFixed(2);
            $('#r1').val(patt);

            // 							completed LIPW
            var a = parseFloat($("#s").val().replace(/[^\d\.\-]/g, ""));
            var b = parseFloat($("#t").val().replace(/[^\d\.\-]/g, ""));
            $("#u").val(a - b);


// 							check NaN
            $(".to").each(function (i) {
                if ($(this).val() == "NaN") {
                    ($(this).val(0))
                } else {
                    var $this = $(this);
                    var input = $this.val();
                    var input = input.replace(/[\D\s\._\-]+/g, "");
                    input = input ? parseFloat(input, 10) : 0;
                    $this.val(function () {
                        return input === 0 ? "0" : input.toLocaleString("en-US");
                    });
                }
            });
            $(".tot").each(function (i) {
                if ($(this).val() == "NaN") {
                    ($(this).val(0))
                }

            });

        });
    });

    function sum() {

        let state = document.getElementById("states").value;

        let none = "none";
        if(state === "none") {
            document.getElementById("states").style.backgroundColor = "red";
            alert("Error: Select your State");
        } else document.getElementById("states").style.backgroundColor = "white";
    }


    document.getElementById("timestamp").value = new Date().toLocaleString();

</script>
</body>

</html>
