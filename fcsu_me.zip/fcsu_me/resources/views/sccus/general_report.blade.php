
@extends('layouts/layout')

@section('content')

    <!-- Begin Page Content -->
    <div class="container-fluid">

        <!-- Page Heading -->

        <!-- DataTales Example -->
        <div class="card shadow mb-4">
            <div class="card-header py-3">
                <h4 class="m-0 font-weight-bold text-primary">{{ Auth::user()->states->state }} State General Report Preview
                    <a href="{{ url()->previous() }}" class="float-right btn btn-success btn-sm">Back</a>
                </h4>
            </div>
            <div class="card-body">
                @if(Session::has('success'))
                    <p class="text-success">{{ Session('success') }}</p>
                @endif
              {{--  <a href="#" class="btn btn-primary m-2 me-1">Export Data</a>--}}

                <div class="table-responsive">

                    <form action="{{ route('sccus.search') }}" method="post">
                        @csrf
                        <div class="card-header col-md-4 col-xs-12" style="background-color: #506dee;">
                            <label for="monthyear" style="color: white;"
                            >Select Month<span style="color: rgb(253, 237, 10);"
                                >(*)</span
                                ></label>
                            <select class="form-control"
                                    name="monthyear" required>
                                <option value="">Select Month</option>
                                @foreach($months as $month)
                                    <option value="{{ $month->id }}"
                                        {{$month->date}}>{{ $month->date }}</option>
                                @endforeach
                            </select>

                        </div>
                        <br/>
                        <div class="col-md-8 col-xs-12">
                            <input type="submit" value="Generate Report" class="btn btn-primary btn-sm" />
                        </div>
                    </form>
                </div>


            </div>
        </div>

    </div>
    <!-- /.container-fluid -->

@endsection

@include('layouts/footer')


<!-- Bootstrap core JavaScript-->

