<table class="table">
    <thead style="background-color: cornflowerblue; color: white">
    <tr>
        <th>Dli</th>
        <th colspan="2">Disbursement Indicator</th>
        <th></th>
        <th>Unit of Measurement</th>
        <th>Previous (as at ... )</th>
        <th>Current (as at ...)</th>
        <th>Total</th>
    </tr>
    </thead>
    <tbody>


    </tbody>
</table>




