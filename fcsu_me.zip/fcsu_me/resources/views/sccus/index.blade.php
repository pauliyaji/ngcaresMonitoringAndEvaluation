
@extends('layouts/layout')

@section('content')

    <!-- Begin Page Content -->
    <div class="container-fluid">

        <!-- Page Heading -->

        <!-- DataTales Example -->
        <div class="card shadow mb-4">
            <div class="card-header py-3">
                <h4 class="m-0 font-weight-bold text-primary">All Submissions from {{ Auth::user()->states->state }}
                    <a href="#" class="float-right btn btn-success btn-sm">Back</a>
                </h4>
            </div>
            <div class="card-body">
                @if(Session::has('success'))
                    <p class="text-success">{{ Session('success') }}</p>
                @endif
                   {{-- <div class="d-flex my-2 ">
                        <a href="{{ route('export') }}" class="btn btn-primary m-2 me-1">Export Data</a>
                        <button type="button" class="btn btn-success m-2" data-bs-toggle="modal" data-bs-target="#exampleModal">
                            Import Data
                        </button>
                    </div>--}}
                <div class="table-responsive">

                    <table class="table table-bordered" id="dataTable">
                        <thead>
                        <tr>
                            <th>State</th>
                            <th>Dli</th>
                            <th>DP</th>
                            <th>Status</th>
                            <th>Period</th>
                            <th>Action</th>

                        </tr>
                        </thead>
                        <tfoot>
                        <tr>
                            <th>State</th>
                            <th>Dli</th>
                            <th>DP</th>
                            <th>Status</th>
                            <th>Period</th>
                            <th>Action</th>
                        </tr>
                        </tfoot>
                        <tbody>
                        @if($sts)
                            @foreach($sts as $d)
                                <tr>
                                    <td>{{ $d->states->state }}</td>
                                    <td>{{ $d->dli->title  }}</td>
                                    <td>{{ $d->dps->name }}</td>
                                    <td style="color: green; font-weight: bold">{{ $d->status->status }}</td>
                                    {{--<td>{{ date('d-M-Y', strtotime($d->created_at)) }}</td>--}}
                                    <td>{{ $d->months->date }}</td>
                                    <td>
                                     @if(Auth::user()->sccu_id)
                                         <div class="btn-group">
                                             <a href="{{ route('socialtransfers.show', $d->id) }}" class="btn btn-info btn-sm"><i class="fa fa-eye"></i></a>
                                             @if($d->status_id != 3)

                                                 <form method="post" action="{{route('socialtransfers.senddata', $d->id)}}">
                                                     @csrf
                                                     @method('put')
                                                     <div class="col-md-6 col-xs-12">
                                                         <input type="submit" value="Confirm" class="btn btn-warning btn-sm" />
                                                     </div>
                                                 </form>
                                             @endif
                                         </div>
                                        @endif
                                    </td>
                                </tr>
                            @endforeach
                        @endif
                        @if($lipws)
                            @foreach($lipws as $d)
                                <tr>
                                    <td>{{ $d->states->state }}</td>
                                    <td>{{ $d->dli->title  }}</td>
                                    <td>{{ $d->dps->name }}</td>
                                    <td style="color: green; font-weight: bold">{{ $d->status->status }}</td>
                                    <td>{{ date('d-M-Y', strtotime($d->created_at)) }}</td>

                                    <td>
                                        @if(Auth::user()->sccu_id)
                                            <div class="btn-group">
                                                <a href="{{ route('lipws.show', $d->id) }}" class="btn btn-info btn-sm"><i class="fa fa-eye"></i></a>

                                                @if($d->status_id != 3)

                                                    <form method="post" action="{{route('lipws.senddata', $d->id)}}">
                                                        @csrf
                                                        @method('put')
                                                        <div class="col-md-6 col-xs-12">
                                                            <input type="submit" value="Confirm" class="btn btn-warning btn-sm" />
                                                        </div>
                                                    </form>
                                                @endif
                                            </div>

                                        @endif
                                    </td>
                                </tr>
                            @endforeach
                        @endif
                        @if($lihds)
                            @foreach($lihds as $d)
                                <tr>
                                    <td>{{ $d->states->state }}</td>
                                    <td>{{ $d->dli->title  }}</td>
                                    <td>{{ $d->dps->name }}</td>
                                    <td style="color: green; font-weight: bold">{{ $d->status->status }}</td>
                                    <td>{{ date('d-M-Y', strtotime($d->created_at)) }}</td>
                                    <td>
                                        @if(Auth::user()->sccu_id)
                                            <div class="btn-group">
                                                <a href="{{ route('livelihoods.show', $d->id) }}" class="btn btn-info btn-sm"><i class="fa fa-eye"></i></a>
                                                @if($d->status_id != 3)

                                                    <form method="post" action="{{route('livelihoods.senddata', $d->id)}}">
                                                        @csrf
                                                        @method('put')
                                                        <div class="col-md-6 col-xs-12">
                                                            <input type="submit" value="Confirm" class="btn btn-warning btn-sm" />
                                                        </div>
                                                    </form>
                                                @endif
                                            </div>
                                        @endif
                                    </td>
                                </tr>
                            @endforeach
                        @endif
                        @if($bss)
                            @foreach($bss as $d)
                                <tr>
                                    <td>{{ $d->states->state }}</td>
                                    <td>{{ $d->dli->title  }}</td>
                                    <td>{{ $d->dps->name }}</td>
                                    <td style="color: green; font-weight: bold">{{ $d->status->status }}</td>
                                    <td>{{ date('d-M-Y', strtotime($d->created_at)) }}</td>
                                    <td>
                                        @if(Auth::user()->sccu_id)
                                            <div class="btn-group">
                                                <a href="{{ route('basicservices.show', $d->id) }}" class="btn btn-info btn-sm"><i class="fa fa-eye"></i></a>
                                                @if($d->status_id != 3)

                                                    <form method="post" action="{{route('basicservices.senddata', $d->id)}}">
                                                        @csrf
                                                        @method('put')
                                                        <div class="col-md-6 col-xs-12">
                                                            <input type="submit" value="Confirm" class="btn btn-warning btn-sm" />
                                                        </div>
                                                    </form>
                                                @endif
                                            </div>
                                        @endif

                                    </td>
                                </tr>
                            @endforeach
                        @endif

                        @if($aginfs)
                            @foreach($aginfs as $d)
                                <tr>
                                    <td>{{ $d->states->state }}</td>
                                    <td>{{ $d->dli->title  }}</td>
                                    <td>{{ $d->dps->name }}</td>
                                    <td style="color: green; font-weight: bold">{{ $d->status->status }}</td>
                                    <td>{{ date('d-M-Y', strtotime($d->created_at)) }}</td>
                                    <td>

                                        @if(Auth::user()->sccu_id)
                                                <div class="btn-group">
                                                <a href="{{ route('agric_infrastructures.show', $d->id) }}" class="btn btn-info btn-sm"><i class="fa fa-eye"></i></a>
                                                @if($d->status_id != 3)

                                                    <form method="post" action="{{route('agric_infrastructures.senddata', $d->id)}}">
                                                        @csrf
                                                        @method('put')
                                                        <div class="col-md-6 col-xs-12">
                                                            <input type="submit" value="Confirm" class="btn btn-warning btn-sm" />
                                                        </div>
                                                    </form>
                                                @endif
                                             </div>
                                        @endif

                                    </td>
                                </tr>
                            @endforeach
                        @endif
                        @if($agass)
                            @foreach($agass as $d)
                                <tr>
                                    <td>{{ $d->states->state }}</td>
                                    <td>{{ $d->dli->title  }}</td>
                                    <td>{{ $d->dps->name }}</td>
                                    <td style="color: green; font-weight: bold">{{ $d->status->status }}</td>
                                    <td>{{ date('d-M-Y', strtotime($d->created_at)) }}</td>

                                    <td>
                                        @if(Auth::user()->sccu_id)
                                            <div class="btn-group">
                                                <a href="{{ route('agric_assets.show', $d->id) }}" class="btn btn-info btn-sm"><i class="fa fa-eye"></i></a>
                                                @if($d->status_id != 3)

                                                    <form method="post" action="{{route('agric_assets.senddata', $d->id)}}">
                                                        @csrf
                                                        @method('put')
                                                        <div class="col-md-6 col-xs-12">
                                                            <input type="submit" value="Confirm" class="btn btn-warning btn-sm" />
                                                        </div>
                                                    </form>
                                                @endif
                                            </div>
                                        @endif

                                    </td>
                                </tr>
                            @endforeach
                        @endif
                        @if($wms)
                            @foreach($wms as $d)
                                <tr>
                                    <td>{{ $d->states->state }}</td>
                                    <td>{{ $d->dli->title  }}</td>
                                    <td>{{ $d->dps->name }}</td>
                                    <td style="color: green; font-weight: bold">{{ $d->status->status }}</td>
                                    <td>{{ date('d-M-Y', strtotime($d->created_at)) }}</td>
                                    <td>

                                   @if(Auth::user()->sccu_id)
                                            <div class="btn-group">
                                                <a href="{{ route('wetmarkets.show', $d->id) }}" class="btn btn-info btn-sm"><i class="fa fa-eye"></i></a>
                                                @if($d->status_id != 3)

                                                    <form method="post" action="{{route('wetmarkets.senddata', $d->id)}}">
                                                        @csrf
                                                        @method('put')
                                                        <div class="col-md-6 col-xs-12">
                                                            <input type="submit" value="Confirm" class="btn btn-warning btn-sm" />
                                                        </div>
                                                    </form>
                                                @endif
                                            </div>
                                        @endif
                                    </td>
                                </tr>
                            @endforeach
                        @endif
                        @if($cgs)
                            @foreach($cgs as $d)
                                <tr>
                                    <td>{{ $d->states->state }}</td>
                                    <td>{{ $d->dli->title  }}</td>
                                    <td>{{ $d->dps->name }}</td>
                                    <td style="color: green; font-weight: bold">{{ $d->status->status }}</td>
                                    <td>{{ date('d-M-Y', strtotime($d->created_at)) }}</td>
                                    <td>

                                        @if(Auth::user()->sccu_id)
                                            <div class="btn-group">
                                                <a href="{{ route('credit_grants.show', $d->id) }}" class="btn btn-info btn-sm"><i class="fa fa-eye"></i></a>
                                                @if($d->status_id != 3)

                                                    <form method="post" action="{{route('credit_grants.senddata', $d->id)}}">
                                                        @csrf
                                                        @method('put')
                                                        <div class="col-md-6 col-xs-12">
                                                            <input type="submit" value="Confirm" class="btn btn-warning btn-sm" />
                                                        </div>
                                                    </form>
                                                @endif
                                            </div>
                                        @endif
                                    </td>
                                </tr>
                            @endforeach
                        @endif
                        @if($ops)
                            @foreach($ops as $d)
                                <tr>
                                    <td>{{ $d->states->state }}</td>
                                    <td>{{ $d->dli->title  }}</td>
                                    <td>{{ $d->dps->name }}</td>
                                    <td style="color: green; font-weight: bold">{{ $d->status->status }}</td>
                                    <td>{{ date('d-M-Y', strtotime($d->created_at)) }}</td>
                                    <td>

                                        @if(Auth::user()->sccu_id)
                                            <div class="btn-group">
                                                <a href="{{ route('operations_grant.show', $d->id) }}" class="btn btn-info btn-sm"><i class="fa fa-eye"></i></a>
                                                @if($d->status_id != 3)

                                                    <form method="post" action="{{route('operations_grant.senddata', $d->id)}}">
                                                        @csrf
                                                        @method('put')
                                                        <div class="col-md-6 col-xs-12">
                                                            <input type="submit" value="Confirm" class="btn btn-warning btn-sm" />
                                                        </div>
                                                    </form>
                                                @endif
                                            </div>
                                        @endif
                                    </td>
                                </tr>
                            @endforeach
                        @endif
                        @if($ens)
                            @foreach($ens as $d)
                                <tr>
                                    <td>{{ $d->states->state }}</td>
                                    <td>{{ $d->dli->title  }}</td>
                                    <td>{{ $d->dps->name }}</td>
                                    <td style="color: green; font-weight: bold">{{ $d->status->status }}</td>
                                    <td>{{ date('d-M-Y', strtotime($d->created_at)) }}</td>
                                    <td>

                                        @if(Auth::user()->sccu_id)
                                            <div class="btn-group">
                                                <a href="{{ route('enhancement_grants.show', $d->id) }}" class="btn btn-info btn-sm"><i class="fa fa-eye"></i></a>
                                                @if($d->status_id != 3)

                                                    <form method="post" action="{{route('enhancement_grants.senddata', $d->id)}}">
                                                        @csrf
                                                        @method('put')
                                                        <div class="col-md-6 col-xs-12">
                                                            <input type="submit" value="Confirm" class="btn btn-warning btn-sm" />
                                                        </div>
                                                    </form>
                                                @endif
                                            </div>
                                        @endif
                                    </td>
                                </tr>
                            @endforeach
                        @endif

                        </tbody>
                    </table>
                </div>


            </div>
        </div>

    </div>
    <!-- /.container-fluid -->

@endsection

@include('layouts/footer')


<!-- Bootstrap core JavaScript-->

