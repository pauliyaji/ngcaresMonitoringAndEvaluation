<?php

namespace App\Http\Controllers;

use App\Exports\Dli6Export;
use App\Exports\Dli9Export;
use App\Models\Approval;
use App\Models\Dli9;
use App\Models\Dli9report;
use App\Models\Dps;
use App\Models\Monthyear;
use App\Models\State;
use App\Models\Status;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Maatwebsite\Excel\Facades\Excel;

class Dli9Controller extends Controller
{
    public function index(){
        $data = Dli9::all();
        return view('credit_grants.index', compact('data'));
    }

    public function create(){
        $states = State::all();
        $months = Monthyear::all();
        $dps = Dps::all();
        return view('credit_grants.create', compact('states',  'months', 'dps'));
    }

    public function show($id){
        $approvals = Approval::all();

        $states = State::all();
        $user = Auth::user()->id;
        $months = Monthyear::all();
        $dps = Dps::all();
        $statuses = Status::all();
        $approvals = Approval::all();
        //$data = Dli9::find($id)->where('user_id', $user)->orWhere('dp_id', Auth::user()->dp_id)->orWhere('state_id', Auth::user()->state_id)->first();
        $data = Dli9::find($id);
        if($data){
            return view('credit_grants.show', compact('data', 'months', 'statuses', 'approvals', 'states', 'dps'));
        }else{
            return redirect()->back()->with('error', 'you do not have the permission');
        }
    }

    public function strans(Request $request, $id){

        $data = Dli9::find($id);
        if($request->approval_id == 1 && $data->dp_id == Auth::user()->dp_id){
            $data->status_id = 2;
            $data->update();
            return redirect()->route('dps.index')->with('success', 'DP approved');
        }else{
            $data->status_id = 4;
            $data->update();
            return redirect()->route('dps.index')->with('success', 'DP Not Approved');
        }

    }

    public function senddata($id){
        $data = Dli9::find($id);
        if($data->status_id == 2){
            $data->status_id = 3;

            $old_rec = Dli9report::where('tab_id', $data->id)->first();
            if($old_rec){
                return redirect()->route('dps.index')->with('error', 'Record already submitted Please contact FCSU Admin');
            }else{
                Dli9report::create([
                    'tot_reg' => $data->tot_reg,
                    'tot_regmmicro' => $data->tot_regmmicro,
                    'tot_regfmicro' => $data->tot_regfmicro,
                    'tot_regmicro' => $data->tot_regmicro,
                    'tot_regmsmall' => $data->tot_regmsmall,
                    'tot_regfsmall' => $data->tot_regfsmall,
                    'tot_regsmall' => $data->tot_regsmall,
                    'tot_eli_ver' => $data->tot_eli_ver,
                    'tot_eli_vermmicro' => $data->tot_eli_vermmicro,
                    'tot_eli_verfmicro' => $data->tot_eli_verfmicro,
                    'tot_eli_vermicro' => $data->tot_eli_vermicro,
                    'tot_eli_vermsmall' => $data->tot_eli_vermsmall,
                    'tot_eli_verfsmall' => $data->tot_eli_verfsmall,
                    'tot_eli_versmall' => $data->tot_eli_versmall,
                    'tot_sel' => $data->tot_sel,
                    'tot_selmmicro' => $data->tot_selmmicro,
                    'tot_selfmicro' => $data->tot_selfmicro,
                    'tot_selmicro' => $data->tot_selmicro,
                    'tot_selmsmall' => $data->tot_selmsmall,
                    'tot_selfsmall' => $data->tot_selsmall,
                    'tot_selsmall' => $data->tot_selsmall,
                    'tot_ver_len' => $data->tot_ver_len,
                    'tot_ver_newl' => $data->tot_ver_newl,
                    'tot_ver_newlmmicro' => $data->tot_ver_newlmmicro,
                    'tot_ver_newlfmicro' => $data->tot_ver_newlfmicro,
                    'tot_ver_newlmicro' => $data->tot_ver_newlmicro,
                    'tot_ver_newlmsmall' => $data->tot_ver_newlmsmall,
                    'tot_ver_newlfsmall' => $data->tot_ver_newlfsmall,
                    'tot_ver_newlsmall' => $data->tot_ver_newlsmall,
                    'tot_reccap' => $data->tot_reccap,
                    'tot_reccap_mmicro' => $data->tot_reccap_mmicro,
                    'tot_reccap_fmicro' => $data->tot_reccap_fmicro,
                    'tot_reccap_micro' => $data->tot_reccap_micro,
                    'tot_reccapmsmall' => $data->tot_reccapmsmall,
                    'tot_reccapfsmall' => $data->tot_reccapfsmall,
                    'tot_reccap_small' => $data->tot_reccap_small,
                    'amt_dis' => $data->amt_dis,
                    'amt_dismicro' => $data->amt_dismicro,
                    'amt_dissmall' => $data->amt_dissmall,

                    'dli_id' => $data->dli_id,
                    'state_id' => $data->state_id,
                    'dp_id' => $data->dp_id,
                    'tab_id' => $data->id,
                    'monthyear' => $data->monthyear,
                ]);
            }

            $data->update();
            return redirect()->route('sccus.index')->with('success', 'Submission sent to FCSU');
        }else{
            return redirect()->route('sccus.index')->with('error', 'DP action is still required');
        }

    }

    public function store(Request $request){

            $data = new Dli9();
            $data->tot_reg = $request->tot_reg;
            $data->tot_regmmicro = $request->tot_regmmicro;
            $data->tot_regfmicro = $request->tot_regfmicro;
            $data->tot_regmicro = $request->tot_regmicro;
            $data->tot_regmsmall = $request->tot_regmsmall;
            $data->tot_regfsmall = $request->tot_regfsmall;
            $data->tot_regsmall = $request->tot_regsmall;
            $data->tot_eli_ver = $request->tot_eli_ver;
            $data->tot_eli_vermmicro = $request->tot_eli_vermmicro;
            $data->tot_eli_verfmicro = $request->tot_eli_verfmicro;
            $data->tot_eli_vermicro = $request->tot_eli_vermicro;
            $data->tot_eli_vermsmall = $request->tot_eli_vermsmall;
            $data->tot_eli_verfsmall = $request->tot_eli_verfsmall;
            $data->tot_eli_versmall = $request->tot_eli_versmall;
            $data->att_reg_minus_ver = $request->att_reg_minus_ver;
            $data->tot_sel = $request->tot_sel;
            $data->tot_selmmicro = $request->tot_selmmicro;
            $data->tot_selfmicro = $request->tot_selfmicro;
            $data->tot_selmicro = $request->tot_selmicro;
            $data->tot_selmsmall = $request->tot_selmsmall;
            $data->tot_selfsmall = $request->tot_selfsmall;
            $data->tot_selsmall = $request->tot_selsmall;
            $data->att_ver_minus_sel = $request->att_ver_minus_sel;
            $data->tot_ver_len = $request->tot_ver_len;
            $data->tot_ver_newl = $request->tot_ver_newl;
            $data->tot_ver_newlmmicro = $request->tot_ver_newlmmicro;
            $data->tot_ver_newlfmicro = $request->tot_ver_newlfmicro;
            $data->tot_ver_newlmicro = $request->tot_ver_newlmicro;
            $data->tot_ver_newlmsmall = $request->tot_ver_newlmsmall;
            $data->tot_ver_newlfsmall = $request->tot_ver_newlfsmall;
            $data->tot_ver_newlsmall = $request->tot_ver_newlsmall;
            $data->tot_reccap = $request->tot_reccap;
            $data->tot_reccap_mmicro = $request->tot_reccap_mmicro;
            $data->tot_reccap_fmicro = $request->tot_reccap_fmicro;
            $data->tot_reccap_micro = $request->tot_reccap_micro;
            $data->tot_reccapmsmall = $request->tot_reccapmsmall;
            $data->tot_reccapfsmall = $request->tot_reccapfsmall;
            $data->tot_reccap_small = $request->tot_reccap_small;
            $data->att_ver_minus_rec = $request->att_ver_minus_rec;
            $data->amt_dis = (int) str_replace(',', '', $request->amt_dis);
            $data->amt_dismicro = (int) str_replace(',', '', $request->amt_dismicro);
            $data->amt_dissmall = (int) str_replace(',', '', $request->amt_dissmall);

            $data->dli_id = 9;
            $data->state_id = Auth::user()->state_id;
            $data->status_id = 4;
            $data->dp_id = Auth::user()->dp_id;
            $data->user_id = Auth::user()->id;
            $data->monthyear = $request->monthyear;

            $data->save();
            return redirect()->route('credit_grants.index')
                ->with('success', 'Data added successfully');
    }

    public function edit($id){
        $states = State::all();
        $user = Auth::user()->id;
        $dps = Dps::all();
        $months = Monthyear::all();
        //$data = Dli9::find($id)->where('user_id', $user)->orWhere('dp_id', Auth::user()->dp_id)->first();
        $data = Dli9::find($id);
        if($data){
            return view('credit_grants/edit', compact('data', 'months','dps', 'states'));
        }
        else{
            return redirect()->back()->with('error', 'You do not have the Permission');
        }
    }

    public function update(Request $request, $id){

        $data = Dli9::find($id);
        $data->tot_reg = $request->tot_reg;
        $data->tot_regmmicro = $request->tot_regmmicro;
        $data->tot_regfmicro = $request->tot_regfmicro;
        $data->tot_regmicro = $request->tot_regmicro;
        $data->tot_regmsmall = $request->tot_regmsmall;
        $data->tot_regfsmall = $request->tot_regfsmall;
        $data->tot_regsmall = $request->tot_regsmall;
        $data->tot_eli_ver = $request->tot_eli_ver;
        $data->tot_eli_vermmicro = $request->tot_eli_vermmicro;
        $data->tot_eli_verfmicro = $request->tot_eli_verfmicro;
        $data->tot_eli_vermicro = $request->tot_eli_vermicro;
        $data->tot_eli_vermsmall = $request->tot_eli_vermsmall;
        $data->tot_eli_verfsmall = $request->tot_eli_verfsmall;
        $data->tot_eli_versmall = $request->tot_eli_versmall;
        $data->att_reg_minus_ver = $request->att_reg_minus_ver;
        $data->tot_sel = $request->tot_sel;
        $data->tot_selmmicro = $request->tot_selmmicro;
        $data->tot_selfmicro = $request->tot_selfmicro;
        $data->tot_selmicro = $request->tot_selmicro;
        $data->tot_selmsmall = $request->tot_selmsmall;
        $data->tot_selfsmall = $request->tot_selfsmall;
        $data->tot_selsmall = $request->tot_selsmall;
        $data->att_ver_minus_sel = $request->att_ver_minus_sel;
        $data->tot_ver_len = $request->tot_ver_len;
        $data->tot_ver_newl = $request->tot_ver_newl;
        $data->tot_ver_newlmmicro = $request->tot_ver_newlmmicro;
        $data->tot_ver_newlfmicro = $request->tot_ver_newlfmicro;
        $data->tot_ver_newlmicro = $request->tot_ver_newlmicro;
        $data->tot_ver_newlmsmall = $request->tot_ver_newlmsmall;
        $data->tot_ver_newlfsmall = $request->tot_ver_newlfsmall;
        $data->tot_ver_newlsmall = $request->tot_ver_newlsmall;
        $data->tot_reccap = $request->tot_reccap;
        $data->tot_reccap_mmicro = $request->tot_reccap_mmicro;
        $data->tot_reccap_fmicro = $request->tot_reccap_fmicro;
        $data->tot_reccap_micro = $request->tot_reccap_micro;
        $data->tot_reccapmsmall = $request->tot_reccapmsmall;
        $data->tot_reccapfsmall = $request->tot_reccapfsmall;
        $data->tot_reccap_small = $request->tot_reccap_small;
        $data->att_ver_minus_rec = $request->att_ver_minus_rec;
        $data->amt_dis = (int) str_replace(',', '', $request->amt_dis);
        $data->amt_dismicro = (int) str_replace(',', '', $request->amt_dismicro);
        $data->amt_dissmall = (int) str_replace(',', '', $request->amt_dissmall);


        $data->dli_id = 9;
        $data->state_id = Auth::user()->state_id;
        $data->status_id = 4;
        $data->dp_id = Auth::user()->dp_id;
        $data->user_id = Auth::user()->id;
       // $data->monthyear = $request->monthyear;

        $data->update();
        return redirect()->route('credit_grants.index')
            ->with('success', 'Data successfully updated');
    }

    public function export()
    {
        $state = State::where('id', Auth::user()->state_id)->first();
        $id = $state->id;
        $location = Auth::user()->states->state;
        return Excel::download(new Dli9Export($id), 'All Credit Grant for '. $location .'.xlsx');
    }

    public function destroy($id){
        $data = Dli9::find($id);
        $data->delete();
        return redirect()->back()->with('success', 'data successfully removed');
    }
}
