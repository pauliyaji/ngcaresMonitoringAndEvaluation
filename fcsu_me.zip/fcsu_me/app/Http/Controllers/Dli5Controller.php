<?php

namespace App\Http\Controllers;

use App\Models\Dli5;
use App\Models\Dps;
use App\Models\Monthyear;
use App\Models\State;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class Dli5Controller extends Controller
{
    public function index(){
        $data = Dli5::all();
        return view('agric_inputs.index', compact('data'));
    }

    public function create(){
        $states = State::all();
        $dps = Dps::all();
        $months = Monthyear::all();
        return view('agric_inputs.create', compact('states', 'months', 'dps'));
    }

    public function show($id){
        $states = State::all();
        $user = Auth::user()->id;
        $dps = Dps::all();
        $months = Monthyear::all();
        //$data = Dli5::find($id)->where('user_id', $user)->orWhere('dp_id', Auth::user()->dp_id)->orWhere('state_id', Auth::user()->state_id)->first();
        $data = Dli5::find($id);
        if($data){
            return view('agric_inputs.show', compact('data',  'months', 'states', 'dps'));
        }else{
            return redirect()->back()->with('error', 'you do not have the permission');
        }
    }

    public function strans(Request $request, $id){
        $data = Dli5::find($id);
        if($request->approval_id == 1 && $data->dp_id == Auth::user()->dp_id){
            $data->status_id = 2;
            $data->update();
            return redirect()->route('dps.index')->with('success', 'DP approved');
        }else{
            $data->status_id = 4;
            $data->update();
            return redirect()->route('dps.index')->with('success', 'DP Not Approved');
        }

    }

    public function senddata($id){
        $data = Dli5::find($id);
        if($data->status_id == 2){
            $data->status_id = 3;
            $data->update();
            return redirect()->route('sccus.index')->with('success', 'Submission sent to FCSU');
        }else{
            return redirect()->route('sccus.index')->with('error', 'DP action is still required');
        }

    }

    public function store(Request $request){
        //dd($request->all());
        $state = Auth::user()->state_id;

        if($request->state_id == $state){
            $data = new Dli5();
            $data->tot_microfcasense = $request->tot_microfcasense;
            $data->tot_fcasmall = $request->tot_fcasmall;
            $data->tot_fca = $request->tot_fca;
            $data->tot_carpprep = $request->tot_carpprep;
            $data->tot_carpappr = $request->tot_carpappr;
            //$data->att_prep_minus_approvcarp = $request->;
            $data->tot_ff_appl_input = $request->tot_ff_appl_input;
            $data->tot_mf_appl_input = $request->tot_mf_appl_input;

            $data->tot_farmers_appl_input = $request->tot_farmers_appl_input;
            $data->tot_ff_recv_input = $request->tot_ff_recv_input;
            $data->tot_mf_recv_input = $request->tot_mf_recv_input;
            $data->tot_farmers_recv_input = $request->tot_farmers_recv_input;

            $data->tot_ffutil_agric_input = $request->tot_ffutil_agric_input;
            $data->tot_mfutil_agric_input = $request->tot_mfutil_agric_input;
            $data->tot_futil_agric_input = $request->tot_futil_agric_input;

            $data->tot_ff_appl_agserv = $request->tot_ff_appl_agserv;
            $data->tot_mf_appl_agserv = $request->tot_mf_appl_agserv;
            $data->tot_fappl_agserv = $request->tot_fappl_agserv;
            $data->tot_ff_recv_agserv = $request->tot_ff_recv_agserv;
            $data->tot_mf_recv_agserv = $request->tot_mf_recv_agserv;
            $data->tot_frecv_agserv = $request->tot_frecv_agserv;

            $data->tot_ffutil_agserv = $request->tot_ffutil_agserv;
            $data->tot_mfutil_agserv = $request->tot_mfutil_agserv;
            $data->tot_futil_agserv = $request->tot_futil_agserv;

            $data->tot_ffappl_css = $request->tot_ffappl_css;
            $data->tot_mfappl_css = $request->tot_mfappl_css;
            $data->tot_fappl_css = $request->tot_fappl_css;
            $data->tot_ffrecv_css = $request->tot_ffrecv_css;
            $data->tot_mfrecv_css = $request->tot_mfrecv_css;
            $data->tot_frecv_css = $request->tot_frecv_css;

            $data->tot_ffutil_css = $request->tot_ffutil_css;
            $data->tot_mfutil_css = $request->tot_mfutil_css;
            $data->tot_futil_css = $request->tot_futil_css;

            $data->totcrops_qtyrecv = $request->totcrops_qtyrecv;
            $data->totcrops_qtyrecv_fert = $request->totcrops_qtyrecv_fert;
            $data->totcrops_qtyrecv_seeds = $request->totcrops_qtyrecv_seeds;
            $data->totcrops_qtyrecv_agro = $request->totcrops_qtyrecv_agro;
            $data->tot_crops_qtyrecv_insec = $request->tot_crops_qtyrecv_insec;
            $data->tot_crops_qtyrecv_herbs = $request->tot_crops_qtyrecv_herbs;
            $data->tot_crops_qtyrecv_pest = $request->tot_crops_qtyrecv_pest;

            $data->totlives_qtyrecv = $request->totlives_qtyrecv;

            $data->totlives_qtyrecv_catfeed = $request->totlives_qtyrecv_catfeed;
            $data->totlives_qtyrecv_catdrugs = $request->totlives_qtyrecv_catdrugs;
            $data->totlives_qtyrecv_catvac = $request->totlives_qtyrecv_catvac;
            $data->totlives_qtyrecv_catdis = $request->totlives_qtyrecv_catdis;
            $data->totlives_qtyrecv_poul = $request->totlives_qtyrecv_poul;
            $data->totlives_qtyrecv_poulfeed = $request->totlives_qtyrecv_poulfeed;
            $data->totlives_qtyrecv_pouldrugs = $request->totlives_qtyrecv_pouldrugs;
            $data->totlives_qtyrecv_poulvac = $request->totlives_qtyrecv_poulvac;
            $data->totlives_qtyrecv_pouldis = $request->totlives_qtyrecv_pouldis;
            $data->totlives_qtyrecv_fish = $request->totlives_qtyrecv_fish;
            $data->totlives_qtyrecv_fishfeed = $request->totlives_qtyrecv_fishfeed;
            $data->totlives_qtyrecv_fishdrugs = $request->totlives_qtyrecv_fishdrugs;
            $data->totlives_qtyrecv_fishvac = $request->totlives_qtyrecv_fishvac;
            $data->totlives_qtyrecv_fishdis = $request->totlives_qtyrecv_fishdis;
            $data->totlives_qtyrecv_others = $request->totlives_qtyrecv_others;
            $data->tot_ffarmersrecadv = $request->tot_ffarmersrecadv;
            $data->tot_mfarmersrecadv = $request->tot_mfarmersrecadv;

            $data->dli_id = 5;
            $data->state_id = Auth::user()->state_id;
            $data->status_id = 4;
            $data->dp_id = Auth::user()->dp_id;
            $data->user_id = Auth::user()->id;
            $data->monthyear = $request->monthyear;

            $data->save();
            return redirect()->route('agric_inputs.index')
                ->with('success', 'Data added successfully');
        }else{
            return redirect()->route('agric_inputs.index')->with('error', 'Selected state is not your state');
        }
    }

    public function edit($id){
        $states = State::all();
        $user = Auth::user()->id;
        $dps = Dps::all();
        $months = Monthyear::all();
       // $data = Dli5::find($id)->where('user_id', $user)->orWhere('dp_id', Auth::user()->dp_id)->first();
        $data = Dli5::find($id);
        if($data){
            return view('agric_inputs/edit', compact('data', 'months', 'dps', 'states'));
        }
        else{
            return redirect()->back()->with('error', 'You do not have the Permission');
        }
    }

    public function update(Request $request, $id){

        $data = Dli5::find($id);
        $data->tot_microfcasense = $request->tot_microfcasense;
        $data->tot_smallfcasense  = $request->tot_smallfcasense;
        $data->tot_fcasense  = $request->tot_fcasense;
        $data->tot_carpprep  = $request->tot_carpprep;
        $data->tot_carpapprov  = $request->tot_carpapprov;
        $data->att_prep_approv  = $request->att_prep_approv;
        $data->att_prep  = $request->att_prep;
        $data->tot_agricinfrac  = $request->tot_agricinfrac;
        $data->tot_ffarmersapp  = $request->tot_ffarmersapp;
        $data->tot_mfarmersapp  = $request->tot_mfarmersapp;
        $data->tot_farmersapp  = $request->tot_farmersapp;
        $data->tot_ffarmersrec  = $request->tot_ffarmersrec;
        $data->tot_mfarmersrec  = $request->tot_mfarmersrec;
        $data->tot_farmersrec  = $request->tot_farmersrec;
        $data->att_app_rec  = $request->att_app_rec;
        $data->pcent_att_app_rec  = $request->pcent_att_app_rec;
        $data->tot_ffarmersutil  = $request->tot_ffarmersutil;
        $data->tot_mfarmersutil  = $request->tot_mfarmersutil;
        $data->tot_farmersutil  = $request->tot_farmersutil;
        $data->att_farmersutil  = $request->att_farmersutil;
        $data->pcent_att_farmersutil  = $request->pcent_att_farmersutil;
        $data->tot_infracomp  = $request->tot_infracomp;
        $data->tot_infracomppaid  = $request->tot_infracomppaid;
        $data->att_comp_paid  = $request->att_comp_paid;

        $data->dli_id = 5;
        $data->state_id = $request->state_id;
        $data->status_id = 4;
        $data->dp_id = $request->dp_id;
        $data->user_id = Auth::user()->id;
        $data->monthyear = $request->monthyear;

        $data->update();

        $data->update();
        return redirect()->route('agric_inputs.index')
            ->with('success', 'Data successfully updated');
    }

    public function destroy($id){
        $data = Dli5::find($id);
        $data->delete();
        return redirect()->back()->with('success', 'data successfully removed');
    }
}
