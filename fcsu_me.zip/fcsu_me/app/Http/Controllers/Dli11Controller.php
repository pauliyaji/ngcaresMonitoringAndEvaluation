<?php

namespace App\Http\Controllers;

use App\Exports\Dli11Export;
use App\Exports\Dli6Export;
use App\Models\Approval;
use App\Models\Dli11;
use App\Models\Dli11report;
use App\Models\Dps;
use App\Models\Monthyear;
use App\Models\State;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Maatwebsite\Excel\Facades\Excel;

class Dli11Controller extends Controller
{
    public function index(){
        $data = Dli11::all();

        return view('enhancement_grants.index', compact('data'));
    }

    public function create(){
        $states = State::all();
        $months = Monthyear::all();
        $dps = Dps::all();
        return view('enhancement_grants.create', compact('states', 'months', 'dps'));
    }

    public function show($id){
        $states = State::all();
        $user = Auth::user()->id;
        $months = Monthyear::all();
        $dps = Dps::all();
        $approvals = Approval::all();

        //$data = Dli11::find($id)->where('user_id', $user)->orWhere('dp_id', Auth::user()->dp_id)->orWhere('state_id', Auth::user()->state_id)->first();
        $data = Dli11::find($id);

        if($data){
            return view('enhancement_grants.show', compact('data',  'months', 'approvals','states', 'dps'));
        }else{
            return redirect()->back()->with('error', 'you do not have the permission');
        }
    }

    public function strans(Request $request, $id){
        $data = Dli11::find($id);
        if($request->approval_id == 1 && $data->dp_id == Auth::user()->dp_id){
            $data->status_id = 2;
            $data->update();
            return redirect()->route('dps.index')->with('success', 'DP approved');
        }else{
            $data->status_id = 4;
            $data->update();
            return redirect()->route('dps.index')->with('success', 'DP Not Approved');
        }

    }

    public function senddata($id){
        $data = Dli11::find($id);
        if($data->status_id == 2){
            $data->status_id = 3;

            $old_rec = Dli11report::where('tab_id', $data->id)->first();
            if($old_rec){
                return redirect()->route('dps.index')->with('error', 'Record already submitted Please contact FCSU Admin');
            }else{
                Dli11report::create([
                    'tot_regit'=> $data->tot_regit,
                    'tot_regitmicro'=> $data->tot_regitmicro,
                    'tot_regitmmicro'=> $data->tot_regitmmicro,
                    'tot_regitfmicro'=> $data->tot_regitfmicro,
                    'tot_regitmsmall'=> $data->tot_regitmsmall,
                    'tot_regitfsmall'=> $data->tot_regitfsmall,
                    'tot_regitsmall'=> $data->tot_regitsmall,
                    'tot_eligverit'=> $data->tot_eligverit,
                    'tot_eligmmicro'=> $data->tot_eligmmicro,
                    'tot_eligfmicro'=> $data->tot_eligfmicro,
                    'tot_eligmicro'=> $data->tot_eligmicro,
                    'tot_eligmsmall'=> $data->tot_eligmsmall,
                    'tot_eligfsmall'=> $data->tot_eligfsmall,
                    'tot_eligsmall'=> $data->tot_eligsmall,
                    'tot_sel'=> $data->tot_sel,
                    'tot_selmmicro'=> $data->tot_selmmicro,
                    'tot_selfmicro'=> $data->tot_selfmicro,
                    'tot_selmicro'=> $data->tot_selmicro,
                    'tot_selmsmall'=> $data->tot_selmsmall,
                    'tot_selfsmall'=> $data->tot_selfsmall,
                    'tot_selsmall'=> $data->tot_selsmall,
                    'tot_ser_pro'=> $data->tot_ser_pro,
                    'tot_conf'=> $data->tot_conf,
                    'tot_confmmicro'=> $data->tot_confmmicro,
                    'tot_conffmicro'=> $data->tot_conffmicro,
                    'tot_confmicro'=> $data->tot_confmicro,
                    'tot_confmsmall'=> $data->tot_confmsmall,
                    'tot_conffsmall'=> $data->tot_conffsmall,
                    'tot_confsmall'=> $data->tot_confsmall,
                    'tot_tech'=> $data->tot_tech,
                    'tot_techmmicro'=> $data->tot_techmmicro,
                    'tot_techfmicro'=> $data->tot_techfmicro,
                    'tot_techmicro'=> $data->tot_techmicro,
                    'tot_techmsmall'=> $data->tot_techmsmall,
                    'tot_techfsmall'=> $data->tot_techfsmall,
                    'tot_techsmall'=> $data->tot_techsmall,
                    'tot_rec'=> $data->tot_rec,
                    'tot_recmmicro'=> $data->tot_recmmicro,
                    'tot_recfmicro'=> $data->tot_recfmicro,
                    'tot_recmicro'=> $data->tot_recmicro,
                    'tot_recmsmall'=> $data->tot_recmsmall,
                    'tot_recfsmall'=> $data->tot_recfsmall,
                    'tot_recsmall'=> $data->tot_recsmall,
                    'tot_dis'=> $data->tot_dis,
                    'tot_dismmicro'=> $data->tot_dismmicro,
                    'tot_disfmicro'=> $data->tot_disfmicro,
                    'tot_dismicro'=> $data->tot_dismicro,
                    'tot_dismsmall'=> $data->tot_dismsmall,
                    'tot_disfsmall'=> $data->tot_disfsmall,
                    'tot_dissmall'=> $data->tot_dissmall,
                    'dli_id'=> $data->dli_id,
                    'state_id'=> $data->state_id,
                    'dp_id'=> $data->dp_id,
                    'monthyear'=> $data->monthyear,
                    'tab_id'=> $data->id,

                ]);
            }

            $data->update();
            return redirect()->route('sccus.index')->with('success', 'Submission sent to FCSU');
        }else{
            return redirect()->route('sccus.index')->with('error', 'DP action is still required');
        }

    }

    public function store(Request $request){

            $data = new Dli11();
            $data->tot_regit = (int) str_replace(',', '', $request->tot_regit);
            $data->tot_regitmmicro = (int) str_replace(',', '', $request->tot_regitmmicro);
            $data->tot_regitfmicro = (int) str_replace(',', '', $request->tot_regitfmicro);
            $data->tot_regitmicro = (int) str_replace(',', '', $request->tot_regitmicro);
            $data->tot_regitmsmall = (int) str_replace(',', '', $request->tot_regitmsmall);
            $data->tot_regitfsmall = (int) str_replace(',', '', $request->tot_regitfsmall);
            $data->tot_regitsmall = (int) str_replace(',', '', $request->tot_regitsmall);
            $data->tot_eligverit = (int) str_replace(',', '', $request->tot_eligverit);
            $data->tot_eligmmicro = (int) str_replace(',', '', $request->tot_eligmmicro);
            $data->tot_eligfmicro = (int) str_replace(',', '', $request->tot_eligfmicro);
            $data->tot_eligmicro = (int) str_replace(',', '', $request->tot_eligmicro);
            $data->tot_eligmsmall = (int) str_replace(',', '', $request->tot_eligmsmall);
            $data->tot_eligfsmall = (int) str_replace(',', '', $request->tot_eligfsmall);
            $data->tot_eligsmall = (int) str_replace(',', '', $request->tot_eligsmall);
            $data->att_reg_minus_ver =(int) str_replace(',', '',  $request->att_reg_minus_ver);
            $data->tot_sel = (int) str_replace(',', '', $request->tot_sel);
            $data->tot_selmmicro = (int) str_replace(',', '', $request->tot_selmmicro);
            $data->tot_selfmicro = (int) str_replace(',', '', $request->tot_selfmicro);
            $data->tot_selmicro = (int) str_replace(',', '', $request->tot_selmicro);
            $data->tot_selmsmall = (int) str_replace(',', '', $request->tot_selmsmall);
            $data->tot_selfsmall = (int) str_replace(',', '', $request->tot_selfsmall);
            $data->tot_selsmall = (int) str_replace(',', '', $request->tot_selsmall);
            $data->att_ver_minus_sel = (int) str_replace(',', '', $request->att_ver_minus_sel);
            $data->tot_ser_pro = (int) str_replace(',', '', $request->tot_ser_pro);
            $data->tot_conf = (int) str_replace(',', '', $request->tot_conf);
            $data->tot_confmmicro = (int) str_replace(',', '', $request->tot_confmmicro);
            $data->tot_conffmicro = (int) str_replace(',', '', $request->tot_conffmicro);
            $data->tot_confmicro = (int) str_replace(',', '', $request->tot_confmicro);
            $data->tot_confmsmall = (int) str_replace(',', '', $request->tot_confmsmall);
            $data->tot_conffsmall = (int) str_replace(',', '', $request->tot_conffsmall);
            $data->tot_confsmall = (int) str_replace(',', '', $request->tot_confsmall);
            $data->tot_tech = (int) str_replace(',', '', $request->tot_tech);
            $data->tot_techmmicro = (int) str_replace(',', '', $request->tot_techmmicro);
            $data->tot_techfmicro = (int) str_replace(',', '', $request->tot_techfmicro);
            $data->tot_techmicro = (int) str_replace(',', '', $request->tot_techmicro);
            $data->tot_techmsmall = (int) str_replace(',', '', $request->tot_techmsmall);
            $data->tot_techfsmall = (int) str_replace(',', '', $request->tot_techfsmall);
            $data->tot_techsmall = (int) str_replace(',', '', $request->tot_techsmall);
            $data->tot_rec = (int) str_replace(',', '', $request->tot_rec);
            $data->tot_recmmicro = (int) str_replace(',', '', $request->tot_recmmicro);
            $data->tot_recfmicro = (int) str_replace(',', '', $request->tot_recfmicro);
            $data->tot_recmicro = (int) str_replace(',', '', $request->tot_recmicro);
            $data->tot_recmsmall = (int) str_replace(',', '', $request->tot_recmsmall);
            $data->tot_recfsmall = (int) str_replace(',', '', $request->tot_recfsmall);
            $data->tot_recsmall = (int) str_replace(',', '', $request->tot_recsmall);
            $data->att_tech_minus_rec = (int) str_replace(',', '', $request->att_tech_minus_rec);
            $data->tot_dis = (int) str_replace(',', '', $request->tot_dis);
            $data->tot_dismmicro = (int) str_replace(',', '', $request->tot_dismmicro);
            $data->tot_disfmicro = (int) str_replace(',', '', $request->tot_disfmicro);
            $data->tot_dismicro = (int) str_replace(',', '', $request->tot_dismicro);
            $data->tot_dismsmall = (int) str_replace(',', '', $request->tot_dismsmall);
            $data->tot_disfsmall = $request->tot_disfsmall;
            $data->tot_dissmall = (int) str_replace(',', '', $request->tot_dissmall);
            $data->att_sel_minus_conf = (int) str_replace(',', '', $request->att_sel_minus_conf);
            $data->att_conf_minus_tech = (int) str_replace(',', '', $request->att_conf_minus_tech);

            $data->dli_id = 11;
            $data->state_id = Auth::user()->state_id;
            $data->user_id = Auth::user()->id;
            $data->dp_id = Auth::user()->dp_id;
            $data->status_id = 4;
            $data->monthyear = $request->monthyear;


        $data->save();
            return redirect()->route('enhancement_grants.index')
                ->with('success', 'Data added successfully');

    }

    public function edit($id){
        $states = State::all();
        $user = Auth::user()->id;
        $dps = Dps::all();
        $months = Monthyear::all();
        //$data = Dli11::find($id)->where('user_id', $user)->orWhere('dp_id', Auth::user()->dp_id)->first();
        $data = Dli11::find($id);
        if($data){
            return view('enhancement_grants/edit', compact('data',  'months', 'dps', 'states'));
        }
        else{
            return redirect()->back()->with('error', 'You do not have the Permission');
        }
    }

    public function update(Request $request, $id){

        $data = Dli11::find($id);
        $data->tot_regit = (int) str_replace(',', '', $request->tot_regit);
        $data->tot_regitmmicro = (int) str_replace(',', '', $request->tot_regitmmicro);
        $data->tot_regitfmicro = (int) str_replace(',', '', $request->tot_regitfmicro);
        $data->tot_regitmicro = (int) str_replace(',', '', $request->tot_regitmicro);
        $data->tot_regitmsmall = (int) str_replace(',', '', $request->tot_regitmsmall);
        $data->tot_regitfsmall = (int) str_replace(',', '', $request->tot_regitfsmall);
        $data->tot_regitsmall = (int) str_replace(',', '', $request->tot_regitsmall);
        $data->tot_eligverit = (int) str_replace(',', '', $request->tot_eligverit);
        $data->tot_eligmmicro = (int) str_replace(',', '', $request->tot_eligmmicro);
        $data->tot_eligfmicro = (int) str_replace(',', '', $request->tot_eligfmicro);
        $data->tot_eligmicro = (int) str_replace(',', '', $request->tot_eligmicro);
        $data->tot_eligmsmall = (int) str_replace(',', '', $request->tot_eligmsmall);
        $data->tot_eligfsmall = (int) str_replace(',', '', $request->tot_eligfsmall);
        $data->tot_eligsmall = (int) str_replace(',', '', $request->tot_eligsmall);
        $data->att_reg_minus_ver =(int) str_replace(',', '',  $request->att_reg_minus_ver);
        $data->tot_sel = (int) str_replace(',', '', $request->tot_sel);
        $data->tot_selmmicro = (int) str_replace(',', '', $request->tot_selmmicro);
        $data->tot_selfmicro = (int) str_replace(',', '', $request->tot_selfmicro);
        $data->tot_selmicro = (int) str_replace(',', '', $request->tot_selmicro);
        $data->tot_selmsmall = (int) str_replace(',', '', $request->tot_selmsmall);
        $data->tot_selfsmall = (int) str_replace(',', '', $request->tot_selfsmall);
        $data->tot_selsmall = (int) str_replace(',', '', $request->tot_selsmall);
        $data->att_ver_minus_sel = (int) str_replace(',', '', $request->att_ver_minus_sel);
        $data->tot_ser_pro = (int) str_replace(',', '', $request->tot_ser_pro);
        $data->tot_conf = (int) str_replace(',', '', $request->tot_conf);
        $data->tot_confmmicro = (int) str_replace(',', '', $request->tot_confmmicro);
        $data->tot_conffmicro = (int) str_replace(',', '', $request->tot_conffmicro);
        $data->tot_confmicro = (int) str_replace(',', '', $request->tot_confmicro);
        $data->tot_confmsmall = (int) str_replace(',', '', $request->tot_confmsmall);
        $data->tot_conffsmall = (int) str_replace(',', '', $request->tot_conffsmall);
        $data->tot_confsmall = (int) str_replace(',', '', $request->tot_confsmall);
        $data->tot_tech = (int) str_replace(',', '', $request->tot_tech);
        $data->tot_techmmicro = (int) str_replace(',', '', $request->tot_techmmicro);
        $data->tot_techfmicro = (int) str_replace(',', '', $request->tot_techfmicro);
        $data->tot_techmicro = (int) str_replace(',', '', $request->tot_techmicro);
        $data->tot_techmsmall = (int) str_replace(',', '', $request->tot_techmsmall);
        $data->tot_techfsmall = (int) str_replace(',', '', $request->tot_techfsmall);
        $data->tot_techsmall = (int) str_replace(',', '', $request->tot_techsmall);
        $data->tot_rec = (int) str_replace(',', '', $request->tot_rec);
        $data->tot_recmmicro = (int) str_replace(',', '', $request->tot_recmmicro);
        $data->tot_recfmicro = (int) str_replace(',', '', $request->tot_recfmicro);
        $data->tot_recmicro = (int) str_replace(',', '', $request->tot_recmicro);
        $data->tot_recmsmall = (int) str_replace(',', '', $request->tot_recmsmall);
        $data->tot_recfsmall = (int) str_replace(',', '', $request->tot_recfsmall);
        $data->tot_recsmall = (int) str_replace(',', '', $request->tot_recsmall);
        $data->att_tech_minus_rec = (int) str_replace(',', '', $request->att_tech_minus_rec);
        $data->tot_dis = (int) str_replace(',', '', $request->tot_dis);
        $data->tot_dismmicro = (int) str_replace(',', '', $request->tot_dismmicro);
        $data->tot_disfmicro = (int) str_replace(',', '', $request->tot_disfmicro);
        $data->tot_dismicro = (int) str_replace(',', '', $request->tot_dismicro);
        $data->tot_dismsmall = (int) str_replace(',', '', $request->tot_dismsmall);
        $data->tot_disfsmall = $request->tot_disfsmall;
        $data->tot_dissmall = (int) str_replace(',', '', $request->tot_dissmall);
        $data->att_sel_minus_conf = (int) str_replace(',', '', $request->att_sel_minus_conf);
        $data->att_conf_minus_tech = (int) str_replace(',', '', $request->att_conf_minus_tech);



        $data->dli_id = 11;
        $data->state_id = Auth::user()->state_id;
        $data->status_id = 4;
        $data->dp_id = Auth::user()->dp_id;
        $data->user_id = Auth::user()->id;
       // $data->monthyear = $request->monthyear;

        $data->update();

        $data->update();
        return redirect()->route('enhancement_grants.index')
            ->with('success', 'Data successfully updated');
    }

    public function export()
    {
        $state = State::where('id', Auth::user()->state_id)->first();
        $id = $state->id;
        $location = Auth::user()->states->state;
        return Excel::download(new Dli11Export($id), 'All Enhancement Grants for '. $location .'.xlsx');
    }

    public function destroy($id){
        $data = Dli11::find($id);
        $data->delete();
        return redirect()->back()->with('success', 'data successfully removed');
    }
}
