<?php

namespace App\Http\Controllers;

use App\Exports\Dli3Export;
use App\Exports\Dli4Export;
use App\Models\Approval;
use App\Models\Dli4;
use App\Models\Dli4report;
use App\Models\Dps;
use App\Models\Monthyear;
use App\Models\State;
use App\Models\Status;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Maatwebsite\Excel\Facades\Excel;

class Dli4Controller extends Controller
{
    public function index(){

        $data = Dli4::all();
        return view('basicservices.index', compact('data'));
    }

    public function show($id){
        $approvals = Approval::all();
        $states = State::all();
        $user = Auth::user()->id;
        $dps = Dps::all();
        $months = Monthyear::all();
        //$data = Dli4::find($id)->where('user_id', $user)->orWhere('dp_id', Auth::user()->dp_id)->orWhere('state_id', Auth::user()->state_id)->first();
        $data = Dli4::find($id);
        if($data){
            return view('basicservices.show', compact('data', 'months',  'approvals', 'states', 'dps'));
        }else{
            return redirect()->back()->with('error', 'you do not have the permission');
        }
    }

    public function strans(Request $request, $id){
        $data = Dli4::find($id);
        if($request->approval_id == 1 && $data->dp_id == Auth::user()->dp_id){
            $data->status_id = 2;
            $data->update();
            return redirect()->route('dps.index')->with('success', 'DP approved');
        }else if($request->approval_id == 2){
            $data->status_id = 1;
            $data->update();
            return redirect()->route('dps.index')->with('success', 'DP not approved');
        }
        else{
            $data->status_id = 4;
            $data->update();
            return redirect()->route('dps.index')->with('success', 'DP Not Approved');
        }

    }

    public function senddata($id){
        $data = Dli4::find($id);
        if($data->status_id == 2) {
            $data->status_id = 3;

            $old_rec = Dli4report::where('tab_id', $data->id)->first();
            if ($old_rec) {
                return redirect()->route('dps.index')->with('error', 'Record already submitted Please contact FCSU Admin');
            } else {
                Dli4report::create([
                    'tot_commssensi'=> $data->tot_commssensi,
                    'tot_grpssensi'=> $data->tot_grpssensi,
                    'tot_eoirecvcomms'=> $data->tot_eoirecvcomms,
                    'tot_eoirecvgrps'=> $data->tot_eoirecvgrps,
                    'tot_cdpssubmit'=> $data->tot_cdpssubmit,
                    'tot_grdpssubmit'=> $data->tot_grdpssubmit,
                    'tot_approvcdps'=> $data->tot_approvcdps,
                    'tot_mpscdpedu'=> $data->tot_mpscdpedu,
                    'tot_mpscdpwat'=> $data->tot_mpscdpwat,
                    'tot_mpscdphlth'=> $data->tot_mpscdphlth,
                    'tot_mpscdpwatsani'=> $data->tot_mpscdpwatsani,
                    'tot_approvgrdp'=> $data->tot_approvgrdp,
                    'tot_grdpsedu'=> $data->tot_grdpsedu,
                    'tot_grdpswat'=> $data->tot_grdpswat,
                    'tot_grdpshlth'=> $data->tot_grdpshlth,
                    'tot_grdpswatsani'=> $data->tot_grdpswatsani,
                    'num_cpmctrained'=> $data->num_cpmctrained,
                    'num_gpmctrained'=> $data->num_gpmctrained,
                    'tot_mpsedu'=> $data->tot_mpsedu,
                    'tot_mpswat'=> $data->tot_mpswat,
                    'tot_mpshlth'=> $data->tot_mpshlth,
                    'tot_mpssani'=> $data->tot_mpssani,
                    'tot_grpmpsedu'=> $data->tot_grpmpsedu,
                    'tot_grpmpswat'=> $data->tot_grpmpswat,
                    'tot_grpmpshlth'=> $data->tot_grpmpshlth,
                    'tot_grpmpssani'=> $data->tot_grpmpssani,
                    'tot_beneofmps'=> $data->tot_beneofmps,
                    'tot_mpscdpnut'=> $data->tot_mpscdpnut,
                    'tot_mpsnut'=> $data->tot_mpsnut,
                    'dli_id'=> $data->dli_id,
                    'state_id'=> $data->state_id,
                    'dp_id'=> $data->dp_id,
                    'monthyear'=> $data->monthyear,
                    'tab_id'=> $data->id,

                ]);
            }
                $data->update();
                return redirect()->route('sccus.index')->with('success', 'Submission sent to FCSU');
            }
        else{
                return redirect()->route('sccus.index')->with('error', 'DP action is still required');
            }


    }

    public function create(){
        $states = State::all();
        $dps = Dps::all();
        $months = Monthyear::all();
        return view('basicservices.create', compact('states', 'months', 'dps'));
    }

    public function store(Request $request){

        $data = new Dli4();
        $data->tot_commssensi = $request->tot_commssensi;
        $data->tot_grpssensi = $request->tot_grpssensi;
        $data->tot_eoirecvcomms = $request->tot_eoirecvcomms;
        $data->tot_eoirecvgrps = $request->tot_eoirecvgrps;
        $data->tot_cdpssubmit = $request->tot_cdpssubmit;
        $data->tot_grdpssubmit = $request->tot_grdpssubmit;
        $data->tot_approvcdps = $request->tot_approvcdps;
        $data->tot_mpscdpedu = $request->tot_mpscdpedu;
        $data->tot_mpscdpwat = $request->tot_mpscdpwat;
        $data->tot_mpscdphlth = $request->tot_mpscdphlth;
        $data->tot_mpscdpwatsani = $request->tot_mpscdpwatsani;
        $data->tot_approvgrdp = $request->tot_approvgrdp;
        $data->tot_grdpsedu = $request->tot_grdpsedu;
        $data->tot_grdpswat = $request->tot_grdpswat;
        $data->tot_grdpshlth = $request->tot_grdpshlth;
        $data->tot_grdpswatsani = $request->tot_grdpswatsani;
        $data->num_cpmctrained = $request->num_cpmctrained;
        $data->num_gpmctrained = $request->num_gpmctrained;
        $data->tot_mpsedu = $request->tot_mpsedu;
        $data->tot_mpswat = $request->tot_mpswat;
        $data->tot_mpshlth = $request->tot_mpshlth;
        $data->tot_mpssani = $request->tot_mpssani;
        $data->tot_grpmpsedu = $request->tot_grpmpsedu;
        $data->tot_grpmpswat = $request->tot_grpmpswat;
        $data->tot_grpmpshlth = $request->tot_grpmpshlth;
        $data->tot_grpmpssani = $request->tot_grpmpssani;
        $data->tot_beneofmps  = $request->tot_beneofmps;
        $data->tot_mpscdpnut = $request->tot_mpscdpnut;
        $data->tot_mpsnut = $request->tot_mpsnut;

        $data->dli_id = 4;
        $data->state_id = Auth::user()->state_id;
        $data->status_id = 4;
        $data->dp_id = Auth::user()->dp_id;
        $data->user_id = Auth::user()->id;
        $data->monthyear = $request->monthyear;
        $data->save();
            return redirect()->route('basicservices.index')
                ->with('success', 'Data added successfully');

    }

    public function edit($id){
        $states = State::all();
        $user = Auth::user()->id;
        $dps = Dps::all();
        $months = Monthyear::all();
        //$data = Dli4::find($id)->where('user_id', $user)->orWhere('dp_id', Auth::user()->dp_id)->first();
        $data = Dli4::find($id);
        if($data){
            return view('basicservices/edit', compact('data', 'months', 'dps', 'states'));
        }
        else{
            return redirect()->back()->with('error', 'You do not have the Permission');
        }
    }

    public function update(Request $request, $id){

        //dd($request->all());
        $data = Dli4::find($id);
        $data->tot_commssensi = $request->tot_commssensi;
        $data->tot_grpssensi = $request->tot_grpssensi;
        $data->tot_eoirecvcomms = $request->tot_eoirecvcomms;
        $data->tot_eoirecvgrps = $request->tot_eoirecvgrps;
        $data->tot_cdpssubmit = $request->tot_cdpssubmit;
        $data->tot_grdpssubmit = $request->tot_grdpssubmit;
        $data->tot_approvcdps = $request->tot_approvcdps;
        $data->tot_mpscdpedu = $request->tot_mpscdpedu;
        $data->tot_mpscdpwat = $request->tot_mpscdpwat;
        $data->tot_mpscdphlth = $request->tot_mpscdphlth;
        $data->tot_mpscdpwatsani = $request->tot_mpscdpwatsani;
        $data->tot_approvgrdp = $request->tot_approvgrdp;
        $data->tot_grdpsedu = $request->tot_grdpsedu;
        $data->tot_grdpswat = $request->tot_grdpswat;
        $data->tot_grdpshlth = $request->tot_grdpshlth;
        $data->tot_grdpswatsani = $request->tot_grdpswatsani;
        $data->num_cpmctrained = $request->num_cpmctrained;
        $data->num_gpmctrained = $request->num_gpmctrained;
        $data->tot_mpsedu = $request->tot_mpsedu;
        $data->tot_mpswat = $request->tot_mpswat;
        $data->tot_mpshlth = $request->tot_mpshlth;
        $data->tot_mpssani = $request->tot_mpssani;
        $data->tot_grpmpsedu = $request->tot_grpmpsedu;
        $data->tot_grpmpswat = $request->tot_grpmpswat;
        $data->tot_grpmpshlth = $request->tot_grpmpshlth;
        $data->tot_grpmpssani = $request->tot_grpmpssani;
        $data->tot_beneofmps  = $request->tot_beneofmps;
        $data->tot_mpscdpnut = $request->tot_mpscdpnut;
        $data->tot_mpsnut = $request->tot_mpsnut;

        $data->dli_id = 4;
        $data->state_id = Auth::user()->state_id;
        $data->status_id = 4;
        $data->user_id = Auth::user()->id;
        //$data->monthyear = $request->monthyear;


        $data->update();
        return redirect()->route('basicservices.index')
            ->with('success', 'Data successfully updated');
    }

    public function export()
    {
        $state = State::where('id', Auth::user()->state_id)->first();
        $id = $state->id;
        $location = Auth::user()->states->state;
        return Excel::download(new Dli4Export($id), 'All Basic Services for '. $location .'.xlsx');
    }

    public function destroy($id){
        $data = Dli4::find($id);
        $data->delete();
        return redirect()->back()->with('success', 'data successfully removed');
    }
}
