<?php

namespace App\Http\Controllers;

use App\Models\Approval;
use App\Models\Dli1;
use App\Models\Dli10;
use App\Models\Dli11;
use App\Models\Dli2;
use App\Models\Dli3;
use App\Models\Dli4;
use App\Models\Dli5;
use App\Models\Dli6;
use App\Models\Dli7;
use App\Models\Dli8;
use App\Models\Dli9;
use App\Models\Dps;
use App\Models\Monthyear;
use App\Models\State;
use App\Models\Status;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class FcsuController extends Controller
{
    public function socialtransfers(){
        $data = Dli1::where('status_id', 3)->get();
        return view('fcsu.socialtransfers', compact('data'));
    }

    public function socialtransfer_view($id){
        $states = State::all();
        $dps = Dps::all();
        $statuses = Status::all();
        $approvals = Approval::all();
        $months = Monthyear::all();
        $data = Dli1::find($id);
        if($data){
            return view('fcsu.socialtransfer_view', compact('data', 'months', 'states','dps', 'statuses', 'approvals'));
        }
        else{
            return redirect()->back()->with('error', 'you do not have the permission');
        }
    }

    public function lipws(){
        $data = Dli2::where('status_id', 3)->get();
        return view('fcsu.lipws', compact('data'));
    }

    public function lipw_view($id){
        $states = State::all();
        $dps = Dps::all();
        $statuses = Status::all();
        $approvals = Approval::all();
        $months = Monthyear::all();
        // $role_id = Auth::user()->roles->pluck('id')[0];
        // dd($role_id);
        $data = Dli2::find($id);
        if($data){
            return view('fcsu.lipw_view', compact('data', 'months', 'states','dps', 'statuses', 'approvals'));
        }
        else{
            return redirect()->back()->with('error', 'you do not have the permission');
        }
    }

    public function livelihoods(){
        $data = Dli3::where('status_id', 3)->get();
        return view('fcsu.livelihoods', compact('data'));
    }

    public function livelihood_view($id){
        $states = State::all();
        $dps = Dps::all();
        $statuses = Status::all();
        $approvals = Approval::all();
        $months = Monthyear::all();

        $data = Dli3::find($id);
        if($data){
            return view('fcsu.livelihood_view', compact('months', 'data', 'states','dps', 'statuses', 'approvals'));
        }
        else{
            return redirect()->back()->with('error', 'you do not have the permission');
        }
    }

    public function basicservices(){
        $data = Dli4::where('status_id', 3)->get();
        return view('fcsu.basicservices', compact('data'));
    }

    public function basicservice_view($id){
        $states = State::all();
        $dps = Dps::all();
        $statuses = Status::all();
        $approvals = Approval::all();
        $months = Monthyear::all();

        $data = Dli4::find($id);
        if($data){
            return view('fcsu.basicservice_view', compact('months', 'data', 'states','dps', 'statuses', 'approvals'));
        }
        else{
            return redirect()->back()->with('error', 'you do not have the permission');
        }
    }

    public function agric_inputs(){
        $data = Dli5::where('status_id', 3)->get();
        return view('fcsu.agric_inputs', compact('data'));
    }

    public function agric_input_view($id){
        $states = State::all();
        $dps = Dps::all();
        $statuses = Status::all();
        $approvals = Approval::all();
        $months = Monthyear::all();

        $data = Dli5::find($id);
        if($data){
            return view('fcsu.agric_input_view', compact('months', 'data', 'states','dps', 'statuses', 'approvals'));
        }
        else{
            return redirect()->back()->with('error', 'you do not have the permission');
        }
    }

    public function agric_infrastructures(){
        $data = Dli6::where('status_id', 3)->get();
        return view('fcsu.agric_infrastructures', compact('data'));
    }

    public function agric_infrastructure_view($id){
        $states = State::all();
        $dps = Dps::all();
        $statuses = Status::all();
        $approvals = Approval::all();
        $months = Monthyear::all();

        $data = Dli6::find($id);
        if($data){
            return view('fcsu.agric_infrastructure_view', compact('months', 'data', 'states','dps', 'statuses', 'approvals'));
        }
        else{
            return redirect()->back()->with('error', 'you do not have the permission');
        }
    }

    public function agric_assets(){
        $data = Dli7::where('status_id', 3)->get();
        return view('fcsu.agric_assets', compact('data'));
    }

    public function agric_asset_view($id){
        $states = State::all();
        $dps = Dps::all();
        $statuses = Status::all();
        $approvals = Approval::all();
        $months = Monthyear::all();

        $data = Dli7::find($id);
        if($data){
            return view('fcsu.agric_asset_view', compact('months', 'data', 'states','dps', 'statuses', 'approvals'));
        }
        else{
            return redirect()->back()->with('error', 'you do not have the permission');
        }
    }

    public function wetmarkets(){
        $data = Dli8::where('status_id', 3)->get();
        return view('fcsu.wetmarkets', compact('data'));
    }

    public function wetmarket_view($id){
        $states = State::all();
        $dps = Dps::all();
        $statuses = Status::all();
        $approvals = Approval::all();
        $months = Monthyear::all();

        $data = Dli8::find($id);
        if($data){
            return view('fcsu.wetmarket_view', compact('months', 'data', 'states','dps', 'statuses', 'approvals'));
        }
        else{
            return redirect()->back()->with('error', 'you do not have the permission');
        }
    }

    public function credit_grants(){
        $data = Dli1::where('status_id', 3)->get();
        return view('fcsu.credit_grants', compact('data'));
    }

    public function credit_grant_view($id){
        $states = State::all();
        $dps = Dps::all();
        $statuses = Status::all();
        $approvals = Approval::all();
        $months = Monthyear::all();

        $data = Dli9::find($id);
        if($data){
            return view('fcsu.credit_grant_view', compact('months', 'data', 'states','dps', 'statuses', 'approvals'));
        }
        else{
            return redirect()->back()->with('error', 'you do not have the permission');
        }
    }

    public function operations_grant(){
        $data = Dli10::where('status_id', 3)->get();
        return view('fcsu.operations_grant', compact('data'));
    }

    public function operations_grant_view($id){
        $states = State::all();
        $dps = Dps::all();
        $statuses = Status::all();
        $approvals = Approval::all();
        $months = Monthyear::all();

        $data = Dli10::find($id);
        if($data){
            return view('fcsu.operations_grant_view', compact('months', 'data', 'states','dps', 'statuses', 'approvals'));
        }
        else{
            return redirect()->back()->with('error', 'you do not have the permission');
        }
    }

    public function enhancement_grants(){
        $data = Dli11::where('status_id', 3)->get();
        return view('fcsu.enhancement_grants', compact('data'));
    }

    public function enhancement_grant_view($id){
        $states = State::all();
        $dps = Dps::all();
        $statuses = Status::all();
        $approvals = Approval::all();
        $months = Monthyear::all();

        $data = Dli11::find($id);
        if($data){
            return view('fcsu.enhancement_grant_view', compact('months', 'data', 'states','dps', 'statuses', 'approvals'));
        }
        else{
            return redirect()->back()->with('error', 'you do not have the permission');
        }
    }
}
