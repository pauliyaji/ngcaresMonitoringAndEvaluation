<?php

namespace App\Http\Controllers;

use App\Exports\Dli10ExpView;
use App\Exports\Dli11ExpView;
use App\Exports\Dli1ExportView;
use App\Exports\Dli1ExpView;
use App\Exports\Dli2ExpView;
use App\Exports\Dli3ExpView;
use App\Exports\Dli4ExpView;
use App\Exports\Dli5ExpView;
use App\Exports\Dli6ExpView;
use App\Exports\Dli7ExpView;
use App\Exports\Dli8ExpView;
use App\Exports\Dli9ExpView;
use App\Exports\dps_reporttable;
use App\Exports\ReportExportView;
use App\Models\Dli1;
use App\Models\Dli10;
use App\Models\Dli10report;
use App\Models\Dli11;
use App\Models\Dli11report;
use App\Models\Dli1rep;
use App\Models\Dli1report;
use App\Models\Dli2;
use App\Models\Dli2report;
use App\Models\Dli3;
use App\Models\Dli3report;
use App\Models\Dli4;
use App\Models\Dli4report;
use App\Models\Dli5;
use App\Models\Dli6;
use App\Models\Dli6report;
use App\Models\Dli7;
use App\Models\Dli7report;
use App\Models\Dli8;
use App\Models\Dli8report;
use App\Models\Dli9;
use App\Models\Dli9report;
use App\Models\Monthyear;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
//use Maatwebsite\Excel\Excel;
use Maatwebsite\Excel\Facades\Excel;


class DpController extends Controller
{
    public function index(){
        $dp = Auth::user()->dp_id;
        $state = Auth::user()->state_id;
        $sts = Dli1::where('state_id', $state)->where('dp_id', $dp)->get();
        $lipws = Dli2::where('state_id', $state)->where('dp_id', $dp)->get();
        $lihds = Dli3::where('state_id', $state)->where('dp_id', $dp)->get();
        $bss = Dli4::where('state_id', $state)->where('dp_id', $dp)->get();
       // $aginps = Dli5::where('state_id', $state)->where('dp_id', $dp)->get();
        $aginfs = Dli6::where('state_id', $state)->where('dp_id', $dp)->get();
        $agass = Dli7::where('state_id', $state)->where('dp_id', $dp)->get();
        $wms = Dli8::where('state_id', $state)->where('dp_id', $dp)->get();
        $cgs = Dli9::where('state_id', $state)->where('dp_id', $dp)->get();
        $ops = Dli10::where('state_id', $state)->where('dp_id', $dp)->get();
        $ens = Dli11::where('state_id', $state)->where('dp_id', $dp)->get();
        //dd($sts);
        return view('dps.index', compact('sts', 'lipws', 'lihds',
            'bss', 'aginfs', 'agass', 'wms', 'cgs', 'ops', 'ens'));
        /*return view('dps.index', compact('sts', 'lipws', 'lihds',
        'bss', 'aginps', 'aginfs', 'agass', 'wms', 'cgs', 'ops', 'ens'));*/
    }

    public function dp_reports(){

        $state = Auth::user()->state_id;
        $sts = Dli1::where('state_id', $state)->get();
        $lipws = Dli2::where('state_id', $state)->get();
        $lihds = Dli3::where('state_id', $state)->get();
        $bss = Dli4::where('state_id', $state)->get();
        // $aginps = Dli5::where('state_id', $state)->where('dp_id', $dp)->get();
        $aginfs = Dli6::where('state_id', $state)->get();
        $agass = Dli7::where('state_id', $state)->get();
        $wms = Dli8::where('state_id', $state)->get();
        $cgs = Dli9::where('state_id', $state)->get();
        $ops = Dli10::where('state_id', $state)->get();
        $ens = Dli11::where('state_id', $state)->get();

        return view('dps.dp_reports', compact('sts', 'lipws', 'lihds',
            'bss', 'aginfs', 'agass', 'wms', 'cgs', 'ops', 'ens'));
    }

    public function sts_report($id)
    {
        $data = Dli1report::where('tab_id', $id)->first();
        // $data = Dli1::find($id);

        $old_date = $data->monthyear - 1;

        //  dd($prev_vals->sum('f_mined'));
       // $old_rec = Dli1report::where('monthyear', '<=',  $old_date)->where('state_id', $data->state_id)->orderBy('id', 'desc')->first();
        if($old_date == 0 or $old_date == 1){
            return redirect()->back()->with('error', 'There are no available records');
        }else{
            $old_rec = Dli1report::where('monthyear', '<=',  $old_date)->where('state_id', $data->state_id)->orderBy('id', 'desc')->first();
            $prev_vals = Dli1report::where('monthyear', '<=', $old_date)->where('state_id', $data->state_id)->orderBy('id', 'desc')->get();

                return view('dps.report', compact('data', 'old_rec', 'prev_vals'));

        }


    }

    public function socialexport(Request $request, $id)
    {
        return Excel::download(new Dli1ExpView($id), 'socialtransfer_report.xlsx');
    }
    public function lipwsexport(Request $request, $id){
        return Excel::download(new Dli2ExpView($id), 'lipws_report.xlsx');
    }
    public function livelihoodsexport(Request $request, $id){
        return Excel::download(new Dli3ExpView($id), 'livelihoods_report.xlsx');
    }
    public function basicexport(Request $request, $id){
        return Excel::download(new Dli4ExpView($id), 'basicservices_report.xlsx');
    }
    public function agric_inputsexport(Request $request, $id){
        return Excel::download(new Dli5ExpView($id), 'agric_inputs_report.xlsx');
    }
    public function agric_infraexport(Request $request, $id){
        return Excel::download(new Dli6ExpView($id), 'agric_infrastructures_report.xlsx');
    }
    public function agric_assetsexport(Request $request, $id){
        return Excel::download(new Dli7ExpView($id), 'agric_assets_report.xlsx');
    }
    public function wetmarketexport(Request $request, $id){
        return Excel::download(new Dli8ExpView($id), 'wetmarkets_report.xlsx');
    }
    public function creditgrant_export(Request $request, $id){
        return Excel::download(new Dli9ExpView($id), 'creditgrant_report.xlsx');
    }
    public function operationsgrant_export(Request $request, $id){
        return Excel::download(new Dli10ExpView($id), 'operations_grant_report.xlsx');
    }
    public function enhancement_grantexport(Request $request, $id){
        return Excel::download(new Dli11ExpView($id), 'enhancement_grant_report.xlsx');
    }


        public function lipws_report($id)
        {
            $data = Dli2report::where('tab_id', $id)->first();

            $old_date = $data->monthyear - 1;

            if ($old_date == 0) {
                return redirect()->back()->with('error', 'There are no available records');
            }
            else {
                $old_rec = Dli2report::where('monthyear', '<=',  $old_date)->where('state_id', $data->state_id)->orderBy('id', 'desc')->first();
                $prev_vals = Dli2report::where('monthyear', '<=',  $old_date)->where('state_id', $data->state_id)->orderBy('id', 'desc')->get();

                return view('dps.lipws_report', compact('data', 'old_rec', 'prev_vals'));

            }
        }

    public function livelihood_report($id){
        $data = Dli3report::where('tab_id', $id)->first();

        $old_date = $data->monthyear - 1;

        if ($old_date == 0) {
            return redirect()->back()->with('error', 'There are no available records');
        }
        else {
            $old_rec = Dli3report::where('monthyear', '<=',  $old_date)->where('state_id', $data->state_id)->orderBy('id', 'desc')->first();
            $prev_vals = Dli3report::where('monthyear', '<=',  $old_date)->where('state_id', $data->state_id)->orderBy('id', 'desc')->get();

            return view('dps.livelihood_report', compact('data', 'old_rec', 'prev_vals'));

        }
    }

    public function basicservices_report($id){
        $data = Dli4report::where('tab_id', $id)->first();

        $old_date = $data->monthyear - 1;

        if ($old_date == 0) {
            return redirect()->back()->with('error', 'There are no available records');
        }
        else {
            $old_rec = Dli4report::where('monthyear', '<=',  $old_date)->where('state_id', $data->state_id)->orderBy('id', 'desc')->first();
            $prev_vals = Dli4report::where('monthyear', '<=',  $old_date)->where('state_id', $data->state_id)->orderBy('id', 'desc')->get();

            return view('dps.basicservices_report', compact('data', 'old_rec', 'prev_vals'));

        }
    }

    public function agric_infrastructure_report($id){
        $data = Dli6report::where('tab_id', $id)->first();

        $old_date = $data->monthyear - 1;

        if ($old_date == 0) {
            return redirect()->back()->with('error', 'There are no available records');
        }
        else {
            $old_rec = Dli6report::where('monthyear', '<=',  $old_date)->where('state_id', $data->state_id)->orderBy('id', 'desc')->first();
            $prev_vals = Dli6report::where('monthyear', '<=',  $old_date)->where('state_id', $data->state_id)->orderBy('id', 'desc')->get();
           // dd(gettype($data->tot_ffarmersapp));
            return view('dps.agric_infrastructure_report', compact('data', 'old_rec', 'prev_vals'));

        }
    }

    public function agric_assets_report($id){
        $data = Dli7report::where('tab_id', $id)->first();

        $old_date = $data->monthyear - 1;

        if ($old_date == 0) {
            return redirect()->back()->with('error', 'There are no available records');
        }
        else {
            $old_rec = Dli7report::where('monthyear', '<=',  $old_date)->where('state_id', $data->state_id)->orderBy('id', 'desc')->first();
            $prev_vals = Dli7report::where('monthyear', '<=',  $old_date)->where('state_id', $data->state_id)->orderBy('id', 'desc')->get();
            // dd(gettype($data->tot_ffarmersapp));
            return view('dps.agric_assets_report', compact('data', 'old_rec', 'prev_vals'));

        }
    }

    public function wetmarket_report($id){
        $data = Dli8report::where('tab_id', $id)->first();

        $old_date = $data->monthyear - 1;

        if ($old_date == 0) {
            return redirect()->back()->with('error', 'There are no available records');
        }
        else {
            $old_rec = Dli8report::where('monthyear', '<=',  $old_date)->where('state_id', $data->state_id)->orderBy('id', 'desc')->first();
            $prev_vals = Dli8report::where('monthyear', '<=',  $old_date)->where('state_id', $data->state_id)->orderBy('id', 'desc')->get();
            // dd(gettype($data->tot_ffarmersapp));
            return view('dps.wetmarket_report', compact('data', 'old_rec', 'prev_vals'));

        }
    }

    public function creditgrant_report($id){
        $data = Dli9report::where('tab_id', $id)->first();

        $old_date = $data->monthyear - 1;

        if ($old_date == 0) {
            return redirect()->back()->with('error', 'There are no available records');
        }
        else {
            $old_rec = Dli9report::where('monthyear', '<=',  $old_date)->where('state_id', $data->state_id)->orderBy('id', 'desc')->first();
            $prev_vals = Dli9report::where('monthyear', '<=',  $old_date)->where('state_id', $data->state_id)->orderBy('id', 'desc')->get();
            // dd(gettype($data->tot_ffarmersapp));
            return view('dps.creditgrant_report', compact('data', 'old_rec', 'prev_vals'));

        }
    }

    public function operationsgrant_report($id){
        $data = Dli10report::where('tab_id', $id)->first();

        $old_date = $data->monthyear - 1;

        if ($old_date == 0) {
            return redirect()->back()->with('error', 'There are no available records');
        }
        else {
            $old_rec = Dli10report::where('monthyear', '<=',  $old_date)->where('state_id', $data->state_id)->orderBy('id', 'desc')->first();
            $prev_vals = Dli10report::where('monthyear', '<=',  $old_date)->where('state_id', $data->state_id)->orderBy('id', 'desc')->get();
            // dd(gettype($data->tot_ffarmersapp));
            return view('dps.operationsgrant_report', compact('data', 'old_rec', 'prev_vals'));

        }
    }

    public function enhancementgrant_report($id){
        $data = Dli11report::where('tab_id', $id)->first();

        $old_date = $data->monthyear - 1;

        if ($old_date == 0) {
            return redirect()->back()->with('error', 'There are no available records');
        }
        else {
            $old_rec = Dli11report::where('monthyear', '<=',  $old_date)->where('state_id', $data->state_id)->orderBy('id', 'desc')->first();
            $prev_vals = Dli11report::where('monthyear', '<=',  $old_date)->where('state_id', $data->state_id)->orderBy('id', 'desc')->get();
            // dd(gettype($data->tot_ffarmersapp));
            return view('dps.enhancementgrant_report', compact('data', 'old_rec', 'prev_vals'));

        }
    }
}
