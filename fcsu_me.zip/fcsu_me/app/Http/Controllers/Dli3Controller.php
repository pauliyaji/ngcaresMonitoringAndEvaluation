<?php

namespace App\Http\Controllers;

use App\Exports\Dli2Export;
use App\Exports\Dli3Export;
use App\Models\Approval;
use App\Models\Dli3;
use App\Models\Dli3report;
use App\Models\Dps;
use App\Models\Monthyear;
use App\Models\State;
use App\Models\Status;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Maatwebsite\Excel\Facades\Excel;

class Dli3Controller extends Controller
{
    public function index(){

        $data = Dli3::all();
        return view('livelihoods.index', compact('data'));
    }

    public function show($id){
        $states = State::all();
        $user = Auth::user()->id;
        $dps = Dps::all();
        $approvals = Approval::all();
        $months = Monthyear::all();

       // $data = Dli3::find($id)->where('user_id', $user)->orWhere('dp_id', Auth::user()->dp_id)->orWhere('state_id', Auth::user()->state_id)->first();
        $data = Dli3::find($id);
        if($data){
            return view('livelihoods.show', compact('data', 'states', 'dps', 'approvals', 'months'));
        }else{
            return redirect()->back()->with('error', 'you do not have the permission');
        }
    }

    public function strans(Request $request, $id){
        $data = Dli3::find($id);
        if($request->approval_id == 1 && $data->dp_id == Auth::user()->dp_id){
            $data->status_id = 2;
            $data->update();
            return redirect()->route('dps.index')->with('success', 'DP approved');
        }else if($request->approval_id == 2){
            $data->status_id = 1;
            $data->update();
            return redirect()->route('dps.index')->with('success', 'DP not approved');
        }
        else{
            $data->status_id = 4;
            $data->update();
            return redirect()->route('dps.index')->with('success', 'DP Not Approved');
        }

    }
    public function senddata($id){
        $data = Dli3::find($id);
        if($data->status_id == 2){
            $data->status_id = 3;

            $old_rec = Dli3report::where('tab_id', $data->id)->first();
            if($old_rec){
                return redirect()->route('dps.index')->with('error', 'Record already submitted Please contact FCSU Admin');
            }else{
                Dli3report::create([
                    'f_mined' => $data->f_mined,
                    'm_mined' => $data->m_mined,
                    'tot_mined' => $data->tot_mined,
                    'f_validated' => $data->f_validated,
                    'm_validated' => $data->m_validated,
                    'tot_validated' => $data->tot_validated,
                    'f_train' => $data->f_train,
                    'm_train' => $data->m_train,
                    'tot_train' => $data->tot_train,
                    'f_grad' => $data->f_grad,
                    'm_grad' => $data->m_grad,
                    'tot_grad' => $data->tot_grad,
                    'tot_fbeneforpsppay' => $data->tot_fbeneforpsppay,
                    'tot_mbeneforpsppay' => $data->tot_mbeneforpsppay,
                    'tot_beneforpsppay' => $data->tot_beneforpsppay,
                    'tot_fbenerecv' => $data->tot_fbenerecv,
                    'tot_mbenerecv' => $data->tot_mbenerecv,
                    'tot_benerecv' => $data->tot_benerecv,
                    'tot_paidbene' => $data->tot_paidbene,
                    'amt_transpsp'=> $data->amt_transpsp,

                    'dli_id' => $data->dli_id,
                    'state_id' => $data->state_id,
                    'user_id' => $data->user_id,
                    'dp_id' => $data->dp_id,
                    'status_id' => $data->status_id,
                    'monthyear' => $data->monthyear,
                    'tab_id' => $data->id,

                ]);
            }

            $data->update();
            return redirect()->route('sccus.index')->with('success', 'Submission sent to FCSU');
        }else{
            return redirect()->route('sccus.index')->with('error', 'DP action is still required');
        }

    }

    public function create(){
        $states = State::all();
        $dps = Dps::all();
        $months = Monthyear::all();

        return view('livelihoods.create', compact('states', 'months', 'dps'));
    }

    public function store(Request $request){

        $data = new Dli3();
        $data->f_mined = $request->f_mined;
        $data->m_mined = $request->m_mined;
        $data->tot_mined = $request->tot_mined;
        $data->f_validated = $request->f_validated;
        $data->m_validated = $request->m_validated;
        $data->tot_validated = $request->tot_validated;
        $data->att_fminedval = $request->att_fminedval;
        $data->att_mminedval = $request->att_mminedval;
        $data->att_totminedval = $request->att_totminedval;
        $data->att_minedvalpercent = $request->att_minedvalpercent;
        $data->comment1 = $request->comment1;
        $data->f_train = $request->f_train;
        $data->m_train = $request->m_train;
        $data->tot_train = $request->tot_train;
        $data->f_grad = $request->f_grad;
        $data->m_grad = $request->m_grad;
        $data->tot_grad = $request->tot_grad;
        $data->att_ftraingrad = $request->att_ftraingrad;
        $data->att_mtraingrad = $request->att_mtraingrad;
        $data->att_tottraingrad = $request->att_tottraingrad;
        $data->att_traingradpercent = $request->att_traingradpercent;
        $data->comment2 = $request->comment2;
        $data->amt_transpsp = $request->amt_transpsp;
        $data->tot_fbeneforpsppay = $request->tot_fbeneforpsppay;
        $data->tot_mbeneforpsppay = $request->tot_mbeneforpsppay;
        $data->tot_beneforpsppay = $request->tot_beneforpsppay;
        $data->tot_fbenerecv = $request->tot_fbenerecv;
        $data->tot_mbenerecv = $request->tot_mbenerecv;
        $data->tot_benerecv = $request->tot_benerecv;
        $data->tot_paidbene = $request->tot_paidbene;
        $data->attr = $request->attr;
        $data->attr_pcent = $request->attr_pcent;
        $data->comment3 = $request->comment3;

        $data->dli_id = 3;
        $data->state_id = Auth::user()->state_id;
        $data->status_id = 4;
        $data->dp_id = Auth::user()->dp_id;
        $data->user_id = Auth::user()->id;
        $data->monthyear = $request->monthyear;
        $data->save();
        return redirect()->route('livelihoods.index')
            ->with('success', 'Data added successfully');
    }

    public function edit($id){
        $states = State::all();
        $user = Auth::user()->id;
        $months = Monthyear::all();
        $dps = Dps::all();
        //$data = Dli3::find($id)->where('user_id', $user)->orWhere('dp_id', Auth::user()->dp_id)->first();
        $data = Dli3::find($id);
        if($data){
            return view('livelihoods/edit', compact('data',  'months', 'dps', 'states'));

        }else{
            return redirect()->back()->with('error', 'You do not have the Permission');
        }

    }

    public function update(Request $request, $id){

        //dd($request->all());
        $data = Dli3::find($id);
        $data->f_mined = $request->f_mined;
        $data->m_mined = $request->m_mined;
        $data->tot_mined = $request->tot_mined;
        $data->f_validated = $request->f_validated;
        $data->m_validated = $request->m_validated;
        $data->tot_validated = $request->tot_validated;
        $data->att_fminedval = $request->att_fminedval;
        $data->att_mminedval = $request->att_mminedval;
        $data->att_totminedval = $request->att_totminedval;
        $data->att_minedvalpercent = $request->att_minedvalpercent;
        $data->comment1 = $request->comment1;
        $data->f_train = $request->f_train;
        $data->m_train = $request->m_train;
        $data->tot_train = $request->tot_train;
        $data->f_grad = $request->f_grad;
        $data->m_grad = $request->m_grad;
        $data->tot_grad = $request->tot_grad;
        $data->att_ftraingrad = $request->att_ftraingrad;
        $data->att_mtraingrad = $request->att_mtraingrad;
        $data->att_tottraingrad = $request->att_tottraingrad;
        $data->att_traingradpercent = $request->att_traingradpercent;
        $data->comment2 = $request->comment2;
        $data->amt_transpsp = $request->amt_transpsp;
        $data->tot_fbeneforpsppay = $request->tot_fbeneforpsppay;
        $data->tot_mbeneforpsppay = $request->tot_mbeneforpsppay;
        $data->tot_beneforpsppay = $request->tot_beneforpsppay;
        $data->tot_fbenerecv = $request->tot_fbenerecv;
        $data->tot_mbenerecv = $request->tot_mbenerecv;
        $data->tot_benerecv = $request->tot_benerecv;
        $data->tot_paidbene = $request->tot_paidbene;
        $data->attr = $request->attr;
        $data->attr_pcent = $request->attr_pcent;
        $data->comment3 = $request->comment3;

        $data->dli_id = 3;
        $data->state_id = Auth::user()->state_id;
        $data->status_id = 4;
        $data->dp_id = Auth::user()->dp_id;
        $data->user_id = Auth::user()->id;
        $data->monthyear = $request->monthyear;


        $data->update();
        return redirect()->route('livelihoods.index')
            ->with('success', 'Data successfully updated');
    }

    public function export()
    {
        $state = State::where('id', Auth::user()->state_id)->first();
        $id = $state->id;
        $location = Auth::user()->states->state;
        return Excel::download(new Dli3Export($id), 'All Livelihoods for '. $location .'.xlsx');
    }


    public function destroy($id){
        $data = Dli3::find($id);
        $data->delete();
        return redirect()->back()->with('success', 'data successfully removed');
    }
}
