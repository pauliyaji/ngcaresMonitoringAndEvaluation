<?php

namespace App\Http\Controllers;

use App\Exports\Dli1sExport;
use App\Exports\Dli2Export;
use App\Models\Approval;
use App\Models\Dli2;
use App\Models\Dli2report;
use App\Models\Dps;
use App\Models\Monthyear;
use App\Models\State;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Maatwebsite\Excel\Facades\Excel;

class Dli2Controller extends Controller
{
    public function index(){

        $data = Dli2::all();
        return view('lipws.index', compact('data'));
    }

    public function show($id){
        $states = State::all();
        $user = Auth::user()->id;
        $dps = Dps::all();
        $approvals = Approval::all();
        $months = Monthyear::all();

        //$data = Dli2::find($id)->where('user_id', $user)->orWhere('dp_id', Auth::user()->dp_id)->orWhere('state_id', Auth::user()->state_id)->first();
        $data = Dli2::find($id);
        if($data){
            return view('lipws.show', compact('data',  'months', 'approvals', 'states', 'dps'));
        }else{
            return redirect()->back()->with('error', 'you do not have the permission');
        }
    }

    public function strans(Request $request, $id){
        $data = Dli2::find($id);
        if($request->approval_id == 1 && $data->dp_id == Auth::user()->dp_id){
            $data->status_id = 2;
            $data->update();
            return redirect()->route('dps.index')->with('success', 'DP approved');
        }else if($request->approval_id == 2){
            $data->status_id = 1;
            $data->update();
            return redirect()->route('dps.index')->with('success', 'DP not approved');
        }
        else{
            $data->status_id = 4;
            $data->update();
            return redirect()->route('dps.index')->with('success', 'DP Not Approved');
        }

    }

    public function senddata($id){
        $data = Dli2::find($id);
        if($data->status_id == 2){
            $data->status_id = 3;

            $old_rec = Dli2report::where('tab_id', $data->id)->first();
            if($old_rec){
                return redirect()->route('dps.index')->with('error', 'Record already submitted Please contact FCSU Admin');
            }else{
                Dli2report::create([
                    'f_mined'=> $data->f_mined,
                    'm_mined'=> $data->m_mined,
                    'tot_mined'=> $data->tot_mined,
                    'f_validated'=> $data->f_validated,
                    'm_validated'=> $data->m_validated,
                    'tot_validated'=> $data->tot_validated,
                    'f_enrolled'=> $data->f_enrolled,
                    'm_enrolled'=> $data->m_enrolled,
                    'tot_enrolled'=> $data->tot_enrolled,
                    'f_deploy'=> $data->f_deploy,
                    'm_deploy'=> $data->m_deploy,
                    'tot_deploy'=> $data->tot_deploy,
                    'num_workdays'=> $data->num_workdays,
                    'amt_transpsp'=> $data->amt_transpsp,
                    'tot_fbeneforpsppay'=> $data->tot_fbeneforpsppay,
                    'tot_mbeneforpsppay'=> $data->tot_mbeneforpsppay,
                    'tot_beneforpsppay'=> $data->tot_beneforpsppay,
                    'tot_fbenepaid'=> $data->tot_fbenepaid,
                    'tot_mbenepaid'=> $data->tot_mbenepaid,
                    'tot_benepaid'=> $data->tot_benepaid,
                    'amountbpaid'=> $data->amountbpaid,
                    'dli_id'=> $data->dli_id,
                    'state_id'=> $data->state_id,
                    'dp_id'=> $data->dp_id,
                    'monthyear'=> $data->monthyear,
                    'tab_id' => $data->id,

                ]);
            }

            $data->update();
            return redirect()->route('sccus.index')->with('success', 'Submission sent to FCSU');
        }else{
            return redirect()->route('sccus.index')->with('error', 'DP action is still required');
        }

    }

    public function create(){
        $states = State::all();
        $months = Monthyear::all();

        $dps = Dps::all();
        return view('lipws.create', compact('states', 'dps', 'months'));
    }

    public function store(Request $request){

        $data = new Dli2();
        $data->f_mined = $request->f_mined;
        $data->m_mined = $request->m_mined;
        $data->tot_mined = $request->tot_mined;

        $data->f_validated = $request->f_validated;
        $data->m_validated = $request->m_validated;
        $data->tot_validated = $request->tot_validated;

        $data->att_fminedval = $request->att_fminedval;
        $data->att_mminedval = $request->att_mminedval;
        $data->att_totminedval = $request->att_totminedval;
        $data->att_minedvalpercent = $request->att_minedvalpercent;

        $data->p_att = $request->p_att;

        $data->f_enrolled = $request->f_enrolled;
        $data->m_enrolled = $request->m_enrolled;
        $data->tot_enrolled = $request->tot_enrolled;

        $data->f_deploy = $request->f_deploy;
        $data->m_deploy = $request->m_deploy;
        $data->tot_deploy = $request->tot_deploy;

        $data->att_fenr_deploy = $request->att_fenr_deploy;
        $data->att_menr_deploy = $request->att_menr_deploy;
        $data->att_totenr_deploy = $request->att_totenr_deploy;
        $data->att_enr_deployed = $request->att_enr_deployed;

        $data->comment = $request->comment;

        $data->num_workdays = $request->num_workdays;
        $data->amt_transpsp = $request->amt_transpsp;

        $data->tot_fbeneforpsppay = $request->tot_fbeneforpsppay;
        $data->tot_mbeneforpsppay = $request->tot_mbeneforpsppay;
        $data->tot_beneforpsppay = $request->tot_beneforpsppay;

        $data->tot_fbenepaid = $request->tot_fbenepaid;
        $data->tot_mbenepaid = $request->tot_mbenepaid;
        $data->tot_benepaid = $request->tot_benepaid;

        $data->att_fbenepaid = $request->att_fbenepaid;
        $data->att_mbenepaid = $request->att_mbenepaid;
        $data->att_benepaid = $request->att_benepaid;
        $data->att_pcent_benepaid = $request->att_pcent_benepaid;

        $data->commenta = $request->commenta;

        $data->amountbpaid = $request->amountbpaid;
        $data->attbpaid = $request->attbpaid;
        $data->attbpaidp = $request->attbpaidp;

        $data->comment4 = $request->comment4;

        $data->dli_id = 2;
        $data->state_id = Auth::user()->state_id;
        $data->status_id = 4;
        $data->dp_id = Auth::user()->dp_id;
        $data->user_id = Auth::user()->id;
        $data->monthyear = $request->monthyear;
        $data->save();
        return redirect()->route('lipws.index')
            ->with('success', 'Data added successfully');

    }

    public function edit($id){

        $states = State::all();
        //  $user = Auth::user()->id;
        $dps = Dps::all();
        $months = Monthyear::all();

        $data = Dli2::find($id);
        if($data){
            return view('lipws/edit', compact('data', 'states', 'dps', 'months'));
        }
        else{
            return redirect()->back()->with('error', 'You do not have the Permission');
        }
    }

    public function update(Request $request, $id){


        //dd($request->all());
        $data = Dli2::find($id);
        $data->f_mined = $request->f_mined;
        $data->m_mined = $request->m_mined;
        $data->tot_mined = $request->tot_mined;

        $data->f_validated = $request->f_validated;
        $data->m_validated = $request->m_validated;
        $data->tot_validated = $request->tot_validated;

        $data->att_fminedval = $request->att_fminedval;
        $data->att_mminedval = $request->att_mminedval;
        $data->att_totminedval = $request->att_totminedval;
        $data->att_minedvalpercent = $request->att_minedvalpercent;

        $data->p_att = $request->p_att;

        $data->f_enrolled = $request->f_enrolled;
        $data->m_enrolled = $request->m_enrolled;
        $data->tot_enrolled = $request->tot_enrolled;

        $data->f_deploy = $request->f_deploy;
        $data->m_deploy = $request->m_deploy;
        $data->tot_deploy = $request->tot_deploy;

        $data->att_fenr_deploy = $request->att_fenr_deploy;
        $data->att_menr_deploy = $request->att_menr_deploy;
        $data->att_totenr_deploy = $request->att_totenr_deploy;
        $data->att_enr_deployed = $request->att_enr_deployed;

        $data->comment = $request->comment;

        $data->num_workdays = $request->num_workdays;
        $data->amt_transpsp = $request->amt_transpsp;

        $data->tot_fbeneforpsppay = $request->tot_fbeneforpsppay;
        $data->tot_mbeneforpsppay = $request->tot_mbeneforpsppay;
        $data->tot_beneforpsppay = $request->tot_beneforpsppay;

        $data->tot_fbenepaid = $request->tot_fbenepaid;
        $data->tot_mbenepaid = $request->tot_mbenepaid;
        $data->tot_benepaid = $request->tot_benepaid;

        $data->att_fbenepaid = $request->att_fbenepaid;
        $data->att_mbenepaid = $request->att_mbenepaid;
        $data->att_benepaid = $request->att_benepaid;
        $data->att_pcent_benepaid = $request->att_pcent_benepaid;

        $data->commenta = $request->commenta;

        $data->amountbpaid = $request->amountbpaid;
        $data->attbpaid = $request->attbpaid;
        $data->attbpaidp = $request->attbpaidp;

        $data->comment4 = $request->comment4;

        $data->dli_id = 2;
        $data->state_id = Auth::user()->state_id;
        $data->status_id = 4;
        $data->user_id = Auth::user()->id;
       // $data->monthyear = $request->monthyear;


        $data->update();
        return redirect()->route('lipws.index')
            ->with('success', 'Data successfully updated');
    }

    public function export()
    {
        $state = State::where('id', Auth::user()->state_id)->first();
        $id = $state->id;
        $location = Auth::user()->states->state;
        return Excel::download(new Dli2Export($id), 'All LIPWs for '. $location .'.xlsx');
    }

    public function destroy($id){
        $data = Dli2::find($id);
        $data->delete();
        return redirect()->back()->with('success', 'data successfully removed');
    }
}
