<?php

namespace App\Http\Controllers;

use App\Exports\Dli6Export;
use App\Exports\Dli8Export;
use App\Models\Approval;
use App\Models\Dli8;
use App\Models\Dli8report;
use App\Models\Dps;
use App\Models\Monthyear;
use App\Models\State;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Maatwebsite\Excel\Facades\Excel;

class Dli8Controller extends Controller
{
    public function index(){
        $data = Dli8::all();
        return view('wetmarkets.index', compact('data'));
    }

    public function create(){
        $states = State::all();
        $months = Monthyear::all();
        $dps = Dps::all();
        return view('wetmarkets.create', compact('states', 'months','dps'));
    }

    public function show($id){
        $approvals = Approval::all();
        $months = Monthyear::all();
        $states = State::all();
        $user = Auth::user()->id;
        $dps = Dps::all();
        //$data = Dli8::find($id)->where('user_id', $user)->orWhere('dp_id', Auth::user()->dp_id)->orWhere('state_id', Auth::user()->state_id)->first();
        $data = Dli8::find($id);
        if($data){
            return view('wetmarkets.show', compact('data', 'months', 'states', 'dps', 'approvals'));
        }else{
            return redirect()->back()->with('error', 'you do not have the permission');
        }
    }

    public function strans(Request $request, $id){
        $data = Dli8::find($id);

        if($request->approval_id == 1 && $data->dp_id == Auth::user()->dp_id){
            $data->status_id = 2;
            $data->update();
            return redirect()->route('dps.index')->with('success', 'DP approved');
        }else{
            $data->status_id = 4;
            $data->update();
            return redirect()->route('dps.index')->with('success', 'DP Not Approved');
        }

    }

    public function senddata($id){
        $data = Dli8::find($id);
        if($data->status_id == 2){
            $data->status_id = 3;
            Dli8report::create([
                'tot_microfcasense' => $data->tot_microfcasense,
                'tot_smallfcasense' => $data->tot_smallfcasense,
                'tot_fcasense' => $data->tot_fcasense,
                'tot_carp_prep' => $data->tot_carp_prep,
                'tot_carp_approv' => $data->tot_carp_approv,
                'tot_exist_wet_mark' => $data->tot_exist_wet_mark,
                'tot_fsellersbene' => $data->tot_fsellersbene,
                'tot_msellersbene' => $data->tot_msellersbene,
                'tot_sellersbene' => $data->tot_sellersbene,
                'tot_wetmktupgraded' => $data->tot_wetmktupgraded,
                'dli_id' => $data->dli_id,
                'state_id' => $data->state_id,
                'tab_id' => $data->id,
                'dp_id' => $data->dp_id,
                'monthyear' => $data->monthyear,

            ]);

            $data->update();
            return redirect()->route('sccus.index')->with('success', 'Submission sent to FCSU');
        }else{
            return redirect()->route('sccus.index')->with('error', 'DP action is still required');
        }


    }

    public function store(Request $request){

            $data = new Dli8();
            $data->tot_microfcasense = $request->tot_microfcasense;
            $data->tot_smallfcasense = $request->tot_smallfcasense;
            $data->tot_fcasense = $request->tot_fcasense;
            $data->tot_carp_prep = $request->tot_carp_prep;
            $data->tot_carp_approv = $request->tot_carp_approv;
            $data->att_prep_approv = $request->att_prep_approv;
            $data->pcent_att_prep_approv = $request->pcent_att_prep_approv;
            $data->tot_exist_wet_mark = $request->tot_exist_wet_mark;
            $data->tot_fsellersbene = (int) str_replace(',', '', $request->tot_fsellersbene);
            $data->tot_msellersbene = (int) str_replace(',', '', $request->tot_msellersbene);
            $data->tot_sellersbene = (int) str_replace(',', '', $request->tot_sellersbene);
            $data->tot_wetmktupgraded = $request->tot_wetmktupgraded;

            $data->dli_id = 8;
            $data->state_id = Auth::user()->state_id;
            $data->status_id = 4;
            $data->dp_id = Auth::user()->dp_id;
            $data->user_id = Auth::user()->id;
            $data->monthyear = $request->monthyear;

            $data->save();
            return redirect()->route('wetmarkets.index')
                ->with('success', 'Data added successfully');

    }

    public function edit($id){
        $states = State::all();
        $user = Auth::user()->id;
        $months = Monthyear::all();
        $dps = Dps::all();
        //$data = Dli8::find($id)->where('user_id', $user)->orWhere('dp_id', Auth::user()->dp_id)->first();
        $data = Dli8::find($id);
        if($data){
            return view('wetmarkets/edit', compact('data',  'months', 'dps', 'states'));
        }
        else{
            return redirect()->back()->with('error', 'You do not have the Permission');
        }
    }

    public function update(Request $request, $id){

        $data = Dli8::find($id);
        $data->tot_microfcasense = $request->tot_microfcasense;
        $data->tot_smallfcasense = $request->tot_smallfcasense;
        $data->tot_fcasense = $request->tot_fcasense;
        $data->tot_carp_prep = $request->tot_carp_prep;
        $data->tot_carp_approv = $request->tot_carp_approv;
        $data->att_prep_approv = $request->att_prep_approv;
        $data->pcent_att_prep_approv = $request->pcent_att_prep_approv;
        $data->tot_exist_wet_mark = $request->tot_exist_wet_mark;
        $data->tot_fsellersbene = (int) str_replace(',', '', $request->tot_fsellersbene);
        $data->tot_msellersbene = (int) str_replace(',', '', $request->tot_msellersbene);
        $data->tot_sellersbene = (int) str_replace(',', '', $request->tot_sellersbene);
        $data->tot_wetmktupgraded = $request->tot_wetmktupgraded;

        $data->dli_id = 8;
        $data->state_id = Auth::user()->state_id;
        $data->status_id = 4;
        $data->dp_id = Auth::user()->dp_id;
        $data->user_id = Auth::user()->id;
       // $data->monthyear = $request->monthyear;


        $data->update();

        return redirect()->route('wetmarkets.index')
            ->with('success', 'Data successfully updated');
    }

    public function export()
    {
        $state = State::where('id', Auth::user()->state_id)->first();
        $id = $state->id;
        $location = Auth::user()->states->state;
        return Excel::download(new Dli8Export($id), 'All Wet Markets for '. $location .'.xlsx');
    }

    public function destroy($id){
        $data = Dli8::find($id);
        $data->delete();
        return redirect()->back()->with('success', 'data successfully removed');
    }
}
