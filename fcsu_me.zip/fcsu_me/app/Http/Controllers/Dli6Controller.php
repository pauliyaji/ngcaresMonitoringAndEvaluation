<?php

namespace App\Http\Controllers;

use App\Exports\Dli4Export;
use App\Exports\Dli6Export;
use App\Models\Approval;
use App\Models\Dli6;
use App\Models\Dli6report;
use App\Models\Dps;
use App\Models\Monthyear;
use App\Models\State;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Maatwebsite\Excel\Facades\Excel;

class Dli6Controller extends Controller
{
    public function index(){

        $data = Dli6::all();
        return view('agric_infrastructures.index', compact('data'));
    }

    public function create(){
        $states = State::all();
        $dps = Dps::all();
        $months = Monthyear::all();
        return view('agric_infrastructures.create', compact('states', 'months','dps'));
    }

    public function show($id){
        $approvals = Approval::all();
        $states = State::all();
        $user = Auth::user()->id;
        $months = Monthyear::all();
        $dps = Dps::all();
        //$data = Dli6::find($id)->where('user_id', $user)->orWhere('dp_id', Auth::user()->dp_id)->orWhere('state_id', Auth::user()->state_id)->first();
        $data = Dli6::find($id);
        if($data){
            return view('agric_infrastructures.show', compact('data', 'months', 'states', 'dps', 'approvals'));
        }else{
            return redirect()->back()->with('error', 'you do not have the permission');
        }
    }

    public function strans(Request $request, $id){

        $data = Dli6::find($id);
        if($request->approval_id == 1 && $data->dp_id == Auth::user()->dp_id){
            $data->status_id = 2;
            $data->update();
            return redirect()->route('dps.index')->with('success', 'DP approved');
        }else if($request->approval_id == 2){
            $data->status_id = 1;
            $data->update();
            return redirect()->route('dps.index')->with('success', 'DP not approved');
        }
        else{
            $data->status_id = 4;
            $data->update();
            return redirect()->route('dps.index')->with('success', 'DP Not Approved');
        }


    }

    public function senddata($id){
        $data = Dli6::find($id);
        if($data->status_id == 2){
            $data->status_id = 3;
            Dli6report::create([
            'tot_microfcasense' => $data->tot_microfcasense,
        'tot_smallfcasense' => $data->tot_smallfcasense,
        'tot_fcasense' => $data->tot_fcasense,
        'tot_carpprep' => $data->tot_carpprep,
        'tot_carpapprov' => $data->tot_carpapprov,
        'tot_agricinfrac' => $data->tot_agricinfrac,
        'tot_ffarmersapp' => $data->tot_ffarmersapp,
        'tot_mfarmersapp' => $data->tot_mfarmersapp,
        'tot_farmersapp' => $data->tot_farmersapp,
        'tot_ffarmersrec' => $data->tot_ffarmersrec,
        'tot_mfarmersrec' => $data->tot_mfarmersrec,
        'tot_farmersrec' => $data->tot_farmersrec,
        'tot_ffarmersutil' => $data->tot_ffarmersutil,
        'tot_mfarmersutil' => $data->tot_mfarmersutil,
        'tot_farmersutil' => $data->tot_farmersutil,
        'att_farmersutil' => $data->att_farmersutil,
        'tot_infracomp' => $data->tot_infracomp,
        'tot_infracomppaid' => $data->tot_infracomppaid,

        'dli_id' => $data->dli_id,
        'state_id' => $data->state_id,
        'dp_id' => $data->dp_id,
        'monthyear' => $data->monthyear,
        'tab_id' => $data->id,
                ]);

            $data->update();
            return redirect()->route('sccus.index')->with('success', 'Submission sent to FCSU');
        }else{
            return redirect()->route('sccus.index')->with('error', 'DP action is still required');
        }

    }

    public function store(Request $request){
            $data = new Dli6();
            $data->tot_microfcasense = $request->tot_microfcasense;
            $data->tot_smallfcasense  = $request->tot_smallfcasense;
            $data->tot_fcasense  = $request->tot_fcasense;
            $data->tot_carpprep  = $request->tot_carpprep;
            $data->tot_carpapprov  = $request->tot_carpapprov;
            $data->att_prep_approv  = $request->att_prep_approv;
            $data->att_prep  = $request->att_prep;
            $data->tot_agricinfrac  = $request->tot_agricinfrac;
            $data->tot_ffarmersapp  = (int) str_replace(',', '', $request->tot_ffarmersapp);
            $data->tot_mfarmersapp  = (int) str_replace(',', '', $request->tot_mfarmersapp);
            $data->tot_farmersapp  = (int) str_replace(',', '', $request->tot_farmersapp);
            $data->tot_ffarmersrec  = (int) str_replace(',', '', $request->tot_ffarmersrec);
            $data->tot_mfarmersrec  = (int) str_replace(',', '', $request->tot_mfarmersrec);
            $data->tot_farmersrec  = (int) str_replace(',', '', $request->tot_farmersrec);
            $data->att_app_rec  = $request->att_app_rec;
            $data->pcent_att_app_rec  = $request->pcent_att_app_rec;
            $data->tot_ffarmersutil  = (int) str_replace(',', '', $request->tot_ffarmersutil);
            $data->tot_mfarmersutil  = (int) str_replace(',', '', $request->tot_mfarmersutil);
            $data->tot_farmersutil  = (int) str_replace(',', '', $request->tot_farmersutil);
            $data->att_farmersutil  = $request->att_farmersutil;
            $data->pcent_att_farmersutil  = $request->pcent_att_farmersutil;
            $data->tot_infracomp  = (int) str_replace(',', '', $request->tot_infracomp);
            $data->tot_infracomppaid  = (int) str_replace(',', '', $request->tot_infracomppaid);
            $data->att_comp_paid  = $request->att_comp_paid;
            $data->dli_id = 6;
            $data->state_id = Auth::user()->state_id;
            $data->status_id = 4;
            $data->dp_id = Auth::user()->dp_id;
            $data->user_id = Auth::user()->id;
            $data->monthyear = $request->monthyear;

        $data->save();
            return redirect()->route('agric_infrastructures.index')
                ->with('success', 'Data added successfully');

    }

    public function edit($id){
        $states = State::all();
        $user = Auth::user()->id;
        $dps = Dps::all();
        $months = Monthyear::all();
        $data = Dli6::find($id);
       // $data = Dli6::find($id)->where('user_id', $user)->orWhere('dp_id', Auth::user()->dp_id)->first();
        if($data){
            return view('agric_infrastructures/edit', compact('data', 'months', 'dps', 'states'));
        }
        else{
            return redirect()->back()->with('error', 'You do not have the Permission');
        }
    }

    public function update(Request $request, $id){

        $data = Dli6::find($id);
        $data->tot_microfcasense = $request->tot_microfcasense;
        $data->tot_smallfcasense  = $request->tot_smallfcasense;
        $data->tot_fcasense  = $request->tot_fcasense;
        $data->tot_carpprep  = $request->tot_carpprep;
        $data->tot_carpapprov  = $request->tot_carpapprov;
        $data->att_prep_approv  = $request->att_prep_approv;
        $data->att_prep  = $request->att_prep;
        $data->tot_agricinfrac  = $request->tot_agricinfrac;
        $data->tot_ffarmersapp  = (int) str_replace(',', '', $request->tot_ffarmersapp);
        $data->tot_mfarmersapp  = (int) str_replace(',', '', $request->tot_mfarmersapp);
        $data->tot_farmersapp  = (int) str_replace(',', '', $request->tot_farmersapp);
        $data->tot_ffarmersrec  = (int) str_replace(',', '', $request->tot_ffarmersrec);
        $data->tot_mfarmersrec  = (int) str_replace(',', '', $request->tot_mfarmersrec);
        $data->tot_farmersrec  = (int) str_replace(',', '', $request->tot_farmersrec);
        $data->att_app_rec  = $request->att_app_rec;
        $data->pcent_att_app_rec  = $request->pcent_att_app_rec;
        $data->tot_ffarmersutil  = (int) str_replace(',', '', $request->tot_ffarmersutil);
        $data->tot_mfarmersutil  = (int) str_replace(',', '', $request->tot_mfarmersutil);
        $data->tot_farmersutil  = (int) str_replace(',', '', $request->tot_farmersutil);
        $data->att_farmersutil  = $request->att_farmersutil;
        $data->pcent_att_farmersutil  = $request->pcent_att_farmersutil;
        $data->tot_infracomp  = (int) str_replace(',', '', $request->tot_infracomp);
        $data->tot_infracomppaid  = (int) str_replace(',', '', $request->tot_infracomppaid);
        $data->att_comp_paid  = $request->att_comp_paid;
        $data->dli_id = 6;
        $data->state_id = Auth::user()->state_id;
        $data->status_id = 4;
        $data->dp_id = Auth::user()->dp_id;
        $data->user_id = Auth::user()->id;
       // $data->monthyear = $request->monthyear;

        $data->update();

        $data->update();
        return redirect()->route('agric_infrastructures.index')
            ->with('success', 'Data successfully updated');
    }

    public function export()
    {
        $state = State::where('id', Auth::user()->state_id)->first();
        $id = $state->id;
        $location = Auth::user()->states->state;
        return Excel::download(new Dli6Export($id), 'All Agricultural Infrastructures for '. $location .'.xlsx');
    }

    public function destroy($id){
        $data = Dli6::find($id);
        $data->delete();
        return redirect()->back()->with('success', 'data successfully removed');
    }
}
