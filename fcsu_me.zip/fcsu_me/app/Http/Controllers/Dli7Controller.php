<?php

namespace App\Http\Controllers;

use App\Exports\Dli6Export;
use App\Exports\Dli7Export;
use App\Models\Approval;
use App\Models\Dli7;
use App\Models\Dli7report;
use App\Models\Dps;
use App\Models\Monthyear;
use App\Models\State;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Maatwebsite\Excel\Facades\Excel;

class Dli7Controller extends Controller
{
    public function index(){
        $data = Dli7::all();
        return view('agric_assets.index', compact('data'));
    }

    public function create(){
        $states = State::all();
        $months = Monthyear::all();
        $dps = Dps::all();
        return view('agric_assets.create', compact('states', 'months','dps'));
    }

    public function show($id){
        $approvals = Approval::all();
        $states = State::all();
        $user = Auth::user()->id;
        $months = Monthyear::all();
        $dps = Dps::all();
        //$data = Dli7::find($id)->where('user_id', $user)->orWhere('dp_id', Auth::user()->dp_id)->orWhere('state_id', Auth::user()->state_id)->first();
        $data = Dli7::find($id);
        if($data){
            return view('agric_assets.show', compact('data', 'months', 'states', 'dps', 'approvals'));
        }else{
            return redirect()->back()->with('error', 'you do not have the permission');
        }
    }

    public function strans(Request $request, $id){

        $data = Dli7::find($id);
        if($request->approval_id == 1 && $data->dp_id == Auth::user()->dp_id){
            $data->status_id = 2;
            $data->update();
            return redirect()->route('dps.index')->with('success', 'DP approved');
        }else if($request->approval_id == 2){
            $data->status_id = 1;
            $data->update();
            return redirect()->route('dps.index')->with('success', 'DP not approved');
        }
        else{
            $data->status_id = 4;
            $data->update();
            return redirect()->route('dps.index')->with('success', 'DP Not Approved');
        }


    }

    public function senddata($id){
        $data = Dli7::find($id);
        if($data->status_id == 2){
            $data->status_id = 3;
            Dli7report::create([
                'tot_microfcasense' => $data->tot_microfcasense,
                'tot_smallfcasense' => $data->tot_smallfcasense,
                'tot_fcasense' => $data->tot_fcasense,
                'tot_carp_prep' => $data->tot_carp_prep,
                'tot_carp_approv' => $data->tot_carp_approv,
                'tot_ffar_app_assets' => $data->tot_ffar_app_assets,
                'tot_mfar_app_assets' => $data->tot_mfar_app_assets,
                'tot_far_app_assets' => $data->tot_far_app_assets,
                'tot_ffar_rec_assets' => $data->tot_ffar_rec_assets,
                'tot_mfar_rec_assets' => $data->tot_mfar_rec_assets,
                'tot_far_rec_assets' => $data->tot_far_rec_assets,
                'tot_ffar_util_assets' => $data->tot_ffar_util_assets,
                'tot_mfar_util_assets' => $data->tot_mfar_util_assets,
                'tot_far_util_assets' => $data->tot_far_util_assets,
                'dli_id' => $data->dli_id,
                'state_id' => $data->state_id,
                'dp_id' => $data->dp_id,
                'tab_id' => $data->id,
                'monthyear' => $data->monthyear,

            ]);

            $data->update();
            return redirect()->route('sccus.index')->with('success', 'Submission sent to FCSU');
        }else{
            return redirect()->route('sccus.index')->with('error', 'DP action is still required');
        }

    }

    public function store(Request $request){
                $data = new Dli7();
                $data->tot_microfcasense = $request->tot_microfcasense;
                $data->tot_smallfcasense = $request->tot_smallfcasense;
                $data->tot_fcasense = $request->tot_fcasense;
                $data->tot_carp_prep = $request->tot_carp_prep;
                $data->tot_carp_approv = $request->tot_carp_approv;
                $data->att_prep_approv = $request->att_prep_approv;
                $data->pcent_att_prep_approv = $request->pcent_att_prep_approv;
                $data->tot_ffar_app_assets = (int) str_replace(',', '', $request->tot_ffar_app_assets);
                $data->tot_mfar_app_assets = (int) str_replace(',', '', $request->tot_mfar_app_assets);
                $data->tot_far_app_assets = (int) str_replace(',', '', $request->tot_far_app_assets);
                $data->tot_ffar_rec_assets = (int) str_replace(',', '', $request->tot_ffar_rec_assets);
                $data->tot_mfar_rec_assets = (int) str_replace(',', '', $request->tot_mfar_rec_assets);
                $data->tot_far_rec_assets = (int) str_replace(',', '', $request->tot_far_rec_assets);
                $data->att_far_app_rec = (int) str_replace(',', '', $request->att_far_app_rec);
                $data->pcent_att_far_app_rec = (int) str_replace(',', '', $request->pcent_att_far_app_rec);
                $data->tot_ffar_util_assets = (int) str_replace(',', '', $request->tot_ffar_util_assets);
                $data->tot_mfar_util_assets = (int) str_replace(',', '', $request->tot_mfar_util_assets);
                $data->tot_far_util_assets = (int) str_replace(',', '', $request->tot_far_util_assets);
                $data->att_rec_util_assets = (int) str_replace(',', '', $request->att_rec_util_assets);
                $data->pcent_att_rec_util_assets = $request->pcent_att_rec_util_assets;

                $data->dli_id = 7;
                $data->state_id = Auth::user()->state_id;
                $data->status_id = 4;
                $data->dp_id = Auth::user()->dp_id;
                $data->user_id = Auth::user()->id;
                $data->monthyear = $request->monthyear;

                $data->save();
                return redirect()->route('agric_assets.index')
                ->with('success', 'Data added successfully');

    }

    public function edit($id){
        $states = State::all();
        $user = Auth::user()->id;
        $dps = Dps::all();
        $months = Monthyear::all();
        //$data = Dli7::find($id)->where('user_id', $user)->orWhere('dp_id', Auth::user()->dp_id)->first();
        $data = Dli7::find($id);
        if($data){
            return view('agric_assets/edit', compact('data', 'months', 'dps', 'states'));
        }
        else{
            return redirect()->back()->with('error', 'You do not have the Permission');
        }
    }

    public function update(Request $request, $id){

        $data = Dli7::find($id);
        $data->tot_microfcasense = $request->tot_microfcasense;
        $data->tot_smallfcasense = $request->tot_smallfcasense;
        $data->tot_fcasense = $request->tot_fcasense;
        $data->tot_carp_prep = $request->tot_carp_prep;
        $data->tot_carp_approv = $request->tot_carp_approv;
        $data->att_prep_approv = $request->att_prep_approv;
        $data->pcent_att_prep_approv = $request->pcent_att_prep_approv;
        $data->tot_ffar_app_assets = (int) str_replace(',', '', $request->tot_ffar_app_assets);
        $data->tot_mfar_app_assets = (int) str_replace(',', '', $request->tot_mfar_app_assets);
        $data->tot_far_app_assets = (int) str_replace(',', '', $request->tot_far_app_assets);
        $data->tot_ffar_rec_assets = (int) str_replace(',', '', $request->tot_ffar_rec_assets);
        $data->tot_mfar_rec_assets = (int) str_replace(',', '', $request->tot_mfar_rec_assets);
        $data->tot_far_rec_assets = (int) str_replace(',', '', $request->tot_far_rec_assets);
        $data->att_far_app_rec = (int) str_replace(',', '', $request->att_far_app_rec);
        $data->pcent_att_far_app_rec = (int) str_replace(',', '', $request->pcent_att_far_app_rec);
        $data->tot_ffar_util_assets = (int) str_replace(',', '', $request->tot_ffar_util_assets);
        $data->tot_mfar_util_assets = (int) str_replace(',', '', $request->tot_mfar_util_assets);
        $data->tot_far_util_assets = (int) str_replace(',', '', $request->tot_far_util_assets);
        $data->att_rec_util_assets = (int) str_replace(',', '', $request->att_rec_util_assets);
        $data->pcent_att_rec_util_assets = $request->pcent_att_rec_util_assets;

        $data->dli_id = 7;
        $data->state_id = Auth::user()->state_id;
        $data->status_id = 4;
        $data->dp_id = Auth::user()->dp_id;
        $data->user_id = Auth::user()->id;
        //$data->monthyear = $request->monthyear;

        $data->update();
        return redirect()->route('agric_assets.index')
            ->with('success', 'Data successfully updated');
    }

    public function export()
    {
        $state = State::where('id', Auth::user()->state_id)->first();
        $id = $state->id;
        $location = Auth::user()->states->state;
        return Excel::download(new Dli7Export($id), 'All Agricultural Assets for '. $location .'.xlsx');
    }

    public function destroy($id){
        $data = Dli7::find($id);
        $data->delete();
        return redirect()->back()->with('success', 'data successfully removed');
    }
}
