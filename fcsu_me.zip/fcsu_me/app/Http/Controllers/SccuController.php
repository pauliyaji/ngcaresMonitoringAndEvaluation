<?php

namespace App\Http\Controllers;

use App\Models\Dli1;
use App\Models\Dli10;
use App\Models\Dli10report;
use App\Models\Dli11;
use App\Models\Dli11report;
use App\Models\Dli1report;
use App\Models\Dli2;
use App\Models\Dli2report;
use App\Models\Dli3;
use App\Models\Dli3report;
use App\Models\Dli4;
use App\Models\Dli4report;
use App\Models\Dli6;
use App\Models\Dli6report;
use App\Models\Dli7;
use App\Models\Dli7report;
use App\Models\Dli8;
use App\Models\Dli8report;
use App\Models\Dli9;
use App\Models\Dli9report;
use App\Models\Monthyear;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class SccuController extends Controller
{
    public function index(){
        $dp = Auth::user()->dp_id;
        $state = Auth::user()->state_id;
        $sts = Dli1::where('state_id', $state)->get();
        $lipws = Dli2::where('state_id', $state)->get();
        $lihds = Dli3::where('state_id', $state)->get();
        $bss = Dli4::where('state_id', $state)->get();
        //$aginps = Dli5::where('state_id', $state)->get();
        $aginfs = Dli6::where('state_id', $state)->get();
        $agass = Dli7::where('state_id', $state)->get();
        $wms = Dli8::where('state_id', $state)->get();
        $cgs = Dli9::where('state_id', $state)->get();
        $ops = Dli10::where('state_id', $state)->get();
        $ens = Dli11::where('state_id', $state)->get();

        return view('sccus.index', compact('sts', 'lipws', 'lihds',
            'bss','aginfs', 'agass', 'wms', 'cgs', 'ops', 'ens'));
        /*return view('sccus.index', compact('sts', 'lipws', 'lihds',
            'bss','aginps', 'aginfs', 'agass', 'wms', 'cgs', 'ops', 'ens'));*/
    }

    public function report(){

        $months = Monthyear::all();
        return view('sccus.general_report', compact('months'));
    }

    public function search(Request $request){
        $state = Auth::user()->state_id;
        $sts = Dli1report::where('state_id', $state)->where('monthyear', $request->monthyear)->get();
        $sts1 = Dli1report::where('state_id', $state)->where('monthyear', $request->monthyear)->first();

        $lipws = Dli2report::where('state_id', $state)->get();
        $lihds = Dli3report::where('state_id', $state)->get();
        $bss = Dli4report::where('state_id', $state)->get();
        //$aginps = Dli5::where('state_id', $state)->get();
        $aginfs = Dli6report::where('state_id', $state)->get();
        $agass = Dli7report::where('state_id', $state)->get();
        $wms = Dli8report::where('state_id', $state)->get();
        $cgs = Dli9report::where('state_id', $state)->get();
        $ops = Dli10report::where('state_id', $state)->get();
        $ens = Dli11report::where('state_id', $state)->get();

        return view('sccus.report', compact('sts','sts1', 'lipws', 'lihds',
            'bss','aginfs', 'agass', 'wms', 'cgs', 'ops', 'ens'));

    }

}
