<?php

namespace App\Http\Controllers;

use App\Exports\Dli1ExportView;
use App\Exports\Dli1sExport;
use App\Models\Approval;
use App\Models\Dli1;
use App\Models\Dli1indicator;
use App\Models\Dli1rep;
use App\Models\Dli1report;
use App\Models\Dps;
use App\Models\Monthyear;
use App\Models\State;
use App\Models\Status;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
//use Maatwebsite\Excel\Excel;
use Maatwebsite\Excel\Facades\Excel;

class Dli1Controller extends Controller
{
    public function index(){

        $data = Dli1::all();
        return view('socialtransfers/index', compact('data'));
    }

    public function show($id){
        $states = State::all();
        $user = Auth::user()->id;
        $dps = Dps::all();
        $statuses = Status::all();
        $approvals = Approval::all();
        $months = Monthyear::all();
       // $role_id = Auth::user()->roles->pluck('id')[0];
       // dd($role_id);
        $data = Dli1::find($id);
        if($data){
            return view('socialtransfers.show', compact('data', 'months', 'states','dps', 'statuses', 'approvals'));
        }
        else{
           return redirect()->back()->with('error', 'you do not have the permission');
        }
    }

    public function strans(Request $request, $id){

                $data = Dli1::find($id);
                if($request->approval_id == 1 && $data->dp_id == Auth::user()->dp_id){
                    $data->status_id = 2;
                    $data->update();

                    return redirect()->route('dps.index')->with('success', 'DP approved');
                }else if($request->approval_id == 2){
                    $data->status_id = 1;
                    $data->update();
                    return redirect()->route('dps.index')->with('success', 'DP not approved');
                }
                else{
                    $data->status_id = 4;
                    $data->update();
                    return redirect()->route('dps.index')->with('success', 'DP Not Approved');
                }


    }

    public function senddata(Request $request, $id){
        $data = Dli1::find($id);
        if($data->status_id == 2){
            $data->status_id = 3;

            $old_rec = Dli1report::where('tab_id', $data->id)->first();
            if($old_rec){
                return redirect()->route('dps.index')->with('error', 'Record already submitted Please contact FCSU Admin');
            }else{
               // $dli1_id = Dli1indicator::all();
                Dli1report::create([
                    'f_mined' => $data->f_mined,
                    'm_mined' => $data->m_mined,
                    'tot_mined' => $data->tot_mined,
                    'aged_mined' => $data->aged_mined,
                    'chro_mined' => $data->chro_mined,
                    'urban_mined' => $data->urban_mined,
                    'needs_mined' => $data->needs_mined,
                    'f_validated' => $data->f_validated,
                    'm_validated' => $data->m_validated,
                    'tot_validated' => $data->tot_validated,
                    'fenrolled' => $data->fenrolled,
                    'menrolled' => $data->menrolled,
                    'tot_enrolled' => $data->tot_enrolled,
                    'aged_fenrolled' => $data->aged_fenrolled,
                    'aged_menrolled' => $data->aged_menrolled,
                    'chro_fenrolled' => $data->chro_fenrolled,
                    'chro_menrolled' => $data->chro_menrolled,
                    'urban_fenrolled' => $data->urban_fenrolled,
                    'urban_menrolled' => $data->urban_menrolled,
                    'needs_fenrolled' => $data->needs_fenrolled,
                    'needs_menrolled' => $data->needs_menrolled,
                    'amt_transpsp' => $data->amt_transpsp,
                    'tot_fbeneforpsppay' => $data->tot_fbeneforpsppay,
                    'tot_mbeneforpsppay' => $data->tot_mbeneforpsppay,
                    'tot_beneforpsppay' => $data->tot_beneforpsppay,
                 //   'amt_transpsp' => $data->,
                    'tot_agedfbeneforpsppay' => $data->tot_agedfbeneforpsppay,
                    'tot_agedmbeneforpsppay' => $data->tot_agedmbeneforpsppay,
                    'tot_chrofbeneforpsppay' => $data->tot_chrofbeneforpsppay,
                    'tot_chrombeneforpsppay' => $data->tot_chrombeneforpsppay,
                    'tot_urbanfbeneforpsppay' => $data->tot_urbanfbeneforpsppay,
                    'tot_urbanmbeneforpsppay' => $data->tot_urbanmbeneforpsppay,
                    'tot_needsfbeneforpsppay' => $data->tot_needsfbeneforpsppay,
                    'tot_needsmbeneforpsppay' => $data->tot_needsmbeneforpsppay,
                    'tot_numbenepaid' => $data->tot_numbenepaid,
                    'dli_id' => $data->dli_id,
                    'state_id' => $data->state_id,
                    'user_id' => $data->user_id,
                    'tab_id' => $data->id,

                    'dp_id' => $data->dp_id,
                    'monthyear' => $data->monthyear,
                ]);

            }
            $data->update();
            return redirect()->route('sccus.index')->with('success', 'Submission sent to FCSU');
        }else{
            return redirect()->route('sccus.index')->with('error', 'DP action is still required');
        }

    }

    public function create(){
        $states = State::all();
        $months = Monthyear::all();
        $dps = Dps::all();
        return view('socialtransfers/create', compact('states', 'months','dps'));
    }

    public function store(Request $request){
            $period = $request->monthyear;

            $state = Auth::user()->state_id;
            $record = Dli1::where('monthyear', $period)->where('state_id', $state)->get();

            if($record->count() > 0){
                return redirect()->route('socialtransfers.index')->with('error', 'Record with same month and year already exist');
            }
            $data = new Dli1();
            $data->f_mined = $request->f_mined;
            $data->m_mined = $request->m_mined;
            $data->tot_mined = $request->tot_mined;

            $data->aged_mined = $request->aged_mined;
            $data->chro_mined = $request->chro_mined;
            $data->urban_mined = $request->urban_mined;
            $data->needs_mined = $request->needs_mined;

            $data->f_validated = $request->f_validated;
            $data->m_validated = $request->m_validated;
            $data->tot_validated = $request->tot_validated;

            $data->att_fmined = $request->att_fmined;
            $data->att_mmined = $request->att_mmined;
            $data->att_totmined = $request->att_totmined;
            $data->att_minedpercent = $request->att_minedpercent;
            $data->fenrolled = $request->fenrolled;
            $data->menrolled = $request->menrolled;
            $data->tot_enrolled = $request->tot_enrolled;
            $data->att_perenrolled = $request->att_perenrolled;
            $data->aged_fenrolled = $request->aged_fenrolled;
            $data->aged_menrolled = $request->aged_menrolled;
            $data->chro_fenrolled = $request->chro_fenrolled;
            $data->chro_menrolled = $request->chro_menrolled;
            $data->urban_fenrolled = $request->urban_fenrolled;
            $data->urban_menrolled = $request->urban_menrolled;
            $data->needs_fenrolled = $request->needs_fenrolled;
            $data->needs_menrolled = $request->needs_menrolled;
            $data->att_fval_enr = $request->att_fval_enr;
            $data->att_mval_enr = $request->att_mval_enr;
            $data->att_totval_enr = $request->att_totval_enr;
            $data->amt_transpsp = $request->amt_transpsp;
            $data->tot_fbeneforpsppay = $request->tot_fbeneforpsppay;
            $data->tot_mbeneforpsppay = $request->tot_mbeneforpsppay;
            $data->tot_beneforpsppay = $request->tot_beneforpsppay;
            $data->tot_agedfbeneforpsppay = $request->tot_agedfbeneforpsppay;
            $data->tot_agedmbeneforpsppay = $request->tot_agedmbeneforpsppay;
            $data->tot_chrofbeneforpsppay = $request->tot_chrofbeneforpsppay;
            $data->tot_chrombeneforpsppay = $request->tot_chrombeneforpsppay;
            $data->tot_urbanfbeneforpsppay = $request->tot_urbanfbeneforpsppay;
            $data->tot_urbanmbeneforpsppay = $request->tot_urbanmbeneforpsppay;
            $data->tot_needsfbeneforpsppay = $request->tot_needsfbeneforpsppay;
            $data->tot_needsmbeneforpsppay = $request->tot_needsmbeneforpsppay;
            $data->tot_numbenepaid = $request->tot_numbenepaid;
            $data->attrition_ntpaid = $request->attrition_ntpaid;
            $data->attrition_ntpaid_percent = $request->attrition_ntpaid_percent;

            $data->comment1 = $request->comment1;
            $data->comment2 = $request->comment2;
            $data->comment3 = $request->comment3;
            $data->comment4 = $request->comment4;

            $data->dli_id = 1;
            $data->state_id = Auth::user()->state_id;
            $data->status_id = 4;
            $data->user_id = Auth::user()->id;
            $data->dp_id = Auth::user()->dp_id;
            $data->monthyear = $request->monthyear;



       /* $prev_month = Dli1::latest()->first();
        if($prev_month->monthyear > $request->monthyear){
            return redirect()->route('socialtransfers.index')
                ->with('error', 'Please Check your record month and year and contact FCSU Admin');
        }else{
            $data->previous = $prev_month->total;
            $data->current = $request->
        }*/


        $data->save();
            return redirect()->route('socialtransfers.index')
                ->with('success', 'Data added successfully');


    }

    public function edit($id){
        $states = State::all();
      //  $user = Auth::user()->id;
        $dps = Dps::all();
        $months = Monthyear::all();

        $data = Dli1::find($id);
        if($data){
            return view('socialtransfers/edit', compact('data', 'states', 'dps', 'months'));
        }
        else{
            return redirect()->back()->with('error', 'You do not have the Permission');
        }
    }

    public function update(Request $request, $id){
       // $user = Auth::user()->id;

        $data = Dli1::find($id);

            $data->f_mined = $request->f_mined;
            $data->m_mined = $request->m_mined;
            $data->tot_mined = $request->tot_mined;
            $data->aged_mined = $request->aged_mined;
            $data->chro_mined = $request->chro_mined;
            $data->urban_mined = $request->urban_mined;
            $data->needs_mined = $request->needs_mined;
            $data->f_validated = $request->f_validated;
            $data->m_validated = $request->m_validated;
            $data->tot_validated = $request->tot_validated;
            $data->att_fmined = $request->att_mmined;
            $data->att_mmined = $request->att_mmined;
            $data->att_totmined = $request->att_totmined;
            $data->att_minedpercent = $request->att_minedpercent;
            $data->fenrolled = $request->fenrolled;
            $data->menrolled = $request->menrolled;
            $data->tot_enrolled = $request->tot_enrolled;
            $data->att_perenrolled = $request->att_perenrolled;
            $data->aged_fenrolled = $request->aged_fenrolled;
            $data->aged_menrolled = $request->aged_menrolled;
            $data->chro_fenrolled = $request->chro_fenrolled;
            $data->chro_menrolled = $request->chro_menrolled;
            $data->urban_fenrolled = $request->urban_fenrolled;
            $data->urban_menrolled = $request->urban_menrolled;
            $data->needs_fenrolled = $request->needs_fenrolled;
            $data->needs_menrolled = $request->needs_menrolled;
            $data->att_fval_enr = $request->att_fval_enr;
            $data->att_mval_enr = $request->att_mval_enr;
            $data->att_totval_enr = $request->att_totval_enr;
            $data->amt_transpsp = $request->amt_transpsp;
            $data->tot_fbeneforpsppay = $request->tot_fbeneforpsppay;
            $data->tot_mbeneforpsppay = $request->tot_mbeneforpsppay;
            $data->tot_beneforpsppay = $request->tot_beneforpsppay;
            $data->tot_agedfbeneforpsppay = $request->tot_agedfbeneforpsppay;
            $data->tot_agedmbeneforpsppay = $request->tot_agedmbeneforpsppay;
            $data->tot_chrofbeneforpsppay = $request->tot_chrofbeneforpsppay;
            $data->tot_chrombeneforpsppay = $request->tot_chrombeneforpsppay;
            $data->tot_urbanfbeneforpsppay = $request->tot_urbanfbeneforpsppay;
            $data->tot_urbanmbeneforpsppay = $request->tot_urbanmbeneforpsppay;
            $data->tot_needsfbeneforpsppay = $request->tot_needsfbeneforpsppay;
            $data->tot_needsmbeneforpsppay = $request->tot_needsmbeneforpsppay;
            $data->tot_numbenepaid = $request->tot_numbenepaid;
            $data->attrition_ntpaid = $request->attrition_ntpaid;
            $data->attrition_ntpaid_percent = $request->attrition_ntpaid_percent;

            $data->comment1 = $request->comment1;
            $data->comment2 = $request->comment2;
            $data->comment3 = $request->comment3;
            $data->comment4 = $request->comment4;
            $data->dli_id = 1;
            $data->state_id = Auth::user()->state_id;
            $data->status_id = 4;
            $data->user_id = Auth::user()->id;
            $data->monthyear = $request->monthyear;
            $data->update();
            return redirect()->route('socialtransfers.index')
                ->with('success', 'Data successfully updated');

    }

    public function destroy($id){
        $data = Dli1::find($id);
        $data->delete();
        return redirect()->back()->with('success', 'data successfully removed');
    }


    /*public function export()
    {
        //return Excel::create();
        dd('na here');
        return Excel::download(new Dli1ExportView, 'socialtransfers.xlsx');
    }*/
    public function export()
    {
        $state = State::where('id', Auth::user()->state_id)->first();
        $id = $state->id;
        $location = Auth::user()->states->state;
        return Excel::download(new Dli1sExport($id), 'All social transfers for '. $location .'.xlsx');
    }

    public function exportview()
    {
        return Excel::download(new Dli1ExportView(), 'data.xlsx');
    }
}
