<?php

namespace App\Http\Controllers;

use App\Exports\Dli10Export;
use App\Exports\Dli6Export;
use App\Models\Approval;
use App\Models\Dli10;
use App\Models\Dli10report;
use App\Models\Dps;
use App\Models\Monthyear;
use App\Models\State;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Maatwebsite\Excel\Facades\Excel;

class Dli10Controller extends Controller
{
    public function index(){
        $data = Dli10::all();
        return view('operations_grant.index', compact('data'));
    }

    public function create(){
        $states = State::all();
        $dps = Dps::all();
        $months = Monthyear::all();
        return view('operations_grant.create', compact('states', 'months', 'dps'));
    }

    public function show($id){
        $approvals = Approval::all();
        $states = State::all();
        $user = Auth::user()->id;
        $months = Monthyear::all();
        $dps = Dps::all();
        //$data = Dli10::find($id)->where('user_id', $user)->orWhere('dp_id', Auth::user()->dp_id)->orWhere('state_id', Auth::user()->state_id)->first();
        $data = Dli10::find($id);
        if($data){
            return view('operations_grant.show', compact('data', 'months', 'states', 'dps', 'approvals'));
        }else{
            return redirect()->back()->with('error', 'you do not have the permission');
        }
    }

    public function strans(Request $request, $id){
        $data = Dli10::find($id);
        if($request->approval_id == 1 && $data->dp_id == Auth::user()->dp_id){
            $data->status_id = 2;
            $data->update();
            return redirect()->route('dps.index')->with('success', 'DP approved');
        }else{
            $data->status_id = 4;
            $data->update();
            return redirect()->route('dps.index')->with('success', 'DP Not Approved');
        }

    }

    public function senddata($id){
        $data = Dli10::find($id);
        if($data->status_id == 2){
            $data->status_id = 3;

            $old_rec = Dli10report::where('tab_id', $data->id)->first();
            if($old_rec){
                return redirect()->route('dps.index')->with('error', 'Record already submitted Please contact FCSU Admin');
            }else{
                Dli10report::create([
                    'tot_reg_ops' => $data->tot_reg_ops,
                    'tot_reg_opsmmicro' => $data->tot_reg_opsmmicro,
                    'tot_reg_opsfmicro' => $data->tot_reg_opsfmicro,
                    'tot_reg_opsmicro' => $data->tot_reg_opsmicro,
                    'tot_reg_opsmsmall' => $data->tot_reg_opsmsmall,
                    'tot_reg_opsfsmall' => $data->tot_reg_opsfsmall,
                    'tot_reg_opssmall' => $data->tot_reg_opssmall,
                    'tot_eli_ver' => $data->tot_eli_ver,
                    'tot_eli_vermmicro' => $data->tot_eli_vermmicro,
                    'tot_eli_verfmicro' => $data->tot_eli_verfmicro,
                    'tot_eli_vermicro' => $data->tot_eli_vermicro,
                    'tot_eli_vermsmall' => $data->tot_eli_vermsmall,
                    'tot_eli_verfsmall' => $data->tot_eli_verfsmall,
                    'tot_eli_versmall' => $data->tot_eli_versmall,
                    'att_reg_minus_ver' => $data->att_reg_minus_ver,
                    'tot_sel_ops' => $data->tot_sel_ops,
                    'tot_sel_opsmmicro' => $data->tot_sel_opsmmicro,
                    'tot_sel_opsfmicro' => $data->tot_sel_opsfmicro,
                    'tot_sel_opsmicro' => $data->tot_sel_opsmicro,
                    'tot_sel_opsmsmall' => $data->tot_sel_opsmsmall,
                    'tot_sel_opsfsmall' => $data->tot_sel_opsfsmall,
                    'tot_sel_opssmall' => $data->tot_sel_opssmall,
                    'tot_ver_minus_sel' => $data->tot_ver_minus_sel,
                    'tot_rec_ops' => $data->tot_rec_ops,
                    'tot_rec_opsmmicro' => $data->tot_rec_opsmmicro,
                    'tot_rec_opsfmicro' => $data->tot_rec_opsfmicro,
                    'tot_rec_opsmicro' => $data->tot_rec_opsmicro,
                    'tot_rec_opsmsmall' => $data->tot_rec_opsmsmall,
                    'tot_rec_opsfsmall' => $data->tot_rec_opsfsmall,
                    'tot_rec_opssmall' => $data->tot_rec_opssmall,
                    'tot_sol_rec' => $data->tot_sol_rec,
                    'tot_sol_recmmicro' => $data->tot_sol_recmmicro,
                    'tot_sol_recfmicro' => $data->tot_sol_recfmicro,
                    'tot_sol_recmicro' => $data->tot_sol_recmicro,
                    'tot_sol_recmsmall' => $data->tot_sol_recmsmall,
                    'tot_sol_recfsmall' => $data->tot_sol_recfsmall,
                    'tot_sol_recsmall' => $data->tot_sol_recsmall,
                    'tot_amt_dis' => $data->tot_amt_dis,
                    'tot_amt_dismmicro' => $data->tot_amt_dismmicro,
                    'tot_amt_disfmicro' => $data->tot_amt_disfmicro,
                    'tot_amt_dismicro' => $data->tot_amt_dismicro,
                    'tot_amt_dismsmall' => $data->tot_amt_dismsmall,
                    'tot_amt_disfsmall' => $data->tot_amt_disfsmall,
                    'tot_amt_dissmall' => $data->tot_amt_dissmall,
                    'dli_id' => $data->dli_id,
                    'state_id' => $data->state_id,
                    'dp_id' => $data->dp_id,
                    'monthyear' => $data->monthyear,
                    'tab_id' => $data->id,
                ]);
            }

            $data->update();
            return redirect()->route('sccus.index')->with('success', 'Submission sent to FCSU');
        }else{
            return redirect()->route('sccus.index')->with('error', 'DP action is still required');
        }


    }

    public function store(Request $request){
        //dd($request->all());
       // $state = Auth::user()->state_id;
            $data = new Dli10();
            $data->tot_reg_ops = $request->tot_reg_ops;
            $data->tot_reg_opsmmicro = $request->tot_reg_opsmmicro;
            $data->tot_reg_opsfmicro = $request->tot_reg_opsfmicro;
            $data->tot_reg_opsmicro = $request->tot_reg_opsmicro;
            $data->tot_reg_opsmsmall = $request->tot_reg_opsmsmall;
            $data->tot_reg_opsfsmall = $request->tot_reg_opsfsmall;
            $data->tot_reg_opssmall = $request->tot_reg_opssmall;
            $data->tot_eli_ver = $request->tot_eli_ver;
            $data->tot_eli_vermmicro = $request->tot_eli_vermmicro;
            $data->tot_eli_verfmicro = $request->tot_eli_verfmicro;
            $data->tot_eli_vermicro = $request->tot_eli_vermicro;
            $data->tot_eli_vermsmall = $request->tot_eli_vermsmall;
            $data->tot_eli_verfsmall = $request->tot_eli_verfsmall;
            $data->tot_eli_versmall = $request->tot_eli_versmall;
            $data->att_reg_minus_ver = $request->att_reg_minus_ver;
            $data->tot_sel_ops = $request->tot_sel_ops;
            $data->tot_sel_opsmmicro = $request->tot_sel_opsmmicro;
            $data->tot_sel_opsfmicro = $request->tot_sel_opsfmicro;
            $data->tot_sel_opsmicro = $request->tot_sel_opsmicro;
            $data->tot_sel_opsmsmall = $request->tot_sel_opsmsmall;
            $data->tot_sel_opsfsmall = $request->tot_sel_opsfsmall;
            $data->tot_sel_opssmall = $request->tot_sel_opssmall;
            $data->tot_ver_minus_sel = $request->tot_ver_minus_sel;
            $data->tot_rec_ops = $request->tot_rec_ops;
            $data->tot_rec_opsmmicro = $request->tot_rec_opsmmicro;
            $data->tot_rec_opsfmicro = $request->tot_rec_opsfmicro;
            $data->tot_rec_opsmicro = $request->tot_rec_opsmicro;
            $data->tot_rec_opsmsmall = $request->tot_rec_opsmsmall;
            $data->tot_rec_opsfsmall = $request->tot_rec_opsfsmall;
            $data->tot_rec_opssmall = $request->tot_rec_opssmall;
            $data->att_sel_minus_rec = $request->att_sel_minus_rec;
            $data->att_sel_minus_solrec = $request->att_sel_minus_solrec;
            $data->tot_sol_rec = $request->tot_sol_rec;
            $data->tot_sol_recmmicro = $request->tot_sol_recmmicro;
            $data->tot_sol_recfmicro = $request->tot_sol_recfmicro;
            $data->tot_sol_recmicro = $request->tot_sol_recmicro;
            $data->tot_sol_recmsmall = $request->tot_sol_recmsmall;
            $data->tot_sol_recfsmall = $request->tot_sol_recfsmall;
            $data->tot_sol_recsmall = $request->tot_sol_recsmall;
            $data->att_sel_minus_solrec = $request->att_sel_minus_solrec;
            $data->att_rec_minus_solrec = $request->att_rec_minus_solrec;
            $data->tot_amt_dis = $request->tot_amt_dis;
            $data->tot_amt_dismmicro = $request->tot_amt_dismmicro;
            $data->tot_amt_disfmicro = $request->tot_amt_disfmicro;
            $data->tot_amt_dismicro = $request->tot_amt_dismicro;
            $data->tot_amt_dismsmall = $request->tot_amt_dismsmall;
            $data->tot_amt_disfsmall = $request->tot_amt_disfsmall;
            $data->tot_amt_dissmall = $request->tot_amt_dissmall;
            $data->att_ver_minus_sel = $request->att_ver_minus_sel;

            $data->dli_id = 10;
            $data->state_id = Auth::user()->state_id;
            $data->status_id = 4;
            $data->dp_id = Auth::user()->dp_id;
            $data->user_id = Auth::user()->id;
            $data->monthyear = $request->monthyear;

            $data->save();
            return redirect()->route('operations_grant.index')
                ->with('success', 'Data added successfully');

    }

    public function edit($id){
        $states = State::all();
        $user = Auth::user()->id;
        $months = Monthyear::all();
        $dps = Dps::all();
       // $data = Dli10::find($id)->where('user_id', $user)->orWhere('dp_id', Auth::user()->dp_id)->first();
        $data = Dli10::find($id);
        if($data){
            return view('operations_grant/edit', compact('months', 'data', 'dps', 'states'));
        }
        else{
            return redirect()->back()->with('error', 'You do not have the Permission');
        }
    }

    public function update(Request $request, $id){

        $data = Dli10::find($id);
        $data->tot_reg_ops = $request->tot_reg_ops;
        $data->tot_reg_opsmmicro = $request->tot_reg_opsmmicro;
        $data->tot_reg_opsfmicro = $request->tot_reg_opsfmicro;
        $data->tot_reg_opsmicro = $request->tot_reg_opsmicro;
        $data->tot_reg_opsmsmall = $request->tot_reg_opsmsmall;
        $data->tot_reg_opsfsmall = $request->tot_reg_opsfsmall;
        $data->tot_reg_opssmall = $request->tot_reg_opssmall;
        $data->tot_eli_ver = $request->tot_eli_ver;
        $data->tot_eli_vermmicro = $request->tot_eli_vermmicro;
        $data->tot_eli_verfmicro = $request->tot_eli_verfmicro;
        $data->tot_eli_vermicro = $request->tot_eli_vermicro;
        $data->tot_eli_vermsmall = $request->tot_eli_vermsmall;
        $data->tot_eli_verfsmall = $request->tot_eli_verfsmall;
        $data->tot_eli_versmall = $request->tot_eli_versmall;
        $data->att_reg_minus_ver = $request->att_reg_minus_ver;
        $data->tot_sel_ops = $request->tot_sel_ops;
        $data->tot_sel_opsmmicro = $request->tot_sel_opsmmicro;
        $data->tot_sel_opsfmicro = $request->tot_sel_opsfmicro;
        $data->tot_sel_opsmicro = $request->tot_sel_opsmicro;
        $data->tot_sel_opsmsmall = $request->tot_sel_opsmsmall;
        $data->tot_sel_opsfsmall = $request->tot_sel_opsfsmall;
        $data->tot_sel_opssmall = $request->tot_sel_opssmall;
        $data->tot_ver_minus_sel = $request->tot_ver_minus_sel;
        $data->att_rec_minus_solrec = $request->att_rec_minus_solrec;
        $data->tot_rec_ops = $request->tot_rec_ops;
        $data->tot_rec_opsmmicro = $request->tot_rec_opsmmicro;
        $data->tot_rec_opsfmicro = $request->tot_rec_opsfmicro;
        $data->tot_rec_opsmicro = $request->tot_rec_opsmicro;
        $data->tot_rec_opsmsmall = $request->tot_rec_opsmsmall;
        $data->tot_rec_opsfsmall = $request->tot_rec_opsfsmall;
        $data->tot_rec_opssmall = $request->tot_rec_opssmall;
        $data->att_sel_minus_rec = $request->att_sel_minus_rec;
        $data->att_sel_minus_solrec = $request->att_sel_minus_solrec;
        $data->tot_sol_rec = $request->tot_sol_rec;
        $data->tot_sol_recmmicro = $request->tot_sol_recmmicro;
        $data->tot_sol_recfmicro = $request->tot_sol_recfmicro;
        $data->tot_sol_recmicro = $request->tot_sol_recmicro;
        $data->tot_sol_recmsmall = $request->tot_sol_recmsmall;
        $data->tot_sol_recfsmall = $request->tot_sol_recfsmall;
        $data->tot_sol_recsmall = $request->tot_sol_recsmall;
        $data->att_sel_minus_solrec = $request->att_sel_minus_solrec;
        $data->tot_amt_dis = $request->tot_amt_dis;
        $data->tot_amt_dismmicro = $request->tot_amt_dismmicro;
        $data->tot_amt_disfmicro = $request->tot_amt_disfmicro;
        $data->tot_amt_dismicro = $request->tot_amt_dismicro;
        $data->tot_amt_dismsmall = $request->tot_amt_dismsmall;
        $data->tot_amt_disfsmall = $request->tot_amt_disfsmall;
        $data->tot_amt_dissmall = $request->tot_amt_dissmall;
        $data->att_ver_minus_sel = $request->att_ver_minus_sel;

        $data->dli_id = 10;
        $data->state_id = Auth::user()->state_id;
        $data->status_id = 4;
        $data->dp_id = Auth::user()->dp_id;
        $data->user_id = Auth::user()->id;
      //  $data->monthyear = $request->monthyear;

        $data->update();

        return redirect()->route('operations_grant.index')
            ->with('success', 'Data successfully updated');
    }

    public function export()
    {
        $state = State::where('id', Auth::user()->state_id)->first();
        $id = $state->id;
        $location = Auth::user()->states->state;
        return Excel::download(new Dli10Export($id), 'All Operations Grant for '. $location .'.xlsx');
    }
    public function destroy($id){
        $data = Dli10::find($id);
        $data->delete();
        return redirect()->back()->with('success', 'data successfully removed');
    }
}
