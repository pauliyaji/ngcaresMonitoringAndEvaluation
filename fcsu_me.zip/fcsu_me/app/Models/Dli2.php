<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Dli2 extends Model
{
    use HasFactory;

    protected $fillable = [
        'f_mined',
        'm_mined',
        'tot_mined',
        'f_validated',
        'm_validated',
        'tot_validated',
        'att_fminedval',
        'att_mminedval',
        'att_totminedval',
        'att_totminedval',
        'att_minedvalpercent',
        'p_att',
        'f_enrolled',
        'm_enrolled',
        'tot_enrolled',
        'f_deploy',
        'm_deploy',
        'tot_deploy',
        'att_fenr_deploy',
        'att_menr_deploy',
        'att_totenr_deploy',
        'att_enr_deployed',
        'comment',
        'num_workdays',
        'amt_transpsp',
        'tot_fbeneforpsppay',
        'tot_mbeneforpsppay',
        'tot_beneforpsppay',
        'tot_fbenepaid',
        'tot_mbenepaid',
        'tot_benepaid',
        'att_fbenepaid',
        'att_mbenepaid',
        'att_benepaid',
        'att_pcent_benepaid',
        'commenta',
        'amountbpaid',
        'attbpaid',
        'attbpaidp',
        'comment4',
        'dli_id',
        'state_id',
        'user_id',
        'dp_id',
        'status_id',
        'monthyear',
        ];

    public function states(){
        return $this->belongsTo(State::class, 'state_id');
    }

    public function dps(){
        return $this->belongsTo(Dps::class, 'dp_id');
    }

    public function dli(){
        return $this->belongsTo(Dlis::class, 'dli_id');
    }

    public function status(){
        return $this->belongsTo(Status::class, 'status_id');
    }

    public function months(){
        return $this->belongsTo(Monthyear::class, 'monthyear');
    }

}
