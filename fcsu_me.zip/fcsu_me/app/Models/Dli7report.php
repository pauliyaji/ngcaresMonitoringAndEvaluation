<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Dli7report extends Model
{
    use HasFactory;

    protected $table ='dli7_report';

    protected $fillable = [
        'tot_microfcasense',
        'tot_smallfcasense',
        'tot_fcasense',
        'tot_carp_prep',
        'tot_carp_approv',
        'tot_ffar_app_assets',
        'tot_mfar_app_assets',
        'tot_far_app_assets',
        'tot_ffar_rec_assets',
        'tot_mfar_rec_assets',
        'tot_far_rec_assets',
        'tot_ffar_util_assets',
        'tot_mfar_util_assets',
        'tot_far_util_assets',
        'dli_id',
        'state_id',
        'dp_id',
        'tab_id',
        'monthyear',

    ];

    public function states(){
        return $this->belongsTo(State::class, 'state_id');
    }

    public function dps(){
        return $this->belongsTo(Dps::class, 'dp_id');
    }

    public function dli(){
        return $this->belongsTo(Dlis::class, 'dli_id');
    }

    public function status(){
        return $this->belongsTo(Status::class, 'status_id');
    }
    public function months(){
        return $this->belongsTo(Monthyear::class, 'monthyear');
    }
}
