<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Dli7 extends Model
{
    use HasFactory;

    protected $fillable = [
        'tot_microfcasense',
        'tot_smallfcasense',
        'tot_fcasense',
        'tot_carp_prep',
        'tot_carp_approv',
        'att_prep_approv',
        'pcent_att_prep_approv',
        'tot_ffar_app_assets',
        'tot_mfar_app_assets',
        'tot_far_app_assets',
        'tot_ffar_rec_assets',
        'tot_mfar_rec_assets',
        'tot_far_rec_assets',
        'att_far_app_rec',
        'pcent_att_far_app_rec',
        'tot_ffar_util_assets',
        'tot_mfar_util_assets',
        'tot_far_util_assets',
        'att_rec_util_assets',
        'pcent_att_rec_util_assets',

        'dli_id',
        'state_id',
        'user_id',
        'dp_id',
        'status_id',
        'monthyear',

    ];

    public function states(){
        return $this->belongsTo(State::class, 'state_id');
    }

    public function dps(){
        return $this->belongsTo(Dps::class, 'dp_id');
    }

    public function dli(){
        return $this->belongsTo(Dlis::class, 'dli_id');
    }

    public function status(){
        return $this->belongsTo(Status::class, 'status_id');
    }
    public function months(){
        return $this->belongsTo(Monthyear::class, 'monthyear');
    }
}
