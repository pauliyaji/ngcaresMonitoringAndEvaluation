<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Dli10report extends Model
{
    use HasFactory;

    protected $table = 'dli10_report';
    protected $fillable = [

        'tot_reg_ops',
        'tot_reg_opsmmicro',
        'tot_reg_opsfmicro',
        'tot_reg_opsmicro',
        'tot_reg_opsmsmall',
        'tot_reg_opsfsmall',
        'tot_reg_opssmall',
        'tot_eli_ver',
        'tot_eli_vermmicro',
        'tot_eli_verfmicro',
        'tot_eli_vermicro',
        'tot_eli_vermsmall',
        'tot_eli_verfsmall',
        'tot_eli_versmall',
        'tot_sel_ops',
        'tot_sel_opsmmicro',
        'tot_sel_opsfmicro',
        'tot_sel_opsmicro',
        'tot_sel_opsmsmall',
        'tot_sel_opsfsmall',
        'tot_sel_opssmall',
        'tot_ver_minus_sel',
        'tot_rec_ops',
        'tot_rec_opsmmicro',
        'tot_rec_opsfmicro',
        'tot_rec_opsmicro',
        'tot_rec_opsmsmall',
        'tot_rec_opsfsmall',
        'tot_rec_opssmall',
        'tot_sol_rec',
        'tot_sol_recmmicro',
        'tot_sol_recfmicro',
        'tot_sol_recmicro',
        'tot_sol_recmsmall',
        'tot_sol_recfsmall',
        'tot_sol_recsmall',
        'tot_amt_dis',
        'tot_amt_dismmicro',
        'tot_amt_disfmicro',
        'tot_amt_dismicro',
        'tot_amt_dismsmall',
        'tot_amt_disfsmall',
        'tot_amt_dissmall',
        'dli_id',
        'state_id',
        'dp_id',
        'monthyear',
        'tab_id'

    ];

    public function states(){
        return $this->belongsTo(State::class, 'state_id');
    }

    public function dps(){
        return $this->belongsTo(Dps::class, 'dp_id');
    }

    public function dli(){
        return $this->belongsTo(Dlis::class, 'dli_id');
    }

    public function status(){
        return $this->belongsTo(Status::class, 'status_id');
    }
    public function months(){
        return $this->belongsTo(Monthyear::class, 'monthyear');
    }
}
