<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Dli3 extends Model
{
    use HasFactory;

    protected $fillable = [
        'f_mined',
        'm_mined',
        'tot_mined',
        'f_validated',
        'm_validated',
        'tot_validated',
        'att_fminedval',
        'att_mminedval',
        'att_totminedval',
        'att_minedvalpercent',
        'comment1',
        'f_train',
        'm_train',
        'tot_train',
        'f_grad',
        'm_grad',
        'tot_grad',
        'att_ftraingrad',
        'att_mtraingrad',
        'att_tottraingrad',
        'att_traingrapercent',
        'comment2',
        'amt_transpsp',
        'tot_fbeneforpsppay',
        'tot_mbeneforpsppay',
        'tot_beneforpsppay',
        'tot_fbenerecv',
        'tot_mbenerecv',
        'tot_benerecv',
        'tot_paidbene',
        'attr',
        'attr_pcent',
        'comment3',
        'dli_id',
        'state_id',
        'user_id',
        'dp_id',
        'status_id',
        'monthyear',

    ];

    public function states(){
        return $this->belongsTo(State::class, 'state_id');
    }

    public function dps(){
        return $this->belongsTo(Dps::class, 'dp_id');
    }

    public function dli(){
        return $this->belongsTo(Dlis::class, 'dli_id');
    }

    public function status(){
        return $this->belongsTo(Status::class, 'status_id');
    }

    public function months(){
        return $this->belongsTo(Monthyear::class, 'monthyear');
    }

}
