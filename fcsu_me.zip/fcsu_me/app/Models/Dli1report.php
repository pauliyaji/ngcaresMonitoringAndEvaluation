<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Dli1report extends Model
{
    use HasFactory;
    protected $table = 'dli1_reports';

    protected $fillable = [
        'f_mined',
        'm_mined',
        'tot_mined',
        'aged_mined',
        'chro_mined',
        'urban_mined',
        'needs_mined',
        'f_validated',
        'm_validated',
        'tot_validated',
        'fenrolled',
        'menrolled',
        'tot_enrolled',
        'aged_fenrolled',
        'aged_menrolled',
        'chro_fenrolled',
        'chro_menrolled',
        'urban_fenrolled',
        'urban_menrolled',
        'needs_fenrolled',
        'needs_menrolled',
        'amt_transpsp',
        'tot_fbeneforpsppay',
        'tot_mbeneforpsppay',
        'tot_beneforpsppay',
       // 'amt_transpsp',
        'tot_agedfbeneforpsppay',
        'tot_agedmbeneforpsppay',
        'tot_chrofbeneforpsppay',
        'tot_chrombeneforpsppay',
        'tot_urbanfbeneforpsppay',
        'tot_urbanmbeneforpsppay',
        'tot_needsfbeneforpsppay',
        'tot_needsmbeneforpsppay',
        'tot_numbenepaid',
        'dli_id',
        'state_id',
        'user_id',
        'tab_id',

        'dp_id',
        'monthyear',

    ];

    public function status(){
        return $this->belongsTo(Status::class, 'status_id');
    }

    public function states(){
        return $this->belongsTo(State::class, 'state_id');
    }

    public function dli(){
        return $this->belongsTo(Dlis::class, 'dli_id');
    }
    public function dps(){
        return $this->belongsTo(Dps::class, 'dp_id');
    }

    public function months(){
        return $this->belongsTo(Monthyear::class, 'monthyear');
    }

}
