<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Dli5 extends Model
{
    use HasFactory;

    protected $fillable = [

        'tot_microfcasense', 'tot_fcasmall', 'tot_fca',
        'tot_carpprep', 'tot_carpappr', 'tot_ff_appl_input',
        'tot_mf_appl_input', 'tot_farmers_appl_input', 'tot_ff_recv_input',
        'tot_mf_recv_input', 'tot_farmers_recv_input', 'tot_ffutil_agric_input',
        'tot_mfutil_agric_input', 'tot_futil_agric_input', 'tot_ff_appl_agserv',
        'tot_mf_appl_agserv', 'tot_fappl_agserv', 'tot_ff_recv_agserv',
        'tot_mf_recv_agserv', 'tot_frecv_agserv', 'tot_ffutil_agserv', 'tot_mfutil_agserv',
        'tot_futil_agserv', 'tot_ffappl_css', 'tot_mfappl_css', 'tot_fappl_css',
        'tot_ffrecv_css', 'tot_mfrecv_css', 'tot_frecv_css', 'tot_ffutil_css',
        'tot_mfutil_css', 'tot_futil_css', 'totcrops_qtyrecv', 'totcrops_qtyrecv_fert',
        'totcrops_qtyrecv_seeds', 'totcrops_qtyrecv_agro', 'tot_crops_qtyrecv_insec',
        'tot_crops_qtyrecv_herbs', 'tot_crops_qtyrecv_pest', 'totlives_qtyrecv',
        'totlives_qtyrecv_catfeed', 'totlives_qtyrecv_catdrugs', 'totlives_qtyrecv_catvac',
        'totlives_qtyrecv_catdis', 'totlives_qtyrecv_poul', 'totlives_qtyrecv_poulfeed',
        'totlives_qtyrecv_pouldrugs', 'totlives_qtyrecv_poulvac', 'totlives_qtyrecv_pouldis',
        'totlives_qtyrecv_fish', 'totlives_qtyrecv_fishfeed', 'totlives_qtyrecv_fishdrugs',
        'totlives_qtyrecv_fishvac', 'totlives_qtyrecv_fishdis', 'totlives_qtyrecv_others',
        'tot_ffarmersrecadv', 'tot_mfarmersrecadv',

        'dli_id',
        'state_id',
        'user_id',
        'dp_id',
        'status_id',
        'monthyear',

    ];

    public function states(){
        return $this->belongsTo(State::class, 'state_id');
    }

    public function dps(){
        return $this->belongsTo(Dps::class, 'dp_id');
    }

    public function dli(){
        return $this->belongsTo(Dlis::class, 'dli_id');
    }

    public function status(){
        return $this->belongsTo(Status::class, 'status_id');
    }
    public function months(){
        return $this->belongsTo(Monthyear::class, 'monthyear');
    }

}
