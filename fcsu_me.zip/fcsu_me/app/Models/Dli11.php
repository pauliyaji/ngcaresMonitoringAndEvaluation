<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Dli11 extends Model
{
    use HasFactory;

    protected $fillable = [
        'tot_regit',
        'tot_regitmmicro',
        'tot_regitfmicro',
        'tot_regitmicro',
        'tot_regitmsmall',
        'tot_regitfsmall',
        'tot_regitsmall',
        'tot_eligverit',
        'tot_eligmmicro',
        'tot_eligfmicro',
        'tot_eligmicro',
        'tot_eligmsmall',
        'tot_eligfsmall',
        'tot_eligsmall',
        'att_reg_minus_ver',
        'att_sel_minus_conf',
        'att_conf_minus_tech',
        'tot_sel',
        'tot_selmmicro',
        'tot_selfmicro',
        'tot_selmicro',
        'tot_selmsmall',
        'tot_selfsmall',
        'tot_selsmall',
        'att_ver_minus_sel',
        'tot_ser_pro',
        'tot_conf',
        'tot_confmmicro',
        'tot_conffmicro',
        'tot_confmicro',
        'tot_confmsmall',
        'tot_conffsmall',
        'tot_confsmall',
        'tot_tech',
        'tot_techmmicro',
        'tot_techfmicro',
        'tot_techmicro',
        'tot_techmsmall',
        'tot_techfsmall',
        'tot_techsmall',
        'tot_rec',
        'tot_recmmicro',
        'tot_recfmicro',
        'tot_recmicro',
        'tot_recmsmall',
        'tot_recfsmall',
        'tot_recsmall',
        'att_tech_minus_rec',
        'tot_dis',
        'tot_dismmicro',
        'tot_disfmicro',
        'tot_dismicro',
        'tot_dismsmall',
        'tot_disfsmall',
        'tot_dissmall',

        'dli_id',
        'state_id',
        'user_id',
        'dp_id',
        'status_id',
        'monthyear',

    ];

    public function states(){
        return $this->belongsTo(State::class, 'state_id');
    }

    public function dps(){
        return $this->belongsTo(Dps::class, 'dp_id');
    }

    public function dli(){
        return $this->belongsTo(Dlis::class, 'dli_id');
    }

    public function status(){
        return $this->belongsTo(Status::class, 'status_id');
    }
    public function months(){
        return $this->belongsTo(Monthyear::class, 'monthyear');
    }
}
