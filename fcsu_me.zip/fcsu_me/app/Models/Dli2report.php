<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Dli2report extends Model
{
    use HasFactory;

    protected $table = 'dli2_report';
    protected $fillable = [
        'f_mined',
        'm_mined',
        'tot_mined',
        'f_validated',
        'm_validated',
        'tot_validated',
        'f_enrolled',
        'm_enrolled',
        'tot_enrolled',
        'f_deploy',
        'm_deploy',
        'tot_deploy',
        'num_workdays',
        'amt_transpsp',
        'tot_fbeneforpsppay',
        'tot_mbeneforpsppay',
        'tot_beneforpsppay',
        'tot_fbenepaid',
        'tot_mbenepaid',
        'tot_benepaid',
        'amountbpaid',
        'dli_id',
        'state_id',
        'tab_id',
        'dp_id',
        'monthyear',
    ];


    public function status(){
        return $this->belongsTo(Status::class, 'status_id');
    }

    public function states(){
        return $this->belongsTo(State::class, 'state_id');
    }

    public function dli(){
        return $this->belongsTo(Dlis::class, 'dli_id');
    }
    public function dps(){
        return $this->belongsTo(Dps::class, 'dp_id');
    }

    public function months(){
        return $this->belongsTo(Monthyear::class, 'monthyear');
    }
}
