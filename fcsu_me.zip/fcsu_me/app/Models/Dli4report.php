<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Dli4report extends Model
{
    use HasFactory;

    protected $table = 'dli4_report';

    protected $fillable = [
        'tot_commssensi',
        'tot_grpssensi',
        'tot_eoirecvcomms',
        'tot_eoirecvgrps',
        'tot_cdpssubmit',
        'tot_grdpssubmit',
        'tot_approvcdps',
        'tot_mpscdpedu',
        'tot_mpscdpwat',
        'tot_mpscdphlth',
        'tot_mpscdpwatsani',
        'tot_approvgrdp',
        'tot_grdpsedu',
        'tot_grdpswat',
        'tot_grdpshlth',
        'tot_grdpswatsani',
        'num_cpmctrained',
        'num_gpmctrained',
        'tot_mpsedu',
        'tot_mpswat',
        'tot_mpshlth',
        'tot_mpssani',
        'tot_grpmpsedu',
        'tot_grpmpswat',
        'tot_grpmpshlth',
        'tot_grpmpssani',
        'tot_beneofmps',
        'tot_mpscdpnut',
        'tot_mpsnut',
        'dli_id',
        'state_id',
        'user_id',
        'dp_id',
        'status_id',
        'monthyear',
        'tab_id',
    ];

    public function states(){
        return $this->belongsTo(State::class, 'state_id');
    }

    public function dps(){
        return $this->belongsTo(Dps::class, 'dp_id');
    }

    public function dli(){
        return $this->belongsTo(Dlis::class, 'dli_id');
    }

    public function status(){
        return $this->belongsTo(Status::class, 'status_id');
    }

    public function months(){
        return $this->belongsTo(Monthyear::class, 'monthyear');
    }

}
