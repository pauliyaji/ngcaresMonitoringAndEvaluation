<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Dli11rep extends Model
{
    use HasFactory;

    protected $table = 'dli11_dp_report';

    protected $fillable = [
        'tot_reg_firms', 'tot_reg_firms_micro_m', 'tot_reg_firms_micro_f',
        'tot_reg_firms_micro', 'tot_reg_firms_small_m', 'tot_reg_firms_small_f',
        'tot_reg_firms_small', 'tot_elig_veri', 'tot_elig_veri_micro_m',
        'tot_elig_veri_micro_f', 'tot_elig_veri_micro', 'tot_elig_veri_small_m',
        'tot_elig_veri_small_f', 'tot_elig_veri_small', 'tot_sel_firms',
        'tot_sel_firms_micro_m', 'tot_sel_firms_micro_f', 'tot_sel_firms_micro',
        'tot_sel_firms_small_m', 'tot_sel_firms_small_f', 'tot_sel_firms_small',
        'tot_it_provi', 'tot_con_rcpt', 'tot_con_rcpt_micro_m', 'tot_con_rcpt_micro_f',
        'tot_con_rcpt_micro', 'tot_con_rcpt_small_m', 'tot_con_rcpt_small_f',
        'tot_con_rcpt_small', 'tot_tech_sup', 'tot_tech_sup_micro_m',
        'tot_tech_sup_micro_f', 'tot_tech_sup_micro', 'tot_tech_sup_small_m',
        'tot_tech_sup_small_f', 'tot_tech_sup_small', 'tot_firms_rcvg',
        'tot_firms_rcvg_micro_m', 'tot_firms_rcvg_micro_f', 'tot_firms_rcvg_micro',
        'tot_firms_rcvg_small_m', 'tot_firms_rcvg_small_f', 'tot_firms_rcvg_small',
        'amt_dis', 'amt_dis_micro_m', 'amt_dis_micro_f', 'amt_dis_micro',
        'amt_dis_small_m', 'amt_dis_small_f', 'amt_dis_small', 'state_id', 'monthyear',
    ];
}
