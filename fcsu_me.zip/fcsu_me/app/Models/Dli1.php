<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Dli1 extends Model
{
    use HasFactory;

    protected $fillable = [
        'f_mined',
        'm_mined',
        'tot_mined',
        'aged_mined',
        'chro_mined',
        'urban_mined',
        'needs_mined',
        'f_validated',
        'm_validated',
        'tot_validated',
        'att_fmined',
        'att_mmined',
        'att_totmined',
        'att_minedpercent',
        'fenrolled',
        'menrolled',
        'tot_enrolled',
        'att_perenrolled',
        'aged_fenrolled',
        'aged_menrolled',
        'chro_fenrolled',
        'chro_menrolled',
        'urban_fenrolled',
        'urban_menrolled',
        'needs_fenrolled',
        'needs_menrolled',
        'att_fval_enr',
        'att_mval_enr',
        'att_totval_enr',
        'amt_transpsp',
        'tot_fbeneforpsppay',
        'tot_mbeneforpsppay',
        'tot_beneforpsppay',
        'amt_transpsp',
        'tot_agedfbeneforpsppay',
        'tot_agedmbeneforpsppay',
        'tot_chrofbeneforpsppay',
        'tot_chrombeneforpsppay',
        'tot_urbanfbeneforpsppay',
        'tot_urbanmbeneforpsppay',
        'tot_needsfbeneforpsppay',
        'tot_needsmbeneforpsppay',
        'tot_numbenepaid',
        'attrition_ntpaid',
        'attrition_ntpaid_percent',

        'dli_id',
        'state_id',
        'user_id',
        'status_id',
        'dp_id',
        'monthyear',

        'comment1',
        'comment2',
        'comment3',
        'comment4',
    ];

    public function status(){
        return $this->belongsTo(Status::class, 'status_id');
    }

    public function states(){
        return $this->belongsTo(State::class, 'state_id');
    }

    public function dli(){
        return $this->belongsTo(Dlis::class, 'dli_id');
    }
    public function dps(){
        return $this->belongsTo(Dps::class, 'dp_id');
    }

    public function months(){
        return $this->belongsTo(Monthyear::class, 'monthyear');
    }


}
