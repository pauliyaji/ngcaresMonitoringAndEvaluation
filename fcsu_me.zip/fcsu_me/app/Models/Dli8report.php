<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Dli8report extends Model
{
    use HasFactory;

    protected $table ='dli8_report';
    protected $fillable =[
        'tot_microfcasense',
        'tot_smallfcasense',
        'tot_fcasense',
        'tot_carp_prep',
        'tot_carp_approv',
        'tot_exist_wet_mark',
        'tot_fsellersbene',
        'tot_msellersbene',
        'tot_sellersbene',
        'tot_wetmktupgraded',

        'dli_id',
        'state_id',
        'tab_id',
        'dp_id',
        'monthyear',

    ];

    public function states(){
        return $this->belongsTo(State::class, 'state_id');
    }

    public function dps(){
        return $this->belongsTo(Dps::class, 'dp_id');
    }

    public function dli(){
        return $this->belongsTo(Dlis::class, 'dli_id');
    }

    public function status(){
        return $this->belongsTo(Status::class, 'status_id');
    }

    public function months(){
        return $this->belongsTo(Monthyear::class, 'monthyear');
    }
}
