<?php $__env->startSection('content'); ?>

    <!-- Begin Page Content -->
    <div class="container-fluid">

        <!-- Page Heading -->

        <!-- DataTales Example -->
        <div class="card shadow mb-4">
            <div class="card-header py-3">
                <h4 class="m-0 font-weight-bold text-primary">All Submissions from <?php echo e(Auth::user()->states->state); ?>

                    <a href="#" class="float-right btn btn-success btn-sm">Back</a>
                </h4>
            </div>
            <div class="card-body">
                <?php if(Session::has('success')): ?>
                    <p class="text-success"><?php echo e(Session('success')); ?></p>
                <?php endif; ?>
                   
                <div class="table-responsive">

                    <table class="table table-bordered" id="dataTable">
                        <thead>
                        <tr>
                            <th>State</th>
                            <th>Dli</th>
                            <th>DP</th>
                            <th>Status</th>
                            <th>Period</th>
                            <th>Action</th>

                        </tr>
                        </thead>
                        <tfoot>
                        <tr>
                            <th>State</th>
                            <th>Dli</th>
                            <th>DP</th>
                            <th>Status</th>
                            <th>Period</th>
                            <th>Action</th>
                        </tr>
                        </tfoot>
                        <tbody>
                        <?php if($sts): ?>
                            <?php $__currentLoopData = $sts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($d->states->state); ?></td>
                                    <td><?php echo e($d->dli->title); ?></td>
                                    <td><?php echo e($d->dps->name); ?></td>
                                    <td style="color: green; font-weight: bold"><?php echo e($d->status->status); ?></td>
                                    
                                    <td><?php echo e($d->months->date); ?></td>
                                    <td>
                                     <?php if(Auth::user()->sccu_id): ?>
                                         <div class="btn-group">
                                             <a href="<?php echo e(route('socialtransfers.show', $d->id)); ?>" class="btn btn-info btn-sm"><i class="fa fa-eye"></i></a>
                                             <?php if($d->status_id != 3): ?>

                                                 <form method="post" action="<?php echo e(route('socialtransfers.senddata', $d->id)); ?>">
                                                     <?php echo csrf_field(); ?>
                                                     <?php echo method_field('put'); ?>
                                                     <div class="col-md-6 col-xs-12">
                                                         <input type="submit" value="Confirm" class="btn btn-warning btn-sm" />
                                                     </div>
                                                 </form>
                                             <?php endif; ?>
                                         </div>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                        <?php if($lipws): ?>
                            <?php $__currentLoopData = $lipws; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($d->states->state); ?></td>
                                    <td><?php echo e($d->dli->title); ?></td>
                                    <td><?php echo e($d->dps->name); ?></td>
                                    <td style="color: green; font-weight: bold"><?php echo e($d->status->status); ?></td>
                                    <td><?php echo e(date('d-M-Y', strtotime($d->created_at))); ?></td>

                                    <td>
                                        <?php if(Auth::user()->sccu_id): ?>
                                            <div class="btn-group">
                                                <a href="<?php echo e(route('lipws.show', $d->id)); ?>" class="btn btn-info btn-sm"><i class="fa fa-eye"></i></a>

                                                <?php if($d->status_id != 3): ?>

                                                    <form method="post" action="<?php echo e(route('lipws.senddata', $d->id)); ?>">
                                                        <?php echo csrf_field(); ?>
                                                        <?php echo method_field('put'); ?>
                                                        <div class="col-md-6 col-xs-12">
                                                            <input type="submit" value="Confirm" class="btn btn-warning btn-sm" />
                                                        </div>
                                                    </form>
                                                <?php endif; ?>
                                            </div>

                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                        <?php if($lihds): ?>
                            <?php $__currentLoopData = $lihds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($d->states->state); ?></td>
                                    <td><?php echo e($d->dli->title); ?></td>
                                    <td><?php echo e($d->dps->name); ?></td>
                                    <td style="color: green; font-weight: bold"><?php echo e($d->status->status); ?></td>
                                    <td><?php echo e(date('d-M-Y', strtotime($d->created_at))); ?></td>
                                    <td>
                                        <?php if(Auth::user()->sccu_id): ?>
                                            <div class="btn-group">
                                                <a href="<?php echo e(route('livelihoods.show', $d->id)); ?>" class="btn btn-info btn-sm"><i class="fa fa-eye"></i></a>
                                                <?php if($d->status_id != 3): ?>

                                                    <form method="post" action="<?php echo e(route('livelihoods.senddata', $d->id)); ?>">
                                                        <?php echo csrf_field(); ?>
                                                        <?php echo method_field('put'); ?>
                                                        <div class="col-md-6 col-xs-12">
                                                            <input type="submit" value="Confirm" class="btn btn-warning btn-sm" />
                                                        </div>
                                                    </form>
                                                <?php endif; ?>
                                            </div>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                        <?php if($bss): ?>
                            <?php $__currentLoopData = $bss; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($d->states->state); ?></td>
                                    <td><?php echo e($d->dli->title); ?></td>
                                    <td><?php echo e($d->dps->name); ?></td>
                                    <td style="color: green; font-weight: bold"><?php echo e($d->status->status); ?></td>
                                    <td><?php echo e(date('d-M-Y', strtotime($d->created_at))); ?></td>
                                    <td>
                                        <?php if(Auth::user()->sccu_id): ?>
                                            <div class="btn-group">
                                                <a href="<?php echo e(route('basicservices.show', $d->id)); ?>" class="btn btn-info btn-sm"><i class="fa fa-eye"></i></a>
                                                <?php if($d->status_id != 3): ?>

                                                    <form method="post" action="<?php echo e(route('basicservices.senddata', $d->id)); ?>">
                                                        <?php echo csrf_field(); ?>
                                                        <?php echo method_field('put'); ?>
                                                        <div class="col-md-6 col-xs-12">
                                                            <input type="submit" value="Confirm" class="btn btn-warning btn-sm" />
                                                        </div>
                                                    </form>
                                                <?php endif; ?>
                                            </div>
                                        <?php endif; ?>

                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>

                        <?php if($aginfs): ?>
                            <?php $__currentLoopData = $aginfs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($d->states->state); ?></td>
                                    <td><?php echo e($d->dli->title); ?></td>
                                    <td><?php echo e($d->dps->name); ?></td>
                                    <td style="color: green; font-weight: bold"><?php echo e($d->status->status); ?></td>
                                    <td><?php echo e(date('d-M-Y', strtotime($d->created_at))); ?></td>
                                    <td>

                                        <?php if(Auth::user()->sccu_id): ?>
                                                <div class="btn-group">
                                                <a href="<?php echo e(route('agric_infrastructures.show', $d->id)); ?>" class="btn btn-info btn-sm"><i class="fa fa-eye"></i></a>
                                                <?php if($d->status_id != 3): ?>

                                                    <form method="post" action="<?php echo e(route('agric_infrastructures.senddata', $d->id)); ?>">
                                                        <?php echo csrf_field(); ?>
                                                        <?php echo method_field('put'); ?>
                                                        <div class="col-md-6 col-xs-12">
                                                            <input type="submit" value="Confirm" class="btn btn-warning btn-sm" />
                                                        </div>
                                                    </form>
                                                <?php endif; ?>
                                             </div>
                                        <?php endif; ?>

                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                        <?php if($agass): ?>
                            <?php $__currentLoopData = $agass; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($d->states->state); ?></td>
                                    <td><?php echo e($d->dli->title); ?></td>
                                    <td><?php echo e($d->dps->name); ?></td>
                                    <td style="color: green; font-weight: bold"><?php echo e($d->status->status); ?></td>
                                    <td><?php echo e(date('d-M-Y', strtotime($d->created_at))); ?></td>

                                    <td>
                                        <?php if(Auth::user()->sccu_id): ?>
                                            <div class="btn-group">
                                                <a href="<?php echo e(route('agric_assets.show', $d->id)); ?>" class="btn btn-info btn-sm"><i class="fa fa-eye"></i></a>
                                                <?php if($d->status_id != 3): ?>

                                                    <form method="post" action="<?php echo e(route('agric_assets.senddata', $d->id)); ?>">
                                                        <?php echo csrf_field(); ?>
                                                        <?php echo method_field('put'); ?>
                                                        <div class="col-md-6 col-xs-12">
                                                            <input type="submit" value="Confirm" class="btn btn-warning btn-sm" />
                                                        </div>
                                                    </form>
                                                <?php endif; ?>
                                            </div>
                                        <?php endif; ?>

                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                        <?php if($wms): ?>
                            <?php $__currentLoopData = $wms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($d->states->state); ?></td>
                                    <td><?php echo e($d->dli->title); ?></td>
                                    <td><?php echo e($d->dps->name); ?></td>
                                    <td style="color: green; font-weight: bold"><?php echo e($d->status->status); ?></td>
                                    <td><?php echo e(date('d-M-Y', strtotime($d->created_at))); ?></td>
                                    <td>

                                   <?php if(Auth::user()->sccu_id): ?>
                                            <div class="btn-group">
                                                <a href="<?php echo e(route('wetmarkets.show', $d->id)); ?>" class="btn btn-info btn-sm"><i class="fa fa-eye"></i></a>
                                                <?php if($d->status_id != 3): ?>

                                                    <form method="post" action="<?php echo e(route('wetmarkets.senddata', $d->id)); ?>">
                                                        <?php echo csrf_field(); ?>
                                                        <?php echo method_field('put'); ?>
                                                        <div class="col-md-6 col-xs-12">
                                                            <input type="submit" value="Confirm" class="btn btn-warning btn-sm" />
                                                        </div>
                                                    </form>
                                                <?php endif; ?>
                                            </div>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                        <?php if($cgs): ?>
                            <?php $__currentLoopData = $cgs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($d->states->state); ?></td>
                                    <td><?php echo e($d->dli->title); ?></td>
                                    <td><?php echo e($d->dps->name); ?></td>
                                    <td style="color: green; font-weight: bold"><?php echo e($d->status->status); ?></td>
                                    <td><?php echo e(date('d-M-Y', strtotime($d->created_at))); ?></td>
                                    <td>

                                        <?php if(Auth::user()->sccu_id): ?>
                                            <div class="btn-group">
                                                <a href="<?php echo e(route('credit_grants.show', $d->id)); ?>" class="btn btn-info btn-sm"><i class="fa fa-eye"></i></a>
                                                <?php if($d->status_id != 3): ?>

                                                    <form method="post" action="<?php echo e(route('credit_grants.senddata', $d->id)); ?>">
                                                        <?php echo csrf_field(); ?>
                                                        <?php echo method_field('put'); ?>
                                                        <div class="col-md-6 col-xs-12">
                                                            <input type="submit" value="Confirm" class="btn btn-warning btn-sm" />
                                                        </div>
                                                    </form>
                                                <?php endif; ?>
                                            </div>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                        <?php if($ops): ?>
                            <?php $__currentLoopData = $ops; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($d->states->state); ?></td>
                                    <td><?php echo e($d->dli->title); ?></td>
                                    <td><?php echo e($d->dps->name); ?></td>
                                    <td style="color: green; font-weight: bold"><?php echo e($d->status->status); ?></td>
                                    <td><?php echo e(date('d-M-Y', strtotime($d->created_at))); ?></td>
                                    <td>

                                        <?php if(Auth::user()->sccu_id): ?>
                                            <div class="btn-group">
                                                <a href="<?php echo e(route('operations_grant.show', $d->id)); ?>" class="btn btn-info btn-sm"><i class="fa fa-eye"></i></a>
                                                <?php if($d->status_id != 3): ?>

                                                    <form method="post" action="<?php echo e(route('operations_grant.senddata', $d->id)); ?>">
                                                        <?php echo csrf_field(); ?>
                                                        <?php echo method_field('put'); ?>
                                                        <div class="col-md-6 col-xs-12">
                                                            <input type="submit" value="Confirm" class="btn btn-warning btn-sm" />
                                                        </div>
                                                    </form>
                                                <?php endif; ?>
                                            </div>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                        <?php if($ens): ?>
                            <?php $__currentLoopData = $ens; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($d->states->state); ?></td>
                                    <td><?php echo e($d->dli->title); ?></td>
                                    <td><?php echo e($d->dps->name); ?></td>
                                    <td style="color: green; font-weight: bold"><?php echo e($d->status->status); ?></td>
                                    <td><?php echo e(date('d-M-Y', strtotime($d->created_at))); ?></td>
                                    <td>

                                        <?php if(Auth::user()->sccu_id): ?>
                                            <div class="btn-group">
                                                <a href="<?php echo e(route('enhancement_grants.show', $d->id)); ?>" class="btn btn-info btn-sm"><i class="fa fa-eye"></i></a>
                                                <?php if($d->status_id != 3): ?>

                                                    <form method="post" action="<?php echo e(route('enhancement_grants.senddata', $d->id)); ?>">
                                                        <?php echo csrf_field(); ?>
                                                        <?php echo method_field('put'); ?>
                                                        <div class="col-md-6 col-xs-12">
                                                            <input type="submit" value="Confirm" class="btn btn-warning btn-sm" />
                                                        </div>
                                                    </form>
                                                <?php endif; ?>
                                            </div>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>

                        </tbody>
                    </table>
                </div>


            </div>
        </div>

    </div>
    <!-- /.container-fluid -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<!-- Bootstrap core JavaScript-->


<?php echo $__env->make('layouts/layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/fcsu_me/resources/views/sccus/index.blade.php ENDPATH**/ ?>