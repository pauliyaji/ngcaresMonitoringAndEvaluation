<?php $__env->startSection('content'); ?>

    <!-- Begin Page Content -->
    <div class="container-fluid">

        <!-- Page Heading -->

        <!-- DataTales Example -->
        <div class="card shadow mb-4">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-primary">Edit Permission
                    <a href="<?php echo e(route('permissions.index')); ?>" class="float-right btn btn-success btn-sm">View All</a>

                </h6>
            </div>
            <div class="card-body">

                <?php if(Session::has('success')): ?>
                    <p class="text-success"><?php echo e(session('success')); ?></p>
                <?php endif; ?>
                <div class="table-responsive">
                    <form method="post" action="<?php echo e(route('permissions.update', $permission->id)); ?>" >
                        <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('put'); ?>
                            <tr>
                                <th>Full Name</th>
                                <td><input type="text" class="form-control" value="<?php echo e($permission->name); ?>" name="name" id="name"/></td>
                            </tr>
                            <tr>
                                <td colspan="2">
                                    <input type="submit" class="btn btn-primary btn-sm" />                                </td>
                            </tr>
                        </table>
                    </form>
                </div>
            </div>
        </div>

    </div>
    <!-- /.container-fluid -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- Bootstrap core JavaScript-->


<?php echo $__env->make('layouts/layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/fcsu_me/resources/views/permissions/edit.blade.php ENDPATH**/ ?>