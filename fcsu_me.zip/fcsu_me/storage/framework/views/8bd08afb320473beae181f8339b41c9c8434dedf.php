<?php $__env->startSection('content'); ?>

    <!-- Begin Page Content -->
    <div class="container-fluid">

        <!-- Page Heading -->

        <!-- DataTales Example -->
        <div class="card shadow mb-4">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-primary">LIVELIHOODS (DLI 1.3)
                    <a href="<?php echo e(route("livelihoods.create")); ?>" class="float-right btn btn-success btn-sm">Add New</a>
                </h6>
            </div>
            <div class="card-body">
                <?php if(Session::has('success')): ?>
                    <p class="text-success"><?php echo e(Session('success')); ?></p>
                <?php endif; ?>
                   <div class="d-flex my-2 ">
                        <a href="<?php echo e(route('exportlivelihood')); ?>" class="btn btn-primary m-2 me-1">Export Data</a>
                       
                    </div>
                <div class="table-responsive">
                    <table class="table table-bordered" id="dataTable">
                        <thead>
                        <tr>
                            <th>#</th>
                            <th>State</th>
                            <th>Head M&E</th>
                            <th>Status</th>
                            <th>Action</th>

                        </tr>
                        </thead>
                        <tfoot>
                        <tr>
                            <th>#</th>
                            <th>State</th>
                            <th>Head M&E</th>
                            <th>Status</th>
                            <th>Action</th>
                        </tr>
                        </tfoot>
                        <tbody>
                        <?php if($data): ?>
                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($d->id); ?></td>
                                    <td><?php echo e($d->states->state); ?></td>
                                    <td><?php echo e($d->dli->title); ?></td>
                                    <td style="color: green; font-weight: bold"><?php echo e($d->status->status); ?></td>

                                    <td>
                                        <?php if(Auth::user()->id == 1): ?>
                                            <a href="<?php echo e(route('livelihoods.show', $d->id)); ?>" class="btn btn-info btn-sm"><i class="fa fa-eye"></i></a>
                                            <a href="<?php echo e(route('livelihoods.edit', $d->id)); ?>" class="btn btn-primary btn-sm"><i class="fa fa-edit"></i></a>
                                        <?php elseif($d->user_id == Auth::user()->id && $d->status_id != 3): ?>
                                            <a href="<?php echo e(route('livelihoods.edit', $d->id)); ?>" class="btn btn-primary btn-sm"><i class="fa fa-edit"></i></a>
                                        <?php elseif($d->user_id == Auth::user()->id): ?>
                                            <a href="<?php echo e(route('livelihoods.show', $d->id)); ?>" class="btn btn-info btn-sm"><i class="fa fa-eye"></i></a>
                                        <?php endif; ?>

                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <!-- Modal -->
        <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">Import CSV</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <form action="import" method="POST" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <div class="input-group mb-3">
                                <input type="file" name="file" class="form-control">
                                <button class="btn btn-primary" type="submit">Submit</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- /.container-fluid -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<!-- Bootstrap core JavaScript-->


<?php echo $__env->make('layouts/layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/fcsu_me/resources/views/livelihoods/index.blade.php ENDPATH**/ ?>