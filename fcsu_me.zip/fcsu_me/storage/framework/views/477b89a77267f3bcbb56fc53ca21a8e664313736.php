<table class="table table-bordered" id="dataTable">
    <thead style="background-color: cornflowerblue; color: white">
    <tr>
        <th>Dli</th>
        <th colspan="2">Disbursement Indicator</th>
        <th></th>
        <th>Unit of Measurement</th>
        <th>Previous (as at <?php echo e($old_rec->months->date); ?> )</th>
        <th>Current (as at <?php echo e($data->months->date); ?>)</th>
        <th>Total</th>
    </tr>
    </thead>

    <tbody>
    <tr>
        <th>2.2.1</th>
        <th>Total Number of FCAs Sensitized and Mobilized </th>
        <th></th>
        <th></th>
        <th>No.</th>
        <?php if($prev_vals == null): ?>
            <th>0</th>
        <?php else: ?>
            <th><?php echo e($prev_vals->sum('tot_fcasense')); ?></th>
        <?php endif; ?>
        <th><?php echo e($data->tot_fcasense); ?></th>
        <th><?php echo e($data->tot_fcasense + $prev_vals->sum('tot_fcasense')); ?></th>
    </tr>
    <tr>
        <th>2.2.2</th>
        <th>Total Number of CARP Prepared </th>
        <th></th>
        <th></th>
        <th>No.</th>
        <?php if($prev_vals == null): ?>
            <th>0</th>
        <?php else: ?>
            <th><?php echo e($prev_vals->sum('tot_carpprep')); ?></th>
        <?php endif; ?>
        <th><?php echo e($data->tot_carpprep); ?></th>
        <th><?php echo e($data->tot_carpprep + $prev_vals->sum('tot_carpprep')); ?></th>
    </tr>

    <tr>
        <th>2.2.3</th>
        <th>Total Number of CARP Approved </th>
        <th></th>
        <th></th>
        <th>No.</th>
        <?php if($prev_vals == null): ?>
            <th>0</th>
        <?php else: ?>
            <th><?php echo e($prev_vals->sum('tot_carpapprov')); ?></th>
        <?php endif; ?>
        <th><?php echo e($data->tot_carpapprov); ?></th>
        <th><?php echo e($data->tot_carpapprov + $prev_vals->sum('tot_carpapprov')); ?></th>
    </tr>

    <tr>
        <th>2.2.4</th>
        <th>Total Number of Agricultural Infrastructures with agreed LIPW Requirements</th>
        <th></th>
        <th></th>
        <th>No.</th>
        <?php if($prev_vals == null): ?>
            <th>0</th>
        <?php else: ?>
            <th><?php echo e($prev_vals->sum('tot_agricinfrac')); ?></th>
        <?php endif; ?>
        <th><?php echo e($data->tot_agricinfrac); ?></th>
        <th><?php echo e($data->tot_agricinfrac + $prev_vals->sum('tot_agricinfrac')); ?></th>
    </tr>

    <tr>
        <th>2.2.5</th>
        <th rowspan="2">Total Number of Farmers who Applied for Agricultural Infrastructures with agreed LIPW Requirements</th>
        <th>Female</th>
        <td></td>
        <td>No.</td>
        <?php if($prev_vals == null): ?>
            <th>0</th>
        <?php else: ?>
            <td><?php echo e($prev_vals->sum('tot_ffarmersapp')); ?></td>
        <?php endif; ?>
        <td><?php echo e($data->tot_ffarmersapp); ?></td>
        <td><?php echo e($data->tot_ffarmersapp + $prev_vals->sum('tot_ffarmersapp')); ?></td>
    </tr>
    <tr>
        <th></th>
        <th>Male</th>
        <td></td>
        <td>No.</td>
        <td><?php echo e($prev_vals->sum('tot_mfarmersapp')); ?></td>
        <td><?php echo e($data->tot_mfarmersapp); ?></td>
        <td><?php echo e($data->tot_mfarmersapp + $prev_vals->sum('tot_mfarmersapp')); ?></td>
    </tr>
    <tr style="background-color: cornflowerblue; color: black;">
        <th></th>
        <td></td>
        <th>Total</th>
        <td></td>

        <td>No.</td>
        <?php if($prev_vals == null): ?>
            <th>0</th>
        <?php else: ?>
            <td><?php echo e($prev_vals->sum('tot_farmersapp')); ?></td>
        <?php endif; ?>
        <th><?php echo e($data->tot_farmersapp); ?></th>
        <th><?php echo e($data->tot_farmersapp + $prev_vals->sum('tot_farmersapp')); ?></th>
    </tr>
    <tr>
        <th>2.2.6</th>
        <th rowspan="2">Total Number of Farmers who Received Agricultural Infrastructures with agreed LIPW Requirements</th>
        <th>Female</th>
        <td></td>
        <td>No.</td>
        <?php if($prev_vals == null): ?>
            <th>0</th>
        <?php else: ?>
            <td><?php echo e($prev_vals->sum('tot_ffarmersrec')); ?></td>
        <?php endif; ?>
        <td><?php echo e($data->tot_ffarmersrec); ?></td>
        <td><?php echo e($data->tot_ffarmersrec + $prev_vals->sum('tot_ffarmersrec')); ?></td>
    </tr>
    <tr>
        <th></th>
        <th>Male</th>
        <td></td>
        <td>No.</td>
        <?php if($prev_vals == null): ?>
            <th>0</th>
        <?php else: ?>
            <td><?php echo e($prev_vals->sum('tot_mfarmersrec')); ?></td>
        <?php endif; ?>
        <td><?php echo e($data->tot_mfarmersrec); ?></td>
        <td><?php echo e($data->tot_mfarmersrec + $prev_vals->sum('tot_mfarmersrec')); ?></td>
    </tr>
    <tr style="background-color: cornflowerblue; color: black;">
        <th></th>
        <td></td>
        <th>Total</th>
        <td></td>

        <td>No.</td>
        <?php if($prev_vals == null): ?>
            <th>0</th>
        <?php else: ?>
            <td><?php echo e($prev_vals->sum('tot_farmersrec')); ?></td>
        <?php endif; ?>
        <th><?php echo e($data->tot_farmersrec); ?></th>
        <th><?php echo e($data->tot_farmersrec + $prev_vals->sum('tot_farmersrec')); ?></th>
    </tr>

    <tr>
        <th>2.2.7</th>
        <th rowspan="2">Total Number of Farmers who are Accessing/Utilizing Improved Agricultural Infrastructures with agreed LIPW Requirements</th>
        <th>Female</th>
        <td></td>
        <td>No.</td>
        <?php if($prev_vals == null): ?>
            <th>0</th>
        <?php else: ?>
            <td><?php echo e($prev_vals->sum('tot_ffarmersutil')); ?></td>
        <?php endif; ?>
        <td><?php echo e($data->tot_ffarmersutil); ?></td>
        <td><?php echo e($data->tot_ffarmersutil + $prev_vals->sum('tot_ffarmersutil')); ?></td>
    </tr>
    <tr>
        <th></th>
        <th>Male</th>
        <td></td>
        <td>No.</td>
        <?php if($prev_vals == null): ?>
            <th>0</th>
        <?php else: ?>
            <td><?php echo e($prev_vals->sum('tot_mfarmersutil')); ?></td>
        <?php endif; ?>
        <td><?php echo e($data->tot_mfarmersutil); ?></td>
        <td><?php echo e($data->tot_mfarmersutil + $prev_vals->sum('tot_mfarmersutil')); ?></td>
    </tr>
    <tr style="background-color: cornflowerblue; color: black;">
        <th></th>
        <td></td>
        <th>Total</th>
        <td></td>

        <td>No.</td>
        <?php if($prev_vals == null): ?>
            <th>0</th>
        <?php else: ?>
            <td><?php echo e($prev_vals->sum('tot_farmersutil')); ?></td>
        <?php endif; ?>
        <th><?php echo e($data->tot_farmersutil); ?></th>
        <th><?php echo e($data->tot_farmersutil + $prev_vals->sum('tot_farmersutil')); ?></th>
    </tr>

    <tr>
        <th>2.2.8</th>
        <th>Total Number of Agricultural Infrastructure Completed </th>
        <th></th>
        <th></th>
        <th>No.</th>
        <?php if($prev_vals == null): ?>
            <th>0</th>
        <?php else: ?>
            <th><?php echo e($prev_vals->sum('tot_infracomp')); ?></th>
        <?php endif; ?>
        <th><?php echo e($data->tot_infracomp); ?></th>
        <th><?php echo e($data->tot_infracomp + $prev_vals->sum('tot_infracomp')); ?></th>
    </tr>


    <tr>
        <th>2.2.9</th>
        <th>Total Number of Completed Agricultural Infrastructure Paid for</th>
        <th></th>
        <th></th>
        <th>No.</th>
        <?php if($prev_vals == null): ?>
            <th>0</th>
        <?php else: ?>
            <th><?php echo e($prev_vals->sum('tot_infracomppaid')); ?></th>
        <?php endif; ?>
        <th><?php echo e($data->tot_infracomppaid); ?></th>
        <th><?php echo e($data->tot_infracomppaid + $prev_vals->sum('tot_infracomppaid')); ?></th>
    </tr>

    </tbody>
</table>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/fcsu_me/resources/views/dps/ag_infra_table.blade.php ENDPATH**/ ?>