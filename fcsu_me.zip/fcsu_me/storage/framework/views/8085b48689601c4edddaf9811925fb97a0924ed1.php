<table class="table table-bordered" id="dataTable">
    <thead style="background-color: cornflowerblue; color: white">
    <tr>
        <th>Dli</th>
        <th colspan="2">Disbursement Indicator</th>
        <th></th>
        <th>Unit of Measurement</th>
        <th>Previous (as at <?php echo e($old_rec->months->date); ?> )</th>
        <th>Current (as at <?php echo e($data->months->date); ?>)</th>
        <th>Total</th>
    </tr>
    </thead>

    <tbody>
    <tr>
        <th>3.3</th>
        <th>Total Number of Registered Firms that Applied for IT-Enhancement</th>
        <th></th>
        <th></th>
        <th>No.</th>

            <th><?php echo e($prev_vals->sum('tot_regit')); ?></th>

        <th><?php echo e($data->tot_regit); ?></th>
        <th><?php echo e($data->tot_regit + $prev_vals->sum('tot_regit')); ?></th>
    </tr>
    <tr>
        <th>3.3.1.1</th>
        <th rowspan="2">Micro Scale Firms</th>
        <th>Male Owners</th>
        <td></td>
        <td>No.</td>
        <?php if($prev_vals == null): ?>
            <th>0</th>
        <?php else: ?>
            <td><?php echo e($prev_vals->sum('tot_regitmmicro')); ?></td>
        <?php endif; ?>
        <td><?php echo e($data->tot_regitmmicro); ?></td>
        <td><?php echo e($data->tot_regitmmicro + $prev_vals->sum('tot_regitmmicro')); ?></td>
    </tr>
    <tr>
        <th></th>
        <th>Female Owners</th>
        <td></td>
        <td>No.</td>
        <?php if($prev_vals == null): ?>
            <th>0</th>
        <?php else: ?>
            <td><?php echo e($prev_vals->sum('tot_regitfmicro')); ?></td>
        <?php endif; ?>
        <td><?php echo e($data->tot_regitfmicro); ?></td>
        <td><?php echo e($data->tot_regitfmicro + $prev_vals->sum('tot_regitfmicro')); ?></td>
    </tr>
    <tr style="background-color: cornflowerblue; color: black;">
        <th></th>
        <td></td>
        <th>Total</th>
        <td></td>

        <td>No.</td>
        <?php if($prev_vals == null): ?>
            <th>0</th>
        <?php else: ?>
            <td><?php echo e($prev_vals->sum('tot_regitmicro')); ?></td>
        <?php endif; ?>
        <th><?php echo e($data->tot_regitmicro); ?></th>
        <th><?php echo e($data->tot_regitmicro + $prev_vals->sum('tot_regitmicro')); ?></th>
    </tr>
    <tr>
        <th>3.3.1.2</th>
        <th rowspan="2">Small Scale Firms</th>
        <th>Male Owners</th>
        <td></td>
        <td>No.</td>
        <?php if($prev_vals == null): ?>
            <th>0</th>
        <?php else: ?>
            <td><?php echo e($prev_vals->sum('tot_regitmsmall')); ?></td>
        <?php endif; ?>
        <td><?php echo e($data->tot_regitmsmall); ?></td>
        <td><?php echo e($data->tot_regitmsmall + $prev_vals->sum('tot_regitmsmall')); ?></td>
    </tr>
    <tr>
        <th></th>
        <th>Female Owners</th>
        <td></td>
        <td>No.</td>
        <?php if($prev_vals == null): ?>
            <th>0</th>
        <?php else: ?>
            <td><?php echo e($prev_vals->sum('tot_regitfsmall')); ?></td>
        <?php endif; ?>
        <td><?php echo e($data->tot_regitfsmall); ?></td>
        <td><?php echo e($data->tot_regitfsmall + $prev_vals->sum('tot_regitfsmall')); ?></td>
    </tr>
    <tr style="background-color: cornflowerblue; color: black;">
        <th></th>
        <td></td>
        <th>Total</th>
        <td></td>

        <td>No.</td>
        <?php if($prev_vals == null): ?>
            <th>0</th>
        <?php else: ?>
            <td><?php echo e($prev_vals->sum('tot_regitsmall')); ?></td>
        <?php endif; ?>
        <th><?php echo e($data->tot_regitsmall); ?></th>
        <th><?php echo e($data->tot_regitsmall + $prev_vals->sum('tot_regitsmall')); ?></th>
    </tr>
    <tr>
        <th>3.3.2</th>
        <th>Total Number of Eligible and Verified Firms for IT-Enhancement</th>
        <th></th>
        <th></th>
        <th>No.</th>
        <?php if($prev_vals == null): ?>
            <th>0</th>
        <?php else: ?>
            <th><?php echo e($prev_vals->sum('tot_eligverit')); ?></th>
        <?php endif; ?>
        <th><?php echo e($data->tot_eligverit); ?></th>
        <th><?php echo e($data->tot_eligverit + $prev_vals->sum('tot_eligverit')); ?></th>
    </tr>

    <tr>
        <th>3.3.2.1</th>
        <th rowspan="2">Micro Scale Firms</th>
        <th>Male Owners</th>
        <td></td>
        <td>No.</td>
        <?php if($prev_vals == null): ?>
            <th>0</th>
        <?php else: ?>
            <td><?php echo e($prev_vals->sum('tot_eligmmicro')); ?></td>
        <?php endif; ?>
        <td><?php echo e($data->tot_eligmmicro); ?></td>
        <td><?php echo e($data->tot_eligmmicro + $prev_vals->sum('tot_eligmmicro')); ?></td>
    </tr>
    <tr>
        <th></th>
        <th>Female Owners</th>
        <td></td>
        <td>No.</td>
        <?php if($prev_vals == null): ?>
            <th>0</th>
        <?php else: ?>
            <td><?php echo e($prev_vals->sum('tot_eligfmicro')); ?></td>
        <?php endif; ?>
        <td><?php echo e($data->tot_eligfmicro); ?></td>
        <td><?php echo e($data->tot_eligfmicro + $prev_vals->sum('tot_eligfmicro')); ?></td>
    </tr>
    <tr style="background-color: cornflowerblue; color: black;">
        <th></th>
        <td></td>
        <th>Total</th>
        <td></td>

        <td>No.</td>
        <?php if($prev_vals == null): ?>
            <th>0</th>
        <?php else: ?>
            <td><?php echo e($prev_vals->sum('tot_eligmicro')); ?></td>
        <?php endif; ?>
        <th><?php echo e($data->tot_eligmicro); ?></th>
        <th><?php echo e($data->tot_eligmicro + $prev_vals->sum('tot_eligmicro')); ?></th>
    </tr>

    <tr>
        <th>3.3.2.2</th>
        <th rowspan="2">Small Scale Firms </th>
        <th>Male Owners</th>
        <td></td>
        <td>No.</td>
        <?php if($prev_vals == null): ?>
            <th>0</th>
        <?php else: ?>
            <td><?php echo e($prev_vals->sum('tot_eligmsmall')); ?></td>
        <?php endif; ?>
        <td><?php echo e($data->tot_eligmsmall); ?></td>
        <td><?php echo e($data->tot_eligmsmall + $prev_vals->sum('tot_eligmsmall')); ?></td>
    </tr>
    <tr>
        <th></th>
        <th>Female Owners</th>
        <td></td>
        <td>No.</td>
        <?php if($prev_vals == null): ?>
            <th>0</th>
        <?php else: ?>
            <td><?php echo e($prev_vals->sum('tot_eligfsmall')); ?></td>
        <?php endif; ?>
        <td><?php echo e($data->tot_eligfsmall); ?></td>
        <td><?php echo e($data->tot_eligfsmall + $prev_vals->sum('tot_eligfsmall')); ?></td>
    </tr>
    <tr style="background-color: cornflowerblue; color: black;">
        <th></th>
        <td></td>
        <th>Total</th>
        <td></td>

        <td>No.</td>
        <?php if($prev_vals == null): ?>
            <th>0</th>
        <?php else: ?>
            <td><?php echo e($prev_vals->sum('tot_eligsmall')); ?></td>
        <?php endif; ?>
        <th><?php echo e($data->tot_eligsmall); ?></th>
        <th><?php echo e($data->tot_eligsmall + $prev_vals->sum('tot_eligsmall')); ?></th>
    </tr>
    <tr>
        <th>3.3.3</th>
        <th>Total Number of Selected Firms for IT-Enhancement</th>
        <th></th>
        <th></th>
        <th>No.</th>
        <?php if($prev_vals == null): ?>
            <th>0</th>
        <?php else: ?>
            <th><?php echo e($prev_vals->sum('tot_sel')); ?></th>
        <?php endif; ?>
        <th><?php echo e($data->tot_sel); ?></th>
        <th><?php echo e($data->tot_sel + $prev_vals->sum('tot_sel')); ?></th>
    </tr>

    <tr>
        <th>3.3.3.1</th>
        <th rowspan="2">Micro Scale Firms</th>
        <th>Male Owners</th>
        <td></td>
        <td>No.</td>
        <?php if($prev_vals == null): ?>
            <th>0</th>
        <?php else: ?>
            <td><?php echo e($prev_vals->sum('tot_selmmicro')); ?></td>
        <?php endif; ?>
        <td><?php echo e($data->tot_selmmicro); ?></td>
        <td><?php echo e($data->tot_selmmicro + $prev_vals->sum('tot_selmmicro')); ?></td>
    </tr>
    <tr>
        <th></th>
        <th>Female Owners</th>
        <td></td>
        <td>No.</td>
        <?php if($prev_vals == null): ?>
            <th>0</th>
        <?php else: ?>
            <td><?php echo e($prev_vals->sum('tot_selfmicro')); ?></td>
        <?php endif; ?>
        <td><?php echo e($data->tot_selfmicro); ?></td>
        <td><?php echo e($data->tot_selfmicro + $prev_vals->sum('tot_selfmicro')); ?></td>
    </tr>
    <tr style="background-color: cornflowerblue; color: black;">
        <th></th>
        <td></td>
        <th>Total</th>
        <td></td>

        <td>No.</td>
        <?php if($prev_vals == null): ?>
            <th>0</th>
        <?php else: ?>
            <td><?php echo e($prev_vals->sum('tot_selmicro')); ?></td>
        <?php endif; ?>
        <th><?php echo e($data->tot_selmicro); ?></th>
        <th><?php echo e($data->tot_selmicro + $prev_vals->sum('tot_selmicro')); ?></th>
    </tr>

    <tr>
        <th>3.3.3.2</th>
        <th rowspan="2">Small Scale Firms</th>
        <th>Male Owners</th>
        <td></td>
        <td>No.</td>
        <?php if($prev_vals == null): ?>
            <th>0</th>
        <?php else: ?>
            <td><?php echo e($prev_vals->sum('tot_selmsmall')); ?></td>
        <?php endif; ?>
        <td><?php echo e($data->tot_selmsmall); ?></td>
        <td><?php echo e($data->tot_selmsmall + $prev_vals->sum('tot_selmsmall')); ?></td>
    </tr>
    <tr>
        <th></th>
        <th>Female Owners</th>
        <td></td>
        <td>No.</td>
        <?php if($prev_vals == null): ?>
            <th>0</th>
        <?php else: ?>
            <td><?php echo e($prev_vals->sum('tot_selfsmall')); ?></td>
        <?php endif; ?>
        <td><?php echo e($data->tot_selfsmall); ?></td>
        <td><?php echo e($data->tot_selfsmall + $prev_vals->sum('tot_selfsmall')); ?></td>
    </tr>
    <tr style="background-color: cornflowerblue; color: black;">
        <th></th>
        <td></td>
        <th>Total</th>
        <td></td>

        <td>No.</td>
        <?php if($prev_vals == null): ?>
            <th>0</th>
        <?php else: ?>
            <td><?php echo e($prev_vals->sum('tot_selsmall')); ?></td>
        <?php endif; ?>
        <th><?php echo e($data->tot_selsmall); ?></th>
        <th><?php echo e($data->tot_selsmall + $prev_vals->sum('tot_selsmall')); ?></th>
    </tr>

    <tr>
        <th>3.3.4</th>
        <th>Total Number of Contracted Service Providers of IT Solutions</th>
        <th></th>
        <th></th>
        <th>No.</th>
        <?php if($prev_vals == null): ?>
            <th>0</th>
        <?php else: ?>
            <th><?php echo e($prev_vals->sum('tot_ser_pro')); ?></th>
        <?php endif; ?>
        <th><?php echo e($data->tot_ser_pro); ?></th>
        <th><?php echo e($data->tot_ser_pro + $prev_vals->sum('tot_ser_pro')); ?></th>
    </tr>

    <tr>
        <th>3.3.5</th>
        <th>Total Number of Firms that Confirm Receipt of IT Solutions</th>
        <th></th>
        <th></th>
        <th>No.</th>
        <?php if($prev_vals == null): ?>
            <th>0</th>
        <?php else: ?>
            <th><?php echo e($prev_vals->sum('tot_conf')); ?></th>
        <?php endif; ?>
        <th><?php echo e($data->tot_conf); ?></th>
        <th><?php echo e($data->tot_conf + $prev_vals->sum('tot_conf')); ?></th>
    </tr>

    <tr>
        <th>3.3.5.1</th>
        <th rowspan="2">Micro Scale Firms</th>
        <th>Male Owners</th>
        <td></td>
        <td>No.</td>
        <?php if($prev_vals == null): ?>
            <th>0</th>
        <?php else: ?>
            <td><?php echo e($prev_vals->sum('tot_confmmicro')); ?></td>
        <?php endif; ?>
        <td><?php echo e($data->tot_confmmicro); ?></td>
        <td><?php echo e($data->tot_confmmicro + $prev_vals->sum('tot_confmmicro')); ?></td>
    </tr>
    <tr>
        <th></th>
        <th>Female Owners</th>
        <td></td>
        <td>No.</td>
        <?php if($prev_vals == null): ?>
            <th>0</th>
        <?php else: ?>
            <td><?php echo e($prev_vals->sum('tot_conffmicro')); ?></td>
        <?php endif; ?>
        <td><?php echo e($data->tot_conffmicro); ?></td>
        <td><?php echo e($data->tot_conffmicro + $prev_vals->sum('tot_conffmicro')); ?></td>
    </tr>
    <tr style="background-color: cornflowerblue; color: black;">
        <th></th>
        <td></td>
        <th>Total</th>
        <td></td>

        <td>No.</td>
        <?php if($prev_vals == null): ?>
            <th>0</th>
        <?php else: ?>
            <td><?php echo e($prev_vals->sum('tot_confmicro')); ?></td>
        <?php endif; ?>
        <th><?php echo e($data->tot_confmicro); ?></th>
        <th><?php echo e($data->tot_confmicro + $prev_vals->sum('tot_confmicro')); ?></th>
    </tr>
    <tr>
        <th>3.3.5.2</th>
        <th rowspan="2">Small Scale Firms</th>
        <th>Male Owners</th>
        <td></td>
        <td>No.</td>
        <?php if($prev_vals == null): ?>
            <th>0</th>
        <?php else: ?>
            <td><?php echo e($prev_vals->sum('tot_confmsmall')); ?></td>
        <?php endif; ?>
        <td><?php echo e($data->tot_confmsmall); ?></td>
        <td><?php echo e($data->tot_confmsmall + $prev_vals->sum('tot_confmsmall')); ?></td>
    </tr>
    <tr>
        <th></th>
        <th>Female Owners</th>
        <td></td>
        <td>No.</td>
        <?php if($prev_vals == null): ?>
            <th>0</th>
        <?php else: ?>
            <td><?php echo e($prev_vals->sum('tot_conffsmall')); ?></td>
        <?php endif; ?>
        <td><?php echo e($data->tot_conffsmall); ?></td>
        <td><?php echo e($data->tot_conffsmall + $prev_vals->sum('tot_conffsmall')); ?></td>
    </tr>
    <tr style="background-color: cornflowerblue; color: black;">
        <th></th>
        <td></td>
        <th>Total</th>
        <td></td>

        <td>No.</td>
        <?php if($prev_vals == null): ?>
            <th>0</th>
        <?php else: ?>
            <td><?php echo e($prev_vals->sum('tot_confsmall')); ?></td>
        <?php endif; ?>
        <th><?php echo e($data->tot_confsmall); ?></th>
        <th><?php echo e($data->tot_confsmall + $prev_vals->sum('tot_confsmall')); ?></th>
    </tr>


    <tr>
        <th>3.3.6</th>
        <th>Total Number of Instances of Technology Deployment to Support Beneficiaries</th>
        <th></th>
        <th></th>
        <th>No.</th>
        <?php if($prev_vals == null): ?>
            <th>0</th>
        <?php else: ?>
            <th><?php echo e($prev_vals->sum('tot_tech')); ?></th>
        <?php endif; ?>
        <th><?php echo e($data->tot_tech); ?></th>
        <th><?php echo e($data->tot_tech + $prev_vals->sum('tot_tech')); ?></th>
    </tr>

    <tr>
        <th>3.3.6.1</th>
        <th rowspan="2">Micro Scale Firms</th>
        <th>Male Owners</th>
        <td></td>
        <td>No.</td>
        <?php if($prev_vals == null): ?>
            <th>0</th>
        <?php else: ?>
            <td><?php echo e($prev_vals->sum('tot_techmmicro')); ?></td>
        <?php endif; ?>
        <td><?php echo e($data->tot_techmmicro); ?></td>
        <td><?php echo e($data->tot_techmmicro + $prev_vals->sum('tot_techmmicro')); ?></td>
    </tr>
    <tr>
        <th></th>
        <th>Female Owners</th>
        <td></td>
        <td>No.</td>
        <?php if($prev_vals == null): ?>
            <th>0</th>
        <?php else: ?>
            <td><?php echo e($prev_vals->sum('tot_techfmicro')); ?></td>
        <?php endif; ?>
        <td><?php echo e($data->tot_techfmicro); ?></td>
        <td><?php echo e($data->tot_techfmicro + $prev_vals->sum('tot_techfmicro')); ?></td>
    </tr>
    <tr style="background-color: cornflowerblue; color: black;">
        <th></th>
        <td></td>
        <th>Total</th>
        <td></td>

        <td>No.</td>
        <?php if($prev_vals == null): ?>
            <th>0</th>
        <?php else: ?>
            <td><?php echo e($prev_vals->sum('tot_techmicro')); ?></td>
        <?php endif; ?>
        <th><?php echo e($data->tot_techmicro); ?></th>
        <th><?php echo e($data->tot_techmicro + $prev_vals->sum('tot_techmicro')); ?></th>
    </tr>
    <tr>
        <th>3.3.6.2</th>
        <th rowspan="2">Small Scale Firms</th>
        <th>Male Owners</th>
        <td></td>
        <td>No.</td>
        <?php if($prev_vals == null): ?>
            <th>0</th>
        <?php else: ?>
            <td><?php echo e($prev_vals->sum('tot_techmsmall')); ?></td>
        <?php endif; ?>
        <td><?php echo e($data->tot_techmsmall); ?></td>
        <td><?php echo e($data->tot_techmsmall + $prev_vals->sum('tot_techmsmall')); ?></td>
    </tr>
    <tr>
        <th></th>
        <th>Female Owners</th>
        <td></td>
        <td>No.</td>
        <?php if($prev_vals == null): ?>
            <th>0</th>
        <?php else: ?>
            <td><?php echo e($prev_vals->sum('tot_techfsmall')); ?></td>
        <?php endif; ?>
        <td><?php echo e($data->tot_techfsmall); ?></td>
        <td><?php echo e($data->tot_techfsmall + $prev_vals->sum('tot_techfsmall')); ?></td>
    </tr>
    <tr style="background-color: cornflowerblue; color: black;">
        <th></th>
        <td></td>
        <th>Total</th>
        <td></td>

        <td>No.</td>
        <?php if($prev_vals == null): ?>
            <th>0</th>
        <?php else: ?>
            <td><?php echo e($prev_vals->sum('tot_techsmall')); ?></td>
        <?php endif; ?>
        <th><?php echo e($data->tot_techsmall); ?></th>
        <th><?php echo e($data->tot_techsmall + $prev_vals->sum('tot_techsmall')); ?></th>
    </tr>

    <tr>
        <th>3.3.7</th>
        <th>Total Number of Firms Receiving Conditional Grants to Support IT Enhancement</th>
        <th></th>
        <th></th>
        <th>No.</th>
        <?php if($prev_vals == null): ?>
            <th>0</th>
        <?php else: ?>
            <th><?php echo e($prev_vals->sum('tot_rec')); ?></th>
        <?php endif; ?>
        <th><?php echo e($data->tot_rec); ?></th>
        <th><?php echo e($data->tot_rec + $prev_vals->sum('tot_rec')); ?></th>
    </tr>
    <tr>
        <th>3.3.7.1</th>
        <th rowspan="2">Micro Scale Firms</th>
        <th>Male Owners</th>
        <td></td>
        <td>No.</td>
        <?php if($prev_vals == null): ?>
            <th>0</th>
        <?php else: ?>
            <td><?php echo e($prev_vals->sum('tot_recmmicro')); ?></td>
        <?php endif; ?>
        <td><?php echo e($data->tot_recmmicro); ?></td>
        <td><?php echo e($data->tot_recmmicro + $prev_vals->sum('tot_recmmicro')); ?></td>
    </tr>
    <tr>
        <th></th>
        <th>Female Owners</th>
        <td></td>
        <td>No.</td>
        <?php if($prev_vals == null): ?>
            <th>0</th>
        <?php else: ?>
            <td><?php echo e($prev_vals->sum('tot_recfmicro')); ?></td>
        <?php endif; ?>
        <td><?php echo e($data->tot_recfmicro); ?></td>
        <td><?php echo e($data->tot_recfmicro + $prev_vals->sum('tot_recfmicro')); ?></td>
    </tr>
    <tr style="background-color: cornflowerblue; color: black;">
        <th></th>
        <td></td>
        <th>Total</th>
        <td></td>

        <td>No.</td>
        <?php if($prev_vals == null): ?>
            <th>0</th>
        <?php else: ?>
            <td><?php echo e($prev_vals->sum('tot_recmicro')); ?></td>
        <?php endif; ?>
        <th><?php echo e($data->tot_recmicro); ?></th>
        <th><?php echo e($data->tot_recmicro + $prev_vals->sum('tot_recmicro')); ?></th>
    </tr>
    <tr>
        <th>3.3.7.2</th>
        <th rowspan="2">Small Scale Firms</th>
        <th>Male Owners</th>
        <td></td>
        <td>No.</td>
        <?php if($prev_vals == null): ?>
            <th>0</th>
        <?php else: ?>
            <td><?php echo e($prev_vals->sum('tot_recmsmall')); ?></td>
        <?php endif; ?>
        <td><?php echo e($data->tot_recmsmall); ?></td>
        <td><?php echo e($data->tot_recmsmall + $prev_vals->sum('tot_recmsmall')); ?></td>
    </tr>
    <tr>
        <th></th>
        <th>Female Owners</th>
        <td></td>
        <td>No.</td>
        <?php if($prev_vals == null): ?>
            <th>0</th>
        <?php else: ?>
            <td><?php echo e($prev_vals->sum('tot_recfsmall')); ?></td>
        <?php endif; ?>
        <td><?php echo e($data->tot_recfsmall); ?></td>
        <td><?php echo e($data->tot_recfsmall + $prev_vals->sum('tot_recfsmall')); ?></td>
    </tr>
    <tr style="background-color: cornflowerblue; color: black;">
        <th></th>
        <td></td>
        <th>Total</th>
        <td></td>

        <td>No.</td>
        <?php if($prev_vals == null): ?>
            <th>0</th>
        <?php else: ?>
            <td><?php echo e($prev_vals->sum('tot_recsmall')); ?></td>
        <?php endif; ?>
        <th><?php echo e($data->tot_recsmall); ?></th>
        <th><?php echo e($data->tot_recsmall + $prev_vals->sum('tot_recsmall')); ?></th>
    </tr>

    <tr>
        <th>3.3.8</th>
        <th>Amount Disbursed to Service Providers of IT Solutions (on behalf of Beneficiary Firms)</th>
        <th></th>
        <th></th>
        <th>No.</th>
        <?php if($prev_vals == null): ?>
            <th>0</th>
        <?php else: ?>
            <th><?php echo e($prev_vals->sum('tot_dis')); ?></th>
        <?php endif; ?>
        <th><?php echo e($data->tot_dis); ?></th>
        <th><?php echo e($data->tot_dis + $prev_vals->sum('tot_dis')); ?></th>
    </tr>
    <tr>
        <th>3.3.8.1</th>
        <th rowspan="2">Micro Scale Firms</th>
        <th>Male Owners</th>
        <td></td>
        <td>No.</td>
        <?php if($prev_vals == null): ?>
            <th>0</th>
        <?php else: ?>
            <td><?php echo e($prev_vals->sum('tot_dismmicro')); ?></td>
        <?php endif; ?>
        <td><?php echo e($data->tot_dismmicro); ?></td>
        <td><?php echo e($data->tot_dismmicro + $prev_vals->sum('tot_dismmicro')); ?></td>
    </tr>
    <tr>
        <th></th>
        <th>Female Owners</th>
        <td></td>
        <td>No.</td>
        <?php if($prev_vals == null): ?>
            <th>0</th>
        <?php else: ?>
            <td><?php echo e($prev_vals->sum('tot_disfmicro')); ?></td>
        <?php endif; ?>
        <td><?php echo e($data->tot_disfmicro); ?></td>
        <td><?php echo e($data->tot_disfmicro + $prev_vals->sum('tot_disfmicro')); ?></td>
    </tr>
    <tr style="background-color: cornflowerblue; color: black;">
        <th></th>
        <td></td>
        <th>Total</th>
        <td></td>

        <td>No.</td>
        <?php if($prev_vals == null): ?>
            <th>0</th>
        <?php else: ?>
            <td><?php echo e($prev_vals->sum('tot_dismicro')); ?></td>
        <?php endif; ?>
        <th><?php echo e($data->tot_dismicro); ?></th>
        <th><?php echo e($data->tot_dismicro + $prev_vals->sum('tot_dismicro')); ?></th>
    </tr>
    <tr>
        <th>3.3.8.2</th>
        <th rowspan="2">Small Scale Firms</th>
        <th>Male Owners</th>
        <td></td>
        <td>No.</td>
        <?php if($prev_vals == null): ?>
            <th>0</th>
        <?php else: ?>
            <td><?php echo e($prev_vals->sum('tot_dismsmall')); ?></td>
        <?php endif; ?>
        <td><?php echo e($data->tot_dismsmall); ?></td>
        <td><?php echo e($data->tot_dismsmall + $prev_vals->sum('tot_dismsmall')); ?></td>
    </tr>
    <tr>
        <th></th>
        <th>Female Owners</th>
        <td></td>
        <td>No.</td>
        <?php if($prev_vals == null): ?>
            <th>0</th>
        <?php else: ?>
            <td><?php echo e($prev_vals->sum('tot_disfsmall')); ?></td>
        <?php endif; ?>
        <td><?php echo e($data->tot_disfsmall); ?></td>
        <td><?php echo e($data->tot_disfsmall + $prev_vals->sum('tot_disfsmall')); ?></td>
    </tr>
    <tr style="background-color: cornflowerblue; color: black;">
        <th></th>
        <td></td>
        <th>Total</th>
        <td></td>

        <td>No.</td>
        <?php if($prev_vals == null): ?>
            <th>0</th>
        <?php else: ?>
            <td><?php echo e($prev_vals->sum('tot_dissmall')); ?></td>
        <?php endif; ?>
        <th><?php echo e($data->tot_dissmall); ?></th>
        <th><?php echo e($data->tot_dissmall + $prev_vals->sum('tot_dissmall')); ?></th>
    </tr>

    </tbody>
</table>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/fcsu_me/resources/views/dps/enhancement_table.blade.php ENDPATH**/ ?>