<table class="table table-bordered" id="dataTable">
    <thead style="background-color: cornflowerblue; color: white">
    <tr>
        <th colspan="8"><?php echo e(Auth::user()->states->state); ?> <?php echo e($data->dli->title); ?> Submission for <?php echo e($data->months->date); ?></th>
    </tr>
    <tr>
        <th>Dli</th>
        <th colspan="2">Disbursement Indicator</th>
        <th></th>
        <th>Unit of Measurement</th>
        <th>Previous (as at <?php echo e($old_rec->months->date); ?> )</th>
        <th>Current (as at <?php echo e($data->months->date); ?> )</th>
        <th>Total</th>
    </tr>
    </thead>
    <tbody>
    <tr>
        <th>2.4.1</th>
        <th>Total Number of FCAs Sensitized and Mobilized</th>
        <th></th>
        <th></th>
        <th>No.</th>
        <?php if($prev_vals == null): ?>
            <th>0</th>
        <?php else: ?>
            <th><?php echo e($prev_vals->sum('tot_microfcasense')); ?></th>
        <?php endif; ?>
        <th><?php echo e($data->tot_microfcasense); ?></th>
        <th><?php echo e($data->tot_microfcasense + $prev_vals->sum('tot_microfcasense')); ?></th>
    </tr>
    <tr>
        <th>2.4.2</th>
        <th>Total Number of CARP Prepared </th>
        <th></th>
        <th></th>
        <th>No.</th>
        <?php if($prev_vals == null): ?>
            <th>0</th>
        <?php else: ?>
            <th><?php echo e($prev_vals->sum('tot_carp_prep')); ?></th>
        <?php endif; ?>
        <th><?php echo e($data->tot_carp_prep); ?></th>
        <th><?php echo e($data->tot_carp_prep + $prev_vals->sum('tot_carp_prep')); ?></th>
    </tr>

    <tr>
        <th>2.4.3</th>
        <th>Total Number of CARP Approved</th>
        <th></th>
        <th></th>
        <th>No.</th>
        <?php if($prev_vals == null): ?>
            <th>0</th>
        <?php else: ?>
            <th><?php echo e($prev_vals->sum('tot_carp_approv')); ?></th>
        <?php endif; ?>
        <th><?php echo e($data->tot_carp_approv); ?></th>
        <th><?php echo e($data->tot_carp_approv + $prev_vals->sum('tot_carp_approv')); ?></th>
    </tr>

    <tr>
        <th>2.4.4</th>
        <th>Total Number of Existing Wet Markets with Upgraded Water and Sanitation Services</th>
        <th></th>
        <th></th>
        <th>No.</th>
        <?php if($prev_vals == null): ?>
            <th>0</th>
        <?php else: ?>
            <th><?php echo e($prev_vals->sum('tot_exist_wet_mark')); ?></th>
        <?php endif; ?>
        <th><?php echo e($data->tot_exist_wet_mark); ?></th>
        <th><?php echo e($data->tot_exist_wet_mark + $prev_vals->sum('tot_exist_wet_mark')); ?></th>
    </tr>

    <tr>
        <th>2.2.5</th>
        <th rowspan="2">Total Number of Sellers Benefitting from Upgraded Wet Markets</th>
        <th>Female</th>
        <td></td>
        <td>No.</td>
        <?php if($prev_vals == null): ?>
            <th>0</th>
        <?php else: ?>
            <td><?php echo e($prev_vals->sum('tot_fsellersbene')); ?></td>
        <?php endif; ?>
        <td><?php echo e($data->tot_fsellersbene); ?></td>
        <td><?php echo e($data->tot_fsellersbene + $prev_vals->sum('tot_fsellersbene')); ?></td>
    </tr>
    <tr>
        <th></th>
        <th>Male</th>
        <td></td>
        <td>No.</td>
        <?php if($prev_vals == null): ?>
            <th>0</th>
        <?php else: ?>
            <td><?php echo e($prev_vals->sum('tot_msellersbene')); ?></td>
        <?php endif; ?>
        <td><?php echo e($data->tot_msellersbene); ?></td>
        <td><?php echo e($data->tot_msellersbene + $prev_vals->sum('tot_msellersbene')); ?></td>
    </tr>
    <tr style="background-color: cornflowerblue; color: black;">
        <th></th>
        <td></td>
        <th>Total</th>
        <td></td>

        <td>No.</td>
        <?php if($prev_vals == null): ?>
            <th>0</th>
        <?php else: ?>
            <td><?php echo e($prev_vals->sum('tot_sellersbene')); ?></td>
        <?php endif; ?>
        <th><?php echo e($data->tot_sellersbene); ?></th>
        <th><?php echo e($data->tot_sellersbene + $prev_vals->sum('tot_sellersbene')); ?></th>
    </tr>

    </tbody>
</table>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/fcsu_me/resources/views/dps/wetmarket_table.blade.php ENDPATH**/ ?>