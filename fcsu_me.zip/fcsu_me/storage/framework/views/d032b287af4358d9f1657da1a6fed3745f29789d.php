<table class="table table-bordered" id="dataTable">
    <thead style="background-color: cornflowerblue; color: white">
    <tr>
        <th>Dli</th>
        <th colspan="2">Disbursement Indicator</th>
        <th></th>
        <th>Unit of Measurement</th>
        <th>Previous (as at <?php echo e($old_rec->months->date); ?> )</th>
        <th>Current (as at <?php echo e($data->months->date); ?>)</th>
        <th>Total</th>
    </tr>
    </thead>
    <tbody>
    <tr>
        <th>1.3.1</th>
        <th rowspan="2">Total Number of Beneficiaries Mined from Agreed Register</th>
        <th>Female</th>
        <td></td>
        <td>No.</td>
        <?php if($prev_vals == null): ?>
            <th>0</th>
        <?php else: ?>
            <td><?php echo e($prev_vals->sum('f_mined')); ?></td>
        <?php endif; ?>
        <td><?php echo e($data->f_mined); ?></td>
        <td><?php echo e($data->f_mined + $prev_vals->sum('f_mined')); ?></td>
    </tr>
    <tr>
        <th></th>
        <th>Male</th>
        <td></td>
        <td>No.</td>
        <?php if($prev_vals == null): ?>
            <th>0</th>
        <?php else: ?>
            <td><?php echo e($prev_vals->sum('m_mined')); ?></td>
        <?php endif; ?>
        <td><?php echo e($data->m_mined); ?></td>
        <td><?php echo e($data->m_mined + $prev_vals->sum('m_mined')); ?></td>
    </tr>
    <tr style="background-color: cornflowerblue; color: black;">
        <th></th>
        <td></td>
        <th>Total</th>
        <td></td>

        <td>No.</td>
        <?php if($prev_vals == null): ?>
            <th>0</th>
        <?php else: ?>
            <td><?php echo e($prev_vals->sum('tot_mined')); ?></td>
        <?php endif; ?>
        <th><?php echo e($data->tot_mined); ?></th>
        <th><?php echo e($data->tot_mined + $prev_vals->sum('tot_mined')); ?></th>
    </tr>
    <tr>
        <th>1.3.2</th>
        <th rowspan="2">Total Number of Mined Beneficiaries Validated</th>
        <th>Female</th>
        <td></td>
        <td>No.</td>
        <?php if($prev_vals == null): ?>
            <th>0</th>
        <?php else: ?>
            <td><?php echo e($prev_vals->sum('f_validated')); ?></td>
        <?php endif; ?>
        <td><?php echo e($data->f_validated); ?></td>
        <td><?php echo e($data->f_validated + $prev_vals->sum('f_validated')); ?></td>
    </tr>
    <tr>
        <th></th>
        <th>Male</th>
        <td></td>
        <td>No.</td>
        <?php if($prev_vals == null): ?>
            <th>0</th>
        <?php else: ?>
            <td><?php echo e($prev_vals->sum('m_validated')); ?></td>
        <?php endif; ?>
        <td><?php echo e($data->m_validated); ?></td>
        <td><?php echo e($data->m_validated + $prev_vals->sum('m_validated')); ?></td>
    </tr>
    <tr style="background-color: cornflowerblue; color: black;">
        <th></th>
        <td></td>
        <th>Total</th>
        <td></td>

        <td>No.</td>
        <?php if($prev_vals == null): ?>
            <th>0</th>
        <?php else: ?>
            <td><?php echo e($prev_vals->sum('tot_validated')); ?></td>
        <?php endif; ?>
        <th><?php echo e($data->tot_validated); ?></th>
        <th><?php echo e($data->tot_validated + $prev_vals->sum('tot_validated')); ?></th>
    </tr>
    <tr>
        <th>1.3.3</th>
        <th rowspan="2">Total Number of Beneficiaries Trained on Livelihood</th>
        <th>Female</th>
        <td></td>
        <td>No.</td>
        <?php if($prev_vals == null): ?>
            <th>0</th>
        <?php else: ?>
            <td><?php echo e($prev_vals->sum('f_train')); ?></td>
        <?php endif; ?>
        <td><?php echo e($data->f_train); ?></td>
        <td><?php echo e($data->f_train + $prev_vals->sum('f_train')); ?></td>
    </tr>
    <tr>
        <th></th>
        <th>Male</th>
        <td></td>
        <td>No.</td>
        <?php if($prev_vals == null): ?>
            <th>0</th>
        <?php else: ?>
            <td><?php echo e($prev_vals->sum('m_train')); ?></td>
        <?php endif; ?>
        <td><?php echo e($data->m_train); ?></td>
        <td><?php echo e($data->m_train + $prev_vals->sum('m_train')); ?></td>
    </tr>
    <tr style="background-color: cornflowerblue; color: black;">
        <th></th>
        <td></td>
        <th>Total</th>
        <td></td>

        <td>No.</td>
        <?php if($prev_vals == null): ?>
            <th>0</th>
        <?php else: ?>
            <td><?php echo e($prev_vals->sum('tot_train')); ?></td>
        <?php endif; ?>
        <th><?php echo e($data->tot_train); ?></th>
        <th><?php echo e($data->tot_train + $prev_vals->sum('tot_train')); ?></th>
    </tr>
    <tr>
        <th>1.3.4</th>
        <th rowspan="2">Total Number of Beneficiaries that have Graduated from Livelihood Training</th>
        <th>Female</th>
        <td></td>
        <td>No.</td>
        <?php if($prev_vals == null): ?>
            <th>0</th>
        <?php else: ?>
            <td><?php echo e($prev_vals->sum('f_grad')); ?></td>
        <?php endif; ?>
        <td><?php echo e($data->f_grad); ?></td>
        <td><?php echo e($data->f_grad + $prev_vals->sum('f_grad')); ?></td>
    </tr>
    <tr>
        <th></th>
        <th>Male</th>
        <td></td>
        <td>No.</td>
        <?php if($prev_vals == null): ?>
            <th>0</th>
        <?php else: ?>
            <td><?php echo e($prev_vals->sum('m_grad')); ?></td>
        <?php endif; ?>
        <td><?php echo e($data->m_grad); ?></td>
        <td><?php echo e($data->m_grad + $prev_vals->sum('m_grad')); ?></td>
    </tr>
    <tr style="background-color: cornflowerblue; color: black;">
        <th></th>
        <td></td>
        <th>Total</th>
        <td></td>

        <td>No.</td>
        <?php if($prev_vals == null): ?>
            <th>0</th>
        <?php else: ?>
            <td><?php echo e($prev_vals->sum('tot_grad')); ?></td>
        <?php endif; ?>
        <th><?php echo e($data->tot_grad); ?></th>
        <th><?php echo e($data->tot_grad + $prev_vals->sum('tot_grad')); ?></th>
    </tr>

    <tr>
        <th>1.3.5</th>
        <th>Total Amount Transferred to PSP</th>
        <th></th>
        <th></th>
        <th>NGN</th>
        <?php if($prev_vals == null): ?>
            <th>0</th>
        <?php else: ?>
            <th><?php echo e(number_format($prev_vals->sum('amt_transpsp'), 2)); ?></th>
        <?php endif; ?>
        <th><?php echo e(number_format($data->amt_transpsp, 2)); ?></th>
        <th><?php echo e(number_format($data->amt_transpsp + $prev_vals->sum('amt_transpsp'), 2)); ?></th>
    </tr>

    <tr>
        <th>1.3.6</th>
        <th rowspan="2">Total Number of Beneficiaries Transferred to PSP for Payment</th>
        <th>Female</th>
        <td></td>
        <td>No.</td>
        <?php if($prev_vals == null): ?>
            <th>0</th>
        <?php else: ?>
            <td><?php echo e($prev_vals->sum('tot_fbeneforpsppay')); ?></td>
        <?php endif; ?>
        <td><?php echo e($data->tot_fbeneforpsppay); ?></td>
        <td><?php echo e($data->tot_fbeneforpsppay + $prev_vals->sum('tot_fbeneforpsppay')); ?></td>
    </tr>
    <tr>
        <th></th>
        <th>Male</th>
        <td></td>
        <td>No.</td>
        <?php if($prev_vals == null): ?>
            <th>0</th>
        <?php else: ?>
            <td><?php echo e($prev_vals->sum('tot_mbeneforpsppay')); ?></td>
        <?php endif; ?>
        <td><?php echo e($data->tot_mbeneforpsppay); ?></td>
        <td><?php echo e($data->tot_mbeneforpsppay + $prev_vals->sum('tot_mbeneforpsppay')); ?></td>
    </tr>
    <tr style="background-color: cornflowerblue; color: black;">
        <th></th>
        <td></td>
        <th>Total</th>
        <td></td>

        <td>No.</td>
        <?php if($prev_vals == null): ?>
            <th>0</th>
        <?php else: ?>
            <td><?php echo e($prev_vals->sum('tot_beneforpsppay')); ?></td>
        <?php endif; ?>
        <th><?php echo e($data->tot_beneforpsppay); ?></th>
        <th><?php echo e($data->tot_beneforpsppay + $prev_vals->sum('tot_beneforpsppay')); ?></th>
    </tr>
    <tr>
        <th>1.3.7</th>
        <th rowspan="2">Total Number of Beneficiaries Supported with Livelihood Grants</th>
        <th>Female</th>
        <td></td>
        <td>No.</td>
        <?php if($prev_vals == null): ?>
            <th>0</th>
        <?php else: ?>
            <td><?php echo e($prev_vals->sum('tot_fbenerecv')); ?></td>
        <?php endif; ?>
        <td><?php echo e($data->tot_fbenerecv); ?></td>
        <td><?php echo e($data->tot_fbenerecv + $prev_vals->sum('tot_fbenerecv')); ?></td>
    </tr>
    <tr>
        <th></th>
        <th>Male</th>
        <td></td>
        <td>No.</td>
        <?php if($prev_vals == null): ?>
            <th>0</th>
        <?php else: ?>
            <td><?php echo e($prev_vals->sum('tot_mbenerecv')); ?></td>
        <?php endif; ?>
        <td><?php echo e($data->tot_mbenerecv); ?></td>
        <td><?php echo e($data->tot_mbenerecv + $prev_vals->sum('tot_mbenerecv')); ?></td>
    </tr>
    <tr style="background-color: cornflowerblue; color: black;">
        <th></th>
        <td></td>
        <th>Total</th>
        <td></td>

        <td>No.</td>
        <?php if($prev_vals == null): ?>
            <th>0</th>
        <?php else: ?>
            <td><?php echo e($prev_vals->sum('tot_benerecv')); ?></td>
        <?php endif; ?>
        <th><?php echo e($data->tot_benerecv); ?></th>
        <th><?php echo e($data->tot_benerecv + $prev_vals->sum('tot_benerecv')); ?></th>
    </tr>

    <tr>
        <th>1.3.8</th>
        <th>Total Amount Paid to Beneficiaries</th>
        <th></th>
        <th></th>
        <th>NGN</th>
        <?php if($prev_vals == null): ?>
            <th>0</th>
        <?php else: ?>
            <th><?php echo e(number_format($prev_vals->sum('tot_paidbene'), 2)); ?></th>
        <?php endif; ?>
        <th><?php echo e(number_format($data->tot_paidbene, 2)); ?></th>
        <th><?php echo e(number_format($data->tot_paidbene + $prev_vals->sum('tot_paidbene'), 2)); ?></th>
    </tr>

    </tbody>
</table>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/fcsu_me/resources/views/dps/livelihoods_table.blade.php ENDPATH**/ ?>