<table class="table table-bordered" id="dataTable">
    <thead>
    <tr>
        <th>#</th>
        <th>State</th>
        <th>DLi</th>
        <th>Status</th>
        <th>Period</th>
        <th>Date</th>
        <th>Action</th>

    </tr>
    </thead>

    <tbody>
    <?php if($data): ?>
        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($d->id); ?></td>
                <td><?php echo e($d->states->state); ?></td>
                <td><?php echo e($d->dli->title); ?></td>
                <td style="color: green; font-weight: bold"><?php echo e($d->status->status); ?></td>
                <td> <?php echo e($d->months->date); ?></td>
                <td><?php echo e(date('d-M-Y', strtotime($d->created_at))); ?></td>

                <td>
                    <?php if(Auth::user()->id == 1 || Auth::user()->roles->first()->id == 17): ?>
                        <a href="<?php echo e(route('agric_assets.show', $d->id)); ?>" class="btn btn-info btn-sm"><i class="fa fa-eye"></i></a>
                        <a href="<?php echo e(route('agric_assets.edit', $d->id)); ?>" class="btn btn-primary btn-sm"><i class="fa fa-edit"></i></a>

                    <?php elseif($d->user_id == Auth::user()->id && $d->status_id != 3): ?>
                        <a href="<?php echo e(route('agric_assets.edit', $d->id)); ?>" class="btn btn-primary btn-sm"><i class="fa fa-edit"></i></a>
                    <?php elseif($d->user_id == Auth::user()->id): ?>

                        <a href="<?php echo e(route('agric_assets.show', $d->id)); ?>" class="btn btn-info btn-sm"><i class="fa fa-eye"></i></a>
                    <?php endif; ?>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
    </tbody>
</table>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/fcsu_me/resources/views/agric_assets/table.blade.php ENDPATH**/ ?>