<?php $__env->startSection('content'); ?>

    <!-- Begin Page Content -->
    <div class="container-fluid">

        <!-- Page Heading -->

        <!-- DataTales Example -->
        <div class="card shadow mb-4">
            <div class="card-header py-3">
                <h4 class="m-0 font-weight-bold text-primary"><?php echo e(Auth::user()->states->state); ?> State General Report Preview
                    <a href="<?php echo e(url()->previous()); ?>" class="float-right btn btn-success btn-sm">Back</a>
                </h4>
            </div>
            <div class="card-body">
                <?php if(Session::has('success')): ?>
                    <p class="text-success"><?php echo e(Session('success')); ?></p>
                <?php endif; ?>
              

                <div class="table-responsive">

                    <form action="<?php echo e(route('sccus.search')); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <div class="card-header col-md-4 col-xs-12" style="background-color: #506dee;">
                            <label for="monthyear" style="color: white;"
                            >Select Month<span style="color: rgb(253, 237, 10);"
                                >(*)</span
                                ></label>
                            <select class="form-control"
                                    name="monthyear" required>
                                <option value="">Select Month</option>
                                <?php $__currentLoopData = $months; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $month): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($month->id); ?>"
                                        <?php echo e($month->date); ?>><?php echo e($month->date); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>

                        </div>
                        <br/>
                        <div class="col-md-8 col-xs-12">
                            <input type="submit" value="Generate Report" class="btn btn-primary btn-sm" />
                        </div>
                    </form>
                </div>


            </div>
        </div>

    </div>
    <!-- /.container-fluid -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<!-- Bootstrap core JavaScript-->


<?php echo $__env->make('layouts/layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/fcsu_me/resources/views/sccus/general_report.blade.php ENDPATH**/ ?>