<table class="table table-bordered" id="dataTable">
    <thead style="background-color: cornflowerblue; color: white">
    <tr>
        <th colspan="8"><?php echo e(Auth::user()->states->state); ?> <?php echo e($data->dli->title); ?> Submission for <?php echo e($data->months->date); ?></th>
    </tr>
    <tr>
        <th>Dli</th>
        <th colspan="2">Disbursement Indicator</th>
        <th></th>
        <th>Unit of Measurement</th>
        <th>Previous (as at <?php echo e($old_rec->months->date); ?> )</th>
        <th>Current (as at <?php echo e($data->months->date); ?> )</th>
        <th>Total</th>
    </tr>
    </thead>

    <tbody>
    <tr>
        <th>1.1.1</th>
        <th rowspan="2">Total Number of Beneficiaries Mined from Agreed Register</th>
        <th>Female</th>
        <td></td>
        <td>No.</td>
        <?php if($data == null): ?>
            <th>0</th>
        <?php else: ?>
            <td><?php echo e($prev_vals->sum('f_mined')); ?></td>
        <?php endif; ?>
        <td><?php echo e($data->f_mined); ?></td>
        <?php if($data != null): ?>
            <td><?php echo e($data->f_mined + $prev_vals->sum('f_mined')); ?></td>
        <?php endif; ?>
    </tr>
    <tr>
        <th></th>
        <th>Male</th>
        <td></td>
        <td>No.</td>
        <?php if($data == null): ?>
            <th>0</th>
        <?php else: ?>
            <td><?php echo e($prev_vals->sum('m_mined')); ?></td>
        <?php endif; ?>
        <td><?php echo e($data->m_mined); ?></td>
        <?php if($data != null): ?>
            <td><?php echo e($data->m_mined + $prev_vals->sum('m_mined')); ?></td>
        <?php endif; ?>
    </tr>
    <tr style="background-color: cornflowerblue; color: black;">
        <th></th>
        <td></td>
        <th>Total</th>
        <td></td>

        <td>No.</td>
        <?php if($data == null): ?>
            <th>0</th>
        <?php else: ?>
            <td><?php echo e($prev_vals->sum('tot_mined')); ?></td>
        <?php endif; ?>
        <th><?php echo e($data->tot_mined); ?></th>
        <?php if($data != null): ?>
            <th><?php echo e($data->tot_mined + $prev_vals->sum('tot_mined')); ?></th>
        <?php endif; ?>
    </tr>

    <tr>
        <th>1.1.2</th>
        <th rowspan="4">Total Number of Beneficiaries Mined disaggregated by vulnerability profile: Aged, Chronically Ill, Urban Poor and People with Special Needs. </th>
        <th>Aged</th>
        <td></td>
        <td>No.</td>
        <?php if($data == null): ?>
            <th>0</th>
        <?php else: ?>
            <td><?php echo e($prev_vals->sum('aged_mined')); ?></td>
        <?php endif; ?>
        <td><?php echo e($data->aged_mined); ?></td>
        <?php if($data != null): ?>
            <td><?php echo e($data->aged_mined +  $prev_vals->sum('aged_mined')); ?></td>
        <?php endif; ?>
    </tr>
    <tr>
        <th></th>
        <th>Chronically ill</th>
        <td></td>
        <td>No.</td>
        <?php if($data == null): ?>
            <th>0</th>
        <?php else: ?>
            <td><?php echo e($prev_vals->sum('chro_mined')); ?></td>
        <?php endif; ?>
        <td><?php echo e($data->chro_mined); ?></td>
        <?php if($data != null): ?>
            <td><?php echo e($data->chro_mined + $prev_vals->sum('chro_mined')); ?></td>
        <?php endif; ?>
    </tr>
    <tr>
        <th></th>
        <th>Urban Poor</th>
        <td></td>
        <td>No.</td>
        <?php if($data == null): ?>
            <th>0</th>
        <?php else: ?>
            <td><?php echo e($prev_vals->sum('urban_mined')); ?></td>
        <?php endif; ?>
        <td><?php echo e($data->urban_mined); ?></td>
        <?php if($data != null): ?>
            <td><?php echo e($data->urban_mined + $prev_vals->sum('urban_mined')); ?></td>
        <?php endif; ?>
    </tr>
    <tr>
        <th></th>
        <th>People with Special Needs</th>
        <td></td>
        <td>No.</td>
        <?php if($data == null): ?>
            <th>0</th>
        <?php else: ?>
            <td><?php echo e($prev_vals->sum('needs_mined')); ?></td>
        <?php endif; ?>
        <td><?php echo e($data->needs_mined); ?></td>
        <?php if($data != null): ?>
            <td><?php echo e($data->needs_mined  + $prev_vals->sum('needs_mined')); ?></td>
        <?php endif; ?>
    </tr>
    <tr style="background-color: cornflowerblue; color: black;">
        <th></th>
        <td></td>
        <th>Total</th>
        <td></td>
        <td>No.</td>


        <th><?php echo e($prev_vals->sum('aged_mined') + $prev_vals->sum('chro_mined') + $prev_vals->sum('urban_mined') + $prev_vals->sum('needs_mined')); ?></th>

        <th><?php echo e($data->aged_mined + $data->chro_mined + $data->urban_mined + $data->needs_mined); ?></th>

        <th><?php echo e($data->aged_mined + $data->chro_mined + $data->urban_mined + $data->needs_mined
        + $prev_vals->sum('aged_mined') + $prev_vals->sum('chro_mined') + $prev_vals->sum('urban_mined') + $prev_vals->sum('needs_mined')); ?></th>

    </tr>

    <tr>
        <th>1.1.3</th>
        <th rowspan="2">Total Number of Mined Beneficiaries Validated</th>
        <th>Female</th>
        <td></td>
        <td>No.</td>
        <?php if($data == null): ?>
            <th>0</th>
        <?php else: ?>
            <td><?php echo e($prev_vals->sum('f_validated')); ?></td>
        <?php endif; ?>
        <td><?php echo e($data->f_validated); ?></td>
        <?php if($data != null): ?>
            <td><?php echo e($data->f_validated + $prev_vals->sum('f_validated')); ?></td>
        <?php endif; ?>
    </tr>
    <tr>
        <th></th>
        <th>Male</th>
        <td></td>
        <td>No.</td>
        <?php if($data == null): ?>
            <th>0</th>
        <?php else: ?>
            <td><?php echo e($prev_vals->sum('m_validated')); ?></td>
        <?php endif; ?>
        <td><?php echo e($data->m_validated); ?></td>
        <?php if($data != null): ?>
            <td><?php echo e($data->m_validated + $prev_vals->sum('m_validated')); ?></td>
        <?php endif; ?>
    </tr>
    <tr style="background-color: cornflowerblue; color: black;">
        <th></th>
        <td></td>
        <th>Total</th>
        <td></td>
        <td>No.</td>
        <?php if($data == null): ?>
            <th>0</th>
        <?php else: ?>
            <td><?php echo e($prev_vals->sum('tot_validated')); ?></td>
        <?php endif; ?>
        <th><?php echo e($data->tot_validated); ?></th>
        <?php if($data != null): ?>
            <th><?php echo e($data->tot_validated + $prev_vals->sum('tot_validated')); ?></th>
        <?php endif; ?>
    </tr>

    <tr>
        <th rowspan="8">1.1.4</th>
        <th rowspan="7">Total Number of Beneficiaries Enrolled disaggregated by vulnerability profile: Aged, Chronically ill, Urban Poor and People with Special Needs </th>
        <th rowspan="2">Aged</th>
        <th>Female</th>
        <td>No.</td>
        <?php if($data == null): ?>
            <th>0</th>
        <?php else: ?>
            <td><?php echo e($prev_vals->sum('aged_fenrolled')); ?></td>
        <?php endif; ?>
        <td><?php echo e($data->aged_fenrolled); ?></td>
        <?php if($data != null): ?>
            <td><?php echo e($data->aged_fenrolled + $prev_vals->sum('aged_fenrolled')); ?></td>
    <?php endif; ?>
    </tr>
    <tr>

        <th>Male</th>
        <td>No.</td>
        <?php if($data == null): ?>
            <th>0</th>
        <?php else: ?>
            <td><?php echo e($prev_vals->sum('aged_menrolled')); ?></td>
        <?php endif; ?>
        <td><?php echo e($data->aged_menrolled); ?></td>
        <?php if($data != null): ?>
            <td><?php echo e($data->aged_menrolled + $prev_vals->sum('aged_menrolled')); ?></td>
        <?php endif; ?>
    </tr>


    <tr>

        <th rowspan="2">Chronically ill</th>
        <th>Female</th>
        <td>No.</td>
        <?php if($data == null): ?>
            <th>0</th>
        <?php else: ?>
            <td><?php echo e($prev_vals->sum('chro_fenrolled')); ?></td>
        <?php endif; ?>
        <td><?php echo e($data->chro_fenrolled); ?></td>
        <?php if($data != null): ?>
            <td><?php echo e($data->chro_fenrolled + $prev_vals->sum('chro_fenrolled')); ?></td>
    <?php endif; ?>
    </tr>
    <tr>

        <th>Male</th>
        <td>No.</td>
        <?php if($data == null): ?>
            <th>0</th>
        <?php else: ?>
            <td><?php echo e($prev_vals->sum('chro_menrolled')); ?></td>
        <?php endif; ?>
        <td><?php echo e($data->chro_menrolled); ?></td>
        <?php if($data != null): ?>
            <td><?php echo e($data->chro_menrolled + $prev_vals->sum('chro_menrolled')); ?></td>
        <?php endif; ?>
    </tr>

    <tr>

        <th rowspan="2">Urban Poor</th>
        <th>Female</th>
        <td>No.</td>
        <?php if($data == null): ?>
            <th>0</th>
        <?php else: ?>
            <td><?php echo e($prev_vals->sum('urban_fenrolled')); ?></td>
        <?php endif; ?>
        <td><?php echo e($data->urban_fenrolled); ?></td>
        <?php if($data != null): ?>
            <td><?php echo e($data->urban_fenrolled + $prev_vals->sum('urban_fenrolled')); ?></td>
    <?php endif; ?>
    </tr>
    <tr>

        <th>Male</th>
        <td>No.</td>
        <?php if($data == null): ?>
            <th>0</th>
        <?php else: ?>
            <td><?php echo e($prev_vals->sum('urban_menrolled')); ?></td>
        <?php endif; ?>
        <td><?php echo e($data->urban_menrolled); ?></td>
        <?php if($data != null): ?>
            <td><?php echo e($data->urban_menrolled + $prev_vals->sum('urban_menrolled')); ?></td>
        <?php endif; ?>
    </tr>

    <tr>

        <th rowspan="2">People with Special Needs</th>
        <th>Female</th>
        <td>No.</td>
        <?php if($data == null): ?>
            <th>0</th>
        <?php else: ?>
            <td><?php echo e($prev_vals->sum('needs_fenrolled')); ?></td>
        <?php endif; ?>
        <td><?php echo e($data->needs_fenrolled); ?></td>
        <?php if($data != null): ?>
            <td><?php echo e($data->needs_fenrolled + $prev_vals->sum('needs_fenrolled')); ?></td>
    <?php endif; ?>
    </tr>
    <tr>
        <th></th>
        <th>Male</th>
        <td>No.</td>
        <?php if($data == null): ?>
            <th>0</th>
        <?php else: ?>
            <td><?php echo e($prev_vals->sum('needs_menrolled')); ?></td>
        <?php endif; ?>
        <td><?php echo e($data->needs_menrolled); ?></td>
        <?php if($data != null): ?>
            <td><?php echo e($data->needs_menrolled + $prev_vals->sum('needs_menrolled')); ?></td>
        <?php endif; ?>
    </tr>

    <tr style="background-color: cornflowerblue; color: black;">
        <th></th>
        <th></th>
        <th>Total</th>
        <th></th>
        <td>No.</td>
        <?php if($data == null): ?>
            <th>0</th>
        <?php else: ?>
            <td><?php echo e($prev_vals->sum('tot_enrolled')); ?></td>
        <?php endif; ?>
        <th><?php echo e($data->tot_enrolled); ?></th>
        <?php if($data != null): ?>
            <th><?php echo e($data->tot_enrolled + $prev_vals->sum('tot_enrolled')); ?></th>
        <?php endif; ?>
    </tr>
    <tr>
        <th>1.1.5</th>
        <th>Total Number of Beneficiaries Paid </th>
        <th></th>
        <th></th>
        <th>NGN</th>
        <?php if($data == null): ?>
            <th>0</th>
        <?php else: ?>
            <th><?php echo e(number_format($prev_vals->sum('amt_transpsp'), 2)); ?></th>
        <?php endif; ?>
        <th><?php echo e(number_format($data->amt_transpsp, 2)); ?></th>
        <?php if($data != null): ?>
            <th><?php echo e(number_format(($data->amt_transpsp + $prev_vals->sum('amt_transpsp')), 2)); ?></th>
        <?php endif; ?>
    </tr>
    <tr>
        <th>1.1.6</th>
        <th rowspan="2">Total Number of Beneficiaries Transferred to PSP for Payment</th>
        <th>Female</th>
        <td></td>
        <td>No.</td>
        <?php if($data == null): ?>
            <th>0</th>
        <?php else: ?>
            <td><?php echo e($prev_vals->sum('tot_fbeneforpsppay')); ?></td>
        <?php endif; ?>
        <td><?php echo e($data->tot_fbeneforpsppay); ?></td>
        <?php if($data != null): ?>
            <td><?php echo e($data->tot_fbeneforpsppay + $prev_vals->sum('tot_fbeneforpsppay')); ?></td>
        <?php endif; ?>
    </tr>
    <tr>
        <th></th>
        <th>Male</th>
        <td></td>
        <td>No.</td>
        <?php if($data == null): ?>
            <th>0</th>
        <?php else: ?>
            <td><?php echo e($prev_vals->sum('tot_mbeneforpsppay')); ?></td>
        <?php endif; ?>
        <td><?php echo e($data->tot_mbeneforpsppay); ?></td>
        <?php if($data != null): ?>
            <td><?php echo e($data->tot_mbeneforpsppay + $prev_vals->sum('tot_mbeneforpsppay')); ?></td>
        <?php endif; ?>
    </tr>
    <tr style="background-color: cornflowerblue; color: black;">
        <th></th>
        <td></td>
        <th>Total</th>
        <td></td>

        <td>No.</td>
        <?php if($data == null): ?>
            <th>0</th>
        <?php else: ?>
            <td><?php echo e($prev_vals->sum('tot_beneforpsppay')); ?></td>
        <?php endif; ?>
        <th><?php echo e($data->tot_beneforpsppay); ?></th>
        <?php if($data != null): ?>
            <th><?php echo e($data->tot_beneforpsppay + $prev_vals->sum('tot_beneforpsppay')); ?></th>
        <?php endif; ?>
    </tr>
    <tr>
        <th rowspan="8">1.1.7</th>
        <th rowspan="7">Total Number of Beneficiaries Transferred to PSP for Payment </th>
        <th rowspan="2">Aged</th>
        <th>Female</th>
        <td>No.</td>
        <?php if($data == null): ?>
            <th>0</th>
        <?php else: ?>
            <td><?php echo e($prev_vals->sum('tot_agedfbeneforpsppay')); ?></td>
        <?php endif; ?>
        <td><?php echo e($data->tot_agedfbeneforpsppay); ?></td>
        <?php if($data != null): ?>
            <td><?php echo e($data->tot_agedfbeneforpsppay + $prev_vals->sum('tot_agedfbeneforpsppay')); ?></td>
    <?php endif; ?>
    </tr>
    <tr>

        <th>Male</th>
        <td>No.</td>
        <?php if($data == null): ?>
            <th>0</th>
        <?php else: ?>
            <td><?php echo e($prev_vals->sum('tot_agedmbeneforpsppay')); ?></td>
        <?php endif; ?>
        <td><?php echo e($data->tot_agedmbeneforpsppay); ?></td>
        <?php if($data != null): ?>
            <td><?php echo e($data->tot_agedmbeneforpsppay + $prev_vals->sum('tot_agedmbeneforpsppay')); ?></td>
        <?php endif; ?>
    </tr>

    <tr>

        <th rowspan="2">Chronically ill</th>
        <th>Female</th>
        <td>No.</td>
        <?php if($data == null): ?>
            <th>0</th>
        <?php else: ?>
            <td><?php echo e($prev_vals->sum('tot_chrofbeneforpsppay')); ?></td>
        <?php endif; ?>
        <td><?php echo e($data->tot_chrofbeneforpsppay); ?></td>
        <?php if($data != null): ?>
            <td><?php echo e($data->tot_chrofbeneforpsppay + $prev_vals->sum('tot_chrofbeneforpsppay')); ?></td>
    <?php endif; ?>
    </tr>
    <tr>

        <th>Male</th>
        <td>No.</td>
        <?php if($data == null): ?>
            <th>0</th>
        <?php else: ?>
            <td><?php echo e($prev_vals->sum('tot_chrombeneforpsppay')); ?></td>
        <?php endif; ?>
        <td><?php echo e($data->tot_chrombeneforpsppay); ?></td>
        <?php if($data != null): ?>
            <td><?php echo e($data->tot_chrombeneforpsppay + $prev_vals->sum('tot_chrombeneforpsppay')); ?></td>
        <?php endif; ?>
    </tr>

    <tr>

        <th rowspan="2">Urban Poor</th>
        <th>Female</th>
        <td>No.</td>
        <?php if($data == null): ?>
            <th>0</th>
        <?php else: ?>
            <td><?php echo e($prev_vals->sum('tot_urbanfbeneforpsppay')); ?></td>
        <?php endif; ?>
        <td><?php echo e($data->tot_urbanfbeneforpsppay); ?></td>
        <?php if($data != null): ?>
            <td><?php echo e($data->tot_urbanfbeneforpsppay + $prev_vals->sum('tot_urbanfbeneforpsppay')); ?></td>
    <?php endif; ?>
    </tr>
    <tr>

        <th>Male</th>
        <td>No.</td>
        <?php if($data == null): ?>
            <th>0</th>
        <?php else: ?>
            <td><?php echo e($prev_vals->sum('tot_urbanmbeneforpsppay')); ?></td>
        <?php endif; ?>
        <td><?php echo e($data->tot_urbanmbeneforpsppay); ?></td>
        <?php if($data != null): ?>
            <td><?php echo e($data->tot_urbanmbeneforpsppay + $prev_vals->sum('tot_urbanmbeneforpsppay')); ?></td>
        <?php endif; ?>
    </tr>

    <tr>

        <th rowspan="2">People with Special Needs</th>
        <th>Female</th>
        <td>No.</td>
        <?php if($data == null): ?>
            <th>0</th>
        <?php else: ?>
            <td><?php echo e($prev_vals->sum('tot_needsfbeneforpsppay')); ?></td>
        <?php endif; ?>
        <td><?php echo e($data->tot_needsfbeneforpsppay); ?></td>
        <?php if($data != null): ?>
            <td><?php echo e($data->tot_needsfbeneforpsppay + $prev_vals->sum('tot_needsfbeneforpsppay')); ?></td>
    <?php endif; ?>
    </tr>
    <tr>
        <th></th>
        <th>Male</th>
        <td>No.</td>
        <?php if($data == null): ?>
            <th>0</th>
        <?php else: ?>
            <td><?php echo e($prev_vals->sum('tot_needsmbeneforpsppay')); ?></td>
        <?php endif; ?>
        <td><?php echo e($data->tot_needsmbeneforpsppay); ?></td>
        <?php if($data != null): ?>
            <td><?php echo e($data->tot_needsmbeneforpsppay + $prev_vals->sum('tot_needsmbeneforpsppay')); ?></td>
        <?php endif; ?>
    </tr>

    <tr style="background-color: cornflowerblue; color: black;">
        <th></th>
        <th></th>
        <th>Total</th>
        <th></th>
        <td>No.</td>
        <?php if($data == null): ?>
            <th>0</th>
        <?php else: ?>
            <td><?php echo e($prev_vals->sum('tot_beneforpsppay')); ?></td>
        <?php endif; ?>
        <th><?php echo e($data->tot_beneforpsppay); ?></th>
        <?php if($data != null): ?>
            <th><?php echo e($data->tot_beneforpsppay + $prev_vals->sum('tot_beneforpsppay')); ?></th>
        <?php endif; ?>
    </tr>

    <tr>
        <th>1.1.8</th>
        <th rowspan="2">Total Number of Beneficiaries Paid</th>
        <th>Female</th>
        <td></td>
        <td>No.</td>
        <?php if($data == null): ?>
            <th>0</th>
        <?php else: ?>
            <td><?php echo e($prev_vals->sum('tot_fbeneforpsppay')); ?></td>
        <?php endif; ?>
        <td><?php echo e($data->tot_fbeneforpsppay); ?></td>
        <?php if($data != null): ?>
            <td><?php echo e($data->tot_fbeneforpsppay + $prev_vals->sum('tot_fbeneforpsppay')); ?></td>
        <?php endif; ?>
    </tr>
    <tr>
        <th></th>
        <th>Male</th>
        <td></td>
        <td>No.</td>

        <td><?php echo e($prev_vals->sum('tot_mbeneforpsppay')); ?></td>

        <td><?php echo e($data->tot_mbeneforpsppay); ?></td>
            <td><?php echo e($data->tot_mbeneforpsppay + $prev_vals->sum('tot_mbeneforpsppay')); ?></td>
    </tr>
    <tr>
        <th></th>
        <th></th>
        <th>Total</th>
        <td></td>
        <td>No.</td>
        <?php if($data == null): ?>
            <th>0</th>
        <?php else: ?>
            <td><?php echo e($prev_vals->sum('tot_mbeneforpsppay') + $prev_vals->sum('tot_fbeneforpsppay')); ?></td>
        <?php endif; ?>
        <td><?php echo e($data->tot_mbeneforpsppay + $data->tot_mbeneforpsppay); ?></td>
        <?php if($data != null): ?>
            <td><?php echo e($data->tot_mbeneforpsppay + $data->tot_mbeneforpsppay + $prev_vals->sum('tot_mbeneforpsppay') + $prev_vals->sum('tot_fbeneforpsppay')); ?></td>
        <?php endif; ?>
    </tr>


    </tbody>
</table>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/fcsu_me/resources/views/dps/socialtransfers_table.blade.php ENDPATH**/ ?>