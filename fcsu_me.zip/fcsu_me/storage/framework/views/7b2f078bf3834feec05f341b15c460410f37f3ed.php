<!DOCTYPE html>
<html>
<head lang="en">
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" />
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.0/jquery.validate.min.js"></script>
    <script
        src="https://code.jquery.com/jquery-3.4.1.js"
        integrity="sha256-WpOohJOqMqqyKL9FccASB9O0KwACQJpFTUBLTYOVvVU="
        crossorigin="anonymous"></script>
    <script>
        function SubForm (){
            $.ajax({
                url:"https://api.apispreadsheets.com/data/OuzCDTw5WeVNCQXO/",
                type:"post",
                data:$("#formid").serializeArray(),
                headers:{
                    accessKey: "d7b748477e3b6de31e764e22e19fdae3",
                    secretKey: "07ce6edf068d49ce819aa86846302dbe"},
                success: function() {
                    location.reload(true);
                    alert("Agricultural Assets(DLI 2.3) Form Data Submitted Successfully");
                },
                error: function() {
                    alert("Network Error: 404");
                }
            });
        }
    </script>
    <title>Agricultural Assets(DLI 2.3)</title>
</head>
<body>
<div class="container p-5 my-5 border">
    <div class="col-md-6 text-right">
        <a href="<?php echo e(url()->previous()); ?>" class="btn btn-lg" style="background-color: #12d3e0;">Back to Result Area</a>
    </div>
    <br />
    <div class="card-header" style="background-color: #1fa366;">
        <h2 style="
          margin-top: 10px;
          margin-left: 10px;
          color: white;
          text-align: center;
        "> M&E-- AGRICULTURAL ASSETS (DLI 2.3) </h2>
    </div>
    <h4 style="text-align: center;">Fill in the information carefully in the appropriate spaces</h4>
    <form method="post" action="<?php echo e(route('agric_assets.store')); ?>" id="formid">
        <?php echo csrf_field(); ?>
        <div class="container border border-success p-4">
            <div class="card-header col-md-4 col-xs-12" style="background-color: #506dee;">
                <label for="states" style="color: white;"
                >Select Month<span style="color: rgb(253, 237, 10);"
                    >(*)</span
                    ></label>
                <select class="form-control"
                        name="monthyear" required>
                    <option value="">Select Month</option>
                    <?php $__currentLoopData = $months; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $month): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($month->id); ?>"
                            <?php echo e($month->date); ?>><?php echo e($month->date); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php if($errors->has('monthyear')): ?>
                    <span class="text-danger text-left"><?php echo e($errors->first('monthyear')); ?></span>
                <?php endif; ?>
            </div>

            <br />
            <div class="row">
                <span class="card-footer bg-success" style="color: white; background-color: #1fa366;"> Total Number of FCAs sensitized and mobilized</span>
                <div class="col-md-4">
                    <label>Micro scale</label>
                    <input type="text" class="form-control fca1" name="tot_microfcasense" id="a" onkeyup="sum()" />
                </div>
                <div class="col-md-4">
                    <label>Small scale</label>
                    <input type="text" class="form-control fca2" name="tot_smallfcasense" id="b" onkeyup="sum()" />
                </div>
                <div class="col-md-4">
                    <label>Total</label>
                    <input type="text" class="form-control to" name="tot_fcasense" id="c" readonly />
                </div>
            </div>
            <br />
            <div class="row">
                <span class="card-footer bg-success" style="color: white; background-color: #1fa366;"> CARP</span>
                <div class="col-md-3">

                    <label>Total Number of CARP Prepared</label>
                    <input type="text" class="form-control carp1" name="tot_carp_prep" id="d" onkeyup="sum()" />
                </div>
                <div class="col-md-3">
                    <label>Total Number of CARP Approved</label>
                    <input type="text" class="form-control carp2" name="tot_carp_approv" id="e" onkeyup="sum()" />
                </div>
                <div class="col-md-3">
                    <label>Attrition (Prepared minus Approved)</label>
                    <input type="text" class="form-control to" name="att_prep_approv" id="f" readonly />
                </div>
                <div class="col-md-3">
                    <br />
                    <label>Attrition %</label>
                    <input type="text" class="form-control to" name="pcent_att_prep_approv" id="f1" readonly />
                </div>
            </div>
            <br />
            <div class="row">
                <span class="card-footer bg-success" style="color: white; background-color: #1fa366;"> Total Number of Farmers who Applied for agricultural Assets </span>
                <div class="col-md-4">
                    <label>Female</label>
                    <input type="text" class="form-control" name="tot_ffar_app_assets" id="g" onkeyup="sum()" />
                </div>
                <div class="col-md-4">
                    <label>Male</label>
                    <input type="text" class="form-control" name="tot_mfar_app_assets" id="h" onkeyup="sum()" />
                </div>
                <div class="col-md-4">
                    <label>Total</label>
                    <input type="text" class="form-control to" name="tot_far_app_assets" id="i" readonly />
                </div>
            </div>
            <br />
            <div class="row">
            <span class="card-footer bg-success" style="color: white;">
              Total Number of Farmers who Received agricultural Assets</span>
                <div class="col-md-3">
                    <br />
                    <label>Female</label>
                    <input type="text" class="form-control" name="tot_ffar_rec_assets" id="j" onkeyup="sum()" />
                </div>
                <div class="col-md-3">
                    <br />
                    <label>Male</label>
                    <input type="text" class="form-control" name="tot_mfar_rec_assets" id="k" onkeyup="sum()" />
                </div>
                <div class="col-md-2">
                    <br />
                    <label>Total</label>
                    <input type="text" class="form-control to" name="tot_far_rec_assets" id="l" readonly />
                </div>
                <div class="col-md-2">
                    <label>Attrition (Applied minus Received)</label>
                    <input type="text" class="form-control to" name="att_far_app_rec" id="m" readonly />
                </div>
                <div class="col-md-2">
                    <br />
                    <label>Attrition %</label>
                    <input type="text" class="form-control to" name="pcent_att_far_app_rec" id="recAtt" readonly />
                </div>
            </div>
            <br />
            <div class="row">
            <span class="card-footer bg-success" style="color: white; background-color: #1fa366;">
              Total Number of Farmers Utilizing agricultural Assets </span>
                <div class="col-md-3">
                    <br />
                    <label>Female</label>
                    <input type="text" class="form-control" name="tot_ffar_util_assets" id="n" onkeyup="sum()" />
                </div>
                <div class="col-md-3">
                    <br />
                    <label>Male</label>
                    <input type="text" class="form-control" name="tot_mfar_util_assets" id="o" onkeyup="sum()" />
                </div>
                <div class="col-md-2">
                    <br />
                    <label>Total</label>
                    <input type="text" class="form-control to" name="tot_far_util_assets" id="p" readonly />
                </div>
                <div class="col-md-2">

                    <label>Attrition (Received minus Utilizing)</label>
                    <input type="text" class="form-control to" name="att_rec_util_assets" id="q" readonly />
                </div>
                <div class="col-md-2">
                    <br />
                    <label>Attrition %</label>
                    <input type="text" class="form-control to" name="pcent_att_rec_util_assets" id="utiAtt" readonly />
                </div>
            </div>
            <input type="hidden" name="timestamp" id="timestamp" />

        </div>
        <br/>
        <div class="col-md-6 col-xs-12">
            <input type="submit" class="btn btn-primary btn-sm" />
        </div>
    </form>
    <br />

</div>

<script type="text/javascript">

    (function($, undefined) {
        "use strict";
        // When ready.
        $(function() {
            var $form = $("#formid");
            var $input = $form.find('input[type="text"]');
            $input.on("keyup", function(event) {
                // When user select text in the document, also abort.
                var selection = window.getSelection().toString();
                if(selection !== "") {
                    return;
                }
                // When the arrow keys are pressed, abort.
                if($.inArray(event.keyCode, [38, 40, 37, 39]) !== -1) {
                    return;
                }
                var $this = $(this);
                // Get the value.
                var input = $this.val();
                var input = input.replace(/[\D\s\._\-]+/g, "");
                input = input ? parseFloat(input, 10) : 0;
                $this.val(function() {
                    return input === 0 ? "0" : input.toLocaleString("en-US");
                });
            });
        });
    })(jQuery);


    $(function() {
        var $form = $("#formid");
        var $input = $form.find('input[type="text"]');

        $input.on("keyup", function (e) {

            // 							FCAs
            var a = parseFloat($(".fca1").val().replace(/[^\d\.\-]/g, ""));
            var b = parseFloat($(".fca2").val().replace(/[^\d\.\-]/g, ""));
            $("#c").val(a + b);

            // 							CARP
            var a = parseFloat($(".carp1").val().replace(/[^\d\.\-]/g, ""));
            var b = parseFloat($(".carp2").val().replace(/[^\d\.\-]/g, ""));
            $("#f").val(a - b);
            var c =  $('#f').val();
            var patt = ((c/a)*100).toFixed(2);
            $('#f1').val(patt);

            // 							applied LIPW
            var a = parseFloat($("#g").val().replace(/[^\d\.\-]/g, ""));
            var b = parseFloat($("#h").val().replace(/[^\d\.\-]/g, ""));
            $("#i").val(a + b);

            // 							received LIPW
            var a = parseFloat($("#j").val().replace(/[^\d\.\-]/g, ""));
            var b = parseFloat($("#k").val().replace(/[^\d\.\-]/g, ""));
            $("#l").val(a + b);
            var c = $('#i').val();
            var d = $('#l').val();
            $("#m").val(c - d);
            var patt = ((d/c)*100).toFixed(2);
            $('#recAtt').val(patt);

            // 							utilizing LIPW
            var a = parseFloat($("#n").val().replace(/[^\d\.\-]/g, ""));
            var b = parseFloat($("#o").val().replace(/[^\d\.\-]/g, ""));
            $("#p").val(a + b);
            var c = $('#l').val();
            var d = $('#p').val();
            $("#q").val(c - d);
            var patt = ((d/c)*100).toFixed(2);
            $('#utiAtt').val(patt);


            // 							check NaN
            $(".to").each(function (i){
                if ($(this).val()  == "NaN"){
                    ($(this).val(0))
                }
            });

        });
    });

    function sum() {

        let state = document.getElementById("states").value;

        let none = "none";
        if(state === "none") {
            document.getElementById("states").style.backgroundColor = "red";
            alert("Error: Select your State");
        } else document.getElementById("states").style.backgroundColor = "white";
    }


    document.getElementById("timestamp").value = new Date().toLocaleString();

</script>
</body>
</html>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/fcsu_me/resources/views/agric_assets/create.blade.php ENDPATH**/ ?>