<!DOCTYPE html>
<html>
<head lang="en">
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" />
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css" />
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.0/jquery.validate.min.js"></script>
    <title>Matching Grants</title>
</head>
<body>
<div class="container p-5 my-5 border">
    <div class="col-md-6 text-right">
        <a href="<?php echo e(url()->previous()); ?>" class="btn btn-lg" style="background-color: #12d3e0;">Back to Result Area</a>
    </div>
    <br />
    <div class="card-header" style="background-color: #0987b9;">
        <h2 style="
            margin-top: 10px;
            margin-left: 10px;
            color: white;
            text-align: center;
          "> M&E-- CREDIT GRANT (DLI 3.1) </h2>
    </div>
    <h4 style="text-align: center;">Fill in the information carefully in the appropriate spaces</h4>
    <form method="post" action="<?php echo e(route('credit_grants.strans', $data->id)); ?>" id="formid">
        <?php echo csrf_field(); ?>
        <?php echo method_field('patch'); ?>
        <div class="container border border-info p-4">
                <div class="row">
                    <div class="card-header col-md-4 col-xs-12" style="background-color: #506dee;">
                        <label for="states" style="color: white;"
                        >Select Your State<span style="color: rgb(253, 237, 10);"
                            >(*)</span
                            ></label>
                        <select class="form-control" disabled
                                name="state_id" required>
                            <option value="">Select State</option>
                            <?php $__currentLoopData = $states; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $state): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option <?php if($data->state_id==$state->id): ?> selected <?php endif; ?>
                                value="<?php echo e($state->id); ?>"><?php echo e($state->state); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <?php if($errors->has('state_id')): ?>
                            <span class="text-danger text-left"><?php echo e($errors->first('state_id')); ?></span>
                        <?php endif; ?>
                    </div>
                    <div class="card-header col-md-4 col-xs-12" style="background-color: #2198b1;">
                        <label for="DPs" style="color: white;"
                        >Select Your DP<span style="color: rgb(253, 237, 10);"
                            >(*)</span
                            ></label>
                        <select class="form-control" disabled
                                name="dp_id" required>
                            <option value="">Select DP</option>
                            <?php $__currentLoopData = $dps; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option <?php if($data->dp_id==$dp->id): ?> selected <?php endif; ?>
                                value="<?php echo e($dp->id); ?>"><?php echo e($dp->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <?php if($errors->has('dp_id')): ?>
                            <span class="text-danger text-left"><?php echo e($errors->first('dp_id')); ?></span>
                        <?php endif; ?>
                    </div>
                    <div class="card-header col-md-4 col-xs-12" style="background-color: #2198b1;">
                        <label for="monthyear" style="color: white;"
                        >Select Month<span style="color: rgb(253, 237, 10);"
                            >(*)</span
                            ></label>
                        <select class="form-control" disabled
                                name="monthyear" required>
                            <option value="">Select Month</option>
                            <?php $__currentLoopData = $months; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $month): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option <?php if($data->monthyear==$month->id): ?> selected <?php endif; ?>
                                value="<?php echo e($month->id); ?>"><?php echo e($month->date); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <?php if($errors->has('monthyear')): ?>
                            <span class="text-danger text-left"><?php echo e($errors->first('monthyear')); ?></span>
                        <?php endif; ?>
                    </div>

                </div>
            <br />
            <!-- ////////////////////////////////////////////////////// -->
            <div class="w3-panel w3-border w3-hover-border-red">
                <br />
                <div class="row" style="color: white; background-color: #9f2b20; padding: 10px;">
              <span class="card-header  col-md-10" style="color: white; background-color: #9f2b20;">
                Total Number of registered firms for matching grants to support post-COVID-19 loans  </span>
                    <div class="col-md-2">
                        <input type="text" class="form-control" value="<?php echo e($data->tot_reg); ?>" name="tot_reg" id="a" readonly/>
                    </div>
                </div>
                <br />
                <!-- ------------------------ -->
                <div class="row">
                    <span class="card-footer " style="color: white; background-color: #0987b9;"> Micro scale Firms</span>
                    <div class="col-md-4">
                        <label>Male Owners</label>
                        <input type="text" class="form-control" value="<?php echo e($data->tot_regmmicro); ?>" name="tot_regmmicro" id="ca" onkeyup="sum()" readonly/>
                    </div>
                    <div class="col-md-4">
                        <label>Female Owners</label>
                        <input type="text" class="form-control" value="<?php echo e($data->tot_regfmicro); ?>" name="tot_regfmicro" id="da" onkeyup="sum()" readonly/>
                    </div>
                    <div class="col-md-4">
                        <label>Total</label>
                        <input type="text" readonly class="form-control to" value="<?php echo e($data->tot_regmicro); ?>" name="tot_regmicro" id="ea" readonly/>
                    </div>
                </div>

                <br />
                <div class="row" >
                    <span class="card-footer " style="color: white; background-color: #0987b9;"> Small Scale Firms </span>
                    <div class="col-md-4">
                        <label>Male Owners</label>
                        <input type="text" class="form-control" value="<?php echo e($data->tot_regmsmall); ?>" name="tot_regmsmall" id="fa" onkeyup="sum()" readonly/>
                    </div>
                    <div class="col-md-4">
                        <label>Female Owners</label>
                        <input type="text" class="form-control" value="<?php echo e($data->tot_regfsmall); ?>" name="tot_regfsmall" id="ga" onkeyup="sum()" readonly/>
                    </div>
                    <div class="col-md-4">
                        <label>Total</label>
                        <input type="text" readonly class="form-control" value="<?php echo e($data->tot_regsmall); ?>" name="tot_regsmall" id="ha" readonly/>
                    </div>
                </div>
                <br />
            </div>
            <br />
            <!-- ---------------------------- -->
            <br />
            <div class="w3-panel w3-border w3-hover-border-red">
                <br />
                <div class="row" style="color: white; background-color: #9f2b20; padding: 10px;">
              <span class="card-header col-md-10 " style="color: white;">
                 Total Number of eligible and verified firms for matching grants to support post-COVID-19 loans </span>
                    <div class="col-md-2">
                        <input type="text" class="form-control" value="<?php echo e($data->tot_eli_ver); ?>" name="tot_eli_ver" id="verified" readonly/>
                    </div>
                </div>
                <br />
                <div class="row">
                    <span class="card-footer " style="color: white; background-color: #0987b9;"> Micro scale Firms</span>
                    <div class="col-md-4">
                        <label>Male Owners</label>
                        <input type="text" class="form-control" value="<?php echo e($data->tot_eli_vermmicro); ?>" name="tot_eli_vermmicro" id="j" onkeyup="sum()" readonly/>
                    </div>
                    <div class="col-md-4">
                        <label>Female Owners</label>
                        <input type="text" class="form-control" value="<?php echo e($data->tot_eli_verfmicro); ?>" name="tot_eli_verfmicro" id="k" onkeyup="sum()" readonly/>
                    </div>
                    <div class="col-md-4">
                        <label>Total</label>
                        <input type="text" readonly class="form-control" value="<?php echo e($data->tot_eli_vermicro); ?>" name="tot_eli_vermicro" id="l" readonly/>
                    </div>
                </div>
                <br />
                <div class="row">
                    <span class="card-footer " style="color: white; background-color: #0987b9;"> Small Scale Firms </span>
                    <div class="col-md-4">
                        <label>Male Owners</label>
                        <input type="text" class="form-control" value="<?php echo e($data->tot_eli_vermsmall); ?>" name="tot_eli_vermsmall" id="m" onkeyup="sum()" readonly/>
                    </div>
                    <div class="col-md-4">
                        <label>Female Owners</label>
                        <input type="text" class="form-control" value="<?php echo e($data->tot_eli_verfsmall); ?>" name="tot_eli_verfsmall" id="n" onkeyup="sum()" readonly/>
                    </div>
                    <div class="col-md-4">
                        <label>Total</label>
                        <input type="text" readonly class="form-control to" value="<?php echo e($data->tot_eli_versmall); ?>" name="tot_eli_versmall" id="o" readonly/>
                    </div>
                </div>
                <br />
                <div class="row">
              <span class="card-header  col-md-8" style="color: white; background-color: #0987b9;">
                Attrition (Receiving Firms minus Verified Firms) </span>
                    <div class="col-md-4">
                        <input type="text" class="form-control to" value="<?php echo e($data->att_reg_minus_ver); ?>" name="att_reg_minus_ver" id="AttritionR-V" readonly />
                    </div>
                </div>
                <br />
            </div>
            <br />

            <!-- ---------------------------- -->
            <!-- ---------------------------- -->

            <!-- ------SELECTED---------------------- -->
            <!-- ---------------------------- -->
            <!-- ---------------------------- -->
            <div class="w3-panel w3-border w3-hover-border-red">
                <br />
                <div class="row" style="color: white; background-color: #9f2b20; padding: 10px;">
              <span class="card-header  col-md-10" style="color: white;">
                Total Number of selected firms for matching grants to support post-COVID-19 loans </span>
                    <div class="col-md-2">
                        <input type="text" class="form-control" value="<?php echo e($data->tot_sel); ?>" name="tot_sel" id="selected" readonly />
                    </div>
                </div>
                <br />
                <div class="row">
                    <span class="card-footer " style="color: white; background-color: #0987b9;"> Micro scale Firms</span>
                    <div class="col-md-4">
                        <label>Male Owners</label>
                        <input type="text" class="form-control" value="<?php echo e($data->tot_selmmicro); ?>" name="tot_selmmicro" id="r" onkeyup="sum()" readonly/>
                    </div>
                    <div class="col-md-4">
                        <label>Female Owners</label>
                        <input type="text" class="form-control" value="<?php echo e($data->tot_selfmicro); ?>" name="tot_selfmicro" id="s" onkeyup="sum()" readonly/>
                    </div>
                    <div class="col-md-4">
                        <label>Total</label>
                        <input type="text" readonly class="form-control" value="<?php echo e($data->tot_selmicro); ?>" name="tot_selmicro" id="t" readonly/>
                    </div>
                </div>
                <br />
                <div class="row">
                    <span class="card-footer " style="color: white; background-color: #0987b9;"> Small Scale Firms </span>
                    <div class="col-md-4">
                        <label>Male Owners</label>
                        <input type="text" class="form-control" value="<?php echo e($data->tot_selmsmall); ?>" name="tot_selmsmall" id="u" onkeyup="sum()" readonly/>
                    </div>
                    <div class="col-md-4">
                        <label>Female Owners</label>
                        <input type="text" class="form-control" value="<?php echo e($data->tot_selfsmall); ?>" name="tot_selfsmall" id="v" onkeyup="sum()" readonly/>
                    </div>
                    <div class="col-md-4">
                        <label>Total</label>
                        <input type="text" readonly class="form-control to" value="<?php echo e($data->tot_selsmall); ?>" name="tot_selsmall" id="w" readonly/>
                    </div>
                </div>
                <br />
                <div class="row">
              <span class="card-header  col-md-8" style="color: white; background-color: #0987b9;">
                Attrition (Verified Firms minus Selected Firms) </span>
                    <div class="col-md-4">
                        <input type="text" class="form-control" value="<?php echo e($data->att_ver_minus_sel); ?>" name="att_ver_minus_sel" id="AttritionV-s" readonly />
                    </div>
                </div>
                <br />
            </div>



            <!-- ------------------ -->
            <!-- ------------------ -->
            <!-- ------------------ -->
            <div class="row">
            <span class="card-header  col-md-10" style="color: white; background-color: #0987b9;">
              Total Number of verified lending financial institutions for matching grants to support post-COVID-19 loans </span>
                <div class="col-md-2">
                    <input type="text" class="form-control" value="<?php echo e($data->tot_ver_len); ?>" name="tot_ver_len" id="x" readonly/>
                </div>
            </div>
            <br />
            <div class="row">
            <span class="card-header  col-md-10" style="color: white; background-color: #0987b9;">
              Total Number of firms with verified new loan records </span>
                <div class="col-md-2">
                    <input type="text" class="form-control" value="<?php echo e($data->tot_ver_newl); ?>" name="tot_ver_newl" id="y" readonly/>
                </div>
            </div>
            <br />
            <div class="row">
                <span class="card-footer " style="color: white; background-color: #0987b9;"> Micro scale Firms</span>
                <div class="col-md-4">
                    <label>Male Owners</label>
                    <input type="text" class="form-control" value="<?php echo e($data->tot_ver_newlmmicro); ?>" name="tot_ver_newlmmicro" id="z" onkeyup="sum()" readonly/>
                </div>
                <div class="col-md-4">
                    <label>Female Owners</label>
                    <input type="text" class="form-control" value="<?php echo e($data->tot_ver_newlfmicro); ?>" name="tot_ver_newlfmicro" id="a1" onkeyup="sum()" readonly/>
                </div>
                <div class="col-md-4">
                    <label>Total</label>
                    <input type="text" readonly class="form-control" value="<?php echo e($data->tot_ver_newlmicro); ?>" name="tot_ver_newlmicro" id="a2" readonly/>
                </div>
            </div>
            <br />
            <div class="row">
                <span class="card-footer " style="color: white; background-color: #0987b9;"> Small Scale Firms </span>
                <div class="col-md-4">
                    <label>Male Owners</label>
                    <input type="text" class="form-control" value="<?php echo e($data->tot_ver_newlmsmall); ?>" name="tot_ver_newlmsmall" id="a3" onkeyup="sum()" readonly/>
                </div>
                <div class="col-md-4">
                    <label>Female Owners</label>
                    <input type="text" class="form-control" value="<?php echo e($data->tot_ver_newlfsmall); ?>" name="tot_ver_newlfsmall" id="a4" onkeyup="sum()" readonly/>
                </div>
                <div class="col-md-4">
                    <label>Total</label>
                    <input type="text" readonly class="form-control" value="<?php echo e($data->tot_ver_newlsmall); ?>" name="tot_ver_newlsmall" id="a5" readonly/>
                </div>
            </div>
            <br />
            <!-- ---------------------------- -->
            <!-- ---------------------------- -->
            <!-- ----RECEIVING -------------- -->

            <div class="w3-panel w3-border w3-hover-border-red">
                <br />
                <div class="row" style="color: white; background-color: #9f2b20; padding: 10px;">
              <span class="card-header col-md-10" style="color: white;">
                 Number of firms receiving conditional capital grant to support new post-COVID 19 loans </span>
                    <div class="col-md-2">
                        <input type="text" class="form-control" value="<?php echo e($data->tot_reccap); ?>" name="tot_reccap" id="b" readonly />
                    </div>
                </div>
                <br />
                <!-- --------------- -->
                <div class="row">
                    <span class="card-footer " style="color: white; background-color: #0987b9;"> Micro scale Firms</span>
                    <div class="col-md-4">
                        <label>Male Owners</label>
                        <input type="text" class="form-control" value="<?php echo e($data->tot_reccap_mmicro); ?>" name="tot_reccap_mmicro" id="cb" onkeyup="sum()" readonly/>
                    </div>
                    <div class="col-md-4">
                        <label>Female Owners</label>
                        <input type="text" class="form-control" value="<?php echo e($data->tot_reccap_fmicro); ?>" name="tot_reccap_fmicro" id="db" onkeyup="sum()" readonly/>
                    </div>
                    <div class="col-md-4">
                        <label>Total</label>
                        <input type="text" readonly class="form-control" value="<?php echo e($data->tot_reccap_micro); ?>" name="tot_reccap_micro" id="eb" readonly/>
                    </div>
                </div>
                <br />
                <div class="row">
                    <span class="card-footer " style="color: white; background-color: #0987b9;"> Small Scale Firms </span>
                    <div class="col-md-4">
                        <label>Male Owners</label>
                        <input type="text" class="form-control" value="<?php echo e($data->tot_reccapmsmall); ?>" name="tot_reccapmsmall" id="fb" onkeyup="sum()" readonly/>
                    </div>
                    <div class="col-md-4">
                        <label>Female Owners</label>
                        <input type="text" class="form-control" value="<?php echo e($data->tot_reccapfsmall); ?>" name="tot_reccapfsmall" id="gb" onkeyup="sum()" readonly/>
                    </div>
                    <div class="col-md-4">
                        <label>Total</label>
                        <input type="text" readonly class="form-control" value="<?php echo e($data->tot_reccap_small); ?>" name="tot_reccap_small" id="hb" readonly/>
                    </div>
                </div>
                <br />
                <!-- ------------------ -->
                <div class="row">
                    <span class="card-header  col-md-8" style="color: white; background-color: #0987b9;"> Attrition (Registered Firms minus Receiving Firms) </span>
                    <div class="col-md-4">
                        <input type="text" class="form-control" value="<?php echo e($data->att_ver_minus_rec); ?>" name="att_ver_minus_rec" id="AttReg_Rec3_1" readonly />
                    </div>
                </div>
                <br />
            </div>
            <!----------------------------------------------------------------------------->
            <!---------------AMOUNT DISBURSED TO LENDING INSTITUTION----------------------->
            <div class="row">
              <span class="card-header  col-md-8" style="color: white; background-color: #0987b9;">
                Amount disbursed to lending financial institutions (on behalf of beneficiary firms) </span>
                <div class="col-md-4">
                    <input type="text" class="form-control" value="<?php echo e($data->amt_dis); ?>" name="amt_dis" id="a14" onkeyup="sum()" readonly/>
                </div>
            </div>
            <br />
            <div class="row">
                <span class="card-header  col-md-8" style="color: white; background-color: #0987b9;"> Micro Scale Firms Total Disbursed </span>
                <div class="col-md-4">
                    <input type="text" class="form-control" value="<?php echo e($data->amt_dismicro); ?>" name="amt_dismicro" id="3-1MTotalDisbursed" onkeyup="sum()" readonly/>
                </div>
            </div>
            <br />
            <div class="row">
                <span class="card-header  col-md-8" style="color: white; background-color: #0987b9;"> Small Scale Firms Total Disbursed </span>
                <div class="col-md-4">
                    <input type="text" class="form-control" value="<?php echo e($data->amt_dissmall); ?>" name="amt_dissmall" id="3-1STotalDisbursed" onkeyup="sum()" readonly/>
                </div>
            </div>
            <br />
            <?php if($data->status_id == 2 && $data->dp_id == Auth::user()->dp_id): ?>
                <div class="card-header col-md-4 col-xs-12" style="background-color: #506dee;">
                    <label for="states" style="color: white;"
                    >Approve status<span style="color: rgb(253, 237, 10);"
                        >(*)</span
                        ></label>
                    <select class="form-control" disabled
                            name="approval_id" required>
                        <option value="">DP Approved</option>

                    </select>
                </div>
            <?php elseif($data->status_id == 3): ?>
                <div class="card-header col-md-4 col-xs-12" style="background-color: #506dee;">
                    <label for="states" style="color: white;"
                    >Submission Status<span style="color: rgb(253, 237, 10);"
                        >(*)</span
                        ></label>
                    <select class="form-control" disabled
                            name="approval_id" required>
                        <option value="">Sent to FCSU</option>

                    </select>
                </div>
            <?php elseif($data->status_id != 2 && $data->dp_id == Auth::user()->dp_id): ?>
                <div class="card-header col-md-4 col-xs-12" style="background-color: #506dee;">
                    <label for="states" style="color: white;"
                    >Approve this submission<span style="color: rgb(253, 237, 10);"
                        >(*)</span
                        ></label>
                    <select class="form-control"
                            name="approval_id" required>
                        <option value="">Select Status</option>
                        <?php $__currentLoopData = $approvals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option <?php if($data->status_id==$status->id): ?> selected <?php endif; ?>
                            value="<?php echo e($status->id); ?>"><?php echo e($status->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php if($errors->has('approval_id')): ?>
                        <span class="text-danger text-left"><?php echo e($errors->first('approval_id')); ?></span>
                    <?php endif; ?>
                </div>

            <?php endif; ?>

        </div>
        <br />
        <input type="hidden" name="timestamp" id="timestamp" />

        <br/>
        <?php if($data->dp_id == Auth::user()->dp_id): ?>
            <div class="col-md-6 col-xs-12">
                <input type="submit" class="btn btn-primary btn-sm" />
            </div>
        <?php endif; ?>

    </form>
    <br />

</div>


<script type="text/javascript">
    src = "https://code.jquery.com/jquery-3.4.1.js";
    integrity = "sha256-WpOohJOqMqqyKL9FccASB9O0KwACQJpFTUBLTYOVvVU=";
    crossorigin = "anonymous";

    function SubForm (){
        $.ajax({
            url:"https://api.apispreadsheets.com/data/1O6ky8rCUyEFzvmM/",
            type:"post",
            data:$("#formid").serializeArray(),
            headers:{
                accessKey: "5cfe9a7d5cb85296c41c7f68d5517e09",
                secretKey: "15bfa6bfd2f56db80bb0424dbcc80ad9"},
            success: function() {
                location.reload(true);
                alert("Credit Grant (DLI 3.1) Form Data Submitted Successfully");
            },
            error: function() {
                alert("Network Error: 404");
            }
        });
    }

    //    function sb(){location.reload(true);alert("Data successfully submitted.");window.location.href = '../';}
    (function($, undefined) {
        "use strict";
        // When ready.
        $(function() {
            var $form = $("#formid");
            var $input = $form.find('input[type="text"]');
            $input.on("keyup", function(event) {
                // When user select text in the document, also abort.
                var selection = window.getSelection().toString();
                if (selection !== "") {
                    return;
                }
                // When the arrow keys are pressed, abort.
                if ($.inArray(event.keyCode, [38, 40, 37, 39]) !== -1) {
                    return;
                }
                var $this = $(this);
                // Get the value.
                var input = $this.val();
                var input = input.replace(/[\D\s\._\-]+/g, "");
                input = input ? parseFloat(input, 10) : 0;
                $this.val(function() {
                    return input === 0 ? "0" : input.toLocaleString("en-US");
                });
            });
        });
    })(jQuery);


    $(function() {
        var $form = $("#formid");
        var $input = $form.find('input[type="text"]');
        $input.on("keyup", function(e) {
            //////////////////////// registered firm //////////////////////////////////
            var a = parseFloat($("#ca").val().replace(/[^\d\.\-]/g, ""));
            var b = parseFloat($("#da").val().replace(/[^\d\.\-]/g, ""));
            var c = parseFloat($("#fa").val().replace(/[^\d\.\-]/g, ""));
            var d = parseFloat($("#ga").val().replace(/[^\d\.\-]/g, ""));
            $("#ea").val(a + b);
            $("#ha").val(c + d);
            $('#a').val(c + d + a + b);

            ///////////////////////// recieving firm //////////////////////////////////
            var a = parseFloat($("#cb").val().replace(/[^\d\.\-]/g, ""));
            var b = parseFloat($("#db").val().replace(/[^\d\.\-]/g, ""));
            var c = parseFloat($("#fb").val().replace(/[^\d\.\-]/g, ""));
            var d = parseFloat($("#gb").val().replace(/[^\d\.\-]/g, ""));
            $("#eb").val(a + b);
            $("#hb").val(c + d);
            $('#b').val(c + d + a + b);
            /////// Attrition
            var e = parseFloat($("#a").val().replace(/[^\d\.\-]/g, ""));
            var f = parseFloat($("#b").val().replace(/[^\d\.\-]/g, ""));
            $('#AttReg_Rec3_1').val(e - f);

            ///////////////////////// verified firm //////////////////////////////////
            var a = parseFloat($("#j").val().replace(/[^\d\.\-]/g, ""));
            var b = parseFloat($("#k").val().replace(/[^\d\.\-]/g, ""));
            var c = parseFloat($("#m").val().replace(/[^\d\.\-]/g, ""));
            var d = parseFloat($("#n").val().replace(/[^\d\.\-]/g, ""));
            $("#l").val(a + b);
            $("#o").val(c + d);
            $('#verified').val(c + d + a + b);
            /////// Attrition
            var e = parseFloat($("#b").val().replace(/[^\d\.\-]/g, ""));
            var f = parseFloat($("#verified").val().replace(/[^\d\.\-]/g, ""));
            $('#AttritionR-V').val(e - f);

            ///////////////////////// selected firm //////////////////////////////////
            var a = parseFloat($("#r").val().replace(/[^\d\.\-]/g, ""));
            var b = parseFloat($("#s").val().replace(/[^\d\.\-]/g, ""));
            var c = parseFloat($("#u").val().replace(/[^\d\.\-]/g, ""));
            var d = parseFloat($("#v").val().replace(/[^\d\.\-]/g, ""));
            $("#t").val(a + b);
            $("#w").val(c + d);
            $('#selected').val(c + d + a + b);
            /////// Attrition
            var e = parseFloat($("#verified").val().replace(/[^\d\.\-]/g, ""));
            var f = parseFloat($("#selected").val().replace(/[^\d\.\-]/g, ""));
            $('#AttritionV-s').val(e - f);

            //-----------------
            var a = parseFloat($("#z").val().replace(/[^\d\.\-]/g, ""));
            var b = parseFloat($("#a1").val().replace(/[^\d\.\-]/g, ""));
            $("#a2").val(a + b);
            var a = parseFloat($("#a3").val().replace(/[^\d\.\-]/g, ""));
            var b = parseFloat($("#a4").val().replace(/[^\d\.\-]/g, ""));
            $("#a5").val(a + b);

            // 							check NaN
            $(".to").each(function(i) {
                if ($(this).val() == "NaN") {
                    ($(this).val(0))
                } else{
                    var $this = $(this);
                    var input = $this.val();
                    var input = input.replace(/[\D\s\._\-]+/g, "");
                    input = input ? parseFloat(input, 10) : 0;
                    $this.val(function() {
                        return input === 0 ? "0" : input.toLocaleString("en-US");
                    });
                }
            });
        });
    });

    function sum() {
        let state = document.getElementById("states").value;

        let none = "none";
        if(state === "none") {
            document.getElementById("states").style.backgroundColor = "red";
            alert("Error: Select your State");
        } else document.getElementById("states").style.backgroundColor = "white";
    }
    // document.getElementById("timestamp").value = new Date(Date.now());
    document.getElementById("timestamp").value = new Date().toLocaleString();

</script>
</body>
</html>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/fcsu_me/resources/views/credit_grants/show.blade.php ENDPATH**/ ?>