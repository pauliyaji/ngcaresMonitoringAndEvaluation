<?php $__env->startSection('content'); ?>

    <!-- Begin Page Content -->
    <div class="container-fluid">

        <!-- Page Heading -->

        <!-- DataTales Example -->
        <div class="card shadow mb-4">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-primary">Add User
                    <a href="<?php echo e(route('roles.index')); ?>" class="float-right btn btn-success btn-sm">View All</a>

                </h6>
            </div>
            <div class="card-body">

                <?php if(Session::has('success')): ?>
                    <p class="text-success"><?php echo e(session('success')); ?></p>
                <?php endif; ?>
                <div class="table-responsive">
                    <form method="post" action="<?php echo e(route('roles.update', $role->id)); ?>">
                        <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                            <?php echo method_field('patch'); ?>
                            <?php echo csrf_field(); ?>
                            <tr>
                                <th>Name</th>
                                <td><input type="text" class="form-control" value="<?php echo e($role->name); ?>" name="name" id="name"/></td>
                            </tr>
                            <tr>
                                <th>Assign Permissions</th>
                                <td>
                                <table class="table table-striped">
                                    <thead>
                                    <th scope="col" width="1%"><input type="checkbox" name="all_permission"></th>
                                    <th scope="col" width="20%">Name</th>
                                    <th scope="col" width="1%">Guard</th>
                                    </thead>

                                    <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td>
                                                <input type="checkbox"
                                                       name="permission[<?php echo e($permission->name); ?>]"
                                                       value="<?php echo e($permission->name); ?>"
                                                       class='permission'
                                                    <?php echo e(in_array($permission->name, $rolePermissions)
                                                        ? 'checked'
                                                        : ''); ?>>
                                            </td>
                                            <td><?php echo e($permission->name); ?></td>
                                            <td><?php echo e($permission->guard_name); ?></td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </table>
                                </td>

                            </tr>
                            <tr>
                                <td colspan="2">
                                    <input type="submit" class="btn btn-primary btn-sm" />
                                </td>
                            </tr>
                        </table>
                    </form>
                </div>
            </div>
        </div>

    </div>
    <!-- /.container-fluid -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- Bootstrap core JavaScript-->

<?php $__env->startSection('scripts'); ?>
    <script type="text/javascript">
        $(document).ready(function() {
            $('[name="all_permission"]').on('click', function() {

                if($(this).is(':checked')) {
                    $.each($('.permission'), function() {
                        $(this).prop('checked',true);
                    });
                } else {
                    $.each($('.permission'), function() {
                        $(this).prop('checked',false);
                    });
                }

            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/fcsu_me/resources/views/roles/edit.blade.php ENDPATH**/ ?>