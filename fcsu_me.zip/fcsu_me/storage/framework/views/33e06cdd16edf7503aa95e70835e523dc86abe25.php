<?php $__env->startSection('content'); ?>

    <!-- Begin Page Content -->
    <div class="container-fluid">

        <!-- Page Heading -->

        <!-- DataTales Example -->
        <div class="card shadow mb-4">
            <div class="card-header py-3">
                <h4 class="m-0 font-weight-bold text-primary"><?php echo e(Auth::user()->states->state); ?> <?php echo e($data->dli->title); ?> Submission for <?php echo e($data->months->date); ?> 
                    <a href="<?php echo e(url()->previous()); ?>" class="float-right btn btn-success btn-sm">Back</a>
                </h4>
            </div>
            <div class="card-body">
                <?php if(Session::has('success')): ?>
                    <p class="text-success"><?php echo e(Session('success')); ?></p>
                <?php endif; ?>
                    <a href="<?php echo e(route('livelihoodsexport', $data->id)); ?>" class="btn btn-primary m-2 me-1">Export Data</a>

                    <div class="table-responsive">

                  <?php echo $__env->make('dps.livelihoods_table', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>


            </div>
        </div>

    </div>
    <!-- /.container-fluid -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<!-- Bootstrap core JavaScript-->


<?php echo $__env->make('layouts/layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/fcsu_me/resources/views/dps/livelihood_report.blade.php ENDPATH**/ ?>