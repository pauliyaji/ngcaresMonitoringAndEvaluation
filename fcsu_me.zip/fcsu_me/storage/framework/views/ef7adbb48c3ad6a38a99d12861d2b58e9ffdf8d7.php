<?php $__env->startSection('content'); ?>
<div class="container-fluid">

    <!-- Page Heading -->
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800">Dashboard</h1>
        <a href="#" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm"><i class="fas fa-download fa-sm text-white-50"></i> Generate Report</a>
    </div>

    <!-- Content Row -->
    <?php if(Auth::user()->roles->first()->id == 17): ?>
    <div class="row">

        <!-- Dli1.1s -->
        <div class="col-xl-3 col-md-6 mb-4">
            <a href="<?php echo e(route('socialtransfers.index')); ?>">
                <div class="card border-left-success shadow h-100 py-2">
                    <div class="card-body">
                        <div class="row no-gutters align-items-center">
                            <div class="col mr-2">
                                <div class="text-xs font-weight-bold text-success text-uppercase mb-1">DLI-1.1 -Submissions - <?php echo e(App\Models\Dli1::count()); ?></div>
                                
                            </div>
                            <div class="col-auto">
                                <i class="fas fa-dollar-sign fa-2x text-gray-300"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </a>
        </div>
        <!-- Dli1.2s -->
        <div class="col-xl-3 col-md-6 mb-4">
            <a href="<?php echo e(route('lipws.index')); ?>">
            <div class="card border-left-success shadow h-100 py-2">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-success text-uppercase mb-1">DLI-1.2 -Submissions - <?php echo e(App\Models\Dli2::count()); ?></div>
                        </div>
                        <div class="col-auto">
                            <i class="fas fa-dollar-sign fa-2x text-gray-300"></i>
                        </div>
                    </div>
                </div>
            </div>
            </a>
        </div>
        <!-- Dli3s -->
        <div class="col-xl-3 col-md-6 mb-4">
            <a href="<?php echo e(route('livelihoods.index')); ?>">
            <div class="card border-left-success shadow h-100 py-2">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-success text-uppercase mb-1">DLI-1.3 -Submissions - <?php echo e(App\Models\Dli3::count()); ?></div>
                        </div>
                        <div class="col-auto">
                            <i class="fas fa-dollar-sign fa-2x text-gray-300"></i>
                        </div>
                    </div>
                </div>
            </div>
            </a>
        </div>
        <!-- Dli1s -->
        <div class="col-xl-3 col-md-6 mb-4">
            <a href="<?php echo e(route('basicservices.index')); ?>">
            <div class="card border-left-success shadow h-100 py-2">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-success text-uppercase mb-1">DLI-1.4 -Submissions - </div>
                        </div>
                        <div class="col-auto">
                            <i class="fas fa-dollar-sign fa-2x text-gray-300"></i>
                        </div>
                    </div>
                </div>
            </div>
            </a>
        </div>

    </div>

    <div class="row">
    <!-- Bookings-->
    <div class="col-xl-3 col-md-6 mb-4">
        <a href="<?php echo e(route('socialtransfers.index')); ?>">
        <div class="card border-left-primary shadow h-100 py-2">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                        <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">Dli 2.1 - Submissions - </div>
                        
                    </div>
                    <div class="col-auto">
                        <i class="fas fa-calendar fa-2x text-gray-300"></i>
                    </div>
                </div>
            </div>
        </div>
        </a>
    </div>
    <!-- Bookings-->
    <div class="col-xl-3 col-md-6 mb-4">
        <a href="<?php echo e(route('socialtransfers.index')); ?>">
        <div class="card border-left-primary shadow h-100 py-2">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                        <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">Dli 2.2 - Submissions - </div>
                    </div>
                    <div class="col-auto">
                        <i class="fas fa-calendar fa-2x text-gray-300"></i>
                    </div>
                </div>
            </div>
        </div>
        </a>
    </div>
    <!-- Bookings-->
    <div class="col-xl-3 col-md-6 mb-4">
        <a href="<?php echo e(route('socialtransfers.index')); ?>">
        <div class="card border-left-primary shadow h-100 py-2">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                        <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">Dli 2.3 - Submissions - </div>
                    </div>
                    <div class="col-auto">
                        <i class="fas fa-calendar fa-2x text-gray-300"></i>
                    </div>
                </div>
            </div>
        </div>
        </a>
    </div>
    <!-- Bookings-->
    <div class="col-xl-3 col-md-6 mb-4">
        <a href="<?php echo e(route('socialtransfers.index')); ?>">
        <div class="card border-left-primary shadow h-100 py-2">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                        <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">Dli 2.4 - Submissions - </div>
                    </div>
                    <div class="col-auto">
                        <i class="fas fa-calendar fa-2x text-gray-300"></i>
                    </div>
                </div>
            </div>
        </div>
        </a>
    </div>
</div>

    <div class="row">
        <!-- Dli3s -->
        <div class="col-xl-3 col-md-6 mb-4">
            <a href="<?php echo e(route('socialtransfers.index')); ?>">
            <div class="card border-left-info shadow h-100 py-2">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-info text-uppercase mb-1">Dli 3.1 - Submissions - </div>
                            <div class="row no-gutters align-items-center">
                                <div class="col-auto">
                                </div>
                                <div class="col">
                                    <div class="progress progress-sm mr-2">
                                        <div class="progress-bar bg-info" role="progressbar" style="width: 50%" aria-valuenow="50" aria-valuemin="0" aria-valuemax="100"></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-auto">
                            <i class="fas fa-clipboard-list fa-2x text-gray-300"></i>
                        </div>
                    </div>
                </div>
            </div>
            </a>
        </div>
        <!-- Rooms -->
        <div class="col-xl-3 col-md-6 mb-4">
            <a href="<?php echo e(route('socialtransfers.index')); ?>">
            <div class="card border-left-info shadow h-100 py-2">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-info text-uppercase mb-1">Dli 3.2 - Submissions - </div>
                            <div class="row no-gutters align-items-center">
                                <div class="col-auto">
                                </div>
                                <div class="col">
                                    <div class="progress progress-sm mr-2">
                                        <div class="progress-bar bg-info" role="progressbar" style="width: 50%" aria-valuenow="50" aria-valuemin="0" aria-valuemax="100"></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-auto">
                            <i class="fas fa-clipboard-list fa-2x text-gray-300"></i>
                        </div>
                    </div>
                </div>
            </div>
            </a>
        </div>
        <!-- Rooms -->
        <div class="col-xl-3 col-md-6 mb-4">
            <a href="<?php echo e(route('socialtransfers.index')); ?>">
            <div class="card border-left-info shadow h-100 py-2">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-info text-uppercase mb-1">Dli 3.3 - Submissions - </div>
                            <div class="row no-gutters align-items-center">
                                <div class="col-auto">
                                </div>
                                <div class="col">
                                    <div class="progress progress-sm mr-2">
                                        <div class="progress-bar bg-info" role="progressbar" style="width: 50%" aria-valuenow="50" aria-valuemin="0" aria-valuemax="100"></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-auto">
                            <i class="fas fa-clipboard-list fa-2x text-gray-300"></i>
                        </div>
                    </div>
                </div>
            </div>
            </a>
        </div>

    </div>
    <?php endif; ?>



</div>

<?php $__env->stopSection(); ?>

    <?php $__env->startSection('scripts'); ?>

        <!-- Bootstrap core JavaScript-->
        <script src="<?php echo e(asset('/vendor/jquery/jquery.min.js')); ?>"></script>
        <script src="<?php echo e(asset('/vendor/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>

        <!-- Core plugin JavaScript-->
        <script src="<?php echo e(asset('/vendor/jquery-easing/jquery.easing.min.js')); ?>"></script>

        <!-- Custom scripts for all pages-->
        <script src="<?php echo e(asset('/js/sb-admin-2.min.js')); ?>"></script>

        <!-- Page level plugins -->
        <script src="<?php echo e(asset('/vendor/chart.js/Chart.min.js')); ?>"></script>
      

        <!-- Page level custom scripts -->
        <script src="<?php echo e(asset('/js/demo/chart-area-demo.js')); ?>"></script>
        <script src="<?php echo e(asset('/js/demo/chart-pie-demo.js')); ?>"></script>

        <?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts/layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/fcsu_me/resources/views/dashboard.blade.php ENDPATH**/ ?>