<table class="table table-bordered" id="dataTable">
    <thead style="background-color: cornflowerblue; color: white">
    <tr>
        <th>Dli</th>
        <th colspan="2">Disbursement Indicator</th>
        <th></th>
        <th>Unit of Measurement</th>
        <th>Previous (as at <?php echo e($old_rec->months->date); ?> )</th>
        <th>Current (as at <?php echo e($data->months->date); ?> )</th>
        <th>Total</th>
    </tr>
    </thead>

    <tbody>
    <tr>
        <th>3.2</th>
        <th>Total Number of Registered Firms that Applied for Operational Grants</th>
        <th></th>
        <th></th>
        <th>No.</th>
        <?php if($prev_vals == null): ?>
            <th>0</th>
        <?php else: ?>
            <th><?php echo e($prev_vals->sum('tot_reg_ops')); ?></th>
        <?php endif; ?>
        <th><?php echo e($data->tot_reg_ops); ?></th>
        <th><?php echo e($data->tot_reg_ops + $prev_vals->sum('tot_reg_ops')); ?></th>
    </tr>
    <tr>
        <th>3.2.1.1</th>
        <th rowspan="2">Micro Scale Firms</th>
        <th>Male Owners</th>
        <td></td>
        <td>No.</td>
        <?php if($prev_vals == null): ?>
            <th>0</th>
        <?php else: ?>
            <td><?php echo e($prev_vals->sum('tot_reg_opsmmicro')); ?></td>
        <?php endif; ?>
        <td><?php echo e($data->tot_reg_opsmmicro); ?></td>
        <td><?php echo e($data->tot_reg_opsmmicro + $prev_vals->sum('tot_reg_opsmmicro')); ?></td>
    </tr>
    <tr>
        <th></th>
        <th>Female Owners</th>
        <td></td>
        <td>No.</td>
        <?php if($prev_vals == null): ?>
            <th>0</th>
        <?php else: ?>
            <td><?php echo e($prev_vals->sum('tot_reg_opsfmicro')); ?></td>
        <?php endif; ?>
        <td><?php echo e($data->tot_reg_opsfmicro); ?></td>
        <td><?php echo e($data->tot_reg_opsfmicro + $prev_vals->sum('tot_reg_opsfmicro')); ?></td>
    </tr>
    <tr style="background-color: cornflowerblue; color: black;">
        <th></th>
        <td></td>
        <th>Total</th>
        <td></td>

        <td>No.</td>
        <?php if($prev_vals == null): ?>
            <th>0</th>
        <?php else: ?>
            <td><?php echo e($prev_vals->sum('tot_reg_opsmicro')); ?></td>
        <?php endif; ?>
        <th><?php echo e($data->tot_reg_opsmicro); ?></th>
        <th><?php echo e($data->tot_reg_opsmicro + $prev_vals->sum('tot_reg_opsmicro')); ?></th>
    </tr>
    <tr>
        <th>3.2.1.2</th>
        <th rowspan="2">Small Scale Firms</th>
        <th>Male Owners</th>
        <td></td>
        <td>No.</td>
        <?php if($prev_vals == null): ?>
            <th>0</th>
        <?php else: ?>
            <td><?php echo e($prev_vals->sum('tot_reg_opsmsmall')); ?></td>
        <?php endif; ?>
        <td><?php echo e($data->tot_reg_opsmsmall); ?></td>
        <td><?php echo e($data->tot_reg_opsmsmall + $prev_vals->sum('tot_reg_opsmsmall')); ?></td>
    </tr>
    <tr>
        <th></th>
        <th>Female Owners</th>
        <td></td>
        <td>No.</td>
        <?php if($prev_vals == null): ?>
            <th>0</th>
        <?php else: ?>
            <td><?php echo e($prev_vals->sum('tot_reg_opsfsmall')); ?></td>
        <?php endif; ?>
        <td><?php echo e($data->tot_reg_opsfsmall); ?></td>
        <td><?php echo e($data->tot_reg_opsfsmall + $prev_vals->sum('tot_reg_opsfsmall')); ?></td>
    </tr>
    <tr style="background-color: cornflowerblue; color: black;">
        <th></th>
        <td></td>
        <th>Total</th>
        <td></td>

        <td>No.</td>
        <?php if($prev_vals == null): ?>
            <th>0</th>
        <?php else: ?>
            <td><?php echo e($prev_vals->sum('tot_reg_opssmall')); ?></td>
        <?php endif; ?>
        <th><?php echo e($data->tot_reg_opssmall); ?></th>
        <th><?php echo e($data->tot_reg_opssmall + $prev_vals->sum('tot_reg_opssmall')); ?></th>
    </tr>
    <tr>
        <th>3.2.2</th>
        <th>The Total Number of Firms that are Eligible and have been Verified for Operational Support Grants</th>
        <th></th>
        <th></th>
        <th>No.</th>
        <?php if($prev_vals == null): ?>
            <th>0</th>
        <?php else: ?>
            <th><?php echo e($prev_vals->sum('tot_eli_ver')); ?></th>
        <?php endif; ?>
        <th><?php echo e($data->tot_eli_ver); ?></th>
        <th><?php echo e($data->tot_eli_ver + $prev_vals->sum('tot_eli_ver')); ?></th>
    </tr>

    <tr>
        <th>3.2.2.1</th>
        <th rowspan="2">Micro Scale Firms</th>
        <th>Male Owners</th>
        <td></td>
        <td>No.</td>
        <?php if($prev_vals == null): ?>
            <th>0</th>
        <?php else: ?>
            <td><?php echo e($prev_vals->sum('tot_eli_vermmicro')); ?></td>
        <?php endif; ?>
        <td><?php echo e($data->tot_eli_vermmicro); ?></td>
        <td><?php echo e($data->tot_eli_vermmicro + $prev_vals->sum('tot_eli_vermmicro')); ?></td>
    </tr>
    <tr>
        <th></th>
        <th>Female Owners</th>
        <td></td>
        <td>No.</td>
        <?php if($prev_vals == null): ?>
            <th>0</th>
        <?php else: ?>
            <td><?php echo e($prev_vals->sum('tot_eli_verfmicro')); ?></td>
        <?php endif; ?>
        <td><?php echo e($data->tot_eli_verfmicro); ?></td>
        <td><?php echo e($data->tot_eli_verfmicro + $prev_vals->sum('tot_eli_verfmicro')); ?></td>
    </tr>
    <tr style="background-color: cornflowerblue; color: black;">
        <th></th>
        <td></td>
        <th>Total</th>
        <td></td>

        <td>No.</td>
        <?php if($prev_vals == null): ?>
            <th>0</th>
        <?php else: ?>
            <td><?php echo e($prev_vals->sum('tot_eli_vermicro')); ?></td>
        <?php endif; ?>
        <th><?php echo e($data->tot_eli_vermicro); ?></th>
        <th><?php echo e($data->tot_eli_vermicro + $prev_vals->sum('tot_eli_vermicro')); ?></th>
    </tr>

    <tr>
        <th>3.2.2.2</th>
        <th rowspan="2">Small Scale Firms </th>
        <th>Male Owners</th>
        <td></td>
        <td>No.</td>
        <?php if($prev_vals == null): ?>
            <th>0</th>
        <?php else: ?>
            <td><?php echo e($prev_vals->sum('tot_eli_vermsmall')); ?></td>
        <?php endif; ?>
        <td><?php echo e($data->tot_eli_vermsmall); ?></td>
        <td><?php echo e($data->tot_eli_vermsmall + $prev_vals->sum('tot_eli_vermsmall')); ?></td>
    </tr>
    <tr>
        <th></th>
        <th>Female Owners</th>
        <td></td>
        <td>No.</td>
        <?php if($prev_vals == null): ?>
            <th>0</th>
        <?php else: ?>
            <td><?php echo e($prev_vals->sum('tot_eli_verfsmall')); ?></td>
        <?php endif; ?>
        <td><?php echo e($data->tot_eli_verfsmall); ?></td>
        <td><?php echo e($data->tot_eli_verfsmall + $prev_vals->sum('tot_eli_verfsmall')); ?></td>
    </tr>
    <tr style="background-color: cornflowerblue; color: black;">
        <th></th>
        <td></td>
        <th>Total</th>
        <td></td>

        <td>No.</td>
        <?php if($prev_vals == null): ?>
            <th>0</th>
        <?php else: ?>
            <td><?php echo e($prev_vals->sum('tot_eli_versmall')); ?></td>
        <?php endif; ?>
        <th><?php echo e($data->tot_eli_versmall); ?></th>
        <th><?php echo e($data->tot_eli_versmall + $prev_vals->sum('tot_eli_versmall')); ?></th>
    </tr>
    <tr>
        <th>3.2.3</th>
        <th>Total Number of Selected Firms for Operational Grants</th>
        <th></th>
        <th></th>
        <th>No.</th>
        <?php if($prev_vals == null): ?>
            <th>0</th>
        <?php else: ?>
            <th><?php echo e($prev_vals->sum('tot_sel_ops')); ?></th>
        <?php endif; ?>
        <th><?php echo e($data->tot_sel_ops); ?></th>
        <th><?php echo e($data->tot_sel_ops + $prev_vals->sum('tot_sel_ops')); ?></th>
    </tr>

    <tr>
        <th>3.2.3.1</th>
        <th rowspan="2">Micro Scale Firms</th>
        <th>Male Owners</th>
        <td></td>
        <td>No.</td>
        <?php if($prev_vals == null): ?>
            <th>0</th>
        <?php else: ?>
            <td><?php echo e($prev_vals->sum('tot_sel_opsmmicro')); ?></td>
        <?php endif; ?>
        <td><?php echo e($data->tot_sel_opsmmicro); ?></td>
        <td><?php echo e($data->tot_sel_opsmmicro + $prev_vals->sum('tot_sel_opsmmicro')); ?></td>
    </tr>
    <tr>
        <th></th>
        <th>Female Owners</th>
        <td></td>
        <td>No.</td>
        <?php if($prev_vals == null): ?>
            <th>0</th>
        <?php else: ?>
            <td><?php echo e($prev_vals->sum('tot_sel_opsfmicro')); ?></td>
        <?php endif; ?>
        <td><?php echo e($data->tot_sel_opsfmicro); ?></td>
        <td><?php echo e($data->tot_sel_opsfmicro + $prev_vals->sum('tot_sel_opsfmicro')); ?></td>
    </tr>
    <tr style="background-color: cornflowerblue; color: black;">
        <th></th>
        <td></td>
        <th>Total</th>
        <td></td>

        <td>No.</td>
        <?php if($prev_vals == null): ?>
            <th>0</th>
        <?php else: ?>
            <td><?php echo e($prev_vals->sum('tot_sel_opsmicro')); ?></td>
        <?php endif; ?>
        <th><?php echo e($data->tot_sel_opsmicro); ?></th>
        <th><?php echo e($data->tot_sel_opsmicro + $prev_vals->sum('tot_sel_opsmicro')); ?></th>
    </tr>

    <tr>
        <th>3.2.3.2</th>
        <th rowspan="2">Small Scale Firms</th>
        <th>Male Owners</th>
        <td></td>
        <td>No.</td>
        <?php if($prev_vals == null): ?>
            <th>0</th>
        <?php else: ?>
            <td><?php echo e($prev_vals->sum('tot_sel_opsmsmall')); ?></td>
        <?php endif; ?>
        <td><?php echo e($data->tot_sel_opsmsmall); ?></td>
        <td><?php echo e($data->tot_sel_opsmsmall + $prev_vals->sum('tot_sel_opsmsmall')); ?></td>
    </tr>
    <tr>
        <th></th>
        <th>Female Owners</th>
        <td></td>
        <td>No.</td>
        <?php if($prev_vals == null): ?>
            <th>0</th>
        <?php else: ?>
            <td><?php echo e($prev_vals->sum('tot_sel_opsfsmall')); ?></td>
        <?php endif; ?>
        <td><?php echo e($data->tot_sel_opsfsmall); ?></td>
        <td><?php echo e($data->tot_sel_opsfsmall + $prev_vals->sum('tot_sel_opsfsmall')); ?></td>
    </tr>
    <tr style="background-color: cornflowerblue; color: black;">
        <th></th>
        <td></td>
        <th>Total</th>
        <td></td>

        <td>No.</td>
        <?php if($prev_vals == null): ?>
            <th>0</th>
        <?php else: ?>
            <td><?php echo e($prev_vals->sum('tot_sel_opssmall')); ?></td>
        <?php endif; ?>
        <th><?php echo e($data->tot_sel_opssmall); ?></th>
        <th><?php echo e($data->tot_sel_opssmall + $prev_vals->sum('tot_sel_opssmall')); ?></th>
    </tr>

    <tr>
        <th>3.2.4</th>
        <th>Total Number of Firms Receiving Operational Support Grants</th>
        <th></th>
        <th></th>
        <th>No.</th>
        <?php if($prev_vals == null): ?>
            <th>0</th>
        <?php else: ?>
            <th><?php echo e($prev_vals->sum('tot_rec_ops')); ?></th>
        <?php endif; ?>
        <th><?php echo e($data->tot_rec_ops); ?></th>
        <th><?php echo e($data->tot_rec_ops + $prev_vals->sum('tot_rec_ops')); ?></th>
    </tr>

    <tr>
        <th>3.2.4.1</th>
        <th rowspan="2">Micro Scale Firms</th>
        <th>Male Owners</th>
        <td></td>
        <td>No.</td>
        <?php if($prev_vals == null): ?>
            <th>0</th>
        <?php else: ?>
            <td><?php echo e($prev_vals->sum('tot_rec_opsmmicro')); ?></td>
        <?php endif; ?>
        <td><?php echo e($data->tot_rec_opsmmicro); ?></td>
        <td><?php echo e($data->tot_rec_opsmmicro + $prev_vals->sum('tot_rec_opsmmicro')); ?></td>
    </tr>
    <tr>
        <th></th>
        <th>Female Owners</th>
        <td></td>
        <td>No.</td>
        <?php if($prev_vals == null): ?>
            <th>0</th>
        <?php else: ?>
            <td><?php echo e($prev_vals->sum('tot_rec_opsfmicro')); ?></td>
        <?php endif; ?>
        <td><?php echo e($data->tot_rec_opsfmicro); ?></td>
        <td><?php echo e($data->tot_rec_opsfmicro + $prev_vals->sum('tot_rec_opsfmicro')); ?></td>
    </tr>
    <tr style="background-color: cornflowerblue; color: black;">
        <th></th>
        <td></td>
        <th>Total</th>
        <td></td>

        <td>No.</td>
        <?php if($prev_vals == null): ?>
            <th>0</th>
        <?php else: ?>
            <td><?php echo e($prev_vals->sum('tot_rec_opsmicro')); ?></td>
        <?php endif; ?>
        <th><?php echo e($data->tot_rec_opsmicro); ?></th>
        <th><?php echo e($data->tot_rec_opsmicro + $prev_vals->sum('tot_rec_opsmicro')); ?></th>
    </tr>
    <tr>
        <th>3.2.4.2</th>
        <th rowspan="2">Small Scale Firms</th>
        <th>Male Owners</th>
        <td></td>
        <td>No.</td>
        <?php if($prev_vals == null): ?>
            <th>0</th>
        <?php else: ?>
            <td><?php echo e($prev_vals->sum('tot_rec_opsmsmall')); ?></td>
        <?php endif; ?>
        <td><?php echo e($data->tot_rec_opsmsmall); ?></td>
        <td><?php echo e($data->tot_rec_opsmsmall + $prev_vals->sum('tot_rec_opsmsmall')); ?></td>
    </tr>
    <tr>
        <th></th>
        <th>Female Owners</th>
        <td></td>
        <td>No.</td>
        <?php if($prev_vals == null): ?>
            <th>0</th>
        <?php else: ?>
            <td><?php echo e($prev_vals->sum('tot_rec_opsfsmall')); ?></td>
        <?php endif; ?>
        <td><?php echo e($data->tot_rec_opsfsmall); ?></td>
        <td><?php echo e($data->tot_rec_opsfsmall + $prev_vals->sum('tot_rec_opsfsmall')); ?></td>
    </tr>
    <tr style="background-color: cornflowerblue; color: black;">
        <th></th>
        <td></td>
        <th>Total</th>
        <td></td>

        <td>No.</td>
        <?php if($prev_vals == null): ?>
            <th>0</th>
        <?php else: ?>
            <td><?php echo e($prev_vals->sum('tot_rec_opssmall')); ?></td>
        <?php endif; ?>
        <th><?php echo e($data->tot_rec_opssmall); ?></th>
        <th><?php echo e($data->tot_rec_opssmall + $prev_vals->sum('tot_rec_opssmall')); ?></th>
    </tr>


    <tr>
        <th>3.2.5</th>
        <th>Firms Working on Mini Solar Panels Receiving Grants for Operational Support</th>
        <th></th>
        <th></th>
        <th>No.</th>
        <?php if($prev_vals == null): ?>
            <th>0</th>
        <?php else: ?>
            <th><?php echo e($prev_vals->sum('tot_sol_rec')); ?></th>
        <?php endif; ?>
        <th><?php echo e($data->tot_sol_rec); ?></th>
        <th><?php echo e($data->tot_sol_rec + $prev_vals->sum('tot_sol_rec')); ?></th>
    </tr>

    <tr>
        <th>3.2.5.1</th>
        <th rowspan="2">Micro Scale Firms</th>
        <th>Male Owners</th>
        <td></td>
        <td>No.</td>
        <?php if($prev_vals == null): ?>
            <th>0</th>
        <?php else: ?>
            <td><?php echo e($prev_vals->sum('tot_sol_recmmicro')); ?></td>
        <?php endif; ?>
        <td><?php echo e($data->tot_sol_recmmicro); ?></td>
        <td><?php echo e($data->tot_sol_recmmicro + $prev_vals->sum('tot_sol_recmmicro')); ?></td>
    </tr>
    <tr>
        <th></th>
        <th>Female Owners</th>
        <td></td>
        <td>No.</td>
        <?php if($prev_vals == null): ?>
            <th>0</th>
        <?php else: ?>
            <td><?php echo e($prev_vals->sum('tot_sol_recfmicro')); ?></td>
        <?php endif; ?>
        <td><?php echo e($data->tot_sol_recfmicro); ?></td>
        <td><?php echo e($data->tot_sol_recfmicro + $prev_vals->sum('tot_sol_recfmicro')); ?></td>
    </tr>
    <tr style="background-color: cornflowerblue; color: black;">
        <th></th>
        <td></td>
        <th>Total</th>
        <td></td>

        <td>No.</td>
        <?php if($prev_vals == null): ?>
            <th>0</th>
        <?php else: ?>
            <td><?php echo e($prev_vals->sum('tot_sol_recmicro')); ?></td>
        <?php endif; ?>
        <th><?php echo e($data->tot_sol_recmicro); ?></th>
        <th><?php echo e($data->tot_sol_recmicro + $prev_vals->sum('tot_sol_recmicro')); ?></th>
    </tr>
    <tr>
        <th>3.2.5.2</th>
        <th rowspan="2">Small Scale Firms</th>
        <th>Male Owners</th>
        <td></td>
        <td>No.</td>
        <?php if($prev_vals == null): ?>
            <th>0</th>
        <?php else: ?>
            <td><?php echo e($prev_vals->sum('tot_sol_recmsmall')); ?></td>
        <?php endif; ?>
        <td><?php echo e($data->tot_sol_recmsmall); ?></td>
        <td><?php echo e($data->tot_sol_recmsmall + $prev_vals->sum('tot_sol_recmsmall')); ?></td>
    </tr>
    <tr>
        <th></th>
        <th>Female Owners</th>
        <td></td>
        <td>No.</td>
        <?php if($prev_vals == null): ?>
            <th>0</th>
        <?php else: ?>
            <td><?php echo e($prev_vals->sum('tot_sol_recfsmall')); ?></td>
        <?php endif; ?>
        <td><?php echo e($data->tot_sol_recfsmall); ?></td>
        <td><?php echo e($data->tot_sol_recfsmall + $prev_vals->sum('tot_sol_recfsmall')); ?></td>
    </tr>
    <tr style="background-color: cornflowerblue; color: black;">
        <th></th>
        <td></td>
        <th>Total</th>
        <td></td>

        <td>No.</td>
        <?php if($prev_vals == null): ?>
            <th>0</th>
        <?php else: ?>
            <td><?php echo e($prev_vals->sum('tot_sol_recsmall')); ?></td>
        <?php endif; ?>
        <th><?php echo e($data->tot_sol_recsmall); ?></th>
        <th><?php echo e($data->tot_sol_recsmall + $prev_vals->sum('tot_sol_recsmall')); ?></th>
    </tr>

    <tr>
        <th>3.2.6</th>
        <th>Amount Disbursed to Beneficiary Firms for Operational Grants</th>
        <th></th>
        <th></th>
        <th>NGN</th>
        <?php if($prev_vals == null): ?>
            <th>0</th>
        <?php else: ?>
            <th><?php echo e($prev_vals->sum('tot_amt_dis')); ?></th>
        <?php endif; ?>
        <th><?php echo e($data->tot_amt_dis); ?></th>
        <th><?php echo e($data->tot_amt_dis + $prev_vals->sum('tot_amt_dis')); ?></th>
    </tr>
    <tr>
        <th>3.2.6.1</th>
        <th rowspan="2">Micro Scale Firms</th>
        <th>Male Owners</th>
        <td></td>
        <td>No.</td>
        <?php if($prev_vals == null): ?>
            <th>0</th>
        <?php else: ?>
            <td><?php echo e($prev_vals->sum('tot_amt_dismmicro')); ?></td>
        <?php endif; ?>
        <td><?php echo e($data->tot_amt_dismmicro); ?></td>
        <td><?php echo e($data->tot_amt_dismmicro + $prev_vals->sum('tot_amt_dismmicro')); ?></td>
    </tr>
    <tr>
        <th></th>
        <th>Female Owners</th>
        <td></td>
        <td>No.</td>
        <?php if($prev_vals == null): ?>
            <th>0</th>
        <?php else: ?>
            <td><?php echo e($prev_vals->sum('tot_amt_disfmicro')); ?></td>
        <?php endif; ?>
        <td><?php echo e($data->tot_amt_disfmicro); ?></td>
        <td><?php echo e($data->tot_amt_disfmicro + $prev_vals->sum('tot_amt_disfmicro')); ?></td>
    </tr>
    <tr style="background-color: cornflowerblue; color: black;">
        <th></th>
        <td></td>
        <th>Total</th>
        <td></td>

        <td>No.</td>
        <?php if($prev_vals == null): ?>
            <th>0</th>
        <?php else: ?>
            <td><?php echo e($prev_vals->sum('tot_amt_dismicro')); ?></td>
        <?php endif; ?>
        <th><?php echo e($data->tot_amt_dismicro); ?></th>
        <th><?php echo e($data->tot_amt_dismicro + $prev_vals->sum('tot_amt_dismicro')); ?></th>
    </tr>
    <tr>
        <th>3.2.6.2</th>
        <th rowspan="2">Small Scale Firms</th>
        <th>Male Owners</th>
        <td></td>
        <td>No.</td>
        <?php if($prev_vals == null): ?>
            <th>0</th>
        <?php else: ?>
            <td><?php echo e($prev_vals->sum('tot_amt_dismsmall')); ?></td>
        <?php endif; ?>
        <td><?php echo e($data->tot_amt_dismsmall); ?></td>
        <td><?php echo e($data->tot_amt_dismsmall + $prev_vals->sum('tot_amt_dismsmall')); ?></td>
    </tr>
    <tr>
        <th></th>
        <th>Female Owners</th>
        <td></td>
        <td>No.</td>
        <?php if($prev_vals == null): ?>
            <th>0</th>
        <?php else: ?>
            <td><?php echo e($prev_vals->sum('tot_amt_disfsmall')); ?></td>
        <?php endif; ?>
        <td><?php echo e($data->tot_amt_disfsmall); ?></td>
        <td><?php echo e($data->tot_amt_disfsmall + $prev_vals->sum('tot_amt_disfsmall')); ?></td>
    </tr>
    <tr style="background-color: cornflowerblue; color: black;">
        <th></th>
        <td></td>
        <th>Total</th>
        <td></td>

        <td>No.</td>
        <?php if($prev_vals == null): ?>
            <th>0</th>
        <?php else: ?>
            <td><?php echo e($prev_vals->sum('tot_amt_dissmall')); ?></td>
        <?php endif; ?>
        <th><?php echo e($data->tot_amt_dissmall); ?></th>
        <th><?php echo e($data->tot_amt_dissmall + $prev_vals->sum('tot_amt_dissmall')); ?></th>
    </tr>
    </tbody>
</table>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/fcsu_me/resources/views/dps/operations_table.blade.php ENDPATH**/ ?>