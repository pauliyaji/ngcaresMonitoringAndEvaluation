<?php $__env->startSection('content'); ?>

    <!-- Begin Page Content -->
    <div class="container-fluid">

        <!-- Page Heading -->

        <!-- DataTales Example -->
        <div class="card shadow mb-4">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-primary">Add User
                    <a href="<?php echo e(route('users.index')); ?>" class="float-right btn btn-success btn-sm">View All</a>

                </h6>
            </div>
            <div class="card-body">

                <?php if(Session::has('success')): ?>
                    <p class="text-success"><?php echo e(session('success')); ?></p>
                <?php endif; ?>
                <div class="table-responsive">
                    <form method="post" action="<?php echo e(route('users.update', $user->id)); ?>" enctype="multipart/form-data">
                        <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('patch'); ?>
                            <tr>
                                <th>Full Name</th>
                                <td><input type="text" class="form-control" value="<?php echo e($user->name); ?>" name="name" id="name"/></td>
                            </tr>
                            <tr>
                                <th>Email</th>
                                <td><input type="text" class="form-control" value="<?php echo e($user->email); ?>" name="email" id="email"/></td>
                            </tr>
                            <tr>
                                <th>Phone</th>
                                <td><input type="text" class="form-control" value="<?php echo e($user->phone); ?>" name="phone" id="phone"/></td>
                            </tr>
                            <tr>
                                <th>Password</th>
                                <td><input type="password" class="form-control" name="password" id="password"/></td>
                            </tr>
                            <tr>
                                <th>Photo</th>
                                <td><img src="<?php echo e(asset('storage/imgs/'.$user->photo)); ?>" height="200px" weight="200px"></td>
                            </tr>
                            <tr>
                                <th>Photo</th>
                                <td><input type="file" name="photo" id="photo" /></td>
                            </tr>
                            <tr>
                                <th>State</th>
                                <td>
                                    <select class="form-control"
                                            name="state_id" required>
                                        <option value="">Select State</option>
                                        <?php $__currentLoopData = $states; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $state): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option <?php if($user->state_id==$state->id): ?> selected <?php endif; ?>
                                            value="<?php echo e($state->id); ?>"><?php echo e($state->state); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <?php if($errors->has('state_id')): ?>
                                        <span class="text-danger text-left"><?php echo e($errors->first('state_id')); ?></span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                            <tr>
                                <th>DP</th>
                                <td>

                                        <select class="form-control"
                                                name="dp_id" required>
                                            <option value="">Select DP</option>
                                            <?php $__currentLoopData = $dps; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option <?php if($user->dp_id==$dp->id): ?> selected <?php endif; ?>
                                                value="<?php echo e($dp->id); ?>"
                                                    <?php echo e($dp->dps); ?>><?php echo e($dp->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>

                                </td>
                            </tr>
                            <tr>
                                <th>SCCU</th>
                                <td>
                                    <select class="form-control"
                                            name="sccu_id" required>
                                        <option value="">Select SCCU</option>
                                        <?php $__currentLoopData = $sccus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sccu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option <?php if($user->sccu_id==$sccu->id): ?> selected <?php endif; ?>
                                            value="<?php echo e($sccu->id); ?>"><?php echo e($sccu->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <?php if($errors->has('sccu_id')): ?>
                                        <span class="text-danger text-left"><?php echo e($errors->first('sccu_id')); ?></span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                            <tr>
                                <th>Role</th>
                                <td>
                                    <select class="form-control"
                                            name="role" required>
                                        <option value="">Select role</option>
                                        <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($role->id); ?>"
                                                <?php echo e(in_array($role->name, $userRole)
                                                    ? 'selected'
                                                    : ''); ?>><?php echo e($role->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <?php if($errors->has('role')): ?>
                                        <span class="text-danger text-left"><?php echo e($errors->first('role')); ?></span>
                                    <?php endif; ?>
                                </td>

                            </tr>
                            <tr>
                                <td colspan="2">
                                    <input type="submit" class="btn btn-primary btn-sm" />                                </td>
                            </tr>
                        </table>
                    </form>
                </div>
            </div>
        </div>

    </div>
    <!-- /.container-fluid -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- Bootstrap core JavaScript-->


<?php echo $__env->make('layouts/layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/fcsu_me/resources/views/users/edit.blade.php ENDPATH**/ ?>