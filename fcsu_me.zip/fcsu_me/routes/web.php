<?php

use App\Http\Controllers\PermissionsController;
use App\Http\Controllers\RolesController;
use App\Http\Controllers\UsersController;
use App\Imports\UsersImport;
use Illuminate\Support\Facades\Route;
use Maatwebsite\Excel\Facades\Excel;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

    /**
     * Home Routes
     */
    //Route::get('/', 'HomeController@index')->name('home.index');
    Route::get('/', function () {
        return view('auth/login');
    });

    Route::get('/dashboard', function () {
        $users = \App\Models\User::all();
        return view('dashboard', compact('users'));
    })->middleware(['auth'])->name('dashboard');

    require __DIR__.'/auth.php';

    Route::post('import', function() {
       Excel::import(new UsersImport, request()->file('file'));
       return redirect()->back()->with('success', 'Data Imported Successfully');
    });

    Route::group(['middleware' => ['auth', 'permission']], function() {
        /**
         * Logout Routes
         */
        //Route::get('/logout', 'LogoutController@perform')->name('logout.perform');

        /**
         * User Routes
         */
        Route::group(['prefix' => 'users'], function() {

            Route::get('/', 'App\Http\Controllers\UsersController@index')->name('users.index');
            Route::get('/create', 'App\Http\Controllers\UsersController@create')->name('users.create');
            Route::post('/create', 'App\Http\Controllers\UsersController@store')->name('users.store');
            Route::get('/{user}/show', 'App\Http\Controllers\UsersController@show')->name('users.show');
            Route::get('/{user}/edit', 'App\Http\Controllers\UsersController@edit')->name('users.edit');
            Route::patch('/{user}/update', 'App\Http\Controllers\UsersController@update')->name('users.update');
            Route::delete('/{user}/delete', 'App\Http\Controllers\UsersController@destroy')->name('users.destroy');
        });
        Route::resource('roles', RolesController::class);
        Route::resource('permissions', PermissionsController::class);

        Route::resource('socialtransfers', \App\Http\Controllers\Dli1Controller::class);
        Route::patch('socialtransfers/{id}/strans', '\App\Http\Controllers\Dli1Controller@strans')->name('socialtransfers.strans');
        Route::put('socialtransfers/{id}/senddata', '\App\Http\Controllers\Dli1Controller@senddata')->name('socialtransfers.senddata');
        Route::get('export/',[\App\Http\Controllers\Dli1Controller::class, 'export'] )->name('export');
        Route::get('exportlipw/',[\App\Http\Controllers\Dli2Controller::class, 'export'] )->name('exportlipw');
        Route::get('exportlivelihood/',[\App\Http\Controllers\Dli3Controller::class, 'export'] )->name('exportlivelihood');
        Route::get('exportbasic/',[\App\Http\Controllers\Dli4Controller::class, 'export'] )->name('exportbasic');
        Route::get('exportinfra/',[\App\Http\Controllers\Dli6Controller::class, 'export'] )->name('exportinfra');
        Route::get('exportassets/',[\App\Http\Controllers\Dli7Controller::class, 'export'] )->name('exportassets');
        Route::get('exportwetmarket/',[\App\Http\Controllers\Dli8Controller::class, 'export'] )->name('exportwetmarket');
        Route::get('exportcredit/',[\App\Http\Controllers\Dli9Controller::class, 'export'] )->name('exportcredit');
        Route::get('exportoperations/',[\App\Http\Controllers\Dli10Controller::class, 'export'] )->name('exportoperations');
        Route::get('exportenhance/',[\App\Http\Controllers\Dli11Controller::class, 'export'] )->name('exportenhance');

        Route::get('exportview/',[\App\Http\Controllers\Dli1Controller::class, 'exportview'] )->name('exportview');
        Route::get('socialexport/{id}',[\App\Http\Controllers\DpController::class, 'socialexport'] )->name('socialexport');
        Route::get('lipwsexport/{id}',[\App\Http\Controllers\DpController::class, 'lipwsexport'] )->name('lipwsexport');
        Route::get('livelihoodsexport/{id}',[\App\Http\Controllers\DpController::class, 'livelihoodsexport'] )->name('livelihoodsexport');
        Route::get('basicexport/{id}',[\App\Http\Controllers\DpController::class, 'basicexport'] )->name('basicexport');
        Route::get('agric_inputsexport/{id}',[\App\Http\Controllers\DpController::class, 'agric_inputsexport'] )->name('agric_inputsexport');
        Route::get('agric_assetsexport/{id}',[\App\Http\Controllers\DpController::class, 'agric_assetsexport'] )->name('agric_assetsexport');
        Route::get('agric_infraexport/{id}',[\App\Http\Controllers\DpController::class, 'agric_infraexport'] )->name('agric_infraexport');
        Route::get('wetmarketexport/{id}',[\App\Http\Controllers\DpController::class, 'wetmarketexport'] )->name('wetmarketexport');
        Route::get('creditgrant_export/{id}',[\App\Http\Controllers\DpController::class, 'creditgrant_export'] )->name('creditgrant_export');
        Route::get('operationsgrant_export/{id}',[\App\Http\Controllers\DpController::class, 'operationsgrant_export'] )->name('operationsgrant_export');
        Route::get('enhancement_grantexport/{id}',[\App\Http\Controllers\DpController::class, 'enhancement_grantexport'] )->name('enhancement_grantexport');

        // Route::get('dps/export_view', [\App\Http\Controllers\DpController::class, 'export_view'])->name('dps.export_view');

        Route::resource('lipws', \App\Http\Controllers\Dli2Controller::class );
        Route::patch('lipws/{id}/strans', '\App\Http\Controllers\Dli2Controller@strans')->name('lipws.strans');
        Route::put('lipws/{id}/senddata', '\App\Http\Controllers\Dli2Controller@senddata')->name('lipws.senddata');

        Route::resource('livelihoods', \App\Http\Controllers\Dli3Controller::class);
        Route::patch('livelihoods/{id}/strans', '\App\Http\Controllers\Dli3Controller@strans')->name('livelihoods.strans');
        Route::put('livelihoods/{id}/senddata', '\App\Http\Controllers\Dli3Controller@senddata')->name('livelihoods.senddata');


        Route::resource('basicservices', \App\Http\Controllers\Dli4Controller::class);
        Route::patch('basicservices/{id}/strans', '\App\Http\Controllers\Dli4Controller@strans')->name('basicservices.strans');
        Route::put('basicservices/{id}/senddata', '\App\Http\Controllers\Dli4Controller@senddata')->name('basicservices.senddata');

        Route::resource('agric_inputs', \App\Http\Controllers\Dli5Controller::class);
        Route::patch('agric_inputs/{id}/strans', '\App\Http\Controllers\Dli8Controller@strans')->name('agric_inputs.strans');
        Route::put('agric_inputs/{id}/senddata', '\App\Http\Controllers\Dli8Controller@senddata')->name('agric_inputs.senddata');

        Route::resource('agric_infrastructures', \App\Http\Controllers\Dli6Controller::class);
        Route::patch('agric_infrastructures/{id}/strans', '\App\Http\Controllers\Dli6Controller@strans')->name('agric_infrastructures.strans');
        Route::put('agric_infrastructures/{id}/senddata', '\App\Http\Controllers\Dli6Controller@senddata')->name('agric_infrastructures.senddata');

        Route::resource('agric_assets', \App\Http\Controllers\Dli7Controller::class);
        Route::patch('agric_assets/{id}/strans', '\App\Http\Controllers\Dli7Controller@strans')->name('agric_assets.strans');
        Route::put('agric_assets/{id}/senddata', '\App\Http\Controllers\Dli7Controller@senddata')->name('agric_assets.senddata');

        Route::resource('wetmarkets', \App\Http\Controllers\Dli8Controller::class);
        Route::patch('wetmarkets/{id}/strans', '\App\Http\Controllers\Dli8Controller@strans')->name('wetmarkets.strans');
        Route::put('wetmarkets/{id}/senddata', '\App\Http\Controllers\Dli8Controller@senddata')->name('wetmarkets.senddata');


        Route::resource('credit_grants', \App\Http\Controllers\Dli9Controller::class);
        Route::patch('credit_grants/{id}/strans', '\App\Http\Controllers\Dli9Controller@strans')->name('credit_grants.strans');
        Route::put('credit_grants/{id}/senddata', '\App\Http\Controllers\Dli9Controller@senddata')->name('credit_grants.senddata');

        Route::resource('operations_grant', \App\Http\Controllers\Dli10Controller::class);
        Route::patch('operations_grant/{id}/strans', '\App\Http\Controllers\Dli10Controller@strans')->name('operations_grant.strans');
        Route::put('operations_grant/{id}/senddata', '\App\Http\Controllers\Dli10Controller@senddata')->name('operations_grant.senddata');

        Route::resource('enhancement_grants', \App\Http\Controllers\Dli11Controller::class);
        Route::patch('enhancement_grants/{id}/strans', '\App\Http\Controllers\Dli11Controller@strans')->name('enhancement_grants.strans');
        Route::put('enhancement_grants/{id}/senddata', '\App\Http\Controllers\Dli11Controller@senddata')->name('enhancement_grants.senddata');


        Route::resource('dps',\App\Http\Controllers\DpController::class);
        Route::get('dps.dp_reports', [\App\Http\Controllers\DpController::class, 'dp_reports'])->name('dps.dp_reports');
        Route::get('dps/sts_report/{id}', [\App\Http\Controllers\DpController::class, 'sts_report'])->name('dps.sts_report');
        Route::get('dps/lipws_report/{id}', [\App\Http\Controllers\DpController::class, 'lipws_report'])->name('dps.lipws_report');
        Route::get('dps/livelihood_report/{id}', [\App\Http\Controllers\DpController::class, 'livelihood_report'])->name('dps.livelihood_report');
        Route::get('dps/basicservices_report/{id}', [\App\Http\Controllers\DpController::class, 'basicservices_report'])->name('dps.basicservices_report');
        Route::get('dps/agric_infrastructure_report/{id}', [\App\Http\Controllers\DpController::class, 'agric_infrastructure_report'])->name('dps.agric_infrastructure_report');
        Route::get('dps/agric_assets_report/{id}', [\App\Http\Controllers\DpController::class, 'agric_assets_report'])->name('dps.agric_assets_report');
        Route::get('dps/wetmarket_report/{id}', [\App\Http\Controllers\DpController::class, 'wetmarket_report'])->name('dps.wetmarket_report');
        Route::get('dps/creditgrant_report/{id}', [\App\Http\Controllers\DpController::class, 'creditgrant_report'])->name('dps.creditgrant_report');
        Route::get('dps/operationsgrant_report/{id}', [\App\Http\Controllers\DpController::class, 'operationsgrant_report'])->name('dps.operationsgrant_report');
        Route::get('dps/enhancementgrant_report/{id}', [\App\Http\Controllers\DpController::class, 'enhancementgrant_report'])->name('dps.enhancementgrant_report');

        Route::get('sccus/general_report', [\App\Http\Controllers\SccuController::class, 'report'])->name('sccus.general_report');
        Route::post('sccus/search', [\App\Http\Controllers\SccuController::class, 'search'])->name('sccus.search');
        Route::resource('sccus', \App\Http\Controllers\SccuController::class);
        Route::get('fcsu/socialtransfers', [\App\Http\Controllers\FcsuController::class, 'socialtransfers'])->name('fcsu.socialtransfers');
        Route::get('fcsu/socialtransfer_view/{id}', [\App\Http\Controllers\FcsuController::class, 'socialtransfer_view'])->name('fcsu.socialtransfer_view');

        Route::get('fcsu/lipws', [\App\Http\Controllers\FcsuController::class, 'lipws'])->name('fcsu.lipws');
        Route::get('fcsu/lipw_view/{id}', [\App\Http\Controllers\FcsuController::class, 'lipw_view'])->name('fcsu.lipw_view');

        Route::get('fcsu/livelihoods', [\App\Http\Controllers\FcsuController::class, 'livelihoods'])->name('fcsu.livelihoods');
        Route::get('fcsu/livelihood_view/{id}', [\App\Http\Controllers\FcsuController::class, 'livelihood_view'])->name('fcsu.livelihood_view');

        Route::get('fcsu/basicservices', [\App\Http\Controllers\FcsuController::class, 'basicservices'])->name('fcsu.basicservices');
        Route::get('fcsu/basicservice_view/{id}', [\App\Http\Controllers\FcsuController::class, 'basicservice_view'])->name('fcsu.basicservice_view');

        Route::get('fcsu/agric_inputs', [\App\Http\Controllers\FcsuController::class, 'agric_inputs'])->name('fcsu.agric_inputs');
        Route::get('fcsu/agric_inputs_view/{id}', [\App\Http\Controllers\FcsuController::class, 'agric_input_view'])->name('fcsu.agric_input_view');

        Route::get('fcsu/agric_infrastructures', [\App\Http\Controllers\FcsuController::class, 'agric_infrastructures'])->name('fcsu.agric_infrastructures');
        Route::get('fcsu/agric_infrastructure_view/{id}', [\App\Http\Controllers\FcsuController::class, 'agric_infrastructure_view'])->name('fcsu.agric_infrastructure_view');

        Route::get('fcsu/agric_assets', [\App\Http\Controllers\FcsuController::class, 'agric_assets'])->name('fcsu.agric_assets');
        Route::get('fcsu/agric_assets_view/{id}', [\App\Http\Controllers\FcsuController::class, 'agric_asset_view'])->name('fcsu.agric_asset_view');

        Route::get('fcsu/wetmarkets', [\App\Http\Controllers\FcsuController::class, 'wetmarkets'])->name('fcsu.wetmarkets');
        Route::get('fcsu/wetmarkets/{id}', [\App\Http\Controllers\FcsuController::class, 'wetmarket_view'])->name('fcsu.wetmarket_view');

        Route::get('fcsu/credit_grants', [\App\Http\Controllers\FcsuController::class, 'credit_grants'])->name('fcsu.credit_grants');
        Route::get('fcsu/credit_grant_view/{id}', [\App\Http\Controllers\FcsuController::class, 'credit_grant_view'])->name('fcsu.credit_grant_view');

        Route::get('fcsu/operations_grant', [\App\Http\Controllers\FcsuController::class, 'operations_grant'])->name('fcsu.operations_grant');
        Route::get('fcsu/operations_grant_view/{id}', [\App\Http\Controllers\FcsuController::class, 'operations_grant_view'])->name('fcsu.operations_grant_view');

        Route::get('fcsu/enhancement_grants', [\App\Http\Controllers\FcsuController::class, 'enhancement_grants'])->name('fcsu.enhancement_grants');
        Route::get('fcsu/enhancement_grant_view/{id}', [\App\Http\Controllers\FcsuController::class, 'enhancement_grant_view'])->name('fcsu.enhancement_grant_view');

    });


