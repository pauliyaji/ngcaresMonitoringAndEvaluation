<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateDli11sTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('dli11s', function (Blueprint $table) {
            $table->id();
            $table->string('tot_regit');
            $table->string('tot_regitmmicro');
            $table->string('tot_regitfmicro');
            $table->string('tot_regitmicro');
            $table->string('tot_regitmsmall');
            $table->string('tot_regitfsmall');
            $table->string('tot_regitsmall');
            $table->string('tot_eligverit');
            $table->string('tot_eligmmicro');
            $table->string('tot_eligfmicro');
            $table->string('tot_eligmicro');
            $table->string('tot_eligmsmall');
            $table->string('tot_eligfsmall');
            $table->string('tot_eligsmall');
            $table->string('att_reg_minus_ver');
            $table->string('tot_sel');
            $table->string('tot_selmmicro');
            $table->string('tot_selfmicro');
            $table->string('tot_selmicro');
            $table->string('tot_selmsmall');
            $table->string('tot_selfsmall');
            $table->string('tot_selsmall');
            $table->string('att_ver_minus_sel');
            $table->string('tot_ser_pro');
            $table->string('tot_conf');
            $table->string('tot_confmmicro');
            $table->string('tot_conffmicro');
            $table->string('tot_confmicro');
            $table->string('tot_confmsmall');
            $table->string('tot_conffsmall');
            $table->string('tot_confsmall');
            $table->string('tot_tech');
            $table->string('tot_techmmicro');
            $table->string('tot_techfmicro');
            $table->string('tot_techmicro');
            $table->string('tot_techmsmall');
            $table->string('tot_techfsmall');
            $table->string('tot_techsmall');
            $table->string('tot_rec');
            $table->string('tot_recmmicro');
            $table->string('tot_recfmicro');
            $table->string('tot_recmicro');
            $table->string('tot_recmsmall');
            $table->string('tot_recfsmall');
            $table->string('tot_recsmall');
            $table->string('att_tech_minus_rec');
            $table->string('tot_dis');
            $table->string('tot_dismmicro');
            $table->string('tot_disfmicro');
            $table->string('tot_dismicro');
            $table->string('tot_dismsmall');
            $table->string('tot_disfsmall');
            $table->string('tot_dissmall');
            $table->string('att_sel_minus_conf');
            $table->string('att_conf_minus_tech');

            $table->string('dli_id');
            $table->string('state_id');
            $table->string('status_id');
            $table->string('user_id');
            $table->string('dp_id');
            $table->string('monthyear');

            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('enhancement_grant');
    }
}
