<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateDli4sTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('dli4s', function (Blueprint $table) {
            $table->id();
            $table->string('tot_commssensi');
            $table->string('tot_grpssensi');
            $table->string('tot_eoirecvcomms');
            $table->string('tot_eoirecvgrps');
            $table->string('tot_cdpssubmit');
            $table->string('tot_grdpssubmit');
            $table->string('tot_approvcdps');
            $table->string('tot_mpscdpedu');
            $table->string('tot_mpscdpwat')->nullable();
            $table->string('tot_mpscdphlth');
            $table->string('tot_mpscdpwatsani');
            $table->string('tot_approvgrdp');
            $table->string('tot_grdpsedu');
            $table->string('tot_grdpswat');
            $table->string('tot_grdpshlth');
            $table->string('tot_grdpswatsani');
            $table->string('num_cpmctrained');
            $table->string('num_gpmctrained');
            $table->string('tot_mpsedu');
            $table->string('tot_mpswat')->nullable();
            $table->string('tot_mpshlth');
            $table->string('tot_mpssani');
            $table->string('tot_grpmpsedu');
            $table->string('tot_grpmpswat');
            $table->string('tot_grpmpshlth');
            $table->string('tot_grpmpssani');
            $table->string('tot_beneofmps');
            $table->string('tot_mpscdpnut');
            $table->string('tot_mpsnut');

            $table->string('dli_id');
            $table->string('state_id');
            $table->string('user_id');
            $table->string('status_id');
            $table->string('dp_id');
            $table->string('monthyear');

            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('basicservices');
    }
}
