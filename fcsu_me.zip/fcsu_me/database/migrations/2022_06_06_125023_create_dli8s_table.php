<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateDli8sTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('dli8s', function (Blueprint $table) {
            $table->id();
            $table->string('tot_microfcasense');
            $table->string('tot_smallfcasense');
            $table->string('tot_fcasense');
            $table->string('tot_carp_prep');
            $table->string('tot_carp_approv');
            $table->string('att_prep_approv');
            $table->string('pcent_att_prep_approv');
            $table->string('tot_exist_wet_mark');
            $table->string('tot_fsellersbene');
            $table->string('tot_msellersbene');
            $table->string('tot_sellersbene');
            $table->string('tot_wetmktupgraded');

            $table->string('dli_id');
            $table->string('state_id');
            $table->string('status_id');
            $table->string('user_id');
            $table->string('dp_id');
            $table->string('monthyear');


            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('dli8s');
    }
}
