<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateDli9sTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('dli9s', function (Blueprint $table) {
            $table->id();
            $table->string('tot_reg');
            $table->string('tot_regmmicro');
            $table->string('tot_regfmicro');
            $table->string('tot_regmicro');
            $table->string('tot_regmsmall');
            $table->string('tot_regfsmall');
            $table->string('tot_regsmall');
            $table->string('tot_eli_ver');
            $table->string('tot_eli_vermmicro');
            $table->string('tot_eli_verfmicro');
            $table->string('tot_eli_vermicro');
            $table->string('tot_eli_vermsmall');
            $table->string('tot_eli_verfsmall');
            $table->string('tot_eli_versmall');
            $table->string('att_reg_minus_ver');
            $table->string('tot_sel');
            $table->string('tot_selmmicro');
            $table->string('tot_selfmicro');
            $table->string('tot_selmicro');
            $table->string('tot_selmsmall');
            $table->string('tot_selfsmall');
            $table->string('tot_selsmall');
            $table->string('att_ver_minus_sel');
            $table->string('tot_ver_len');
            $table->string('tot_ver_newl');
            $table->string('tot_ver_newlmmicro');
            $table->string('tot_ver_newlfmicro');
            $table->string('tot_ver_newlmicro');
            $table->string('tot_ver_newlmsmall');
            $table->string('tot_ver_newlfsmall');
            $table->string('tot_ver_newlsmall');
            $table->string('tot_reccap');
            $table->string('tot_reccap_mmicro');
            $table->string('tot_reccap_fmicro');
            $table->string('tot_reccap_micro');
            $table->string('tot_reccapmsmall');
            $table->string('tot_reccapfsmall');
            $table->string('tot_reccap_small');
            $table->string('att_ver_minus_rec');
            $table->string('amt_dis');
            $table->string('amt_dismicro');
            $table->string('amt_dissmall');

            $table->string('dli_id');
            $table->string('state_id');
            $table->string('status_id');
            $table->string('user_id');
            $table->string('dp_id');
            $table->string('monthyear');


            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('credit_grants');
    }
}
