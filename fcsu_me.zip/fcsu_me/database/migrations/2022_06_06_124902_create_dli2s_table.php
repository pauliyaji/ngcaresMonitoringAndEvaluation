<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateDli2sTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('dli2s', function (Blueprint $table) {
            $table->id();
            $table->String('f_mined');
            $table->String('m_mined');
            $table->String('tot_mined');
            $table->String('f_validated');
            $table->String('m_validated');
            $table->String('tot_validated');
            $table->String('att_fminedval');
            $table->String('att_mminedval');
            $table->String('att_totminedval');
            $table->String('att_minedvalpercent');
            $table->String('p_att')->nullable();
            $table->String('f_enrolled');
            $table->String('m_enrolled');
            $table->String('tot_enrolled');
            $table->String('f_deploy');
            $table->String('m_deploy');
            $table->String('tot_deploy');
            $table->String('att_fenr_deploy');
            $table->String('att_menr_deploy');
            $table->String('att_totenr_deploy');
            $table->String('att_enr_deployed');

            $table->String('comment')->nullable();

            $table->String('num_workdays');
            $table->String('amt_transpsp');
            $table->String('tot_fbeneforpsppay');
            $table->String('tot_mbeneforpsppay');
            $table->String('tot_beneforpsppay');
            $table->String('tot_fbenepaid');
            $table->String('tot_mbenepaid');
            $table->String('tot_benepaid');
            $table->string('att_fbenepaid');
            $table->string('att_mbenepaid');
            $table->string('att_benepaid');

            $table->string('att_pcent_benepaid');
            $table->string('commenta')->nullable();
            $table->string('amountbpaid');
            $table->string('attbpaid');
            $table->string('attbpaidp');
            $table->string('comment4')->nullable();

            $table->string('dli_id');
            $table->string('state_id');
            $table->string('user_id');
            $table->string('status_id');
            $table->string('dp_id');
            $table->string('monthyear');

            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('lipws');
    }
}
