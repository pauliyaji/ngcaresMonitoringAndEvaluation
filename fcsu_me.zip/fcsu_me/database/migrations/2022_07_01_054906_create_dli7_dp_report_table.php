<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateDli7DpReportTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('dli7_dp_report', function (Blueprint $table) {
            $table->id();
            $table->string('tot_fcas_sen_mob');
            $table->string('tot_carp_prep');
            $table->string('tot_carp_app');

            $table->string('tot_farm_applied_f');
            $table->string('tot_farm_applied_m');
            $table->string('tot_farm_applied');

            $table->string('tot_farm_recvd_f');
            $table->string('tot_farm_recvd_m');
            $table->string('tot_farm_recvd');

            $table->string('tot_farm_utilizing_f');
            $table->string('tot_farm_utilizing_m');
            $table->string('tot_farm_utilizing');

            $table->string('state_id');
            $table->string('monthyear');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('dli7_dp_report');
    }
}
