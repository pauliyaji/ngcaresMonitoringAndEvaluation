<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateDli3DpReportTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('dli3_dp_report', function (Blueprint $table) {
            $table->id();
            $table->string('livs_tot_bene_mined_f');
            $table->string('livs_tot_bene_mined_m');
            $table->string('livs_tot_bene_mined');

            $table->string('livs_tot_bene_validated_f');
            $table->string('livs_tot_bene_validated_m');
            $table->string('livs_tot_bene_validated');

            $table->string('livs_tot_bene_trained_f');
            $table->string('livs_tot_bene_trained_m');
            $table->string('livs_tot_bene_trained');

            $table->string('livs_tot_bene_grad_f');
            $table->string('livs_tot_bene_grad_m');
            $table->string('livs_tot_bene_grad');

            $table->string('livs_tot_amt_psp');
            $table->string('livs_tot_bene_trans_psp_f');
            $table->string('livs_tot_bene_trans_psp_m');

            $table->string('livs_tot_bene_supported');
            $table->string('livs_tot_bene_supported_f');
            $table->string('livs_tot_bene_supported_m');

            $table->string('livs_tot_amt_paid_bene');
            $table->string('state_id');
            $table->string('monthyear');

            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('dli3_dp_report');
    }
}
