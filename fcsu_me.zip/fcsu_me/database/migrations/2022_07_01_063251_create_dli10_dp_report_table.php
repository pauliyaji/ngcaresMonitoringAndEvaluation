<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateDli10DpReportTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('dli10_dp_report', function (Blueprint $table) {
            $table->id();
            $table->string('tot_reg_firms_app');
            $table->string('tot_reg_firms_app_micro_m');
            $table->string('tot_reg_firms_app_micro_f');
            $table->string('tot_reg_firms_app_micro');
            $table->string('tot_reg_firms_app_small_m');
            $table->string('tot_reg_firms_app_small_f');
            $table->string('tot_reg_firms_app_small');

            $table->string('tot_elig_veri_micro_m');
            $table->string('tot_elig_veri_micro_f');
            $table->string('tot_elig_veri_micro');
            $table->string('tot_elig_veri_small_m');
            $table->string('tot_elig_veri_small_f');
            $table->string('tot_elig_veri_small');

            $table->string('tot_sel_firms');
            $table->string('tot_sel_veri_micro_m');
            $table->string('tot_sel_veri_micro_f');
            $table->string('tot_sel_veri_micro');
            $table->string('tot_sel_veri_small_m');
            $table->string('tot_sel_veri_small_f');
            $table->string('tot_sel_veri_small');

            $table->string('tot_firms_rcvg');
            $table->string('tot_firms_rcvg_micro_m');
            $table->string('tot_firms_rcvg_micro_f');
            $table->string('tot_firms_rcvg_micro');
            $table->string('tot_firms_rcvg_small_m');
            $table->string('tot_firms_rcvg_small_f');
            $table->string('tot_firms_rcvg_small');

            $table->string('tot_firms_solar');
            $table->string('tot_firms_solar_micro_m');
            $table->string('tot_firms_solar_micro_f');
            $table->string('tot_firms_solar_micro');
            $table->string('tot_firms_solar_small_m');
            $table->string('tot_firms_solar_small_f');
            $table->string('tot_firms_solar_small');

            $table->string('amt_dis');
            $table->string('amt_dis_micro_m');
            $table->string('amt_dis_micro_f');
            $table->string('amt_dis_micro');
            $table->string('amt_dis_small_m');
            $table->string('amt_dis_small_f');
            $table->string('amt_dis_small');

            $table->string('state_id');
            $table->string('monthyear');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('dli10_dp_report');
    }
}
