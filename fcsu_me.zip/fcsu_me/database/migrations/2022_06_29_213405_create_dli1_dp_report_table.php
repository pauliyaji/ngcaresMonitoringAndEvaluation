<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateDli1DpReportTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('dli1_dp_report', function (Blueprint $table) {
            $table->id();
            $table->string('tot_bene_mined_f');
            $table->string('tot_bene_mined_m');
            $table->string('tot_bene_mined');

            $table->string('tot_bene_mined_dis_aged');
            $table->string('tot_bene_mined_dis_chro');
            $table->string('tot_bene_mined_dis_urban');
            $table->string('tot_bene_mined_dis_spn');
            $table->string('tot_bene_mined_dis_others')->nullable();
            $table->string('tot_bene_validated_f');
            $table->string('tot_bene_validated_m');
            $table->string('tot_bene_validated');

            $table->string('tot_bene_mined_dis_aged_f');
            $table->string('tot_bene_mined_dis_aged_m');
            $table->string('tot_bene_mined_dis_chro_f');
            $table->string('tot_bene_mined_dis_chro_m');
            $table->string('tot_bene_mined_dis_urban_f');
            $table->string('tot_bene_mined_dis_urban_m');
            $table->string('tot_bene_mined_dis_spn_f');
            $table->string('tot_bene_mined_dis_spn_m');
            $table->string('amt_trans_psp');

            $table->string('tot_bene_trans_psp_f');
            $table->string('tot_bene_trans_psp_m');
            $table->string('tot_bene_trans_psp');

            $table->string('tot_bene_trans_psp_aged_f');
            $table->string('tot_bene_trans_psp_aged_m');
            $table->string('tot_bene_trans_psp_chro_f');
            $table->string('tot_bene_trans_psp_chro_m');
            $table->string('tot_bene_trans_psp_urban_f');
            $table->string('tot_bene_trans_psp_urban_m');
            $table->string('tot_bene_trans_psp_spn_f');
            $table->string('tot_bene_trans_psp_spn_m');
            $table->string('tot_bene_trans_psp_others')->nullable();
            $table->string('tot_bene_trans_psp_total');

            $table->string('tot_bene_paid');
            $table->string('tot_bene_paid_f');
            $table->string('tot_bene_paid_m');

            $table->string('state_id');
            $table->string('monthyear');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('dli1_dp_report');
    }
}
