<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateDli1sTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('dli1s', function (Blueprint $table) {
            $table->id();
            $table->string('f_mined');
            $table->String('m_mined');
            $table->String('tot_mined');
            $table->String('aged_mined');
            $table->String('chro_mined');
            $table->String('urban_mined');
            $table->String('needs_mined');
            $table->String('f_validated');
            $table->String('m_validated');
            $table->String('tot_validated');
            $table->String('att_fmined');
            $table->String('att_mmined');
            $table->String('att_totmined');
            $table->String('att_minedpercent');
            $table->String('fenrolled');
            $table->String('menrolled');
            $table->String('tot_enrolled');
            $table->String('aged_fenrolled');
            $table->String('aged_menrolled');
            $table->String('chro_fenrolled');
            $table->String('chro_menrolled');
            $table->String('urban_fenrolled');
            $table->String('urban_menrolled');
            $table->String('needs_fenrolled');
            $table->String('needs_menrolled');
            $table->String('att_perenrolled');

            $table->String('att_fval_enr');
            $table->String('att_mval_enr');
            $table->String('att_totval_enr');
            $table->String('amt_transpsp');
            $table->String('tot_fbeneforpsppay');
            $table->String('tot_mbeneforpsppay');
            $table->String('tot_beneforpsppay');
            $table->String('tot_agedfbeneforpsppay');
            $table->String('tot_agedmbeneforpsppay');
            $table->String('tot_chrofbeneforpsppay');
            $table->String('tot_chrombeneforpsppay');
            $table->String('tot_urbanfbeneforpsppay');
            $table->String('tot_urbanmbeneforpsppay');
            $table->String('tot_needsfbeneforpsppay');
            $table->String('tot_needsmbeneforpsppay');
            $table->String('tot_numbenepaid');
            $table->String('attrition_ntpaid');
            $table->string('attrition_ntpaid_percent');

            $table->String('dli_id');
            $table->String('state_id');
            $table->String('user_id');
            $table->String('status_id');
            $table->String('dp_id');
            $table->String('comment1')->nullable();
            $table->String('comment2')->nullable();
            $table->String('comment3')->nullable();
            $table->String('comment4')->nullable();
            $table->string('monthyear');
            $table->string('previous')->nullable();
            $table->string('current')->nullable();
            $table->string('total')->nullable();

            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('socialtransfers');
    }
}
