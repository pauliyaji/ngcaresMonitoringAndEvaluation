<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateDli4DpReportTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('dli4_dp_report', function (Blueprint $table) {
            $table->id();
            $table->string('bs_tot_com_grp_sen_pov_lga');
            $table->string('bs_tot_eoi_com_grp_sen_pov');
            $table->string('bs_tot_cdp');
            $table->string('bs_no_cpmc_trained');
            $table->string('bs_no_com_with_func_cdps');
            $table->string('bs_tot_app_cdps_for_funding');
            $table->string('bs_tot_cdp_com_edu');
            $table->string('bs_tot_cdp_com_health');
            $table->string('bs_tot_cdp_com_nut');
            $table->string('bs_tot_cdp_com_water');
            $table->string('bs_tot_cdp_com');

            $table->string('bs_tot_cdp_fun_edu');
            $table->string('bs_tot_cdp_fun_health');
            $table->string('bs_tot_cdp_fun_nut');
            $table->string('bs_tot_cdp_fun_water');
            $table->string('bs_tot_cdp_fun');

            $table->string('bs_tot_mps_com_edu');
            $table->string('bs_tot_mps_com_health');
            $table->string('bs_tot_mps_com_nut');
            $table->string('bs_tot_mps_com_water');
            $table->string('bs_tot_mps_com');

            $table->string('bs_tot_dir_bene_com_fun_mps_f');
            $table->string('bs_tot_dir_bene_com_fun_mps_m');
            $table->string('bs_tot_dir_bene_com_fun_mps');

            $table->string('bs_tot_grdps_sub_grp');
            $table->string('bs_tot_gpmc_trained');
            $table->string('bs_tot_no_comm_com_fun_grdps');
            $table->string('bs_tot_app_grdp_funding');

            $table->string('bs_tot_grdps_fun_edu');
            $table->string('bs_tot_grdps_fun_health');
            $table->string('bs_tot_grdps_fun_nut');
            $table->string('bs_tot_grdps_fun_water');
            $table->string('bs_tot_grdps_fun');

            $table->string('bs_tot_gmps_in_app_grdps_edu');
            $table->string('bs_tot_gmps_in_app_grdps_health');
            $table->string('bs_tot_gmps_in_app_grdps_nut');
            $table->string('bs_tot_gmps_in_app_grdps_water');
            $table->string('bs_tot_gmps_in_app_grdps');

            $table->string('bs_tot_gmps_com_with_env_edu');
            $table->string('bs_tot_gmps_com_with_env_health');
            $table->string('bs_tot_gmps_com_with_env_nut');
            $table->string('bs_tot_gmps_com_with_env_water');
            $table->string('bs_tot_gmps_com_with_env');

            $table->string('bs_dir_bene_com_fun_gmps_f');
            $table->string('bs_dir_bene_com_fun_gmps_m');
            $table->string('bs_dir_bene_com_fun_gmps');
            $table->string('state_id');
            $table->string('monthyear');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('dli4_dp_report');
    }
}
