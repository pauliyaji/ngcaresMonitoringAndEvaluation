<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateDli9DpReportTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('dli9_dp_report', function (Blueprint $table) {
            $table->id();

            $table->string('tot_reg_firms');
            $table->string('tot_reg_firms_micro_m');
            $table->string('tot_reg_firms_micro_f');
            $table->string('tot_reg_firms_micro');

            $table->string('tot_reg_firms_small_m');
            $table->string('tot_reg_firms_small_f');
            $table->string('tot_reg_firms_small');

            $table->string('tot_elig_firms');
            $table->string('tot_elig_firms_micro_m');
            $table->string('tot_elig_firms_micro_f');
            $table->string('tot_elig_firms_micro');

            $table->string('tot_elig_firms_small_m');
            $table->string('tot_elig_firms_small_f');
            $table->string('tot_elig_firms_small');

            $table->string('tot_sel_firms');
            $table->string('tot_sel_firms_micro_m');
            $table->string('tot_sel_firms_micro_f');
            $table->string('tot_sel_firms_micro');

            $table->string('tot_sel_firms_small_m');
            $table->string('tot_sel_firms_small_f');
            $table->string('tot_sel_firms_small');

            $table->string('tot_veri_len_inst');
            $table->string('tot_firms_veri');
            $table->string('tot_firms_micro_m');
            $table->string('tot_firms_micro_f');
            $table->string('tot_firms_micro');

            $table->string('tot_firms_small_m');
            $table->string('tot_firms_small_f');
            $table->string('tot_firms_small');

            $table->string('tot_firms_rcving');
            $table->string('tot_firms_rcving_micro_m');
            $table->string('tot_firms_rcving_micro_f');
            $table->string('tot_firms_rcving_micro');
            $table->string('tot_firms_rcving_small_m');
            $table->string('tot_firms_rcving_small_f');
            $table->string('tot_firms_rcving_small');

            $table->string('amt_dis_to_len');
            $table->string('tot_dis_to_len_micro_m');
            $table->string('tot_dis_to_len_micro_f');
            $table->string('tot_dis_to_len_micro');
            $table->string('tot_dis_to_len_small_m');
            $table->string('tot_dis_to_len_small_f');
            $table->string('tot_dis_to_len_small');

            $table->string('state_id');
            $table->string('monthyear');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('dli9_dp_report');
    }
}
