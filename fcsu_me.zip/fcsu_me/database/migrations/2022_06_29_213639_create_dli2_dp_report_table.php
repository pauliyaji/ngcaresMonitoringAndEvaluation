<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateDli2DpReportTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('dli2_dp_report', function (Blueprint $table) {
            $table->id();
            $table->string('lipw_tot_bene_mined_f');
            $table->string('lipw_tot_bene_mined_m');
            $table->string('lipw_tot_bene_mined');

            $table->string('lipw_tot_bene_mined_validated_f');
            $table->string('lipw_tot_bene_mined_validated_m');
            $table->string('lipw_tot_bene_mined_validated');

            $table->string('lipw_tot_enrolled_f');
            $table->string('lipw_tot_enrolled_m');
            $table->string('lipw_tot_enrolled');

            $table->string('lipw_tot_deployed_f');
            $table->string('lipw_tot_deployed_m');
            $table->string('lipw_tot_deployed');

            $table->string('lipw_no_working_days');
            $table->string('lipw_tot_amt_trans_psp');

            $table->string('lipw_tot_bene_trans_f');
            $table->string('lipw_tot_bene_trans_m');
            $table->string('lipw_tot_bene_trans');

            $table->string('lipw_tot_bene_paid_f');
            $table->string('lipw_tot_bene_paid_m');
            $table->string('lipw_tot_bene_paid');

            //lipws ends here

            $table->string('state_id');
            $table->string('monthyear');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('dli2_dp_report');
    }
}
