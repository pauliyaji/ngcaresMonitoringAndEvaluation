<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateDli10sTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('dli10s', function (Blueprint $table) {
            $table->id();

            $table->string('tot_reg_ops');
            $table->string('tot_reg_opsmmicro');
            $table->string('tot_reg_opsfmicro');
            $table->string('tot_reg_opsmicro');
            $table->string('tot_reg_opsmsmall');
            $table->string('tot_reg_opsfsmall');
            $table->string('tot_reg_opssmall');
            $table->string('tot_eli_ver');
            $table->string('tot_eli_vermmicro');
            $table->string('tot_eli_verfmicro');
            $table->string('tot_eli_vermicro');
            $table->string('tot_eli_vermsmall');
            $table->string('tot_eli_verfsmall');
            $table->string('tot_eli_versmall');
            $table->string('att_reg_minus_ver');
            $table->string('tot_sel_ops');
            $table->string('tot_sel_opsmmicro');
            $table->string('tot_sel_opsfmicro');
            $table->string('tot_sel_opsmicro');
            $table->string('tot_sel_opsmsmall');
            $table->string('tot_sel_opsfsmall');
            $table->string('tot_sel_opssmall');
            $table->string('tot_ver_minus_sel')->nullable();
            $table->string('tot_rec_ops');
            $table->string('tot_rec_opsmmicro');
            $table->string('tot_rec_opsfmicro');
            $table->string('tot_rec_opsmicro');
            $table->string('tot_rec_opsmsmall');
            $table->string('tot_rec_opsfsmall');
            $table->string('tot_rec_opssmall');
            $table->string('att_ver_minus_sel');
            $table->string('att_sel_minus_rec');
            $table->string('tot_sol_rec');
            $table->string('tot_sol_recmmicro');
            $table->string('tot_sol_recfmicro');
            $table->string('tot_sol_recmicro');
            $table->string('tot_sol_recmsmall');
            $table->string('tot_sol_recfsmall');
            $table->string('tot_sol_recsmall');
            $table->string('att_sel_minus_solrec')->nullable();
            $table->string('att_rec_minus_solrec');
            $table->string('tot_amt_dis');
            $table->string('tot_amt_dismmicro');
            $table->string('tot_amt_disfmicro');
            $table->string('tot_amt_dismicro');
            $table->string('tot_amt_dismsmall');
            $table->string('tot_amt_disfsmall');
            $table->string('tot_amt_dissmall');

            $table->string('dli_id');
            $table->string('state_id');
            $table->string('status_id');
            $table->string('user_id');
            $table->string('dp_id');
            $table->string('monthyear');


            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('operations_grant');
    }
}
