<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateDli6DpReportTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('dli6_dp_report', function (Blueprint $table) {
            $table->id();
            $table->string('tot_fcas_sen_mob');
            $table->string('tot_num_carp_prep');
            $table->string('tot_num_carp_app');
            $table->string('tot_agric_inf_with_ag_lipw');
            $table->string('tot_f_applied_for_agric_infra_f');
            $table->string('tot_f_applied_for_agric_infra_m');
            $table->string('tot_f_applied_for_agric_infra');
            $table->string('tot_f_recvd_for_agric_infra_f');
            $table->string('tot_f_recvd_for_agric_infra_m');
            $table->string('tot_f_recvd_for_agric_infra');
            $table->string('tot_f_accessing_agric_infra_f');
            $table->string('tot_f_accessing_agric_infra_m');
            $table->string('tot_f_accessing_agric_infra');
            $table->string('tot_agric_infr_comp');
            $table->string('tot_comp_agric_infr_paid');
            $table->string('state_id');
            $table->string('monthyear');

            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('dli6_dp_report');
    }
}
