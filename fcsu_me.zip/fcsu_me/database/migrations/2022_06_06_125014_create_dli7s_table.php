<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateDli7sTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('dli7s', function (Blueprint $table) {
            $table->id();
            $table->string('tot_microfcasense');
            $table->string('tot_smallfcasense');
            $table->string('tot_fcasense');
            $table->string('tot_carp_prep');
            $table->string('tot_carp_approv');
            $table->string('att_prep_approv');
            $table->string('pcent_att_prep_approv');
            $table->string('tot_ffar_app_assets');
            $table->string('tot_mfar_app_assets');
            $table->string('tot_far_app_assets');
            $table->string('tot_ffar_rec_assets');
            $table->string('tot_mfar_rec_assets');
            $table->string('tot_far_rec_assets');
            $table->string('att_far_app_rec');
            $table->string('pcent_att_far_app_rec');
            $table->string('tot_ffar_util_assets');
            $table->string('tot_mfar_util_assets');
            $table->string('tot_far_util_assets');
            $table->string('att_rec_util_assets');
            $table->string('pcent_att_rec_util_assets');

            $table->string('dli_id');
            $table->string('state_id');
            $table->string('status_id');
            $table->string('user_id');
            $table->string('dp_id');
            $table->string('monthyear');


            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('agric_assets');
    }
}
