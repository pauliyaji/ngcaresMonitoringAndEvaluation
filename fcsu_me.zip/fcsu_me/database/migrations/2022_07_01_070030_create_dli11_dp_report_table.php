<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateDli11DpReportTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('dli11_dp_report', function (Blueprint $table) {
            $table->id();
            $table->string('tot_reg_firms');
            $table->string('tot_reg_firms_micro_m');
            $table->string('tot_reg_firms_micro_f');
            $table->string('tot_reg_firms_micro');
            $table->string('tot_reg_firms_small_m');
            $table->string('tot_reg_firms_small_f');
            $table->string('tot_reg_firms_small');

            $table->string('tot_elig_veri');
            $table->string('tot_elig_veri_micro_m');
            $table->string('tot_elig_veri_micro_f');
            $table->string('tot_elig_veri_micro');
            $table->string('tot_elig_veri_small_m');
            $table->string('tot_elig_veri_small_f');
            $table->string('tot_elig_veri_small');

            $table->string('tot_sel_firms');
            $table->string('tot_sel_firms_micro_m');
            $table->string('tot_sel_firms_micro_f');
            $table->string('tot_sel_firms_micro');
            $table->string('tot_sel_firms_small_m');
            $table->string('tot_sel_firms_small_f');
            $table->string('tot_sel_firms_small');

            $table->string('tot_it_provi');

            $table->string('tot_con_rcpt');
            $table->string('tot_con_rcpt_micro_m');
            $table->string('tot_con_rcpt_micro_f');
            $table->string('tot_con_rcpt_micro');
            $table->string('tot_con_rcpt_small_m');
            $table->string('tot_con_rcpt_small_f');
            $table->string('tot_con_rcpt_small');

            $table->string('tot_tech_sup');
            $table->string('tot_tech_sup_micro_m');
            $table->string('tot_tech_sup_micro_f');
            $table->string('tot_tech_sup_micro');
            $table->string('tot_tech_sup_small_m');
            $table->string('tot_tech_sup_small_f');
            $table->string('tot_tech_sup_small');

            $table->string('tot_firms_rcvg');
            $table->string('tot_firms_rcvg_micro_m');
            $table->string('tot_firms_rcvg_micro_f');
            $table->string('tot_firms_rcvg_micro');
            $table->string('tot_firms_rcvg_small_m');
            $table->string('tot_firms_rcvg_small_f');
            $table->string('tot_firms_rcvg_small');

            $table->string('amt_dis');
            $table->string('amt_dis_micro_m');
            $table->string('amt_dis_micro_f');
            $table->string('amt_dis_micro');
            $table->string('amt_dis_small_m');
            $table->string('amt_dis_small_f');
            $table->string('amt_dis_small');

            $table->string('state_id');
            $table->string('monthyear');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('dli11_dp_report');
    }
}
