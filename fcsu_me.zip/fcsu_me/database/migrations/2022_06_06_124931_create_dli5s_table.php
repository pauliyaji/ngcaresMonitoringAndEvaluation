<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateDli5sTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('dli5s', function (Blueprint $table) {
            $table->id();
            $table->string('tot_microfcasense');
            $table->string('tot_fcasmall');
            $table->string('tot_fca');
            $table->string('tot_carpprep');
            $table->string('tot_carpappr');
            //$table->string('att_prep_minus_approvcarp');
            $table->string('tot_ff_appl_input');
            $table->string('tot_mf_appl_input');

            $table->string('tot_farmers_appl_input');
            $table->string('tot_ff_recv_input');
            $table->string('tot_mf_recv_input');
            $table->string('tot_farmers_recv_input');
          //  $table->string('att_fappl_recv_input');
          //  $table->string('att_mappl_recv_input');
          //  $table->string('att_appl_recv_input');

          //  $table->string('comment2');
            $table->string('tot_ffutil_agric_input');
            $table->string('tot_mfutil_agric_input');
            $table->string('tot_futil_agric_input');
          //  $table->string('att_futil_agric_input');

            //$table->string('comment3');

            $table->string('tot_ff_appl_agserv');
            $table->string('tot_mf_appl_agserv');
            $table->string('tot_fappl_agserv');
            $table->string('tot_ff_recv_agserv');
            $table->string('tot_mf_recv_agserv');
            $table->string('tot_frecv_agserv');
           // $table->string('att_ffappl_recv_agserv');
           // $table->string('att_mfappl_recv_agserv');
           // $table->string('att_appl_recv_agserv');
           // $table->string('attpcent_fappl_recv_agserv');

         //   $table->string('comment4');

            $table->string('tot_ffutil_agserv');
            $table->string('tot_mfutil_agserv');
            $table->string('tot_futil_agserv');
            //$table->string('att_futil_agserv');
           // $table->string('comment5');
            $table->string('tot_ffappl_css');
            $table->string('tot_mfappl_css');
            $table->string('tot_fappl_css');
            $table->string('tot_ffrecv_css');
            $table->string('tot_mfrecv_css');
            $table->string('tot_frecv_css');
           // $table->string('att_ffappl_recv_css');
           // $table->string('att_mfappl_recv_css');
           // $table->string('att_fappl_recv_css');
            //$table->string('attpcent_fappl_recv_css');
           // $table->string('comment6');

            $table->string('tot_ffutil_css');
            $table->string('tot_mfutil_css');
            $table->string('tot_futil_css');
            //$table->string('att_futil_recv_css');
           // $table->string('att_mfutil_recv_css');
           // $table->string('atttot_futil_recv_css');
            //$table->string('attpcent_futil_recv_css');
          //  $table->string('comment7');

            $table->string('totcrops_qtyrecv');
            $table->string('totcrops_qtyrecv_fert');
            $table->string('totcrops_qtyrecv_seeds');
            $table->string('totcrops_qtyrecv_agro');
            $table->string('tot_crops_qtyrecv_insec');
            $table->string('tot_crops_qtyrecv_herbs');
            $table->string('tot_crops_qtyrecv_pest');

            $table->string('totlives_qtyrecv');

            $table->string('totlives_qtyrecv_catfeed');
            $table->string('totlives_qtyrecv_catdrugs');
            $table->string('totlives_qtyrecv_catvac');
            $table->string('totlives_qtyrecv_catdis');
            $table->string('totlives_qtyrecv_poul');
            $table->string('totlives_qtyrecv_poulfeed');
            $table->string('totlives_qtyrecv_pouldrugs');
            $table->string('totlives_qtyrecv_poulvac');
            $table->string('totlives_qtyrecv_pouldis');
            $table->string('totlives_qtyrecv_fish');
            $table->string('totlives_qtyrecv_fishfeed');
            $table->string('totlives_qtyrecv_fishdrugs');
            $table->string('totlives_qtyrecv_fishvac');
            $table->string('totlives_qtyrecv_fishdis');
            $table->string('totlives_qtyrecv_others');
            $table->string('tot_ffarmersrecadv');
            $table->string('tot_mfarmersrecadv');

            $table->string('dli_id');
            $table->string('state_id');
            $table->string('status_id');
            $table->string('user_id');
            $table->string('dp_id');
            $table->string('monthyear');

            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('agric_infrastructure');
    }
}
