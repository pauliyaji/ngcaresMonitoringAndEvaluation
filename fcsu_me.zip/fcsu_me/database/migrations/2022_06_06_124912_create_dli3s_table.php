<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateDli3sTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('dli3s', function (Blueprint $table) {
            $table->id();
            $table->string('f_mined');
            $table->string('m_mined');
            $table->string('tot_mined');
            $table->string('f_validated');
            $table->string('m_validated');
            $table->string('tot_validated');
            $table->string('att_fminedval');
            $table->string('att_mminedval');
            $table->string('att_totminedval');
            $table->string('att_minedvalpercent');
            $table->string('comment1')->nullable();
            $table->string('f_train');
            $table->string('m_train');
            $table->string('tot_train');
            $table->string('f_grad');
            $table->string('m_grad');
            $table->string('tot_grad');
            $table->string('att_ftraingrad');
            $table->string('att_mtraingrad');
            $table->string('att_tottraingrad');
            $table->string('att_traingradpercent');
            $table->string('comment2')->nullable();
            $table->string('amt_transpsp');
            $table->string('tot_fbeneforpsppay');
            $table->string('tot_mbeneforpsppay');
            $table->string('tot_beneforpsppay');
            $table->string('tot_fbenerecv');
            $table->string('tot_mbenerecv');
            $table->string('tot_benerecv');
            $table->string('tot_paidbene');
            $table->string('attr');
            $table->string('attr_pcent');
            $table->string('comment3')->nullable();

            $table->string('dli_id');
            $table->string('state_id');
            $table->string('user_id');
            $table->string('status_id');
            $table->string('dp_id');
            $table->string('monthyear');

            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('livelihoods');
    }
}
