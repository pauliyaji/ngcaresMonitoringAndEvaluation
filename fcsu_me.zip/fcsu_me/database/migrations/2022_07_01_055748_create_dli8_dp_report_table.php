<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateDli8DpReportTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('dli8_dp_report', function (Blueprint $table) {
            $table->id();
            $table->string('tot_fcas_sen_mob');
            $table->string('tot_carp_prep');
            $table->string('tot_carp_app');
            $table->string('tot_wet_mark_with_san');
            $table->string('tot_sellers_bene_f');
            $table->string('tot_sellers_bene_m');
            $table->string('tot_sellers_bene');

            $table->string('state_id');
            $table->string('monthyear');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('dli8_dp_report');
    }
}
