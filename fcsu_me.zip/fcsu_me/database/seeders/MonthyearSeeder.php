<?php

namespace Database\Seeders;

use App\Models\Monthyear;
use Illuminate\Database\Seeder;

class MonthyearSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        Monthyear::create([
            'date' => 'Jan 2020',
        ]);
        Monthyear::create([
            'date' => 'Feb 2020',
        ]);
        Monthyear::create([
            'date' => 'Mar 2020',
        ]);
        Monthyear::create([
            'date' => 'Apr 2020',
        ]);
        Monthyear::create([
            'date' => 'May 2020',
        ]);
        Monthyear::create([
            'date' => 'Jun 2020',
        ]);
        Monthyear::create([
            'date' => 'July 2020',
        ]);
        Monthyear::create([
            'date' => 'Aug 2020',
        ]);
        Monthyear::create([
            'date' => 'Sep 2020',
        ]);
        Monthyear::create([
            'date' => 'Oct 2020',
        ]);
        Monthyear::create([
            'date' => 'Nov 2020',
        ]);
        Monthyear::create([
            'date' => 'Dec 2020',
        ]);
        Monthyear::create([
            'date' => 'Jan 2021',
        ]);
        Monthyear::create([
            'date' => 'Feb 2021',
        ]);
        Monthyear::create([
            'date' => 'Mar 2021',
        ]);
        Monthyear::create([
            'date' => 'Apr 2021',
        ]);
        Monthyear::create([
            'date' => 'May 2021',
        ]);
        Monthyear::create([
            'date' => 'Jun 2021',
        ]);
        Monthyear::create([
            'date' => 'Jul 2021',
        ]);
        Monthyear::create([
            'date' => 'Aug 2021',
        ]);
        Monthyear::create([
            'date' => 'Sep 2021',
        ]);
        Monthyear::create([
            'date' => 'Oct 2021',
        ]);
        Monthyear::create([
            'date' => 'Nov 2021',
        ]);
        Monthyear::create([
            'date' => 'Dec 2021',
        ]);
        Monthyear::create([
            'date' => 'Jan 2022',
        ]);
        Monthyear::create([
            'date' => 'Feb 2022',
        ]);
        Monthyear::create([
            'date' => 'Mar 2022',
        ]);
        Monthyear::create([
            'date' => 'Apr 2022',
        ]);
        Monthyear::create([
            'date' => 'May 2022',
        ]);
        Monthyear::create([
            'date' => 'Jun 2022',
        ]);
        Monthyear::create([
            'date' => 'Jul 2022',
        ]);
        Monthyear::create([
            'date' => 'Aug 2022',
        ]);
        Monthyear::create([
            'date' => 'Sep 2022',
        ]);
        Monthyear::create([
            'date' => 'Oct 2022',
        ]);
        Monthyear::create([
            'date' => 'Nov 2022',
        ]);
        Monthyear::create([
            'date' => 'Dec 2022',
        ]);
        Monthyear::create([
            'date' => 'Jan 2023',
        ]);
        Monthyear::create([
            'date' => 'Feb 2023',
        ]);
        Monthyear::create([
            'date' => 'Mar 2023',
        ]);
        Monthyear::create([
            'date' => 'Apr 2023',
        ]);
        Monthyear::create([
            'date' => 'May 2023',
        ]);
        Monthyear::create([
            'date' => 'Jun 2023',
        ]);
        Monthyear::create([
            'date' => 'Jul 2023',
        ]);
        Monthyear::create([
            'date' => 'Aug 2023',
        ]);
        Monthyear::create([
            'date' => 'Sep 2023',
        ]);
        Monthyear::create([
            'date' => 'Oct 2023',
        ]);
        Monthyear::create([
            'date' => 'Nov 2023',
        ]);
        Monthyear::create([
            'date' => 'Dec 2023',
        ]);
    }
}
